import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { HttpUtilsService } from "../../_base/crud";
import { environment } from "../../../../environments/environment.base";

@Injectable()
export class TaxCalculationService {
	loginEmployee: any;
	constructor(private http: HttpClient, private httpUtils: HttpUtilsService) {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
	}
	getTaxes(limit, offset): Observable<any> {
		return this.http.get(
			environment.vehicleInfoService +
				"/taxcalculations/all?orgId=" +
				this.loginEmployee.orgId +
				"&limit=" +
				limit +
				"&offset=" +
				offset
		);
	}

	deleteTax(id): any {
		return this.http.delete(
			environment.vehicleInfoService + "/taxcalculations/delete?taxId=" + id
		);
	}

	updateTax(data): Observable<any> {
		return this.http.put(
			`${environment.vehicleInfoService}/taxcalculations/update`,
			data
		);
	}

	createTax(data): Observable<any> {
		return this.http.post(`${environment.vehicleInfoService}/taxcalculations/add`, data);
	}
}
