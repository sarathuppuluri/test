import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment.base';

@Injectable()
export class InsuranceService {
	loginEmployee: any;
	constructor(private http: HttpClient) {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
	}

	getAllInsurance(): Observable<any> {
		return this.http.get(environment.ops + '/all', {
			headers: this.getHeaders(),
		});
	}

	getHeaders() {
		let headers = new HttpHeaders();
		headers = headers.append("orgid", this.loginEmployee.orgId);
		return headers;
	}

	deleteInsurance(id) {
		return this.http.delete(
			environment.ops + '/delete/id/' + id
		);
	}

	updateInsurance(data) {
		return this.http.post(
			environment.ops + '/update',
			data,
			{
				headers: this.getHeaders(),
			}
		);
	}

	createInsurance(data) {
		return this.http.post(environment.ops + '/add', data, {
			headers: this.getHeaders(),
		});
	}

	getInsuranceByLeadId(id): Observable<any> {
		return this.http.get(
			environment.ops + '/getbyId?id=' + id,
			{ headers: this.getHeaders() }
		);
	}

	getInsuranceById(id): Observable<any> {
		return this.http.get(
			environment.ops + "/getbyId?id=" + id,
			{ headers: this.getHeaders() }
		);
	}

	createContact(data) {
		return this.http.post(
			environment.sales + "/contact?allocateDse=false",
			data
		);
	}
}
