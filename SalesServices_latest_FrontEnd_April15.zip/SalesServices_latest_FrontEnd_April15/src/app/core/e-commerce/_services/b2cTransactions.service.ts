import { Injectable } from "@angular/core";
import { HttpUtilsService, QueryParamsModel } from "../../_base/crud";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable, of } from "rxjs";
import { environment } from "../../../../environments/environment.base";

// B2C APIs
const API_VEHICLES_URL = `${environment.vehicleInfoService}`;
const API_SERVICES_URL = `${environment.vehicleServices}`;
const API_TESTDRIVE_URL = `${environment.ops}/dms-testdrive`;

@Injectable()
export class B2CTransactionsService {
	constructor(
		private http: HttpClient,
		private httpUtils: HttpUtilsService
	) {}

	// To Get All New Car Bookings
	getNewCarBookings(
		orgId,
		branchId,
		queryParams: QueryParamsModel
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${API_VEHICLES_URL}/carBooking`
		);
	}

	// To Get All Used Car Bookings
	getUsedCarBookings(
		orgId,
		branchId,
		queryParams: QueryParamsModel
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${API_VEHICLES_URL}/api/oldVehicleBooking/details?orgId=${orgId}&branch=${branchId}&offset=${httpParams.get(
				"startindex"
			)}&limit=${httpParams.get("endindex")}`
		);
	}

	// TO get All Accessories Records
	getAccessories(
		orgId,
		branchId,
		queryParams: QueryParamsModel
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${API_VEHICLES_URL}/vehicle/accessoriesBooking?orgId=${orgId}&branch=${branchId}&offset=${httpParams.get(
				"startindex"
			)}&limit=${httpParams.get("endindex")}`
		);
	}

	// To Get All Services Records
	getServices(branchId, queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${API_SERVICES_URL}/api/tenant/${branchId}/appointment?page=${httpParams.get(
				"startindex"
			)}&size=${httpParams.get("endindex")}`
		);
	}

	// To Get ALL Test Drive Records
	getTestDrive(
		orgId,
		branchId,
		queryParams: QueryParamsModel
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${environment.ops}/testdrive/history?branch=${branchId}&limit=${httpParams.get(
				"endindex"
			)}&offset=${httpParams.get("startindex")}&orgId=${orgId}&source=APP`
		);
	}

	// To Get All New Car Finance Records
	getNewCarFinance(orgId, queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.ops
			}/api/allnewcarfinance?orgId=${orgId}&limit=${httpParams.get(
				"endindex"
			)}&offSet=${httpParams.get("startindex")}`
		);
	}

	// To Get All Old Car Finance Records
	getOldCarFinance(orgId,branchId, queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.ops
			}/api/alloldcarfinance?orgId=${orgId}&branchId=${branchId}&limit=${httpParams.get(
				"endindex"
			)}&offSet=${httpParams.get("startindex")}`
		);
	}

	// To Get All Insurance Records
	getInsurance(
		orgId,
		queryParams: QueryParamsModel,
		branchId
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.ops
			}/renewinsurance/api/all?branchId=${branchId}&limit=${httpParams.get(
				"endindex"
			)}&offSet=${httpParams.get("startindex")}&orgId=${orgId}`
		);
	}

	// To Get Old Car Evaluations
	getOldCarEvalaution(
		orgId,
		queryParams: QueryParamsModel,
		branchId
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.ops
			}/api/vehicles?orgId=${orgId}&branchId=${branchId}&offset=${httpParams.get(
				"startindex"
			)}&limit=${httpParams.get("endindex")}`
		);
	}

	// To Get All Roadside Assistance
	getRoadSideAssistance(
		orgId,
		queryParams: QueryParamsModel
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.customerService
			}/rsa/customerRsa?limit=${httpParams.get(
				"endindex"
			)}&offSet=${httpParams.get("startindex")}&orgId=${orgId}`
		);
	}
}
