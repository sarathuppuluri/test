import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { HttpUtilsService } from "../../_base/crud";
import { environment } from "../../../../environments/environment.base";

@Injectable()
export class CCEService {
	loginEmployee: any;
	serviceHostUrl = `${environment.vehicleServices}`;
	constructor(private http: HttpClient, private httpUtils: HttpUtilsService) {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
	}

	getCallsBYCategory(tenant, category, page, size): Observable<any> {
		return this.http.get(
			environment.vehicleServices +
				"/api/tenant/" +
				tenant +
				"/followup/category/" +
				category +
				"?page=" +
				page +
				"&size=" +
				size,
			{ headers: this.getHeaders() }
		);
	}

	getCallsBYCategoryWithSearch(
		tenant,
		category,
		page,
		size,
		serviceId,
		fromDate,
		toDate,
		vehicleModel
	): Observable<any> {
		return this.http.get(
			environment.vehicleServices +
				"/api/tenant/" +
				tenant +
				"/followup/category/" +
				category +
				"?page=" +
				page +
				"&size=" +
				size +
				this.formURL(serviceId, fromDate, toDate, vehicleModel),
			{ headers: this.getHeaders() }
		);
	}

	formURL(serviceId, fromDate, toDate, vehicleModel) {
		let url = "";
		if (serviceId) {
			url = "&serviceId=" + serviceId;
			return url;
		}
		if (vehicleModel) {
			url = "&vehicleModel=" + vehicleModel;
			return url;
		}
		if (fromDate || toDate) {
			url = "&fromDate=" + new Date(fromDate).toISOString().split('T')[0] + "&toDate=" + new Date(toDate).toISOString().split('T')[0];
			return url;
		}
	}

	getDashBoardDetails(category, tenant): Observable<any> {
		return this.http.get(
			environment.vehicleServices +
				"/api/tenant/" +
				tenant +
				"/followup/category/" +
				category
		);
	}

	saveFollowup(data, tenant) {
		return this.http.post(
			environment.vehicleServices +
				"/api/tenant/" +
				tenant +
				"/followup",
			data
		);
	}

	updateFollowup(data, tenant) {
		return this.http.put(
			environment.vehicleServices +
				"/api/tenant/" +
				tenant +
				"/followup",
			data,{ headers: this.getHeaders() }
		);
	}

	getMasterData(tenant, type): Observable<any> {
		return this.http.get(
			environment.vehicleServices +
				"/api/tenant/" +
				tenant +
				"/followup/master-data/" +
				type,
			{ headers: this.getHeaders() }
		);
	}

	getHeaders() {
		let headers = new HttpHeaders();
		headers = headers.append("empId", this.loginEmployee.empId);
		return headers;
	}

	updateNotInterestedData(data) {
		return this.http.put(
			environment.vehicleServices +
				"/api/tenant/" +
				this.loginEmployee.branchId +
				"/followup/",
			data,
			{ headers: this.getHeaders() }
		);
	}

	getCallDetailsById(followId, activityID): Observable<any> {
		return this.http.get(
			environment.vehicleServices +
				"/api/tenant/" +
				this.loginEmployee.branchId +
				"/followup/" +
				followId +
				"/activity/" +
				activityID,
			{ headers: this.getHeaders() }
		);
	}

	getStats(): Observable<any> {
		return this.http.get(
			environment.vehicleServices +
				"/api/tenant/" +
				this.loginEmployee.branchId +
				"/followup/stats",
			{ headers: this.getHeaders() }
		);
	}

	getActivityDetails(id): Observable<any> {
		return this.http.get(
			environment.vehicleServices +
				"/api/tenant/" +
				this.loginEmployee.branchId +
				"/followup/" +
				id +
				"/activity",
			{ headers: this.getHeaders() }
		);
	}

	getCustomerInfo(regNumber) {
		const url = `${this.serviceHostUrl}/api/tenant/${this.loginEmployee.branchId}/vehicle/${regNumber}/complete-info`;
		return this.http.get<any>(url);
	}

	getAllAppointments(customerContactNumber) {
		const url = `${this.serviceHostUrl}/api/org/${this.loginEmployee.branchId}/${customerContactNumber}/appointments`;
		return this.http.get<any>(url);
	}

	updateCustomer(customerObj,id) {
		const url = `${this.serviceHostUrl}/api/tenant/${this.loginEmployee.branchId}/customer/${id}`;
		return this.http.put<any>(url, customerObj);
	}
	getServiceTypes() {
		const url = `${this.serviceHostUrl}/api/tenant/${this.loginEmployee.branchId}/service-types`;
		return this.http.get<any>(url);
	}
	getVehicles(): Observable<any> {
		return this.http.get(
			environment.vehicleInfoService +
				"/api/vehicle_details?organizationId=" +
				this.loginEmployee.orgId
		);
	}
	getAllEmployeeInfo() {
		const url = `${this.serviceHostUrl}/api/tenant/${this.loginEmployee.branchId}/employee/all/by-role`;
		return this.http.get<any>(url);
	}
}
