// Angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../_base/crud';
// Models
import { IncentivesModel } from '../_models/incentive.model';
import { environment } from '../../../../environments/environment.base';
import { HttpHeaders } from '@angular/common/http';


@Injectable()
export class IncentivesService {
	constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

	// Get Incentive By Id
	getIncentiveById(orgId, queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(`${environment.roleManagement}/Incentive/details?orgId=${orgId}&offset=${httpParams.get('startindex')}&limit=${httpParams.get('endindex')}`);
	}

	// Get all Incentives
	getIncentivesList(): Observable<any> {
		// const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(`${environment.roleManagement}/dms/incentive-rules/listall`);
	}

	// Delete Incentive
	deleteIncentive(incentiveId): Observable<any> {
		return this.http.delete<any>(`${environment.roleManagement}/dms/incentive-rules/delete?ruleId=${incentiveId}`);
	}

	// Create Incentive
	createIncentive(data): Observable<any> {
		return this.http.post<any>(`${environment.roleManagement}/dms/incentive-rules/create`, data);
	}

	// Update Incentive
	updateIncentive(data): Observable<any> {
		return this.http.put<any>(`${environment.roleManagement}/dms/incentive-rules/update`, data);
	}

	// Search Incentive
	searchIncentive(incentiveType, segment): Observable<any> {
		return this.http.get<any>(`${environment.roleManagement}/dms/incentive-rules/search?incentiveType=${incentiveType}&segment=${segment}`);
	}
}
