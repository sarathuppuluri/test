import { Injectable } from '@angular/core';
import { HttpUtilsService } from '../../_base/crud';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment.base';


const API_PINCODE_URL = `${environment.API_PINCODE_URL}`;

const API_get = `${environment.ops}/evalutionoldcar/getevalutionoldcar`;

const API_getEvalById = `${environment.ops}/evalutionoldcar/getevalutionoldcarbyid`;

const API_save = `${environment.ops}/evalutionoldcar/saveevalutionoldcar`;
const API_FetchVahanDetails = `${environment.ops}/evalutionoldcar/fetchVahanPoratlApi`;
const API_DEL = `${environment.ops}/evalutionoldcar/deleteevalutionoldcar`;
const API_put = `${environment.ops}/evalutionoldcar/updateevalutionoldcar`;
const API_EVA = `${environment.ops}/evalutionoldcar/evalutions`;


const API_CHECKLISTPOST = `${environment.ops}/checkList/saveCheckListData`;
const API_VEHICLE = `${environment.sales}/lead?phone=`;

// const API_MANAGERAPPROVE = `${environment.checkListDomain}/evalutionoldcar/approveEvalutor`;
// const API_MANAGERREJECT = `${environment.checkListDomain}/evalutionoldcar/rejectEvalutor`;

const API_GETCHECK = `${environment.ops}/checkList/fetchCategory/1`;


@Injectable()
export class EvaluatorService {

    constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }
    // mainget
    role;

    mainget(): Observable<any> {
        return this.http.get<any>(API_get);
    }

    // location using pincode
    getLocationUsingPincode(pincode): Observable<any> {
        return this.http.get<any>(API_PINCODE_URL + `/${pincode}`);
    }

    // registration details
    getregistration(registrationNumber): Observable<any> {
        return this.http.get<any>(API_FetchVahanDetails + `/${registrationNumber}`);
    }

    // get eva
    geteva(id, page, pageSize): Observable<any> {
        let headers = new HttpHeaders();
        headers = headers.append('role', 'Evaluator');
        headers = headers.append('empid', id);
        return this.http.get<any>(API_EVA + '?page=0' + page + '&size=' + pageSize, { headers });
    }

    getapprove(id, page, pageSize): Observable<any> {
        let headers = new HttpHeaders();
        headers = headers.append('role', 'Admin Manager');
        headers = headers.append('empid', id);
        return this.http.get<any>(API_EVA + '?page=0' + page + '&size=' + pageSize, { headers });
    }





    vehiclelist(mobileNumber): Observable<any> {
        return this.http.get<any>(API_VEHICLE + `${mobileNumber}`);
    }

    // get form details
    getcarparameters(getcardetails): Observable<any> {
        return this.http.get<any>(API_get + `/${getcardetails}`);
    }

    getevalutionoldcarbyid(id) {
        return this.http.get<any>(`${API_getEvalById}/${id}`);
    }

    // GET CHECK
    getchecklist(): Observable<any> {
        return this.http.get<any>(API_GETCHECK);
    }

    getimage(file) {
        const url = `${environment.sales}/documents`;
        return this.http.post(url, file);
    }

    // delete form details through id
    deldata(del): Observable<any> {
        return this.http.delete<any>(API_DEL + `/${del}`);
    }
    // check list post
    checklistpost(data): Observable<any> {
        return this.http.post(API_CHECKLISTPOST, data);
    }

    saveevalutionoldcardetails(values): Observable<any> {
        return this.http.post<any>(API_save, values);

    }

    editevaluationoldcardetails(registrationNumber, editvalues): Observable<any> {
        return this.http.put<any>(API_put + `/${registrationNumber}`, editvalues);
    }

    SaveACarEvalutionDetails(url, data) {
        return this.http.post(url, data);
    }
}
