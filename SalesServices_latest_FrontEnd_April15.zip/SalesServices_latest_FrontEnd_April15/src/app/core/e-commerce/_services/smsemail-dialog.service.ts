import { Injectable } from '@angular/core';
import { SMSEMAILDialogModel } from '../_models/smsemail-dialog-model';
import { MatDialogRef, MatDialog } from '@angular/material';
import { SMSEMAILDialogComponent } from '../../../views/pages/apps/e-commerce/sms-email-dialog/sms-email-dialog.component';
import { SMSEMAILEnums } from '../_consts/smsemail-dialog-enums';

@Injectable({
  providedIn: 'root'
})
export class SMSEMAILDialogService {

  private dialogData: SMSEMAILDialogModel;
  private dialogRef: MatDialogRef<SMSEMAILDialogComponent>;

  constructor(
    private dialog: MatDialog,
  ) { }

  /**
   * Expects an INPUT to be present
   */
  prompt(data: SMSEMAILDialogModel) {
    this.dialogData = data;
    this.dialogData.dialogType = SMSEMAILEnums.pcDialogType.PROMPT;
    return this.openDialog();
  }

  alert(data: SMSEMAILDialogModel) {
    this.dialogData = data;
    this.dialogData.dialogType = SMSEMAILEnums.pcDialogType.ALERT;
    return this.openDialog();
  }

  confirm(data: SMSEMAILDialogModel) {
    this.dialogData = data;
    this.dialogData.dialogType = SMSEMAILEnums.pcDialogType.CONFIRM;
    return this.openDialog();
  }

  dropdown(data: SMSEMAILDialogModel) {
    this.dialogData = data;
    this.dialogData.dialogType = SMSEMAILEnums.pcDialogType.DROP_DOWN;
    return this.openDialog();
  }

  email(data: SMSEMAILDialogModel) {
    this.dialogData = data;
    this.dialogData.dialogType = SMSEMAILEnums.pcDialogType.EMAIL;
    return this.openDialog();
  }

  sms(data: SMSEMAILDialogModel) {
    this.dialogData = data;
    this.dialogData.dialogType = SMSEMAILEnums.pcDialogType.SMS;
    return this.openDialog();
  }


  private openDialog() {
    if (this.dialogRef) {
      this.dialogRef.close();
    }
    this.dialogRef = this.dialog.open(SMSEMAILDialogComponent, {
      width: '30em',
      data: this.dialogData,
      closeOnNavigation: true,
      disableClose: this.dialogData.disableClose
    });
    this.dialogRef.afterClosed().subscribe(res => { });
    return this.dialogRef;
  }
}
