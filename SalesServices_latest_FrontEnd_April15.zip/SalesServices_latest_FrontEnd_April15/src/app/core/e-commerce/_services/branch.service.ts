// Angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../_base/crud';
// Models
import { BranchModel } from '../_models/branch.model';
import { environment } from '../../../../environments/environment.base';
import { HttpHeaders } from '@angular/common/http';


@Injectable()
export class BranchService {
	constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

	// Get Branch By Id
	getBranchById(orgId, queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(`${environment.roleManagement}/branch/details?orgId=${orgId}&offset=${httpParams.get('startindex')}&limit=${httpParams.get('endindex')}`);
	}

	// Delete Branch
	deleteBranch(branchId): Observable<any> {
		return this.http.delete<any>(`${environment.roleManagement}/branch/delete?id=${branchId}`);
	}

	// Create Branch
	createBranch(data): Observable<any> {
		return this.http.post<any>(`${environment.roleManagement}/branch/create`, data);
	}

	// Update Branch
	updateBranch(data): Observable<any> {
		return this.http.post<any>(`${environment.roleManagement}/branch/update`, data);
	}


	/**
	 * Employee APIs also Configured Here
	 */
	// Get Employee By Id
	getEmployeeById(orgId, branchId, queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(`${environment.roleManagement}/employee/details?orgId=${orgId}&branchId=${branchId}&offset=${httpParams.get('startindex')}&limit=${httpParams.get('endindex')}`);
	}

	// Delete Employee
	deleteEmployee(empId): Observable<any> {
		return this.http.delete<any>(`${environment.roleManagement}/employee/delete?id=${empId}`);
	}

	// Create Employee
	createEmployee(data): Observable<any> {
		return this.http.post<any>(`${environment.roleManagement}/employee/create`, data);
	}

	// Update Employee
	updateEmployee(data): Observable<any> {
		return this.http.post<any>(`${environment.roleManagement}/employee/update`, data);
	}


	// Create Employee In Cognito
	createCognitoEMP(data): Observable<any> {
		return this.http.post<any>(`${environment.hrms}/employeeregistration`, data);
	}

	// Confirm Employee In Cognito
	confirmCognitoEMP(data): Observable<any> {
		return this.http.post<any>(`${environment.hrms}/employeeconfirmpassword`, data);
	}

	// Get Departments And Designation
	getDepartmentDesignation(orgId, branchId): Observable<any> {
		return this.http.get<any>(`${environment.roleManagement}/employee/master-data/orgId/${orgId}/branchId/${branchId}`);
	}

	// Get Employee ReportingTo Details
	getEmpReportingTo(orgId, branchId, gradeId, deptId): Observable<any> {
		return this.http.get<any>(`${environment.roleManagement}/employee/reports-to?orgId=${orgId}&branchId=${branchId}&grade=${gradeId}&deptId=${deptId}`);
	}

	// Get Employee Based on Department and Designation  -- Low Level hierarchy
	getEmpLowLevel(orgId, branchId, deptId, desigId): Observable<any> {
		return this.http.get<any>(`${environment.roleManagement}/employee/dept-employees?orgId=${orgId}&branchId=${branchId}&deptId=${deptId}&desigId=${desigId}`);
	}

	// Task Delegation Post i.e Transfer leads from one Emp to Another
	sendEmpTransfer(empIdFrom, empIdTo): Observable<any> {
		return this.http.post<any>(`${environment.sales}/task-delegation/process?emplIdFrom=${empIdFrom}&emplIdTo=${empIdTo}`, {});
	}

	/**
	 * Phone Directory APIs
	 */
	// Get All Phone Directories
	getPhoneDirectory(orgId): Observable<any> {
		return this.http.get<any>(`${environment.roleManagement}/api/phone_dairy/list?organizationId=${orgId}`);
	}

	// Delete Phone Directory
	deletePhoneDirectory(id): Observable<any> {
		return this.http.delete<any>(`${environment.roleManagement}/api/phone_dairy/delete/${id}`);
	}

	// Create Phone Directory
	createPhoneDirectory(data): Observable<any> {
		return this.http.post<any>(`${environment.roleManagement}/api/phone_dairy/create`, data);
	}

	// Update Phone Directory
	updatePhoneDirectory(data): Observable<any> {
		return this.http.post<any>(`${environment.roleManagement}/api/phone_dairy/update`, data);
	}
}
