// Angular
import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
// RxJS
import { Observable } from "rxjs";
// CRUD
import {
	HttpUtilsService,
	QueryParamsModel,
	QueryResultsModel,
} from "../../_base/crud";
// Models
import { environment } from "./../../../../environments/environment.base";
import { Task } from "../_models/car.model";

const API_ONROLECLCIK_URL = "user/role/id";
const API_UPDATE_ONCLICK_URL = "user/role";
const API_MAP_ROLE_OR_EMP_URL = "mapping";

const API_EMP_ALLOCATION_URL = "employee-allocation";
const API_SOURCE_OF_ENQUIRY_URL = `${environment.sales}/master-data/source-of-enquiry`;
const API_WORKFLOW_URL = "workflow/lead";

@Injectable()
export class MyRolesService {
	readUrl;
	createUrl;
	updateUrl;
	deleteUrl;

	private loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));

	constructor(
		private http: HttpClient,
		private httpUtils: HttpUtilsService
	) {}

	// For Getting Menu
	getRedesignedMenu(username): Observable<any> {
		return this.http.get<any>(
			`${environment.roleManagement}/user/${username}`
		);
	}

	// For Getting Employees
	getRedsignedEmployees(
		queryParams: QueryParamsModel,
		org_id,
		branch_id
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
	//	return this.http.get<any>(
	//		`${environment.roleManagement}/dms/employee?limit=${httpParams.get(
	//			"endindex"
	//		)}&offset=${httpParams.get(
	//			"startindex"
	//		)}&branchId=${branch_id}&orgId=${org_id}`
	//	);

			return this.http.get<any>(
			`${environment.sales}/employees/org/${org_id}/branch/${branch_id}?offset=${httpParams.get(
				"startindex"
			)}&limit=${httpParams.get(
				"endindex"
			)}`
		);

	}

	// Search based on the EmployeeName or EmpId (Get)
	getEmployeesNameOrId(empName, empId): Observable<any> {
		if (empName !== "" && (empId === "" || empId === null)) {
			return this.http.get<any>(
				`${environment.sales}/employees?name=${empName}&branchId=${this.loginEmployee.branchId}&orgId=${this.loginEmployee.orgId}`
			);
		} else if (empId !== "" && (empName === "" || empName === null)) {
			return this.http.get<any>(
				`${environment.sales}/employees?id=${empId}&branchId=${this.loginEmployee.branchId}&orgId=${this.loginEmployee.orgId}`
			);
		} else {
			return this.http.get<any>(
				`${environment.sales}/employees?id=${empId}&name=${empName}
				&branchId=${this.loginEmployee.branchId}&orgId=${this.loginEmployee.orgId}`
			);
		}
	}

	// Search based on the EmployeeName or EmpId For Roles (Get)
	getEmployeesNameOrIdRoles(empName, empId, roleId): Observable<any> {
		if (empName !== "" && (empId === "" || empId === null)) {
			return this.http.get<any>(
				`${environment.sales}/employees?name=${empName}&roleId=${roleId}`
			);
		} else if (empId !== "" && (empName === "" || empName === null)) {
			return this.http.get<any>(
				`${environment.sales}/employees?id=${empId}&roleId=${roleId}`
			);
		} else {
			return this.http.get<any>(
				`${environment.sales}/employees?id=${empId}&name=${empName}&roleId=${roleId}`
			);
		}
	}

	// For Getting Roles
	getRedsignedRolesNewChange(
		queryParams: QueryParamsModel,
		orgId,
		branchId
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${environment.roleManagement}/role?limit=${httpParams.get(
				"endindex"
			)}&offset=${httpParams.get(
				"startindex"
			)}&orgId=${orgId}&branchId=${branchId}`
		);
	}

	// Getting Roles for Performance Reporting
	getAllRoles(page, pageSize, orgId, branchId): Observable<any> {
		return this.http.get<any>(
			`${environment.roleManagement}/role?limit=${page}&offset=${pageSize}&orgId=${orgId}&branchId=${branchId}`
		);
	}

	// Search based on the RoleName (Get)
	getRolesBasedOnName(roleName): Observable<any> {
		return this.http.get<any>(
			`${environment.roleManagement}/role/name?name=${roleName}&branchId=${this.loginEmployee.branchId}&orgId=${this.loginEmployee.orgId}`
		);
	}

	// For Creating Role and Employees
	createRedsignedRole(data): Observable<any> {
		return this.http.post<any>(`${environment.roleManagement}/role`, data);
	}

	// For Updating Role and Employees
	updateRedsignedRole(data): Observable<any> {
		return this.http.put<any>(`${environment.roleManagement}/role`, data);
	}

	// For Deleting Role and Employees
	deleteRedsignedRole(id): Observable<any> {
		return this.http.delete<any>(`${environment.roleManagement}/role/${id}`);
	}

	// For Getting Mapped Elements to Role based on ID
	getRoleMappingById(id): Observable<any> {
		return this.http.get<any>(
			`${environment.roleManagement}/${API_ONROLECLCIK_URL}/${id}`
		);
	}

	// For Updating Mapped Elements to Role
	updateMapping(data): Observable<any> {
		return this.http.put<any>(
			`${environment.roleManagement}/${API_UPDATE_ONCLICK_URL}`,
			data
		);
	}

	// For Getting Employees which are not mapped to a Role
	getEmpNotMappedOnce(
		roleId,
		queryParams: QueryParamsModel
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.roleManagement
			}/mapping/employees/role/${roleId}?limit=${httpParams.get(
				"endindex"
			)}&offset=${httpParams.get("startindex")}`
		);
	}

	// For Mapping EMP or Role
	mapEMPOrROle(roleId, empId): Observable<any> {
		const body = {};
		return this.http.post<any>(
			`${environment.roleManagement}/${API_MAP_ROLE_OR_EMP_URL}/role/${roleId}?empId=${empId}`,
			body
		);
	}

	// For Mapping Multiple EMP to Role (Dev)
	mapEmpOrRoleDev(body): Observable<any> {
		return this.http.post<any>(
			`${environment.roleManagement}/${API_MAP_ROLE_OR_EMP_URL}/role/emp`,
			body
		);
	}

	// For Unmapping Multiple Emp to Role (Dev)
	unmapEmporRoleDev(body): Observable<any> {
		const httpHeaders = this.httpUtils.getHTTPHeaders();
		const options = {
			headers: httpHeaders,
			body,
		};
		return this.http.delete<any>(
			`${environment.roleManagement}/${API_MAP_ROLE_OR_EMP_URL}/role/emp`,
			options
		);
	}

	/**
	 * Employee Allocation Strategy
	 */
	// Get All Strategies
	getAllAllocationTypes(): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/${API_EMP_ALLOCATION_URL}/strategies`
		);
	}

	// Get all Source of Enquiries
	getAllSourceOfEnquiries(): Observable<any> {
		return this.http.get<any>(`${API_SOURCE_OF_ENQUIRY_URL}`);
	}

	// For getting all Role for Emp Allocation Strategy
	getAllRolesAllocation(): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/${API_EMP_ALLOCATION_URL}/roles`
		);
	}

	// Submit Api for EMP Allocation
	updateEmpAllocation(data): Observable<any> {
		return this.http.put<any>(
			`${environment.sales}/${API_EMP_ALLOCATION_URL}/strategy`,
			data
		);
	}

	// Get all Source-Role Mapping
	getAllSourceRoleMapping(orgId, branchId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/${API_EMP_ALLOCATION_URL}/role-enquiry-source/${orgId}/${branchId}`
		);
	}

	// Submit all Source-Role Mapping
	updateSourceRoleMapping(data): Observable<any> {
		return this.http.put<any>(
			`${environment.sales}/${API_EMP_ALLOCATION_URL}/strategy`,
			data
		);
	}

	// Get Tasks Based On the UniversalId and Stage
	getAllTasksUniversalID(universalID, stage) {
		return this.http.get<any>(
			`${environment.sales}/${API_WORKFLOW_URL}/universalId/${universalID}?stage=${stage}`
		);
	}

	getAllMyTasks(userId, pageLimit, pageNo) {
		return this.http
			.get<any>(
				`${environment.sales}/workflow/assignedtasks?empId=${userId}&limit=${pageLimit}&offset=${pageNo}`
			)
			.toPromise()
			.then((res) => res.dmsEntity as Task[])
			.then((data: any) => {
				// {"errorMessage":"","success":false,"error":false}
				if (data) {
					return data.myTasks;
				} else {
					return data;
				}
			});
	}

	/**
	 * Get All Tasks of Today's and Pending.
	 */
	// To Get All Todays Tasks
	getAllTodaysTasks(empId, queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.sales
			}/task-history/current-day-task?empid=${empId}&limit=${httpParams.get(
				"endindex"
			)}&offset=${httpParams.get("startindex")}`
		);
	}

	// Search Todays Tasks
	searchTodaysTasks(
		empId,
		customerName,
		taskName,
		queryParams: QueryParamsModel
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		if (customerName !== "" && (taskName === "" || taskName === null)) {
			return this.http.get<any>(
				`${
					environment.sales
				}/workflow/todaysTasks?empId=${empId}&limit=${httpParams.get(
					"endindex"
				)}&offset=${httpParams.get(
					"startindex"
				)}&customerName=${customerName}`
			);
		} else if (
			taskName !== "" &&
			(customerName === "" || customerName === null)
		) {
			return this.http.get<any>(
				`${
					environment.sales
				}/workflow/todaysTasks?empId=${empId}&limit=${httpParams.get(
					"endindex"
				)}&offset=${httpParams.get("startindex")}&taskName=${taskName}`
			);
		} else {
			return this.http.get<any>(
				`${
					environment.sales
				}/workflow/todaysTasks?empId=${empId}&limit=${httpParams.get(
					"endindex"
				)}&offset=${httpParams.get(
					"startindex"
				)}&customerName=${customerName}&taskName=${taskName}`
			);
		}
	}

	// To Get All Pending Tasks
	getAllPendingTasks(empId, queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.sales
			}/task-history/future-or-past-tasks?empid=${empId}&limit=${httpParams.get(
				"endindex"
			)}&offset=${httpParams.get("startindex")}`
		);
	}

	// Search Pending Tasks
	searchPendingTasks(
		empId,
		customerName,
		taskName,
		queryParams: QueryParamsModel
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		if (customerName !== "" && (taskName === "" || taskName === null)) {
			return this.http.get<any>(
				`${
					environment.sales
				}/workflow/olderTasks?empId=${empId}&limit=${httpParams.get(
					"endindex"
				)}&offset=${httpParams.get(
					"startindex"
				)}&customerName=${customerName}`
			);
		} else if (
			taskName !== "" &&
			(customerName === "" || customerName === null)
		) {
			return this.http.get<any>(
				`${
					environment.sales
				}/workflow/olderTasks?empId=${empId}&limit=${httpParams.get(
					"endindex"
				)}&offset=${httpParams.get("startindex")}&taskName=${taskName}`
			);
		} else {
			return this.http.get<any>(
				`${
					environment.sales
				}/workflow/olderTasks?empId=${empId}&limit=${httpParams.get(
					"endindex"
				)}&offset=${httpParams.get(
					"startindex"
				)}&customerName=${customerName}&taskName=${taskName}`
			);
		}
	}

	getEmployessBySource(id): Observable<any> {
		return this.http.get<any>(
			`${environment.roleManagement}/source/employees?sourceId=${id}`
		);
	}
	getRolesByEmployeeId(id, org_id, branch_id): Observable<any> {
		return this.http.get<any>(
			`${environment.roleManagement}/dms/employee?id=${id}&branchId=${branch_id}&orgId=${org_id}`
		);
	}

	unmapEmpFromSource(body): Observable<any> {
		const httpHeaders = this.httpUtils.getHTTPHeaders();
		const options = {
			headers: httpHeaders,
			body,
		};
		return this.http.delete<any>(
			`${environment.roleManagement}/source`,
			options
		);
	}

	unmapRoleFromEmp(body, org_id, branch_id): Observable<any> {
		const httpHeaders = this.httpUtils.getHTTPHeaders();
		const options = {
			headers: httpHeaders,
			body,
		};
		return this.http.delete<any>(
			`${environment.roleManagement}/dms `,
			options
		);
	}
}
