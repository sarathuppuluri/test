import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject, Observable, of } from 'rxjs';
import { environment } from '../../../../environments/environment.base';

const API_ENQUIRY_URL = `${environment.preEnquiryDomain}/dev/enquiry`;

const API_GETACTIVITY_URL = `${environment.sales}/dms`;



@Injectable()
export class Lead360Service {
	selectedTaskObj: any = {}; // This is for  lead360 activity

	isUserLogin = false;
	token = "";
	userDetails: any;
	companyId = "";
	leadDetails: any;

	leadId = "";
	data: any;
	leadData = new Subject<boolean>();
	financeDataSubject = new Subject<boolean>();
	financeData: any;
	taskActivityData: any;
	taskActivityDataSubject = new Subject<boolean>();

	constructor(private http: HttpClient) {
		if (sessionStorage.getItem("userData") !== null) {
			this.isUserLogin = true;
			this.userDetails = JSON.parse(sessionStorage.getItem("userData"));
		} else {
			this.isUserLogin = false;
		}
	}

	getCustomer(id, idToken, orgid, showroomid) {
		let headers = new HttpHeaders();
		headers = headers.append("showroomid", showroomid);
		headers = headers.append("orgid", orgid);
		headers = headers.append("auth-token", idToken);
		this.http
			.get<any>(API_ENQUIRY_URL + `/personalinfo/customer/id/${id}`, {
				headers,
			})
			.subscribe((data) => {
				this.financeData = data;
				this.financeDataSubject.next(true);
			});
	}

	getCurruntTaskById(taskId: number) {
		return this.http.get<any>(`${environment.sales}/workflow/task/${taskId}`);
	}

	getPersonalInfo(universalId) {
		return this.http.get<any>(
			`${environment.sales}/lead/id/${universalId}`
		);
	}

	getStatusOfStages(universalId) {
		return this.http.get<any>(
			`${environment.sales}/workflow/lead/stage/${universalId}`
		);
	}

	fetchTaskByLeadUniversalId(universalId) {
		return this.http.get<any>(
			`${environment.sales}/workflow/lead/universalId/${universalId}`
		);
	}

	getCurrentActivity(userName) {
		this.http
			.get<any>(
				API_GETACTIVITY_URL + `/workflow/task?empName=${userName}`
			)
			.subscribe((data) => {
				this.taskActivityData = data;
				this.taskActivityDataSubject.next(true);
			});
	}

	leadStageUpdate(stage, universalId) {
		const headerDict = {
			"Content-Type": "application/json",
		};
		const requestOptions = {
			headers: new HttpHeaders(headerDict),
		};
		return this.http.post(
			`${environment.sales}/dms/lead/stage/${universalId}?stage=${stage}`,
			{},
			requestOptions
		);
	}

	saveActivity(newActivityObj: any) {
		const headerDict = {
			"Content-Type": "application/json",
		};
		const requestOptions = {
			headers: new HttpHeaders(headerDict),
		};
		return this.http.post(
			`${environment.sales}/dms/task`,
			newActivityObj,
			requestOptions
		);
	}
	saveFollowUpActivity(newActivityObj) {
		const headerDict = {
			"Content-Type": "application/json",
		};
		const requestOptions = {
			headers: new HttpHeaders(headerDict),
		};
		return this.http.put(`${environment.sales}/dms/task`, newActivityObj);
	}

	saveHomeVisitActivity(newActivityObj) {
		const headerDict = {
			"Content-Type": "application/json",
		};
		const requestOptions = {
			headers: new HttpHeaders(headerDict),
		};
		return this.http.post(`${environment.sales}/homevisit`, newActivityObj);
	}
	saveEvalutionActivity(newActivityObj) {
		const headerDict = {
			"Content-Type": "application/json",
		};
		const requestOptions = {
			headers: new HttpHeaders(headerDict),
		};
		return this.http.post(
			`${environment.sales}/evaluation`,
			newActivityObj
		);
	}

	saveFinanceActivity(newActivityObj) {
		const headerDict = {
			"Content-Type": "application/json",
		};
		const requestOptions = {
			headers: new HttpHeaders(headerDict),
		};
		return this.http.post(`${environment.sales}/finance`, newActivityObj);
	}

	getAllVehicleDetails(organizationId) {
		return this.http.get<any>(
			`${environment.vehicleInfoService}/api/vehicle_details?organizationId=${organizationId}`
		);
	}
	getVehicleOnRoadPrice(organizationId, varientId) {
		return this.http.get<any>(
			`${environment.vehicleInfoService}/api/vehicle_on_road_prices/${varientId}/${organizationId}`
		);
	}

	getVehicleOffers(organizationId, varientId, vehicleId) {
		let headers = new HttpHeaders();
		headers = headers.append("orgId", organizationId);
		headers = headers.append("Access-Control-Allow-Origin", "*");
		headers = headers.append("Access-Control-Allow-Methods", "GET");
		headers = headers.append(
			"Access-Control-Allow-Headers",
			"Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"
		);

		return this.http.get<any>(
			`${environment.ops}/api/allofferdetail?varientId=${varientId}&vehicleId=${vehicleId}`,
			{ headers }
		);
	}

	// to get task difinitions
	getTaskDifinitions() {
		return this.http.get<any>(
			`${environment.roleManagement}/taskDefinitions`
		);
	}

	// to get Process Difinitions
	getProcessDifinitions() {
		return this.http.get<any>(`${environment.sales}/activities`);
	}

	// to get emplayee by name /& id
	getEmplayeeByNameOrId(empName, empId) {
		let url = "";

		if (empId !== "" && empName === "") {
			url = "id=" + empId;
		}
		if (empName !== "" && empId === "") {
			url = "name=" + empName;
		}
		if (empName !== "" && empId !== "") {
			url = "id=" + empId + "&name=" + empName;
		}
		return this.http.get<any>(`${environment.sales}/employees?${url}`);
	}

	// Save Evaluation
	updateEvaluationTask(requestBody) {
		const headerDict = {
			"Content-Type": "application/json",
		};
		const requestOptions = {
			headers: new HttpHeaders(headerDict),
		};
		return this.http.post(
			`${environment.sales}/evaluation`,
			requestBody,
			requestOptions
		);
	}

	/**
	 * Common Code used in the Stages -- get all tasks
	 */

	getAllTasksByUniversalId(universalId) {
		this.http
			.get<any>(
				`${environment.sales}/workflow/lead/universalId/${universalId}`
			)
			.subscribe((res) => {
				res.dmsEntity.tasks.forEach((element) => {
					if (
						element.taskStatus === "ASSIGNED" ||
						element.taskStatus === "SENT_FOR_APPROVAL"
					) {
						element.taskStatus =
							element.lastTask === true ? "CANCELLED" : "CLOSED";
						this.http
							.put(`${environment.sales}/dms/task`, element)
							.subscribe((result) => {});
					}
				});
			});
	}

	getAllApprovalTasksByUniversalId(universalId) {
		this.http
			.get<any>(
				`${environment.sales}/workflow/lead/universalId/${universalId}`
			)
			.subscribe((res) => {
				res.dmsEntity.tasks.forEach((element) => {
					if (
						element.taskStatus === "ASSIGNED" &&
						element.lastTask === true
					) {
						element.taskStatus = "SENT_FOR_APPROVAL";
						this.http
							.put(`${environment.sales}/dms/task`, element)
							.subscribe((result) => {});
					}
				});
			});
	}
	/** FOR task-history  */
	getTaskHistoryById(taskId) {
		return this.http.get<any>(
			`${environment.sales}/task-history/taskid/${taskId}`
		);
	}
}
