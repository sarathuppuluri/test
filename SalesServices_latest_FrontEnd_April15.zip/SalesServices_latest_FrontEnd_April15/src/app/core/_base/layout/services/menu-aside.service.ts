// Angular
import { Injectable } from "@angular/core";
// RxJS
import { BehaviorSubject } from "rxjs";
// Object path
import * as objectPath from "object-path";
// Services
import { MenuConfigService } from "./menu-config.service";
import { MyRolesService } from "../../../e-commerce/_services/myroles.service";

@Injectable()
export class MenuAsideService {
	userName;

	/**
	 * Service constructor
	 *
	 * @param menuConfigService: MenuConfigService
	 */
	constructor(
		private menuConfigService: MenuConfigService,
		private myroleservice: MyRolesService
	) {
		this.PrepareJSONData();
	}
	// Public properties
	menuList$: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);

	roleId;

	// Dynamic Loading of Menu. Calling service to get Menu
	tempList = [];
	menuPrepare = [];
	PrepareJSONData() {
		this.userName = localStorage.getItem("userName");
		if (this.userName === null || this.userName === undefined) {
			setTimeout(() => {
				this.PrepareJSONData();
			}, 100);
		} else {
			this.myroleservice
				.getRedesignedMenu(this.userName)
				.subscribe((res) => {
					localStorage.setItem(
						"loginEmployee",
						JSON.stringify(res.dmsEntity.loginEmployee)
					);
					this.menuPrepare = res.dmsEntity.menuList;
					this.menuPrepare.forEach((element) => {
						element.icon = `icon-${element.menuName}`;
						element.bullet = "dot";
						if (element.submenu.length <= 1) {
							element.page = `/${element.menuName}/${element.submenu[0].menuName}`;
							delete element.submenu;
						} else {
							element.submenu.forEach((ele) => {
								ele.page = `/${element.menuName}/${ele.menuName}`;
							});
						}
					});
					this.loadJsonEmployeeMenu();
					this.submenuFetch();
				});
		}
	}

	loadJsonEmployeeMenu() {
		const menuItems: any[] = this.menuPrepare;
		console.log("Menu List" + menuItems);
		this.menuList$.next(menuItems);
	}

	submenuFetch() {
		this.userName = localStorage.getItem("userName");
		this.myroleservice.getRedesignedMenu(this.userName).subscribe((res) => {
			this.tempList = res.dmsEntity.menuList;
		});
	}

	policyGroup = [];

	getUnique(array, field) {
		const unique = array
			.map((element) => element[field])
			.map((element, i, final) => final.indexOf(element) === i && i)
			.filter((element) => array[element])
			.map((element) => array[element]);
		return unique;
	}

	loadEmployeeMenu() {
		const menuItems: any[] = this.policyGroup;
		this.menuList$.next(menuItems);
	}

	/**
	 * Load menu list
	 */
	loadAdminMenu() {
		// get menu list
		if (
			objectPath.get(
				this.menuConfigService.getMenus(),
				"aside.policygroups"
			) === undefined
		) {
			setTimeout(() => {
				this.loadAdminMenu();
			}, 100);
		} else {
			const menuItems: any[] = objectPath.get(
				this.menuConfigService.getMenus(),
				"aside.policygroups"
			);
			this.menuList$.next(menuItems);
		}
	}
}
