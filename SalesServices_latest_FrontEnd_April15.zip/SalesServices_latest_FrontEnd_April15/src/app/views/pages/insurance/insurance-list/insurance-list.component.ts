import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { InsuranceService } from '../../../../core/e-commerce/_services/insurance.service';
import { Router } from '@angular/router';

@Component({
	selector: 'kt-insurance-list',
	templateUrl: './insurance-list.component.html',
	styleUrls: ['./insurance-list.component.scss'],
})
export class InsuranceListComponent implements OnInit {
	insurances: any;
	constructor(
		private insuranceService: InsuranceService,
		private router: Router,
		private changeDetectorRef: ChangeDetectorRef
	) {}

	ngOnInit() {
		this.getAllInsurance();
	}

	getAllInsurance() {
		this.insuranceService.getAllInsurance().subscribe((data) => {
			this.insurances = data.insuranceDetails;
			this.changeDetectorRef.detectChanges();
		});
	}

	editInsurance(insurance) {
		this.router.navigateByUrl('insurance/edit/' + insurance.id);
	}

	deleteInsurance(insurance) {
		this.insuranceService
			.deleteInsurance(insurance.id)
			.subscribe((data) => {
				this.getAllInsurance();
				this.changeDetectorRef.detectChanges();
			});
	}

	createInsurance() {
		this.router.navigateByUrl('insurance/create');
	}
}
