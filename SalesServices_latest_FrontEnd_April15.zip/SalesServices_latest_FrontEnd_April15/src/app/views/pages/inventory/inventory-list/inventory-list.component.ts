import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { InventoryService } from '../../../../core/e-commerce/_services/inventory.service';
import { Router } from '@angular/router';
import moment from 'moment';

@Component({
	selector: 'kt-inventory-list',
	templateUrl: './inventory-list.component.html',
	styleUrls: ['./inventory-list.component.scss'],
})
export class InventoryListComponent implements OnInit {
	constructor(
		private inventoryService: InventoryService,
		private router: Router,
		private changeDetectorRef: ChangeDetectorRef
	) { }
	inventories = [];
	deAllotedDate;
	allotedDate;
	vechilesData = [];
	loginEmployee: any;
	model;

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.get();
		this.getVehicles();
	}

	get() {
		this.inventoryService.get().subscribe((data) => {
			this.inventories = data.inventoryList;
			this.changeDetectorRef.detectChanges();
		});
	}

	getVehicles() {
		this.inventoryService
			.getVehicles(this.loginEmployee.orgId)
			.subscribe((data) => {
				this.vechilesData = data;
			});
	}

	editInventory(inv) {
		this.router.navigateByUrl("inventory/Edit/" + inv.id);
	}

	create() {
		this.router.navigateByUrl("inventory/Create");
	}

	search() {
		let searchFormat =
			'branch_id=' +
			this.loginEmployee.branchId +
			'&org_id=' +
			this.loginEmployee.orgId;
		if (this.model) {
			searchFormat = searchFormat + '&model=' + this.model;
		}
		if (this.allotedDate) {
			searchFormat = searchFormat + '&allotedDate=' + moment(this.allotedDate).format('YYYY-MM-DD');
		}
		if (this.deAllotedDate) {
			searchFormat =
				searchFormat + '&deAllotedDate=' + moment(this.deAllotedDate).format('YYYY-MM-DD');
		}
		if (!this.model && !this.allotedDate && !this.deAllotedDate) {
			this.get();
		} else {
			this.inventoryService.search(searchFormat).subscribe((data) => {
				this.inventories = data && data.inventoryList ? data.inventoryList : [];
				this.changeDetectorRef.detectChanges();
			});
		}
	}

	deleteInventory(inv) {
		this.inventoryService.delete(inv.id).subscribe((data) => {
			this.get();
		});
	}

	clearFilter() {
		this.model = '';
		this.allotedDate = null;
		this.deAllotedDate = null;
		this.get();
	}
}
