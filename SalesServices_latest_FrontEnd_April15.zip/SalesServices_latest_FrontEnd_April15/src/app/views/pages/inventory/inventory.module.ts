// Angular
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
// Core Module
import { CoreModule } from '../../../core/core.module';
import { PartialsModule } from '../../partials/partials.module';
import { MatIconModule } from '@angular/material/icon';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {
	MatTabsModule,
	MatCardModule,
	MatInputModule,
	MatFormFieldModule,
	MatExpansionModule,
	MatStepperModule,
	MatCheckboxModule,
	MatButtonModule,
	MatAutocompleteModule,
	MatMenuModule,
} from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { InventoryComponent } from './inventory.component';
import { InventoryService } from '../../../core/e-commerce/_services/inventory.service';
import { InventoryListComponent } from './inventory-list/inventory-list.component';

@NgModule({
	imports: [
		CommonModule,
		PartialsModule,
		CoreModule,
		MatIconModule,
		NgbModule,
		MatTabsModule,
		MatMenuModule,
		MatCardModule,
		FormsModule,
		ReactiveFormsModule,
		MatFormFieldModule,
		MatStepperModule,
		MatInputModule,
		MatButtonModule,
		MatCheckboxModule,
		MatAutocompleteModule,
		MatInputModule,
		MatExpansionModule,
		ReactiveFormsModule,
		FlexLayoutModule,
		MatDatepickerModule,
		RouterModule.forChild([
			{
				path: 'inventory',
				component: InventoryListComponent,
			},
			{
				path: 'Create',
				component: InventoryComponent,
			},

			{
				path: 'Edit/:id',
				component: InventoryComponent,
			},
		]),
	],
	providers: [InventoryService],
	declarations: [InventoryComponent, InventoryListComponent],
})
export class InventoryModule {}
