// Angular
import { Component, OnInit, ChangeDetectorRef, Inject, ChangeDetectionStrategy, ViewEncapsulation, ViewChild, ElementRef, OnDestroy } from '@angular/core';
// Material
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
// RxJS
import { Subscription, of } from 'rxjs';
import { delay } from 'rxjs/operators';
// NGRX
import { Update } from '@ngrx/entity';
import { Store, select } from '@ngrx/store';
// CRUD
import { LayoutUtilsService, MessageType, TypesUtilsService, QueryParamsModel } from '../../../../core/_base/crud';
// Services and Models
import { CustomerModel } from '../../../../core/e-commerce';
import { IncentivesModel } from '../../../../core/e-commerce/_models/incentive.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IncentivesService } from '../../../../core/e-commerce/_services/incentives.service';

declare let ol: any;

@Component({
	styleUrls: ['./incentives-edit.dialog.component.scss'],
	selector: 'kt-incentives-edit-dialog',
	templateUrl: './incentives-edit.dialog.component.html'
})
export class IncentivesEditDialogComponent implements OnInit, OnDestroy {

	/**
	 * Component constructor
	 *
	 * @param dialogRef: MatDialogRef<CustomerEditDialogComponent>
	 * @param data: any
	 * @param fb: FormBuilder
	 * @param store: Store<AppState>
	 * @param typesUtilsService: TypesUtilsService
	 */
	constructor(public dialogRef: MatDialogRef<IncentivesEditDialogComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any,
		private fb: FormBuilder,
		private changeDetectorRef: ChangeDetectorRef,
		private layoutUtilsService: LayoutUtilsService,
		private IncentiveService: IncentivesService) {
	}
	// Public properties
	customerForm: FormGroup;
	hasFormErrors = false;
	viewLoading = false;
	IncentiveEdit: any;

	IncentiveForm: FormGroup;

	hasSubmitted = false;
	message = '';


	tempData = [];
	AllDataIncentive: any = [];
	dataSource: any = [];

	ngOnInit() {
		this.IncentiveEdit = this.data.editIncentive;
		this.createForm();
	}

	createForm() {
		this.IncentiveForm = this.fb.group({
			segment: [this.IncentiveEdit.segment],
			rule_minval: [this.IncentiveEdit.rule_minval],
			rule_maxval: [this.IncentiveEdit.rule_maxval],
			incentive_amt: [this.IncentiveEdit.incentive_amt],
			incentive_unit: [this.IncentiveEdit.incentive_unit],
			incentive_type: [this.IncentiveEdit.incentive_type],
			team: [this.IncentiveEdit.team]
		});
	}


	/**
	 * On destroy
	 */
	ngOnDestroy() {
	}


	/**
	 * Check control is invalid
	 * @param controlName: string
	 */
	isControlInvalid(controlName: string): boolean {
		const control = this.IncentiveForm.controls[controlName];
		const result = control.invalid && control.touched;
		return result;
	}

	onSubmit() {
		this.hasSubmitted = true;
		this.hasFormErrors = false;
		const controls = this.IncentiveForm.controls;
		if (this.IncentiveForm.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		}

		this.IncentiveEdit.segment = controls.segment.value;
		this.IncentiveEdit.rule_minval = controls.rule_minval.value;
		this.IncentiveEdit.rule_maxval = controls.rule_maxval.value;
		this.IncentiveEdit.incentive_amt = controls.incentive_amt.value;
		this.IncentiveEdit.incentive_unit = controls.incentive_unit.value;
		this.IncentiveEdit.incentive_type = controls.incentive_type.value;
		this.IncentiveEdit.team = controls.team.value;

		const IncentiveDataObj = this.IncentiveEdit;

		if (Number(this.IncentiveEdit.id) > 0) {
			this.updateIncentive(IncentiveDataObj);
		} else {
			this.createIncentive(IncentiveDataObj);
		}
	}

	createIncentive(IncentiveData) {
		this.IncentiveService.createIncentive(IncentiveData).subscribe(response => {
			this.hasSubmitted = false;
			if (!response) {
				return;
			}
			
			this.dialogRef.close({ response, isEdit: false });
		});
	}


	updateIncentive(editIncentive) {
		this.IncentiveService.updateIncentive(editIncentive).subscribe(response => {
			this.hasSubmitted = false;
			if (!response) {
				return;
			}

			this.dialogRef.close({ response, isEdit: true });
		});
	}

	/** Alect Close event */
	onAlertClose() {
		this.hasFormErrors = false;
	}
}
