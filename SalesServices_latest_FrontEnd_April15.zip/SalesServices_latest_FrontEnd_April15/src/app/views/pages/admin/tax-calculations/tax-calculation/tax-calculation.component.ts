import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { TaxCalculationService } from '../../../../../core/e-commerce/_services/taxCalculation.service';
import { FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
	selector: 'kt-tax-calculation',
	templateUrl: './tax-calculation.component.html',
	styleUrls: ['./tax-calculation.component.scss'],
})
export class TaxCalculationComponent implements OnInit {
	taxId = '';
	taxForm: FormGroup;
	loginEmployee: any;
	showError = false;
	typePersonal = 'Personal';
	unitPersonal = 'percent';
	firsTimePersonal = '';
	nextTimePersonal = '';
	allTimePersonal = '';

	typeCompany = 'Company';
	unitCompany = 'percent';
	firsTimeCompany = '';
	nextTimeCompany = '';
	allTimeCompany = '';

	typeTaxi = 'Taxi';
	unitTaxi = 'percent';
	firsTimeTaxi = '';
	nextTimeTaxi = '';
	allTimeTaxi = '';

	typeHandicap = 'Handicap';
	unitHandicap = 'amount';
	firsTimeHandicap = '';
	nextTimeHandicap = '';
	allTimeHandicap = '';

	typeDefault = 'Default';
	unitDefault = 'percent';
	firsTimeDefault = '';
	nextTimeDefault = '';
	allTimeDefault = '';

	conditionAmount = 0;

	unitValues = [
		{ text: 'Percent', value: 'percent' },
		{ text: 'Amount', value: 'amount' },
	];
	typeValues = [
		{ text: 'Personal', value: 'Personal' },
		{ text: 'Company', value: 'Company' },
		{ text: 'Taxi', value: 'Taxi' },
		{ text: 'Handicap', value: 'Handicap' },
		{ text: 'Default', value: 'Default' },
	];
	constructor(
		public router: Router,
		public activatedRoute: ActivatedRoute,
		public taxCalculationService: TaxCalculationService,
		private _snackBar: MatSnackBar,
		private cd: ChangeDetectorRef
	) { }

	ngOnInit() {
		this.taxId = this.activatedRoute.snapshot.paramMap.get('id');
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		if (this.taxId) {
			this.getTaxDetails();
		}
	}

	goBack() {
		this.router.navigateByUrl('adminPanel/Taxrate');
	}

	getTaxDetails() {
		this.taxCalculationService.getTaxes(10, 0).subscribe((data) => {
			this.setData(data);
		});
	}

	setData(data) {
		if (data && data.roadtaxList) {
			this.conditionAmount =
				data.roadtaxList[0].tax_calculation.conditionAmount;
			data.roadtaxList[0].tax_calculation.customerType.forEach((obj) => {
				if (obj.type === 'Personal') {
					this.typePersonal = obj.type;
					this.unitPersonal = obj.unit;
					this.firsTimePersonal = obj.firsTime;
					this.nextTimePersonal = obj.nextTime;
					this.allTimePersonal = obj.allTime;
				} else if (obj.type === 'Company') {
					this.typeCompany = obj.type;
					this.unitCompany = obj.unit;
					this.firsTimeCompany = obj.firsTime;
					this.nextTimeCompany = obj.nextTime;
					this.allTimeCompany = obj.allTime;
				} else if (obj.type === 'Taxi') {
					this.typeTaxi = obj.type;
					this.unitTaxi = obj.unit;
					this.firsTimeTaxi = obj.firsTime;
					this.nextTimeTaxi = obj.nextTime;
					this.allTimeTaxi = obj.allTime;
				} else if (obj.type === 'Handicap') {
					this.typeHandicap = obj.type;
					this.unitHandicap = obj.unit;
					this.firsTimeHandicap = obj.firsTime;
					this.nextTimeHandicap = obj.nextTime;
					this.allTimeHandicap = obj.allTime;
				} else if (obj.type === 'Default') {
					this.typeDefault = obj.type;
					this.unitDefault = obj.unit;
					this.firsTimeDefault = obj.firsTime;
					this.nextTimeDefault = obj.nextTime;
					this.allTimeDefault = obj.allTime;
				}
			});
		}
		this.cd.detectChanges();
	}

	saveDetails() {
		this.showError = false;
		if (
			!this.conditionAmount ||
			this.conditionAmount === 0 ||
			((!this.allTimePersonal || this.allTimePersonal === '0') &&
				this.nextTimePersonal &&
				!this.firsTimePersonal) ||
			((!this.allTimePersonal || this.allTimePersonal === '0') &&
				this.firsTimePersonal &&
				!this.nextTimePersonal) ||
			(!this.firsTimePersonal &&
				!this.nextTimePersonal &&
				!this.allTimePersonal) ||
			((!this.allTimeCompany || this.allTimeCompany === '0') &&
				this.nextTimeCompany &&
				!this.firsTimeCompany) ||
			((!this.allTimeCompany || this.allTimeCompany === '0') &&
				this.firsTimeCompany &&
				!this.nextTimeCompany) ||
			(!this.firsTimeCompany &&
				!this.nextTimeCompany &&
				!this.allTimeCompany) ||
			((!this.allTimeTaxi || this.allTimeTaxi === '0') &&
				this.nextTimeTaxi &&
				!this.firsTimeTaxi) ||
			((!this.allTimeTaxi || this.allTimeTaxi === '0') &&
				this.firsTimeTaxi &&
				!this.nextTimeTaxi) ||
			(!this.firsTimeTaxi && !this.nextTimeTaxi && !this.allTimeTaxi) ||
			((!this.allTimeHandicap || this.allTimeHandicap === '0') &&
				this.nextTimeHandicap &&
				!this.firsTimeHandicap) ||
			((!this.allTimeHandicap || this.allTimeHandicap === '0') &&
				this.firsTimeHandicap &&
				!this.nextTimeHandicap) ||
			(!this.firsTimeHandicap &&
				!this.nextTimeHandicap &&
				!this.allTimeHandicap) ||
			((!this.allTimeDefault || this.allTimeDefault === '0') &&
				this.nextTimeDefault &&
				!this.firsTimeDefault) ||
			((!this.allTimeDefault || this.allTimeDefault === '0') &&
				this.firsTimeDefault &&
				!this.nextTimeDefault) ||
			(!this.firsTimeDefault &&
				!this.nextTimeDefault &&
				!this.allTimeDefault)
		) {
			this.showError = true;
		} else {
			if (this.taxId) {
				this.taxCalculationService
					.updateTax(this.createTaxObject())
					.subscribe((data) => {
						this.openSnackBar(
							'Tax Details Updated Successfully',
							'Success'
						);
						this.goBack();
					});
			} else {
				this.taxCalculationService
					.createTax(this.createTaxObject())
					.subscribe((data) => {
						this.openSnackBar(
							'Tax Details Saved Successfully',
							'Success'
						);
						this.goBack();
					});
			}
		}
	}

	createTaxObject() {
		const data = {
			id: this.taxId,
			organization_id: this.loginEmployee.orgId,
			tax_calculation: {
				customerType: [
					{
						type: this.typePersonal,
						unit: this.unitPersonal,
						firsTime: this.firsTimePersonal,
						nextTime: this.nextTimePersonal,
						allTime: this.allTimePersonal,
					},
					{
						type: this.typeCompany,
						unit: this.unitCompany,
						firsTime: this.firsTimeCompany,
						nextTime: this.nextTimeCompany,
						allTime: this.allTimeCompany,
					},
					{
						type: this.typeTaxi,
						unit: this.unitTaxi,
						firsTime: this.firsTimeTaxi,
						nextTime: this.nextTimeTaxi,
						allTime: this.allTimeTaxi,
					},
					{
						type: this.typeHandicap,
						unit: this.unitHandicap,
						firsTime: this.firsTimeHandicap,
						nextTime: this.nextTimeHandicap,
						allTime: this.allTimeHandicap,
					},
					{
						type: this.typeDefault,
						unit: this.unitDefault,
						firsTime: this.firsTimeDefault,
						nextTime: this.nextTimeDefault,
						allTime: this.allTimeDefault,
					},
				],
				conditionAmount: this.conditionAmount,
			},
		};
		return JSON.parse(JSON.stringify(data));
	}

	private openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 5000,
		});
	}

	clear() {
		this.firsTimePersonal = '';
		this.nextTimePersonal = '';
		this.allTimePersonal = '';
		this.firsTimeCompany = '';
		this.nextTimeCompany = '';
		this.allTimeCompany = '';
		this.firsTimeTaxi = '';
		this.nextTimeTaxi = '';
		this.allTimeTaxi = '';
		this.firsTimeHandicap = '';
		this.nextTimeHandicap = '';
		this.allTimeHandicap = '';
		this.firsTimeDefault = '';
		this.nextTimeDefault = '';
		this.allTimeDefault = '';
	}
}
