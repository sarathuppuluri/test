import { Component, OnInit, Input, EventEmitter, Output } from "@angular/core";

@Component({
	selector: "kt-star",
	templateUrl: "./star.component.html",
	styleUrls: ["./star.component.scss"],
})
export class StarComponent implements OnInit {
	@Input() rating: number;
	@Input() starCount: number;
	@Input() color: string;
	@Output() private ratingUpdated = new EventEmitter();

	ratingArr = [];

	constructor() {}

	ngOnInit() {
		for (let index = 0; index < this.starCount; index++) {
			this.ratingArr.push(index);
		}
	}

	showIcon(index: number) {
		if (this.rating >= index + 1) {
			return "star";
		} else {
			return "star_border";
		}
	}
}
export enum StarRatingColor {
	primary = "primary",
	accent = "accent",
	warn = "warn",
}
