import { ChangeDetectorRef, Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { TaskApproverService } from "../../../../../core/e-commerce/_services/taskApprover.service";

@Component({
	selector: "kt-task-approver-list",
	templateUrl: "./task-approver-list.component.html",
	styleUrls: ["./task-approver-list.component.scss"],
})
export class TaskApproverListComponent implements OnInit {
	approverList = [];
	isLoading = false;
	constructor(
		private taskApproverService: TaskApproverService,
		private router: Router,
		private changeDetectorRef: ChangeDetectorRef
	) {}

	ngOnInit() {
		this.getAllTaskApprovers();
	}

	getAllTaskApprovers() {
		this.taskApproverService.getTasksApproverList().subscribe((data) => {
			this.approverList = data.dmsEntity.listTaskApproverModel;
			this.changeDetectorRef.detectChanges();
		});
	}

	createTaskApprover() {
		this.router.navigateByUrl("adminPanel/taskApprover/create");
	}

	editTaskApprover(approver) {
		this.taskApproverService.empName = approver.empName;
		this.taskApproverService.rowObject = approver;
		this.router.navigateByUrl(
			"adminPanel/taskApprover/edit/" +
				approver.taskDefId +
				"/" +
				approver.empid
		);
	}

	deleteTaskApprover(approver) {
		this.taskApproverService
			.deleteTaskApprover(approver.id)
			.subscribe((data) => {
				this.approverList = [];
				this.getAllTaskApprovers();
				this.changeDetectorRef.detectChanges();
			});
	}
}
