// Angular
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
// Metronic
// Material   // Imported By Me...
import {
	MatInputModule,
	MatPaginatorModule,
	MatProgressSpinnerModule,
	MatSortModule,
	MatTableModule,
	MatSelectModule,
	MatMenuModule,
	MatProgressBarModule,
	MatButtonModule,
	MatCheckboxModule,
	MatDialogModule,
	MatTabsModule,
	MatNativeDateModule,
	MatCardModule,
	MatRadioModule,
	MatIconModule,
	MatDatepickerModule,
	MatAutocompleteModule,
	MAT_DIALOG_DEFAULT_OPTIONS,
	MatSnackBarModule,
	MatTooltipModule,
	MatExpansionModule,
	MAT_DATE_LOCALE,
} from "@angular/material";
import { NgbAlertConfig, NgbModule } from "@ng-bootstrap/ng-bootstrap";
// Components
import { OfferListComponent } from "./offer-list/offer-list.component";
import { OfferFromComponent } from "./offer/offer.component";
import { OffersService } from "../../../../core/e-commerce/_services/offers.service";
import { OfferMappingComponent } from "./offer-mapping/offer-mapping.component";
import { OfferMapingsListComponent } from "./offer-mapings-list/offer-mapings-list.component";
import { CorpOfferComponent } from "./corp-offer/corp-offer.component";

@NgModule({
	declarations: [
		OfferListComponent,
		OfferFromComponent,
		OfferMappingComponent,
		OfferMapingsListComponent,
		CorpOfferComponent,
	],
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatInputModule,
		MatPaginatorModule,
		MatProgressSpinnerModule,
		MatSortModule,
		MatTableModule,
		MatSelectModule,
		MatMenuModule,
		MatProgressBarModule,
		MatButtonModule,
		MatCheckboxModule,
		MatDialogModule,
		MatTabsModule,
		MatNativeDateModule,
		MatCardModule,
		MatRadioModule,
		MatIconModule,
		MatDatepickerModule,
		MatAutocompleteModule,
		MatSnackBarModule,
		MatTooltipModule,
		MatExpansionModule,
		NgbModule,
		RouterModule.forChild([
			{
				path: "",
				component: OfferListComponent,
			},
			{
				path: "adminPanel/offers",
				component: OfferListComponent,
			},
			{
				path: "create",
				component: OfferFromComponent,
			},
			{
				path: "corp-offer/create",
				component: CorpOfferComponent,
			},
			{
				path: "offer/:type/:id",
				component: OfferFromComponent,
			},
			{
				path: "corp-offer/:type/:id",
				component: CorpOfferComponent,
			},
			{
				path: "mappings/:id",
				component: OfferMapingsListComponent,
			},
			{
				path: "mapping/create/:id",
				component: OfferMappingComponent,
			},
			{
				path: "mapping/:id/:isEdit",
				component: OfferMappingComponent,
			},
		]),
	],
	entryComponents: [],
	providers: [NgbAlertConfig, OffersService],
})
export class OfferModule {}
