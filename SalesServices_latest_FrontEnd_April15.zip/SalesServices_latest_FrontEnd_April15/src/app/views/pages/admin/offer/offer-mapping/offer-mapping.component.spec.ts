import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferMappingComponent } from './offer-mapping.component';

describe('OfferMappingComponent', () => {
  let component: OfferMappingComponent;
  let fixture: ComponentFixture<OfferMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfferMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
