import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, FormArray } from "@angular/forms";
import { OffersService } from "../../../../../core/e-commerce/_services/offers.service";
import { ActivatedRoute, Router } from "@angular/router";

@Component({
	selector: "kt-corp-offer",
	templateUrl: "./corp-offer.component.html",
	styleUrls: ["./corp-offer.component.scss"],
})
export class CorpOfferComponent implements OnInit {
	offerForm: FormGroup;
	loginEmployee: any;
	offerId: any;
	showError = false;
	offerType;
	offerTypes = [
		{ text: "Discount", value: "discount" },
		{ text: "Accessories", value: "accessories" },
	];
	statusValues = [
		{ text: "Active", value: "Active" },
		{ text: "InActive", value: "InActive" },
	];
	allowValues = [
		{ text: "Yes", value: true },
		{ text: "No", value: false },
	];
	constructor(
		private fb: FormBuilder,
		private offersService: OffersService,
		private route: ActivatedRoute,
		private router: Router
	) {}

	ngOnInit() {
		this.createForm();
		this.offerId = this.route.snapshot.paramMap.get("id");
		this.offerType = this.route.snapshot.paramMap.get("type");
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		if (this.offerId) {
			this.getOfferDetailsByid();
		} else {
			this.offerForm.patchValue({
				status: "Active",
				offerType: "discount",
				startDate: new Date(),
				checkboxAllowed: true,
			});
		}
	}

	getOfferDetailsByid() {
		this.offersService
			.getOfferById(this.offerType, this.offerId)
			.subscribe((data) => {
				this.offerForm.patchValue(data.offerCorporate[0]);
				this.offerForm.controls['offerCorporates'] =
				this.fb.array(data.offerCorporate[0].offerCorporates.map(obj => {
					const offerCorp = this.newCorporate();
					offerCorp.patchValue(obj);
					return offerCorp ;
				}));
			});
	}

	createForm() {
		this.offerForm = this.fb.group({
			id: [""],
			name: [""],
			organisationId: [""],
			shotDescription: [""],
			longDescription: [""],
			offerType: [""],
			startDate: [""],
			endDate: [""],
			status: [""],
			htmlUrl: [""],
			smallIconUrl: [""],
			imageUrl: [""],
			offerCorporates: this.fb.array([]),
			confirmationMassage: [""],
			modifiedDate: [""],
			checkboxAllowed: [""],
			createdBy: [""],
			createdDate: [""],
			modifiedBy: [""],
		});
	}

	corporates(): FormArray {
		return this.offerForm.get("offerCorporates") as FormArray;
	}

	newCorporate(): FormGroup {
		return this.fb.group({
			company: "",
			discount_amount: "",
		});
	}

	addCorporate() {
		this.corporates().push(this.newCorporate());
	}

	removeCorporate(i: number) {
		this.corporates().removeAt(i);
	}

	clear() {
		this.createForm();
	}

	goBack() {
		this.router.navigateByUrl("adminPanel/offers");
	}

	getCorpObject() {
		const corpObject = {
			checkboxAllowed: this.offerForm.value.checkboxAllowed,
			confirmationMassage: this.offerForm.value.confirmationMassage,
			createdBy: this.offerForm.value.createdBy,
			createdDate: this.offerForm.value.createdDate,
			endDate: this.offerForm.value.endDate,
			htmlUrl: this.offerForm.value.htmlUrl,
			id: this.offerForm.value.id,
			imageUrl: this.offerForm.value.imageUrl,
			longDescription: this.offerForm.value.longDescription,
			modifiedBy: this.offerForm.value.modifiedBy,
			modifiedDate: this.offerForm.value.modifiedDate,
			name: this.offerForm.value.name,
			offerCorporates: this.getofferCropDetails(),
			offerType: this.offerForm.value.offerType,
			organisationId: this.offerForm.value.organisationId,
			shotDescription: this.offerForm.value.shotDescription,
			smallIconUrl: this.offerForm.value.smallIconUrl,
			startDate: this.offerForm.value.startDate,
			status: this.offerForm.value.status,
		};
		return corpObject;
	}

	getofferCropDetails() {
		if (this.offerForm.value.offerCorporates === []) {
			return "[]";
		} else {
			let data = JSON.stringify(
				JSON.stringify(this.offerForm.value.offerCorporates)
			);
			data = data.substring(1, data.length - 1);
			return data;
		}
	}
	submit() {
		this.showError = false;
		if (
			!this.offerForm.value.name ||
			!this.offerForm.value.shotDescription ||
			!this.offerForm.value.offerType ||
			!this.offerForm.value.startDate ||
			!this.offerForm.value.endDate ||
			!this.offerForm.value.checkboxAllowed ||
			!this.offerForm.value.confirmationMassage
		) {
			this.showError = true;
		} else {
			if (this.offerForm.value.startDate > this.offerForm.value.endDate) {
				alert("End date should be greater than start date");
				return;
			}
			if (this.offerId) {
				this.offerForm.patchValue({
					smallIconUrl: "",
					imageUrl: "",
					modifiedDate: new Date(),
					modifiedBy: this.loginEmployee.empId,
				});
				this.offersService
					.updateCropOffer(this.getCorpObject())
					.subscribe((data) => {
						this.router.navigateByUrl("adminPanel/offers");
					});
			} else {
				this.offerForm.patchValue({
					id: 0,
					createdBy: this.loginEmployee.empId,
					smallIconUrl: "",
					imageUrl: "",
					modifiedDate: new Date(),
					organisationId: this.loginEmployee.orgId,
					createdDate: new Date(),
				});
				this.offersService
					.createCropOffer(this.getCorpObject())
					.subscribe((data) => {
						this.router.navigateByUrl("adminPanel/offers");
					});
			}
		}
	}
}
