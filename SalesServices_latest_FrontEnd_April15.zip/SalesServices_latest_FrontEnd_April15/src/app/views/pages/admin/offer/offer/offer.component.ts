import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { OffersService } from "../../../../../core/e-commerce/_services/offers.service";
import { ActivatedRoute, Router } from "@angular/router";

@Component({
	selector: "kt-offer",
	templateUrl: "./offer.component.html",
	styleUrls: ["./offer.component.scss"],
})
export class OfferFromComponent implements OnInit {
	offerForm: FormGroup;
	loginEmployee: any;
	offerId: any;
	showError = false;
	offerType;
	offerTypes = [
		{ text: "Discount", value: "discount" },
		{ text: "Accessories", value: "accessories" },
	];
	statusValues = [
		{ text: "Active", value: "Active" },
		{ text: "InActive", value: "InActive" },
	];
	allowValues = [
		{ text: "Yes", value: true },
		{ text: "No", value: false },
	];
	constructor(
		private fb: FormBuilder,
		private offersService: OffersService,
		private route: ActivatedRoute,
		private router: Router
	) {}

	ngOnInit() {
		this.createForm();
		this.offerId = this.route.snapshot.paramMap.get("id");
		this.offerType = this.route.snapshot.paramMap.get("type");
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		if (this.offerId) {
			this.getOfferDetailsByid();
		} else {
			this.offerForm.patchValue({
				status: "Active",
				offerType: "discount",
				startDate: new Date(),
				checkboxAllowed: true,
			});
		}
	}

	goBack() {
		this.router.navigateByUrl("adminPanel/offers");
	}

	getOfferDetailsByid() {
		this.offersService
			.getOfferById(this.offerType, this.offerId)
			.subscribe((data) => {
				this.offerForm.patchValue(data.offerDetails[0]);
			});
	}

	createForm() {
		this.offerForm = this.fb.group({
			id: [""],
			offerName: [""],
			organisationId: [""],
			amount: [""],
			shotDescription: [""],
			longDescription: [""],
			offerType: [""],
			startDate: [""],
			end_date: [""],
			status: [""],
			smallIconUrl: [""],
			imageUrl: [""],
			htmlUrl: [""],
			confirmationMassage: [""],
			modifiedDate: [""],
			checkboxAllowed: [""],
			createdBy: [""],
			createdDate: [""],
			modifiedBy: [""],
		});
	}

	clear() {
		this.createForm();
	}

	submit() {
		this.showError = false;
		if (
			!this.offerForm.value.offerName ||
			!this.offerForm.value.amount ||
			!this.offerForm.value.shotDescription ||
			!this.offerForm.value.offerType ||
			!this.offerForm.value.startDate ||
			!this.offerForm.value.end_date ||
			!this.offerForm.value.checkboxAllowed ||
			!this.offerForm.value.confirmationMassage
		) {
			this.showError = true;
		} else {
			if (
				this.offerForm.value.startDate >
				this.offerForm.value.end_date
			) {
				alert("End date should be greater than start date");
				return;
			}
			if (this.offerId) {
				this.offerForm.patchValue({
					smallIconUrl: "",
					imageUrl: "",
					modifiedBy: this.loginEmployee.empId,
					modifiedDate: new Date(),
				});
				this.offersService
					.updateOffer(JSON.stringify(this.offerForm.value))
					.subscribe((data) => {
						this.router.navigateByUrl("adminPanel/offers");
					});
			} else {
				this.offerForm.patchValue({
					id: 0,
					createdBy: this.loginEmployee.empId,
					smallIconUrl: "",
					imageUrl: "",
					organisationId: this.loginEmployee.orgId,
					createdDate: new Date(),
					modifiedDate: new Date(),
				});
				this.offersService
					.createOffer(this.offerForm.value)
					.subscribe((data) => {
						this.router.navigateByUrl("adminPanel/offers");
					});
			}
		}
	}
}
