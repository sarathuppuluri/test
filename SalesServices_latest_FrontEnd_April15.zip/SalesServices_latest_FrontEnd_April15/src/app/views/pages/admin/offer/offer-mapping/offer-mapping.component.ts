import { Component, OnInit, ViewChild } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { OffersService } from "../../../../../core/e-commerce/_services/offers.service";
import { ActivatedRoute, Router } from "@angular/router";
import { MatOption, MatSelect } from "@angular/material";
import { Location } from "@angular/common";

@Component({
	selector: "kt-offer-mapping",
	templateUrl: "./offer-mapping.component.html",
	styleUrls: ["./offer-mapping.component.scss"],
})
export class OfferMappingComponent implements OnInit {
	offerMappingForm: FormGroup;
	loginEmployee: any;
	offerId: any;
	showError = false;

	isEdit: any;
	vehicles = [];
	varientsList = [];
	types = [
		{ text: "Corporate", value: "CORPORATE" },
		{ text: "General", value: "GENERAL" },
	];
	@ViewChild("allSelected", { static: false }) private allSelected: MatOption;
	constructor(
		private fb: FormBuilder,
		private offersService: OffersService,
		private route: ActivatedRoute,
		private router: Router,
		private location: Location
	) {}

	ngOnInit() {
		this.createForm();
		this.offerId = this.route.snapshot.paramMap.get("id");
		this.isEdit = this.route.snapshot.paramMap.get("isEdit");
		this.getVehicles();
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
	}

	tosslePerOne(all) {
		if (this.allSelected.selected) {
			this.allSelected.deselect();
			return false;
		}
		if (
			this.offerMappingForm.controls.varientId.value.length ===
			this.varientsList.length
		)
			this.allSelected.select();
	}

	goBack() {
		this.location.back();
	}

	toggleAllSelection() {
		if (this.allSelected.selected) {
			this.offerMappingForm.controls.varientId.patchValue([
				...this.varientsList.map((item) => item.id),
				0,
			]);
		} else {
			this.offerMappingForm.controls.varientId.patchValue([]);
		}
	}

	createForm() {
		this.offerMappingForm = this.fb.group({
			id: [""],
			offerId: [""],
			type: [""],
			varientId: [""],
			vehicleId: [""],
		});
	}

	getOfferDetailsByid() {
		this.offersService
			.getOfferMappingById(this.offerId)
			.subscribe((data) => {
				this.offerMappingForm.patchValue(data[0]);
				let Varientlist = [];
				if (data && data[0]) {
					data[0].varients.forEach((a) => {
						Varientlist.push(a.varientId);
					});
				}
				this.offerMappingForm.patchValue({ varientId: Varientlist });
				this.changeVechileModel();
			});
	}

	clear() {
		this.createForm();
	}

	getVehicles() {
		this.offersService.getVehicles().subscribe((data) => {
			this.vehicles = data;
			if (this.isEdit) {
				this.getOfferDetailsByid();
			}
		});
	}

	changeVechileModel() {
		this.varientsList = this.vehicles.filter(
			(a) => a.vehicleId === this.offerMappingForm.value.vehicleId
		)[0].varients;
	}

	getMappingObject() {
		let data = {
			allVarient: "",
			id: this.offerMappingForm.value.id,
			offerId: this.offerMappingForm.value.offerId,
			offerName: "",
			type: this.offerMappingForm.value.type,
			vehicleId: this.offerMappingForm.value.vehicleId,
			vehicleModel: this.getVehicleName(
				this.offerMappingForm.value.vehicleId
			),
			varients: this.getVarients(),
		};
		return data;
	}

	getVarients() {
		let data = [];
		this.offerMappingForm.value.varientId.forEach((a) => {
			data.push({ varientId: a, varientName: this.getVarientName(a) });
		});
		return data;
	}

	getVarientName(id) {
		return this.varientsList.filter((a) => a.id === id)[0].name;
	}

	getVehicleName(id) {
		return this.vehicles.filter((a) => a.vehicleId === id)[0].model;
	}

	submit() {
		this.showError = false;
		if (
			!this.offerMappingForm.value.vehicleId ||
			!this.offerMappingForm.value.vehicleId ||
			!this.offerMappingForm.value.vehicleId
		) {
			this.showError = true;
		} else {
			if (this.isEdit) {
				this.offersService
					.updateOfferMapping(JSON.parse(JSON.stringify(this.getMappingObject())))
					.subscribe((data) => {
						this.location.back();
					});
			} else {
				this.offerMappingForm.patchValue({
					id: 0,
					offerId: this.offerId,
				});
				this.offersService
					.createOfferMapping(JSON.parse(JSON.stringify(this.offerMappingForm.value)))
					.subscribe((data) => {
						this.location.back();
					});
			}
		}
	}
}
