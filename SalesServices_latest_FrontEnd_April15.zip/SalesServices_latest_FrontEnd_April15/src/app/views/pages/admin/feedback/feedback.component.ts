import { Component, OnInit } from "@angular/core";
import { FeedbackService } from "../../../../core/e-commerce/_services/feedback.service";

@Component({
	selector: "kt-feedback",
	templateUrl: "./feedback.component.html",
	styleUrls: ["./feedback.component.scss"],
})
export class FeedbackComponent implements OnInit {
	limit: number = 10;
	offset: number = 0;
	feedbackData;
	purposes = [];
	isLoading = false;
	scope;
	constructor(public feedbackService: FeedbackService) {}

	ngOnInit() {
		this.getFeedback();
	}

	getFeedback() {
		this.isLoading = true;
		this.feedbackService
			.getFeedbacks(this.limit, this.offset)
			.subscribe((data) => {
				this.isLoading = false;
				this.feedbackData = data.feedback.content;
				this.scope = data.feedback;
			});
	}

	paginatorEvents(event) {
		this.offset = event.pageIndex;
		this.limit = event.pageSize;
		this.getFeedback();
	}

}
