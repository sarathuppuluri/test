import { Component, OnInit, Inject, ChangeDetectorRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EnquiryService } from '../../../../../core/e-commerce';

@Component({
	selector: 'kt-finance-edit.dialog.component.ts',
	templateUrl: './finance-edit.dialog.component.ts.component.html',
	styleUrls: ['./finance-edit.dialog.component.ts.component.scss']
})
export class FinanceEditDialogComponent implements OnInit {
	crmUniversalId: any;
	EnquiryEditForm3: FormGroup;
	hasSubmitted: boolean;
	hasFormErrors: boolean;

	previewURL = [];
	docKeyNames = [];

	docsPath: any = {};
	leadObject: any = {};
	loginEmployee: any;

	documentsObject = [];
	// Lead Attachments Object
	tempObjDoc = {
		branchId: '',
		contentSize: 0,
		createdBy: Date.now(),
		description: '',
		documentNumber: '',
		documentPath: '',
		documentType: '',
		documentVersion: 0,
		fileName: '',
		gstNumber: '',
		id: 0,
		isActive: 0,
		isPrivate: 0,
		keyName: '',
		modifiedBy: '',
		orgId: '',
		ownerId: '',
		ownerName: '',
		parentId: '',
		tinNumber: ''
	};
	taskStatus = '';

	constructor(public dialogRef: MatDialogRef<FinanceEditDialogComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any,
		private fb: FormBuilder,
		private enquiryservice: EnquiryService,
		private changedetectorref: ChangeDetectorRef) {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
	}

	ngOnInit() {
		this.crmUniversalId = this.data.crmUniversalId;
		this.taskStatus = this.data.status;
		this.enquiryForm();
		this.getLeadDetailsUniversalId();
	}

	enquiryForm() {
		this.EnquiryEditForm3 = this.fb.group({
			employeeId: [''],
			employeeIdFileName: [''],
			payslips: [''],
			payslipsFileName: [''],
			form16: [''],
			form16FileName: [''],
			bankStatement: [''],
			bankStatementFileName: [''],
			birthCertificate: [''],
			birthCertificateFileName: [''],
			passport: [''],
			passportFileName: [''],
			appointmentLetter: [''],
			appointmentLetterFileName: [''],
			aadhar: [''],
			aadharFileName: [''],
			authorityLetter: [''],
			authorityLetterFileName: [''],
			auditedBalance: [''],
			auditedBalanceFileName: [''],
			profitLoss: [''],
			profitLossFileName: [''],
			addressProof: [''],
			addressProofFileName: [''],
			pattaPassBook: [''],
			pattaPassBookFileName: [''],
			kisancard: [''],
			kisancardFileName: [''],
		});
	}

	/**
	   * On destroy
	   */
	ngOnDestroy() { }

	/**
	   * Check control is invalid
	   * @param controlName: string
	   */
	isControlInvalid(controlName: string): boolean {
		const control = this.EnquiryEditForm3.controls[controlName];
		const result = control.invalid && control.touched;
		return result;
	}

	onSubmit() {
		this.hasSubmitted = true;
		this.hasFormErrors = false;
		const controls = this.EnquiryEditForm3.controls;
		if (this.EnquiryEditForm3.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		}

		this.updateLeadDetails(controls);
	}

	// Get Lead Details By UniversalID
	getLeadDetailsUniversalId() {
		this.enquiryservice.getLeadByUniversalID(this.crmUniversalId).subscribe(res => {
			if (!res) {
				return;
			}
			this.leadObject = res.dmsEntity;
			if (this.leadObject.dmsLeadDto.dmsAttachments.length > 0) {
				this.documentsObject = this.leadObject.dmsLeadDto.dmsAttachments;
				const customerDocs = this.leadObject.dmsLeadDto.dmsAttachments.reduce((acc, record) => {
					acc[record.documentType] = (record.documentNumber === '' ? record.fileName : record.documentNumber);
					acc[record.documentType + 'doc'] = record.documentPath;
					acc[record.documentType + 'key'] = record.keyName;
					return acc;
				}, {});
				const test = {
					employeeIdFileName: customerDocs.employeeId,
					payslipsFileName: customerDocs.payslips,
					form16FileName: customerDocs.form16,
					bankStatementFileName: customerDocs.bankStatement,
					birthCertificateFileName: customerDocs.birthCertificate,
					passportFileName: customerDocs.passport,
					appointmentLetterFileName: customerDocs.appointmentLetter,
					aadharFileName: customerDocs.aadhar,
					authorityLetterFileName: customerDocs.authorityLetter,
					auditedBalanceFileName: customerDocs.auditedBalance,
					profitLossFileName: customerDocs.profitLoss,
					addressProofFileName: customerDocs.addressProof,
					pattaPassBookFileName: customerDocs.pattaPassBook,
					kisancardFileName: customerDocs.kisancard
				};
				this.docsPath = {
					employeeIdPath: customerDocs.employeeIddoc,
					employeeIdKey: customerDocs.employeeIdkey,
					payslipsPath: customerDocs.payslipsdoc,
					payslipsKey: customerDocs.payslipskey,
					form16Path: customerDocs.form16doc,
					form16Key: customerDocs.form16key,
					bankStatementPath: customerDocs.bankStatementdoc,
					bankStatementKey: customerDocs.bankStatementkey,
					birthCertificatePath: customerDocs.birthCertificatedoc,
					birthCertificateKey: customerDocs.birthCertificatekey,
					passportPath: customerDocs.passportdoc,
					passportKey: customerDocs.passportkey,
					appointmentLetterPath: customerDocs.appointmentLetterdoc,
					appointmentLetterKey: customerDocs.appointmentLetterkey,
					aadharPath: customerDocs.aadhardoc,
					aadharKey: customerDocs.aadharkey,
					authorityLetterPath: customerDocs.authorityLetterdoc,
					authorityLetterKey: customerDocs.authorityLetterkey,
					auditedBalancePath: customerDocs.auditedBalancedoc,
					auditedBalanceKey: customerDocs.auditedBalancekey,
					profitLossPath: customerDocs.profitLossdoc,
					profitLossKey: customerDocs.profitLosskey,
					addressProofPath: customerDocs.addressProofdoc,
					addressProofKey: customerDocs.addressProofkey,
					pattaPassBookPath: customerDocs.pattaPassBookdoc,
					pattaPassBookKey: customerDocs.pattaPassBookkey,
					kisancardPath: customerDocs.kisancarddoc,
					kisancardKey: customerDocs.kisancardkey
				};
				this.previewURL[1] = this.docsPath.employeeIdPath;
				this.previewURL[2] = this.docsPath.payslipsPath;
				this.previewURL[3] = this.docsPath.form16Path;
				this.previewURL[4] = this.docsPath.bankStatementPath;
				this.previewURL[5] = this.docsPath.birthCertificatePath;
				this.previewURL[6] = this.docsPath.passportPath;
				this.previewURL[7] = this.docsPath.appointmentLetterPath;
				this.previewURL[8] = this.docsPath.aadharPath;
				this.previewURL[9] = this.docsPath.authorityLetterPath;
				this.previewURL[10] = this.docsPath.auditedBalancePath;
				this.previewURL[11] = this.docsPath.profitLossPath;
				this.previewURL[12] = this.docsPath.addressProofPath;
				this.previewURL[13] = this.docsPath.pattaPassBookPath;
				this.previewURL[14] = this.docsPath.kisancardPath;
				this.EnquiryEditForm3.patchValue(test);
			}
		});

		if (this.taskStatus === 'SENT_FOR_APPROVAL') {
			this.EnquiryEditForm3.disable();
		}
	}

	// Post Lead Details
	updateLeadDetails(controls) {
		this.leadObject.dmsLeadDto.dmsAttachments = this.documentsObject;

		this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
			if (res.statusCode !== 500) {
				this.leadObject = res.dmsEntity;
				this.documentsObject = this.leadObject.dmsLeadDto.dmsAttachments;
				this.hasSubmitted = false;
				this.changedetectorref.detectChanges();
				this.dialogRef.close({ res, isEdit: true });
			} else {
				this.hasSubmitted = false;
				this.changedetectorref.detectChanges();
			}
		});
	}

	// Lead Attachments Number Object
	documentNumber(type, docNumber) {
		const index = this.documentsObject.findIndex(element => element.documentType === type);
		if (index !== -1) {
			this.documentsObject[index].documentNumber = docNumber;
		} else {
			this.tempObjDoc.documentNumber = docNumber;
			this.tempObjDoc.documentType = type;
			this.tempObjDoc.id = 0;
			this.tempObjDoc.branchId = this.loginEmployee.branchId;
			this.tempObjDoc.orgId = this.loginEmployee.orgId;
			this.documentsObject.push(this.tempObjDoc);
		}
	}

	// File Upload for Lead Attachments
	onFileSelect(event, docType, formEle, i) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			this.EnquiryEditForm3.get(formEle).setValue(file.name);
			const formData = new FormData();
			formData.append('file', file);
			formData.append('universalId', this.crmUniversalId);
			formData.append('documentType', docType);
			this.enquiryservice.createCustomerDoc(formData).subscribe(res => {
				const index = this.documentsObject.findIndex(element => element.documentType === docType);
				if (index !== -1) {
					this.documentsObject[index].documentPath = res.documentPath;
					this.documentsObject[index].fileName = res.fileName;
					this.documentsObject[index].keyName = res.keyName;
				} else {
					this.tempObjDoc.documentPath = res.documentPath;
					this.tempObjDoc.documentType = docType;
					this.tempObjDoc.fileName = res.fileName;
					this.tempObjDoc.keyName = res.keyName;
					this.tempObjDoc.id = 0;
					this.tempObjDoc.branchId = this.loginEmployee.branchId;
					this.tempObjDoc.orgId = this.loginEmployee.orgId;
					this.tempObjDoc.modifiedBy = this.loginEmployee.empName;
					this.tempObjDoc.ownerName = this.loginEmployee.empName;
					let tempStuctObj = Object.assign({}, this.tempObjDoc);
					this.documentsObject.push(tempStuctObj);
					tempStuctObj = null;
				}
				this.previewURL[i] = res.documentPath;
				this.docKeyNames[i] = res.keyName;
				this.changedetectorref.detectChanges();
			});
		}
	}

	// Delete Documents from S3 Bucket
	deleteDocument(docName, formEle, i) {
		if (docName !== undefined) {
			this.enquiryservice.deleteDocument(docName).subscribe(res => {
				docName = undefined;
			}, (err) => {
				docName = undefined;
			});
		}
		this.EnquiryEditForm3.get(formEle).reset();
		this.documentsObject.forEach((element, index) => {
			if (element.documentPath.length === this.previewURL[i].length) {
				this.documentsObject.splice(index, 1);
			}
		});
		this.previewURL[i] = null;
	}

	/** Alect Close event */
	onAlertClose() {
		this.hasFormErrors = false;
	}

}
