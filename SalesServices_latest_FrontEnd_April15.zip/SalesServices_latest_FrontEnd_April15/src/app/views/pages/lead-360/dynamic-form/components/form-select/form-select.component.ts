import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';

@Component({
  selector: 'form-select',
  styleUrls: ['form-select.component.scss'],
  template: `
    <div class="col-12  row-space  dynamic-field form-select"  [formGroup]="group">
      <mat-form-field>
        <mat-label>{{ config.label }}</mat-label>
        <select #mySelect
        (change)='onOptionsSelected(mySelect.value)'
        [formControlName]="config.name" 
         matNativeControl>
          <option value="">{{ config.placeholder }}</option>
          <option *ngFor="let option of config.options" [ngValue] ="option">
            {{ option }}
          </option>
        </select>
      </mat-form-field>
    </div>
  `
})
export class FormSelectComponent implements Field {
  config: FieldConfig;
  group: FormGroup;

  onOptionsSelected(value) {
  }
}
