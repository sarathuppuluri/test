  export class TestDriveDialogData {
	constructor(
		private mobileNo: number,
		private modelName: string,
		private crmUniversalId: string,
		private entityModuleId: string,		
		private response: any,
	) { }
}

  