import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
	selector: 'kt-verify-docs-editdialog',
	templateUrl: './verify-docs-edit.dialog.component.html',
	styleUrls: ['./verify-docs-edit.dialog.component.scss']
})
export class VerifyDocsEditDialogComponent implements OnInit {
	hasSubmitted: boolean;
	univId: string;
	constructor(public dialogRef: MatDialogRef<VerifyDocsEditDialogComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any) {
			this.univId = this.data.crmUniversalId;
		}

	ngOnInit() {
	}

}
