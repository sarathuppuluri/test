import { Component, OnInit, Inject } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { QueryParamsModel } from "../../../../core/_base/crud";
import { BookingTestDriveService, PreenquiryService } from "../../../../core/e-commerce/_services";
import {
	MatDialogRef,
	MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { MatSnackBar } from "@angular/material/snack-bar";
import moment from "moment";

export interface DialogData {
	id: number;
	firstName: string;
	lastName: string;
	middleName: string;
	customerDetails: any;
	modelDetails: any;
	dmsAddresses: any;
	crmUniversalId: string;
	entityModuleId: string;
}

@Component({
	selector: "kt-tdtestappointment",
	templateUrl: "./tdappointment.component.html",
	styleUrls: ["./tdappointment.component.scss"],
})
export class TdTestappointmentComponent implements OnInit {
	requestForm: FormGroup;
	leadObj: any;

	models = [];
	fuelTypes = [];
	transmissionTypes = [];
	varients = [];
	vehicles = [];
	vehicleId: number;
	varientId: number;
	crmUniversalId: string;
	documentPaths: string[] = [];
	testDriveId: string;
	testDrive;
	allotments = [];
	dseEmployees = [];
	drivers = [];
	loginEmployee: any = JSON.parse(localStorage.getItem("loginEmployee"));
	role: string; //= this.loginEmployee.empId//this.loginEmployee.hrmsRole;
	isManager: boolean = false;
	branchId = this.loginEmployee.branchId;
	orgId = this.loginEmployee.orgId;
	reportingManger = this.loginEmployee.reportingManagerId;
	cancelledFlag: boolean = false;
	minDate = new Date();
	timeValidationMsg: string;

	constructor(
		public testDriveService: BookingTestDriveService,
		private fb: FormBuilder,
		private preenquiryService: PreenquiryService,
		private _snackBar: MatSnackBar,
		public dialogRef: MatDialogRef<TdTestappointmentComponent>,
		@Inject(MAT_DIALOG_DATA) public data: DialogData
	) {
		this.role = this.loginEmployee.roles.find(
			(role: string) =>
				role === "Testdrive_DSE" || role === "Testdrive_Manager"
		);
		this.isManager = !!this.loginEmployee.roles.find(
			(role: string) => role === "Testdrive_Manager"
		);
		if (this.role) {
			this.initForm();
		} else {
			alert(
				"Employee does not have sufficient privileges(roles) to view TestDrive."
			);
			this.dialogRef.close();
		}
		this.leadObj = data;
	}

	ngOnInit() {
		this.getEmployees();
		this.requestForm.controls['mobile'].setValue(this.leadObj.mobileNo);
		this.requestForm.controls['name'].setValue(this.leadObj.firstname);
		this.requestForm.controls['model'].setValue(this.leadObj.modelName);
		this.requestForm.controls['email'].setValue(this.leadObj.email);

		this.crmUniversalId = this.leadObj.crmUniversalId;

		if (this.leadObj.entityModuleId) {
			this.testDriveId = this.leadObj.entityModuleId;
		} else {
			this.testDriveId = "0";
		}
		if (this.testDriveId !== "0") {
			this.patchForm();
		} else {
			this.getLookups();
		}
	}
	public closeMatDialog() {
		this.dialogRef.close("");
	}

	public initForm() {
		this.requestForm = this.fb.group({
			mobile: [""],
			name: [""],
			email: [""],
			model: ["", Validators.required],
			fuel: ["", Validators.required],
			ttype: ["", Validators.required],
			varient: ["", Validators.required],
			prefferedDate: ["", Validators.required],
			prefferedTime: ["", Validators.required],
			actualStartTime: ["", Validators.required],
			actualEndTime: ["", Validators.required],
			customerHaveingDl: ["", Validators.required],
			file: [],
			address: [],
			location: ["", Validators.required],
			dseId: [""],
			customerQuery: [],
			driverId: [],
		});
	}

	/**
	 * This method is used for disabling the form on based on the role and satus of the test drive
	 */
	public checkForDisable() {
		let disabled = false;
		if (
			this.role === "Testdrive_DSE" ||
			this.role === "Testdrive_Manager"
		) {
			if (this.testDrive && (this.testDrive.status === "APPROVED" || this.testDrive.status === "SENT_FOR_APPROVAL")) {
				return true;
			}
		}
		return disabled;
	}

	/**
	 * this method is for search the customer by mobile number.
	 */
	public checkForPerson() {
		if (this.leadObj.entityModuleId) {
			return false;
		}
		const queryParams = new QueryParamsModel({}, "", "", 0, 1);
		this.preenquiryService
			.getSearchResultsPreEnquiry(
				this.requestForm.value.mobile,
				null,
				"ENQUIRY",
				queryParams,
				this.loginEmployee.empId
			)
			.subscribe((res) => {
				if (res.dmsEntity) {
					let customer = res.dmsEntity.leadDtoPage.content[0];
					this.requestForm.controls["name"].setValue(
						customer.firstName
					);
					this.crmUniversalId = customer.universalId;
					this.requestForm.controls.model.setValue(customer.model);
					this.requestForm.controls.email.setValue(customer.email);
					this.modelChange();
				} else {
					this.openSnackBar(res.message, "fail");
				}
			});
	}

	/**
	 * this method is for the auto assign of fuel type, transmission type and varient when there is a change in Model.
	 */
	public modelChange() {
		this.vehicles.forEach((vehicle) => {
			if (vehicle.vehicleInfo.model === this.requestForm.value.model) {
				this.fuelTypes.push({
					value: vehicle.vehicleInfo.fuelType,
				});
				this.transmissionTypes.push({
					value: vehicle.vehicleInfo.transmission_type,
				});
				this.varients.push({
					value: vehicle.vehicleInfo.varientName,
				});
				this.vehicleId = vehicle.id;
				this.varientId = vehicle.varientId;
			}
		});
	}

	/**
	 * this method for the getting the demo vehicles list.
	 */
	public getLookups() {
		this.testDriveService.getLookups().subscribe(
			(res) => {
				if (res.vehicles) {
					this.vehicles = res.vehicles;
					this.vehicles.forEach((vehicle) => {
						this.models.push({
							value: vehicle.vehicleInfo.model,
						});
					});
					this.modelChange();
				} else {
					this.openSnackBar("No Vehicles are available.", "Fail");
				}
			},
			(error) => {
				this.openSnackBar(
					error.error["message"],
					error.error["status"]
				);
			}
		);
	}

	/**
	 * this method for the checking the allotment on the customer prefferd date
	 */
	public checkAllotment() {
		if (this.vehicleId) {
			const d = moment(this.requestForm.value.prefferedDate).format(
				"DD-MM-YYYY"
			);
			this.testDriveService.checkAllotment(d, this.vehicleId).subscribe(
				(res) => {
					this.allotments = res.vehicleAllotments
						? res.vehicleAllotments
						: [];
				},
				(error) => {
					this.openSnackBar(
						error.error["message"],
						error.error["status"]
					);
				}
			);
		}
	}

	/**
	 *
	 * @param event files that are selected from the file chooser which contains the license images.
	 */
	public onFileSelected(event) {
		this.documentPaths = [];
		if (event.target.files.length <= 2) {
			let formData = new FormData();
			formData.append("file", event.target.files[0]);
			formData.append("universalId", this.crmUniversalId);
			formData.append("documentType", "License");
			this.testDriveService.uploadFiles(formData).subscribe(
				(res) => {
					this.documentPaths.push(res.documentPath);
				},
				() => {
					this.openSnackBar("Error in uploading Image", "Fail");
				}
			);
			if (event.target.files.length === 2) {
				let formData = new FormData();
				formData.append("file", event.target.files[1]);
				formData.append("universalId", this.crmUniversalId);
				formData.append("documentType", "License");
				this.testDriveService.uploadFiles(formData).subscribe(
					(res) => {
						this.documentPaths.push(res.documentPath);
					},
					() => {
						this.openSnackBar("Error in uploading Image", "Fail");
					}
				);
			}
		} else {
			alert("Only 2 Files are allowed");
		}
	}

	/**
	 * this method is the validating the customer preffered date and time with current date and time
	 */
	public validateCustomerPrefferedTime() {
		if (
			this.requestForm.controls.prefferedDate.value &&
			this.requestForm.controls.prefferedTime.value
		) {
			const customerDate = this.formatDateTime(
				this.requestForm.controls.prefferedDate.value,
				this.requestForm.controls.prefferedTime.value
			);
			const currentDate = moment();
			if (moment(customerDate).isBefore(currentDate)) {
				this.timeValidationMsg =
					"Customer preffered Time should be greater than Current Time.";
			} else {
				this.timeValidationMsg = "";
			}
		}
	}

	/**
	 * this method is for validating the actual start date time with customer preffered date time
	 */
	public validateCustomerActualStartTime() {
		if (
			this.requestForm.controls.prefferedTime.value &&
			this.requestForm.controls.actualStartTime.value
		) {
			const customerPrefferedTime = this.formatDateTime(
				this.requestForm.controls.prefferedDate.value,
				this.requestForm.controls.prefferedTime.value
			);
			const actualStartTime = this.formatDateTime(
				this.requestForm.controls.prefferedDate.value,
				this.requestForm.controls.actualStartTime.value
			);
			if (moment(customerPrefferedTime).isBefore(actualStartTime)) {
				this.timeValidationMsg =
					"Customer preffered Time should be less than Actual Start Time.";
			} else {
				this.timeValidationMsg = "";
			}
		}
	}

	/**
	 * This method is for the validating actual start time and actual end time
	 */
	public validateCustomerActualEndTime() {
		if (
			this.requestForm.controls.prefferedTime.value &&
			this.requestForm.controls.actualStartTime.value &&
			this.requestForm.controls.actualEndTime.value
		) {
			const startTime = this.formatDateTime(
				this.requestForm.controls.prefferedDate.value,
				this.requestForm.controls.actualStartTime.value
			);
			const endTime = this.formatDateTime(
				this.requestForm.controls.prefferedDate.value,
				this.requestForm.controls.actualEndTime.value
			);
			if (moment(startTime).isBefore(endTime)) {
				this.timeValidationMsg = "";
			} else {
				this.timeValidationMsg =
					"End Time should not be less than Start Time";
			}
		}
	}

	public formatTimeValue(value) {
		return value.toString().length < 2 ? "0" + value : value;
	}

	public submit() {
		if (this.requestForm.valid && !this.timeValidationMsg) {
			//this.varientId = vehicle.varientId;
			if (!this.vehicleId) {
				this.openSnackBar("Please select the Model", "");
				return 0;
			}
			if (!this.varientId) {
				this.openSnackBar("Please select the Varient", "");
				return 0;
			}
			const requestBody = this.requestBodyConstruct();
			this.testDriveService
				.submitAppointmentRequest(requestBody)
				.subscribe(
					(res: any) => {
						if (res.status === "SUCCESS") {
							this.openSnackBar(
								"Appointment has been created successfully.",
								"success"
							);
							this.updateTask(
								res.confirmationId,
								"SENT_FOR_APPROVAL",
								"Success",
								"Test Drive"
							);
						} else if (res.status === "FAILURE") {
							this.openSnackBar(res.statusDescription, "fail");
						} else {
							this.openSnackBar(res.statusCode, "fail");
						}
					},
					() => {
						this.openSnackBar("Sever is down", "Fail");
					}
				);
		}
	}
	/**
	 * this method for task update.
	 */
	public updateTask(confirmationId, status, remarks, taskName) {
		const requestBody = {
			universalId: this.crmUniversalId,
			taskId: null,
			remarks: remarks ? remarks : "",
			universalModuleId: confirmationId,
			expectedStarttime: this.formatDateTime(
				this.requestForm.controls.prefferedDate.value,
				this.requestForm.controls.actualStartTime.value
			).format(),
			status,
			taskName,
			expectedEndTime: this.formatDateTime(
				this.requestForm.controls.prefferedDate.value,
				this.requestForm.controls.actualEndTime.value
			).format(),
		};

		this.testDriveService.updateTask(requestBody).subscribe(
			(res: any) => {
				if (res.success) {
					this.openSnackBar(
						"Confirmation Id updated in task.",
						"success"
					);
					this.dialogRef.close("success");
				} else if (res.statusCode === 500) {
					this.openSnackBar(
						"Internal server error, statusCode:500 ",
						"fail"
					);
				} else {
					this.openSnackBar(res.errorMessage, "fail");
				}
			},
			() => {
				this.openSnackBar("Server is down", "Fail");
			}
		);
	}
	/**
	 *
	 * @param requestBody contains the updated testdrive data
	 * this method is used for the update the testdrive
	 */
	public updateAppointment(requestBody, status, remarks?) {
		this.testDriveService.updateAppointmentRequest(requestBody).subscribe(
			(res: any) => {
				if (res.status === "SUCCESS") {
					this.updateTask(
						res.confirmationId,
						status,
						remarks,
						"Test Drive Approval"
					);
				} else {
					this.openSnackBar("Failed to update the Testdrive", "Fail");
				}
			},
			() => {
				this.openSnackBar("Server is down", "Fail");
			}
		);
	}

	/**
	 *
	 * @param documentName conatins the document Name that needs to be deleted.
	 */
	public deleteDocument(docName, index) {
		const confirmDialog = window.confirm(
			"Are you sure to delete the document?"
		);
		this.documentPaths[index] = '';
	}

	/**
	 * this method for approve the test drive by manager and manger can update the info and directly approve the test drive.
	 */
	public approve() {
		if (!this.timeValidationMsg) {
			let requestBody: any = this.requestBodyConstruct();
			requestBody = this.updateData(requestBody);
			requestBody.appointment.status = "APPROVED";
			requestBody.appointment.managerApprovedDatetime = moment().format(
				"DD-MM-YYYY hh:mm:ss"
			);
			this.updateAppointment(requestBody, "APPROVED");
		}
	}

	/**
	 * this method is for update the test drive who has role DSE
	 */
	public update() {
		if (!this.timeValidationMsg) {
			let requestBody: any = this.requestBodyConstruct();
			requestBody = this.updateData(requestBody);
			this.updateAppointment(requestBody, "SENT_FOR_APPROVAL");
		}
	}

	public checkout() {
		if (this.requestForm.valid && !this.timeValidationMsg) {
			let requestBody: any = this.requestBodyConstruct();
			requestBody = this.updateData(requestBody);
			requestBody.appointment.managerApprovedDatetime = this.testDrive.managerApprovedDatetime;
			requestBody.appointment.managerId = this.testDrive.managerId;
			requestBody.appointment.securityOutId = JSON.parse(
				localStorage.getItem("loginEmployee")
			);
			requestBody.appointment.customerPickupDatetime =
				this.formatDate(new Date()) + this.formatTime(new Date());
			this.testDriveService
				.updateAppointmentRequest(requestBody)
				.subscribe(
					(res: any) => {
						this.openSnackBar(res, "updateAppointmentRequest");
					},
					() => {
						this.openSnackBar("Server is down", "Fail");
					}
				);
		}
	}

	public checkIn() {
		if (this.requestForm.valid && !this.timeValidationMsg) {
			const requestBody: any = this.requestBodyConstruct();
			requestBody.appointment.securityInId = JSON.parse(
				localStorage.getItem("loginEmployee")
			);
			requestBody.appointment.customerDropDatetime = new Date();
			this.testDriveService
				.updateAppointmentRequest(requestBody)
				.subscribe(
					(res: any) => {
						this.openSnackBar(res, "updateAppointmentRequest");
					},
					() => {
						this.openSnackBar("Server is down", "Fail");
					}
				);
		}
	}

	/**
	 * this method is for the cancel / reject the testdrive and to show the remarks input.
	 */
	public cancel() {
		this.cancelledFlag = true;
	}
	/**
	 * this method is for the submit the remarks
	 */
	public submitRemarks() {
		if (!this.timeValidationMsg) {
			let requestBody: any = this.requestBodyConstruct();
			requestBody = this.updateData(requestBody);
			requestBody.appointment.customerQuery = this.requestForm.value.customerQuery;
			requestBody.appointment.canceledBy = "MANAGER";
			requestBody.appointment.status = "CANCELLED";
			this.updateAppointment(
				requestBody,
				"CANCELLED",
				this.requestForm.value.customerQuery
			);
		}
	}

	/**
	 * this method is for the reschedule the testdrive
	 */
	public reSchedule() {
		if (!this.timeValidationMsg) {
			let requestBody: any = this.requestBodyConstruct();
			requestBody = this.updateData(requestBody);
			if (this.role === "Testdrive_Manager") {
				this.approve();
			} else {
				requestBody.appointment.status = "SENT_FOR_APPROVAL";
				requestBody.appointment.managerApprovedDatetime = this.testDrive.managerApprovedDatetime;
				this.updateAppointment(requestBody, "SENT_FOR_APPROVAL");
			}
		}
	}

	public closeTestDrive() {
		if (!this.timeValidationMsg) {
			let requestBody: any = this.requestBodyConstruct();
			requestBody = this.updateData(requestBody);
			requestBody.appointment.status = "CLOSED";
			requestBody.appointment.managerApprovedDatetime = this.testDrive.managerApprovedDatetime;
			this.updateAppointment(requestBody, "CLOSED");
		}
	}

	/**
	 *
	 * @param requestBody contains the existed test drive info and setting some more fields.
	 */
	public updateData(requestBody) {
		requestBody.appointment.testdriveId = parseInt(this.testDriveId);
		requestBody.appointment.customerId = this.testDrive.customerId;
		requestBody.appointment.status = this.testDrive.status;
		requestBody.appointment.datetime = this.testDrive.datetime;
		requestBody.appointment.dseId = this.testDrive.dseId;
		requestBody.appointment.managerId = this.testDrive.managerId;
		return requestBody;
	}

	public formatDate(date) {
		let d = new Date(date),
			month = '' + (d.getMonth() + 1),
			day = '' + d.getDate(),
			year = d.getFullYear();

		if (month.length < 2) month = "0" + month;
		if (day.length < 2) day = "0" + day;

		return [day, month, year].join("-");
	}

	public formatTime(date) {
		let d = new Date(date),
			hour = " " + d.getHours(),
			minutes = d.getMinutes(),
			seconds = d.getSeconds();

		return [hour, minutes, seconds].join(":");
	}
	/**
	 *
	 * @param date date to format
	 * @param time time to format
	 * this method is for format the date and time by moment
	 */
	public formatDateTime(date, time) {
		const dt = new Date(date);
		dt.setHours(time.hour);
		dt.setMinutes(time.minute);
		time.second ? dt.setSeconds(time.second) : "";
		return moment(dt);
	}

	/**
	 *
	 * @param date contains the data
	 */
	public deFormatDate(date) {
		const d = date.split("-");
		const dt = new Date();
		dt.setDate(d[0]);
		dt.setMonth(d[1] - 1);
		dt.setFullYear(d[2]);
		return dt;
	}

	/**
	 * this method is for get the employees list based on reole name i.e DSE, Driver
	 */
	public getEmployees() {
		this.testDriveService.getEmployees("Testdrive_DSE").subscribe(
			(response) => {
				if (response.dmsEntity) {
					this.dseEmployees = response.dmsEntity.employees;
					const dseEmp = this.dseEmployees.find(
						(emp) => emp.empId === this.loginEmployee.empId
					);
					if (dseEmp) {
						this.requestForm.controls.dseId.setValue(dseEmp.empId);
					}
				}
			},
			(error) => {
				this.openSnackBar(
					error.error["message"],
					error.error["status"]
				);
			}
		);
		this.testDriveService.getEmployees("Driver").subscribe(
			(response) => {
				this.drivers = response.dmsEntity.employees;
			},
			(error) => {
				this.openSnackBar(
					error.error["message"],
					error.error["status"]
				);
			}
		);
	}

	public requestBodyConstruct() {
		const rqstBody = {
			appointment: {
				address: this.requestForm.controls.address.value,
				branchId: parseInt(this.branchId),
				customerHaveingDl:
					this.requestForm.controls.customerHaveingDl.value === "Yes"
						? true
						: false,
				customerId: this.crmUniversalId,
				dlBackUrl: this.documentPaths.length
					? this.documentPaths[0]
					: "",
				dlFrontUrl: this.documentPaths.length
					? this.documentPaths[1]
					: "",
				dseId: !this.requestForm.controls.dseId.value
					? this.loginEmployee.empId
					: this.requestForm.controls.dseId.value,
				endTime: this.formatDateTime(
					this.requestForm.controls.prefferedDate.value,
					this.requestForm.controls.actualEndTime.value
				).format("DD-MM-YYYY hh:mm:ss"),
				location: this.requestForm.controls.location.value,
				orgId: parseInt(this.orgId),
				source: "ShowroomWalkin",
				startTime: this.formatDateTime(
					this.requestForm.controls.prefferedDate.value,
					this.requestForm.controls.actualStartTime.value
				).format("DD-MM-YYYY hh:mm:ss"),
				testDriveDatetime: this.formatDateTime(
					this.requestForm.controls.prefferedDate.value,
					this.requestForm.controls.prefferedTime.value
				).format("DD-MM-YYYY hh:mm:ss"),
				testdriveId: 0,
				status: this.isManager ? "APPROVED" : "SENT_FOR_APPROVAL",
				varientId: this.varientId,
				vehicleId: this.vehicleId,
				driverId: this.requestForm.controls.driverId.value,
			},
		};
		return rqstBody;
	}

	public patchForm() {
		this.testDriveService.getAppointmentRequest(this.testDriveId).subscribe(
			(res) => {
				this.testDrive = res.testDrives[0];
				this.crmUniversalId = this.testDrive.customerId;
				if (this.testDrive) {
					this.requestForm.controls["location"].setValue(
						this.testDrive.location
					);
					if (this.testDrive.location === "customer") {
						this.requestForm.controls["address"].setValue(
							this.testDrive.address
						);
					}
					this.requestForm.controls["customerHaveingDl"].setValue(
						this.testDrive.customerHaveingDl ? "Yes" : "No"
					);
					if (this.testDrive.customerHaveingDl) {
						this.documentPaths.push(
							this.testDrive.dlFrontUrl,
							this.testDrive.dlBackUrl
						);
					}
					if (this.testDrive.testDriveDatetime) {
						const prD = this.testDrive.testDriveDatetime.split(" ");
						this.requestForm.controls["prefferedDate"].setValue(
							this.deFormatDate(prD[0])
						);
						this.requestForm.controls["prefferedTime"].setValue({
							hour: parseInt(prD[1].split(":")[0]),
							minute: parseInt(prD[1].split(":")[1]),
						});
						this.vehicleId = this.testDrive.vehicleId;
						this.varientId = this.testDrive.varientId;
						this.checkAllotment();
					}
					if (this.testDrive.startTime) {
						const acD = this.testDrive.startTime.split(" ");
						this.requestForm.controls["actualStartTime"].setValue({
							hour: parseInt(acD[1].split(":")[0]),
							minute: parseInt(acD[1].split(":")[1]),
						});
					}
					if (this.testDrive.endTime) {
						const acED = this.testDrive.endTime.split(" ");
						this.requestForm.controls["actualEndTime"].setValue({
							hour: parseInt(acED[1].split(":")[0]),
							minute: parseInt(acED[1].split(":")[1]),
						});
					}
					this.models.push({
						value: this.testDrive.vehicleInfo.model,
					});
					this.requestForm.controls["model"].setValue(
						this.testDrive.vehicleInfo.model
					);
					this.fuelTypes.push({
						value: this.testDrive.vehicleInfo.fuelType,
					});
					this.requestForm.controls["fuel"].setValue(
						this.testDrive.vehicleInfo.fuelType
					);
					this.transmissionTypes.push({
						value: this.testDrive.vehicleInfo.transmission_type,
					});
					this.requestForm.controls["ttype"].setValue(
						this.testDrive.vehicleInfo.transmission_type
					);

					this.varients.push({
						value: this.testDrive.vehicleInfo.varientName,
					});
					this.requestForm.controls["customerQuery"].setValue(
						this.testDrive.customerQuery
					);
					this.requestForm.controls["varient"].setValue(
						this.testDrive.vehicleInfo.varientName
					);
					if (this.testDrive.customerInfo) {
						if (this.testDrive.customerInfo.mobile != null) {
							this.requestForm.controls["mobile"].setValue(
								this.testDrive.customerInfo.mobile
							);
						}

						if (this.testDrive.customerInfo.mobile != null) {
							this.requestForm.controls["name"].setValue(
								this.testDrive.customerInfo.name
							);
						} else {
							this.requestForm.controls["name"].setValue(
								this.testDrive.customerInfo.id
							);
						}

						this.requestForm.controls["email"].setValue(
							this.testDrive.customerInfo.email
						);
					}
				}
			},
			(error) => {
				alert(
					"patchForm getAppointmentRequest==>" + error.error.message
				);
			}
		);
	}

	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 3000,
		});
	}
}
