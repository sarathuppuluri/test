import { TestBed } from '@angular/core/testing';

import { PcDialogService } from './pc-dialog.service';

describe('PcDialogService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PcDialogService = TestBed.get(PcDialogService);
    expect(service).toBeTruthy();
  });
});
