import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingleadsComponent } from './bookingleads.component';

describe('BookingleadsComponent', () => {
  let component: BookingleadsComponent;
  let fixture: ComponentFixture<BookingleadsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookingleadsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingleadsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
