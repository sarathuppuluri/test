import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'kt-booking',
    templateUrl: './bookingmain.component.html'
})
export class BookingMainComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
