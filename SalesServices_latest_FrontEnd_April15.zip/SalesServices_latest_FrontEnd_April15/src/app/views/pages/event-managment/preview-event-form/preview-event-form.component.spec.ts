import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreviewEventFormComponent } from './preview-event-form.component';

describe('PreviewEventFormComponent', () => {
  let component: PreviewEventFormComponent;
  let fixture: ComponentFixture<PreviewEventFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreviewEventFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreviewEventFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
