import {
	Component,
	OnInit,
	Injectable,
	ChangeDetectorRef,
} from "@angular/core";
import { EventManagementService } from "../../../../core/e-commerce/_services/event-management.service";
import { QueryParamsModel } from "../../../../core/_base/crud";
import { Router } from "@angular/router";
import { DatePipe } from "@angular/common";
import { FormGroup, FormBuilder } from "@angular/forms";

@Injectable()
@Component({
	selector: "kt-preview-event-form",
	templateUrl: "./preview-event-form.component.html",
	styleUrls: ["./preview-event-form.component.scss"],
	providers: [DatePipe],
})
export class PreviewEventFormComponent implements OnInit {
	getEventShedule: any;
	page = 0;
	pageSize = 1;
	assessmentSetails;
	billUploadForm: FormGroup;
	loginEmployee: any;
	flag = true;
	documentPaths = [];
	eventImagesPaths = [];

	constructor(
		private fb: FormBuilder,
		private changedetectorref: ChangeDetectorRef,
		private event: EventManagementService,
		private router: Router
	) {}

	ngOnInit() {
		this.createForm();
		window.onload = (event) => {
			this.router.navigate(["eventManagement/evenManagement"]);
		};
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.flag = false;
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize
		);
		this.getDocuments();
		this.getEventDocuments();
		this.event
			.getEventShedule(
				this.event.eventId,
				queryParams,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res) => {
				this.getEventShedule = res[0];
				this.flag = true;
			});
	}
	createForm() {
		this.billUploadForm = this.fb.group({
			bills: [""],
			billFileName: [""],
			billName: [""],
			billNo: [""],
			billAmount: [""],
			eventImages: [""],
		});
	}
	deleteDocument(document) {
		this.event
			.deleteDocument(this.event.eventId, document.billNo, document.image)
			.subscribe(
				(data) => {
					this.getDocuments();
				},
				(err) => {
					this.getDocuments();
				}
			);
	}
	deleteEventDocument(document) {
		this.event
			.deleteEventDocument(
				this.event.eventId,
				this.loginEmployee.orgId,
				document.image,
				1
			)
			.subscribe(
				(data) => {
					this.getEventDocuments();
					this.changedetectorref.detectChanges();
				},
				(err) => {
					this.getEventDocuments();
				}
			);
	}
	getDocuments() {
		this.event.getDocuments(this.event.eventId).subscribe((data) => {
			if (data) {
				this.documentPaths = [];
				data.forEach((obj) => {
					obj.documentList.forEach((path) => {
						this.documentPaths.push({
							image: path,
							billNo: obj.billNo,
							billName: obj.billName,
							billAmount: obj.billAmount,
						});
					});
				});
				this.changedetectorref.detectChanges();
			}
		});
	}
	getEventDocuments() {
		this.event
			.getEventDocuments(this.event.eventId, 1, this.loginEmployee.orgId)
			.subscribe((data) => {
				this.eventImagesPaths = [];
				if (data && data.documentList) {
					this.eventImagesPaths = [];
					data.documentList.forEach((obj) => {
						this.eventImagesPaths.push({
							image: obj,
						});
					});
					this.changedetectorref.detectChanges();
				}
			});
	}
	showUpload() {
		if (
			!this.billUploadForm.value.billName ||
			!this.billUploadForm.value.billNo ||
			!this.billUploadForm.value.billAmount
		) {
			return false;
		}
		return true;
	}
	edit() {
		this.event.formResetCheck = true;
		this.router.navigate(["/eventManagement/evenManagement/createEvent"]);
	}
	delete() {
		this.event
			.deleteEventShedules(
				this.event.eventId,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res) => {
				const queryParams = new QueryParamsModel(
					{},
					"",
					"",
					this.page,
					this.pageSize
				);
				this.event.getAllEventShedules(
					this.loginEmployee.orgId,
					this.loginEmployee.branchId,
					queryParams
				);
				this.router.navigate(["/eventManagement/evenManagement"]);
			});
	}

	onFileSelect(event) {
		const date = new Date().toDateString();
		if (event.target.files.length > 0) {
			const formData = new FormData();
			formData.append("eventId", this.event.eventId);
			formData.append("branchId", "1");
			formData.append("orgid", this.loginEmployee.orgId);
			formData.append("billNo", this.billUploadForm.value.billNo);
			formData.append("billName", this.billUploadForm.value.billName);
			formData.append("billAmount", this.billUploadForm.value.billAmount);
			formData.append("createdDateTime", date);
			formData.append("modifiedDateTime", date);
			const docLength = event.target.files.length - 1;
			for (let i = 0; i <= docLength; i++) {
				formData.append("billImages", event.target.files[i]);
				formData.append("documentTypes", event.target.files[i].type);
				this.event.uploadDocument(formData).subscribe((data) => {
					if (i === docLength) {
						this.getDocuments();
						this.billUploadForm.reset();
					}
				});
				formData.delete("billImages");
				formData.delete("documentTypes");
			}
		}
	}

	onEventFileSelect(event) {
		const date = new Date().toDateString();
		if (event.target.files.length > 0) {
			const formData = new FormData();
			formData.append("eventId", this.event.eventId);
			formData.append("branchId", "1");
			formData.append("orgid", this.loginEmployee.orgId);
			formData.append("createdDateTime", date);
			formData.append("modifiedDateTime", date);
			const docLength = event.target.files.length - 1;
			for (let i = 0; i <= docLength; i++) {
				formData.append("eventImages", event.target.files[i]);
				formData.append("documentTypes", event.target.files[i].type);
				this.event.uploadEventDocument(formData).subscribe((data) => {
					if (i === docLength) {
						this.getEventDocuments();
					}
				});
				formData.delete("eventImages");
				formData.delete("documentTypes");
			}
		}
	}
}

