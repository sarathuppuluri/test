import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DropAnalysisComponent } from './drop-analysis.component';

describe('DropAnalysisComponent', () => {
  let component: DropAnalysisComponent;
  let fixture: ComponentFixture<DropAnalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DropAnalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DropAnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
