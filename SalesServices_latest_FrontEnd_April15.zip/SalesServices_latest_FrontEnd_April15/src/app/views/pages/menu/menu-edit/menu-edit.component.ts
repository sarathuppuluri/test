import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// Material
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'kt-menu-edit',
  templateUrl: './menu-edit.component.html',
  styleUrls: ['./menu-edit.component.scss']
})
export class MenuEditComponent implements OnInit {

  menuEdit: any;
  menuEditForm: FormGroup;
  hasFormErrors = false;

  constructor(public dialogRef: MatDialogRef<MenuEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder) { }

  ngOnInit() {
    this.menuEdit = this.data.menuData;
    this.createForm();
  }

  createForm() {
    this.menuEditForm = this.fb.group({
      displayName: [this.menuEdit.displayName, Validators.required],
      description: [this.menuEdit.description]
    });
  }

  /**
	 * Check control is invalid
	 * @param controlName: string
	 */
  isControlInvalid(controlName: string): boolean {
    const control = this.menuEditForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }

	/*
	 * On Submit
	 */
  onSubmit() {
    this.hasFormErrors = false;
    const controls = this.menuEditForm.controls;
    /** check form */
    if (this.menuEditForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      return;
    }

    let data = {};

    this.menuEdit.displayName = controls.displayName.value;
    this.menuEdit.description = controls.description.value;
    data = this.menuEdit;

    this.dialogRef.close({ data, isEdit: true });
  }

   /** Alect Close event */
   onAlertClose($event) {
    this.hasFormErrors = false;
  }
}
