import { Component, OnInit } from "@angular/core";
import { InsuranceCalculatorService } from "../../../core/e-commerce/_services/insurance-calculator.service";

@Component({
	selector: "kt-insurance-calculator",
	templateUrl: "./insurance-calculator.component.html",
	styleUrls: ["./insurance-calculator.component.scss"],
})
export class InsuranceCalculatorComponent implements OnInit {
	public vehiclesData: any;
	public variantsList = [];
	loginEmployee: any;
	model = "";
	varient = "";
	tenure = 0;
	vehicleDetails: any;
	price;
	zone = "";
	zoneData = [
		{ text: "Metro", value: "metro" },
		{ text: "Non-Metro", value: "non-metro" },
	];
	constructor(private insService: InsuranceCalculatorService) {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
	}

	ngOnInit() {
		this.getVehicles();
	}

	getVehicles() {
		this.insService
			.getVehicles(this.loginEmployee.orgId)
			.subscribe((data) => {
				this.vehiclesData = data;
			});
	}
	changeVechileModel() {
		this.variantsList = this.vehiclesData.filter(
			(a) => a.model === this.model
		)[0].varients;
	}

	changeVariant() {
		this.vehicleDetails = this.variantsList.filter(
			(record) => record.name === this.varient
		);
	}
	clear() {}

	calculateInsurance() {
		this.insService
			.getonRoadPrice(
				this.vehicleDetails[0].vehicleImages[0].varient_id,
				this.loginEmployee.orgId
			)
			.subscribe((result) => {
				this.price = result.ex_showroom_price;
				const details = {
					orgId: this.loginEmployee.orgId,
					branchId: this.loginEmployee.branchId,
					zone: this.zone,
					vehicleCC: this.vehicleDetails[0].enginecc,
					tenure: this.tenure,
				};
				this.insService
					.getInsuranceDetails(details)
					.subscribe((data) => {
					});
			});
	}
}
