import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-allotment',
  templateUrl: './allotment.component.html',
  styleUrls: ['./allotment.component.scss']
})
export class AllotmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
