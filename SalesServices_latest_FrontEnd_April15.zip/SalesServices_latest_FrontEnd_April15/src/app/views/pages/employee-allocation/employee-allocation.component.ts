import { Component, OnInit, ChangeDetectorRef } from "@angular/core";
import {
	CdkDragDrop,
	moveItemInArray,
	transferArrayItem,
} from "@angular/cdk/drag-drop";
import {
	MyRolesService,
	PreenquiryService,
} from "../../../core/e-commerce/_services";
import { SelectionModel } from "@angular/cdk/collections";

@Component({
	selector: "kt-employee-allocation",
	templateUrl: "./employee-allocation.component.html",
	styleUrls: ["./employee-allocation.component.scss"],
})
export class EmployeeAllocationComponent implements OnInit {
	constructor(
		private myroleservice: MyRolesService,
		private changeDetectorRef: ChangeDetectorRef,
		private preEnquiryService: PreenquiryService
	) {
		this.userName = JSON.parse(
			localStorage.getItem("loginEmployee")
		).empName;
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
	}

	allocatedMethod: any = [];
	allocationTypes: any = [];
	selection = new SelectionModel<any>(true, []);
	selectedType: any;
	sourceOfEnquires: any = [];
	sourceOfEnquiresRole: any = [];
	roles: any = [];
	mappedSourceOfEnquiry: any = [];
	roleSourceMapped: any = [];
	submitButCheck = false;
	step;
	selectedSource;
	rolesourceMapObj: any = [];
	employeeList = [];
	message = "";
	userName = "";
	loginEmployee: any;

	ngOnInit() {
		this.message = "";
		// get all allocation Types
		this.myroleservice.getAllAllocationTypes().subscribe((res) => {
			this.allocationTypes = res.dmsEntity.dmsallocationStartegies;
			this.changeDetectorRef.detectChanges();
		});

		// get all Source of Enquiries
		this.myroleservice.getAllSourceOfEnquiries().subscribe((res) => {
			this.sourceOfEnquires = res;
			this.sourceOfEnquiresRole = [...res];
			this.sourceOfEnquires.forEach((element: any) => {
				// get Strategy Based on Source
				this.preEnquiryService
					.getStrategySource(element.id)
					.subscribe((response) => {
						if (response) {
							this.allocatedMethod[element.id] =
								response.allocation_id;
						}
					});
			});
			this.changeDetectorRef.detectChanges();
		});

		this.getAllRolesAndMapping();
	}

	// Roles and Source Of Enquiry Mapping --- and Deleting Mapped Sources to Roles
	getAllRolesAndMapping() {
		this.myroleservice.getAllRolesAllocation().subscribe((res) => {
			if (res && res.dmsEntity) {
				this.roles = res.dmsEntity.dmsRoles;
				this.myroleservice
					.getAllSourceRoleMapping(
						this.loginEmployee.orgId,
						this.loginEmployee.branchId
					)
					.subscribe((response) => {
						this.roleSourceMapped =
							response.dmsRoleEnquirysourceMapping;
						this.roles.forEach((element, i) => {
							this.mappedSourceOfEnquiry.push([]);
							this.roleSourceMapped.forEach((subElement) => {
								if (
									element.roleId === subElement.roleId &&
									subElement.dmsSourceOfEnquiry !== null
								) {
									element.id = subElement.id;
									this.mappedSourceOfEnquiry[i].push(
										subElement.dmsSourceOfEnquiry
									);
									this.sourceOfEnquiresRole.forEach(
										(sourceElement, j) => {
											if (
												sourceElement.id ===
												subElement.dmsSourceOfEnquiry.id
											) {
												this.sourceOfEnquiresRole.splice(
													j,
													1
												);
											}
										}
									);
									this.changeDetectorRef.detectChanges();
								}
							});
						});
					});
			}
		});
	}

	// Send Strategy Based on Source
	sendSourceStrategy(source, allocationId) {
		const body = {
			allocation_id: allocationId,
			branch_id: this.loginEmployee.branchId,
			// created_datetime: '2020-06-17T13:12:26.570Z',
			id: source,
			// modified_datetime: '2020-06-17T13:12:26.570Z',
			source_enquiry_id: source,
		};
		this.preEnquiryService.sendStrategySoure(body).subscribe((res) => {});
	}

	finalUpdateAllocationType() {
		this.submitButCheck = false;

		this.myroleservice
			.updateSourceRoleMapping(this.roleSourceMapped)
			.subscribe((res) => {
				if (!res) {
					this.message = `There is an error while updating. Please Try Again`;
					return;
				}
				this.message = `Mapping Updated Successfully`;
				this.gotoTop();
				this.changeDetectorRef.detectChanges();
			});
	}

	gotoTop() {
		window.scroll({
			top: 0,
			left: 0,
			behavior: "smooth",
		});
	}

	drop(event: CdkDragDrop<string[]>) {
		if (event.previousContainer === event.container) {
			moveItemInArray(
				event.container.data,
				event.previousIndex,
				event.currentIndex
			);
		} else {
			if (
				!event.container.data.includes(
					event.previousContainer.data[event.previousIndex]
				) &&
				(event.container.data.length < 1 ||
					Number.isNaN(parseFloat(event.container.id)))
			) {
				transferArrayItem(
					event.previousContainer.data,
					event.container.data,
					event.previousIndex,
					event.currentIndex
				);

				this.submitButCheck = true;
				event.container.data.forEach((element: any) => {
					let roleSourceCheck = false;
					this.roleSourceMapped.forEach((roleSourceElement) => {
						if (roleSourceElement.enquirySourceId === element.id) {
							roleSourceCheck = true;
							roleSourceElement.roleId = Number.isNaN(
								parseFloat(event.container.id)
							)
								? this.roles[event.container.id].roleId
								: this.roles[event.container.id].roleId;
							roleSourceElement.createdBy = this.userName;
							roleSourceElement.updatedBy = this.userName;
						}
					});
					if (
						!roleSourceCheck &&
						!Number.isNaN(parseFloat(event.container.id))
					) {
						const tempObj = {
							// id: 0,
							createdBy: this.userName,
							enquirySourceId: element.id,
							isActive: true,
							roleId: this.roles[event.container.id].roleId,
							updatedBy: this.userName,
							dmsSourceOfEnquiry: {
								id: element.id,
								description: element.description,
								isActive: true,
								name: element.name,
								value: element.value,
							},
						};
						this.roleSourceMapped.push(tempObj);
					}
				});
			}
		}
	}

	getEmployessBySourceId(id) {
		this.employeeList = [];
		this.myroleservice.getEmployessBySource(id).subscribe((data) => {
			this.employeeList = data.employeeDtoList;
			this.changeDetectorRef.detectChanges();
		});
	}

	sourceExpanded(item) {
		this.selectedSource = item;
		this.getEmployessBySourceId(item.id);
	}

	unmapEmployeesToRole() {
		const employeeDtoList = [];
		this.selection.selected.forEach((elem: any) => {
			employeeDtoList.push(elem);
		});
		const object = {
			sorceId: this.selectedSource.id,
			sourceName: this.selectedSource.name,
			employeeDtoList,
		};
		this.myroleservice.unmapEmpFromSource(object).subscribe(
			(response) => {
				this.selection.clear();
				this.getEmployessBySourceId(this.selectedSource.id);
			},
			(error) => {
				this.selection.clear();
				this.getEmployessBySourceId(this.selectedSource.id);
			}
		);
	}

	masterToggle() {
		if (this.selection.selected.length === this.employeeList.length) {
			this.selection.clear();
		} else {
			this.employeeList.forEach((row) => this.selection.select(row));
		}
	}

	isAllSelected(): boolean {
		const numSelected = this.selection.selected.length;
		const numRows = this.employeeList.length;
		return numSelected === numRows;
	}

	setStep(i) {
		this.step = i;
	}
}
