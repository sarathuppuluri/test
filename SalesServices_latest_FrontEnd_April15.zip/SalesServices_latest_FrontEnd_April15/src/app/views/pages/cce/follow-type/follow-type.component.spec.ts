import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FollowTypeComponent } from './follow-type.component';

describe('FollowTypeComponent', () => {
  let component: FollowTypeComponent;
  let fixture: ComponentFixture<FollowTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FollowTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FollowTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
