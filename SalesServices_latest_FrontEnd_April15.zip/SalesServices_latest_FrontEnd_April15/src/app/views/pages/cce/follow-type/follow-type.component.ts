import { Component, OnInit, ChangeDetectorRef } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { CCEService } from "../../../../core/e-commerce/_services/cce.service";
import { Router, ActivatedRoute } from "@angular/router";
import { MatDialog } from "@angular/material/dialog";
import { CreateFollowTypeComponent } from "./create-follow-type/create-follow-type.component";
import moment from "moment";
import { forkJoin } from "rxjs";
import { MatSnackBar } from "@angular/material/snack-bar";
import { Location } from "@angular/common";
@Component({
	selector: "kt-follow-type",
	templateUrl: "./follow-type.component.html",
	styleUrls: ["./follow-type.component.scss"],
})
export class FollowTypeComponent implements OnInit {
	followup: any;
	followUpForm: FormGroup;
	serviceForm: FormGroup;
	purchaseCarForm: FormGroup;
	vehicleForm: FormGroup;
	dissatisfiedForm: FormGroup;
	disStaisFiedWithPreviousServiceForm: FormGroup;
	escalationForm: FormGroup;
	reasonsList = [];
	hideButtons = false;
	isEmployeeListDisabled=true;
	showSave = false;
	creRemarks = "";
	regNumber = "";
	selectedReason = "";
	showremarks = false;
	showLocation = false;
	locationName = "";
	showServices = false;
	doorService = "Yes";
	showpinCode = false;
	showError = false;
	noResponce = false;
	dissatisfiedList = [];
	creAssigned = "";
	pinCode = "";
	serviceValue = "";
	showNewCarForm = false;
	showVehicleForm = false;
	dissatisfied = false;
	homeVisitReason = "";
	selectedDistasified = "";
	showNoButton = false;
	showYesButton = false;
	activityId;
	followUpId;
	employeeData = [];
	followUpsDetails = [];
	showremarksNoResponce = false;
	showSaveNoResponce = false;
	showdisStaisFiedWithPreviousServiceForm = false;
	showEscalationForm = false;
	vehicleDetails = {
		vehicleModel: "",
		color: "",
		fuelType: "",
		regNumber: "",
		chassisNumber: "",
		engineNumber: "",
		purchaseDate: "",
		sellingDealer: "",
		sellingLocation: "",
	};
	vehicleWarranty = {
		amountPaid: "",
		expiryDate: "",
		id: "",
		startDate: "",
		status: "",
		tenantIdentifier: "",
		vehicleRegNumber: "",
		warrantyType: "",
	};
	insuranceDetails = {
		customer: "",
		endDate: "",
		id: "",
		insuranceAmount: "",
		insuranceIdentifier: "",
		provider: "",
		startDate: "",
		vehicleRegNumber: "",
	};
	serviceDetails = {
		serviceDate: "",
	};
	customerDetails = {
		id: "",
		altContactNumber: "",
		contactNumber: "",
		customerType: "",
		doa: "",
		dateOfBirth: "",
		email: "",
		firstName: "",
		gender: "",
		lastName: "",
		occupation: "",
		customerAddresses: "",
	};
	creRemarksDisatisfied = "";
	showremarksDisatisfied = false;
	alreadyServices = ["OTHER_DEALER", "OWN_DEALER", "WORKSHOP"];
	home_visited_reasons = [
		"CALL_DISCONNECTED",
		"RINGING_NO_RESPONCE",
		"PHONE_NOT_REACHABLE",
		"WRONG_PHONE_NO",
		"PHONE_NUMBER_NOT_AVAILABLE",
	];
	loginEmployee;
	gender;
	previousServiceValues = [
		"High Cost",
		"Poor Service",
		"Washing,Noise",
		"Demanded Repairs",
		"Delay in Pick up",
		"Delay in Delivery",
		"Problem with Estimate",
		"Staff Behaviour",
		"Parts Not Available",
		"Other",
	];
	genderValues = [
		{ text: "Not Specified", value: "NOT_SPECIFIED" },
		{ text: "Male", value: "MALE" },
		{ text: "Female", value: "FEMALE" },
	];
	fuelValues = [
		{ text: "Petrol", value: "PETROL" },
		{ text: "Disel", value: "DIESEL" },
		{ text: "Hybrid", value: "HYBRID" },
		{ text: "Electric", value: "ELECTRIC" },
	];
	followupReasons: any = [];
	followupResults: any = [];
	followupStatus: any = [];

	constructor(
		private fb: FormBuilder,
		public cceService: CCEService,
		private router: Router,
		private activatedRoute: ActivatedRoute,
		public dialog: MatDialog,
		private _snackBar: MatSnackBar,
		private location: Location,
		private cd: ChangeDetectorRef
	) {}
	ngOnInit() {
		this.createForm();
		if(JSON.parse(localStorage.getItem('loginEmployee')).roles.find((a)=>a==='Customer Care Manager')){
			this.isEmployeeListDisabled=false;
		}
		this.activatedRoute.params.subscribe((params) => {
			this.activityId = params.activityId;
			this.followUpId = params.followUpId;
		});
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.getCallDetails();
		this.getMasterData();
		this.getEmployees();
	}

	private getCallDetails() {
		this.cceService
			.getCallDetailsById(this.followUpId, this.activityId)
			.subscribe((data) => {
				this.followup = data.body;
				this.followUpForm.patchValue(data.body);
				this.followUpForm.patchValue({ id: data.body.cre.id });
				this.cd.detectChanges();
				this.getCustomerInfo(data);
				this.getFollowUpsInfomation();
				this.regNumber = this.followUpForm.value.vehicleRegNumber;
				this.cd.detectChanges();
			});
	}

	getCustomerInfo(data) {
		this.cceService
			.getCustomerInfo(data.body.vehicleRegNumber)
			.subscribe((data) => {
				this.vehicleDetails = data.body.vehicle;
				this.customerDetails = data.body.customer;
				this.insuranceDetails = data.body.vehicleInsurance
					? data.body.vehicleInsurance
					: this.insuranceDetails;
				this.vehicleWarranty = data.body.vehicleWarranty
					? data.body.vehicleWarranty
					: this.vehicleWarranty;
				this.getAllAppointments(data.body.customer.contactNumber);
				this.cd.detectChanges();
			});
	}

	getFollowUpsInfomation() {
		this.cceService
			.getActivityDetails(this.followUpId)
			.subscribe((data) => {
				this.followUpsDetails = data.body.serviceFollowUpActivities;
				this.creAssigned = data.body.creAssigned.id;
			});
	}

	getAllAppointments(contactNumber) {
		this.cceService.getAllAppointments(contactNumber).subscribe((data) => {
			this.serviceDetails = data.body;
		});
	}

	private getMasterData() {
		const reasons = this.cceService.getMasterData(
			this.loginEmployee.branchId,
			"FOLLOW_UP_REASON"
		);
		const results = this.cceService.getMasterData(
			this.loginEmployee.branchId,
			"FOLLOW_UP_RESULT"
		);
		const status = this.cceService.getMasterData(
			this.loginEmployee.branchId,
			"FOLLOW_UP_STATUS"
		);
		forkJoin(reasons, results, status).subscribe((response) => {
			if (response) {
				this.followupReasons = response[0].body;
				this.followupResults = response[1].body;
				this.followupStatus = response[2].body;
			}
		});
	}

	createForm() {
		this.followUpForm = this.fb.group({
			id: [""],
			startDate: [""],
			endDate: [""],
			customer: [""],
			cre: [""],
			vehicle: [""],
			createdBy: [""],
			createdDate: [""],
			serviceDueDate: [""],
			serviceType: [""],
			assignCRE: [""],
			creRemarks: [""],
			followUpDate: [""],
			followUpActivityId: [""],
			followUpResultCapture: this.fb.group({
				reason: [""],
				creRemarks: [""],
			}),
			followUpActivityStatus: [""],
			followUpActivityResult: [""],
			followUpId: [""],
			followUpReason: [""],
			customerRemarks: [""],
		});
		this.serviceForm = this.fb.group({
			serviceDate: [""],
			serviceDealerType: [null],
			delearName: [""],
			serviceLocation: [""],
			lastMileage: [""],
			serviceType: [""],
			serviceManager: [""],
			remarks: [""],
		});
		this.purchaseCarForm = this.fb.group({
			vehicleRegNumber: [""],
			vin: [""],
			engineNumber: [""],
			chassisNumber: [""],
			vehicleModel: [""],
			variant: [""],
			color: [""],
			fuelType: [null],
			kmReading: [""],
			purchaseDate: [""],
			sellingLocation: [""],
			sellingDealer: [""],
		});
		this.vehicleForm = this.fb.group({
			firstName: [""],
			lastName: [""],
			contactNumber: [""],
			alternateContactNumber: [""],
			email: [""],
			gender: [null],
			customerType: [""],
			dateOfArrival: [""],
			occupation: [""],
			address: [""],
			dateOfBirth: [""],
		});
		this.dissatisfiedForm = this.fb.group({
			sales: [""],
			service: [""],
			Service: [""],
		});
		this.disStaisFiedWithPreviousServiceForm = this.fb.group({
			lastServiceDate: [""],
			serviceAdvisor: [""],
			assignTo: [""],
			reasonforDissatisfaction: [""],
			customerFeedback: [""],
			creRemarks: [""],
		});
		this.escalationForm = this.fb.group({
			ourWorkShopNotIntersted: [""],
			escaltionMatrix: [""],
			complanints: [""],
			feedback: [""],
			cceRemarks: [""],
		});
	}

	public followupDialog(): void {
		const dialogRef = this.dialog.open(CreateFollowTypeComponent, {
			data: {
				followupReasons: this.followupReasons,
				followUpId: this.followup.followUpId,
				assignedCRE: this.followUpForm.value.cre.id,
			},
		});

		dialogRef.afterClosed().subscribe((result) => {
			if (result) {
				result.startDate = moment(result.startDate).format(
					"YYYY-MM-DD"
				);
				result.endDate = moment(result.endDate).format("YYYY-MM-DD");
				const requestBody = {
					id: this.followUpForm.value.followUpActivityId,
					startDate: this.followUpForm.value.startDate,
					endDate: this.followUpForm.value.endDate,
					assignCRE: this.followUpForm.value.cre.id,
					creRemarks: this.followUpForm.value.creRemarks,
					customerRemarks: this.followUpForm.value.customerRemarks,
					followUpActivityStatus: "CLOSED",
					followUpActivityResult: "FOLLOW_UP_CREATED",
					followUpId: this.followUpForm.value.followUpId,
				};
				this.cceService
					.updateFollowup(requestBody, this.loginEmployee.branchId)
					.subscribe(
						() => {
							this.cceService
								.saveFollowup(
									result,
									this.loginEmployee.branchId
								)
								.subscribe(
									() => {
										this.openSnackBar(
											"Followup created is Successfull",
											"Success"
										);
										this.router.navigateByUrl(
											"services/cceDashboard/call-list/FRESH_CALLS"
										);
									},
									(error) => {
										this.openSnackBar(
											error.error.message,
											error.error.status
										);
									}
								);
						},
						(error) => {
							this.openSnackBar(
								error.error.message,
								error.error.status
							);
						}
					);
			}
		});
	}

	public bookAppointment() {
		const requestBody = {
			id: this.followUpForm.value.followUpActivityId,
			startDate: this.followUpForm.value.startDate,
			endDate: this.followUpForm.value.endDate,
			assignCRE: this.followUpForm.value.cre.id,
			creRemarks: this.followUpForm.value.creRemarks,
			customerRemarks: this.followUpForm.value.customerRemarks,
			followUpActivityStatus: "CLOSED",
			followUpActivityResult: "SERVICE_BOOKED",
			followUpId: this.followUpForm.value.followUpId,
		};
		this.cceService
			.updateFollowup(requestBody, this.loginEmployee.branchId)
			.subscribe(
				() => {
					this.openSnackBar(
						"Navigating to Booking to create",
						"Success"
					);
					this.router.navigate([
						`/services/service-booking/${this.followup.vehicle}/0/false`,
					]);
				},
				(error) => {
					this.openSnackBar(error.error.message, error.error.status);
				}
			);
	}

	public submit() {
		const requestBody = {
			id: this.followUpForm.value.followUpActivityId,
			startDate: this.followUpForm.value.startDate,
			endDate: this.followUpForm.value.endDate,
			assignCRE: this.followUpForm.value.id,
			creRemarks: this.followUpForm.value.creRemarks,
			customerRemarks: this.followUpForm.value.customerRemarks,
			followUpActivityStatus: "OPEN",
			followUpActivityResult: "SERVICE_BOOKED",
			followUpId: this.followUpForm.value.followUpId,
		};
		this.cceService
			.updateFollowup(requestBody, this.loginEmployee.branchId)
			.subscribe((data) => {
				this.saveCustomer();
			});
	}
	formatAddress() {
		return {
			addresses: {
				additionalProp1: {
					address: "string",
					pin: "string",
					state: "string",
					city: "string",
					longitude: 0,
					latitude: 0,
					label: "HOME",
					addressLabelIfOther: "string",
				},
				additionalProp2: {
					address: "string",
					pin: "string",
					state: "string",
					city: "string",
					longitude: 0,
					latitude: 0,
					label: "HOME",
					addressLabelIfOther: "string",
				},
				additionalProp3: {
					address: "string",
					pin: "string",
					state: "string",
					city: "string",
					longitude: 0,
					latitude: 0,
					label: "HOME",
					addressLabelIfOther: "string",
				},
			},
		};
	}
	saveCustomer() {
		if (this.customerDetails.contactNumber) {
			this.showError = false;
			const customer = {
				alternateContactNumber: this.customerDetails.altContactNumber,
				contactNumber: this.customerDetails.contactNumber,
				addresses: null,
				customerType: this.customerDetails.customerType,
				dateOfArrival: this.customerDetails.doa,
				dateOfBirth: this.customerDetails.dateOfBirth,
				email: this.customerDetails.email,
				firstName: this.customerDetails.firstName,
				lastName: this.customerDetails.lastName,
			};
			this.cceService
				.updateCustomer(customer, this.customerDetails.id)
				.subscribe((data) => {
					this.openSnackBar("Updated Sucessfully", "Success");
					this.router.navigateByUrl(
						"services/cceDashboard/call-list/FRESH_CALLS"
					);
				});
		} else {
			this.showError = true;
		}
	}

	public serviceChange(event) {}

	public notInterested() {
		this.cceService
			.getMasterData(
				this.loginEmployee.branchId,
				"FOLLOWUP_CLOSING_ACTION"
			)
			.subscribe((data) => {
				this.hideButtons = false;
				this.reasonsList = data.body[1].CustomerNotInterestedReasons;
				this.cd.detectChanges();
			});
	}

	public cancel() {
		this.reasonsList = [];
		this.hideButtons = true;
	}

	public SaveNotInterestedDetails(seletedReason = null) {
		this.cceService
			.updateNotInterestedData(this.prepareData(seletedReason))
			.subscribe((result) => {
				this.openSnackBar(
					"Saved SucessFully Routing to List View",
					"Success"
				);
				setTimeout(() => {
					this.router.navigateByUrl(
						"services/cceDashboard/call-list/FRESH_CALLS"
					);
				}, 1000);
			});
	}

	public resaonSelectionChange(event) {
		const reasons = [
			"APPOINTMENT_BOOKING",
			"OUT_OF_STATION",
			"DISTANCE_FROM_DEALER_LOCATION",
			"EXPECTING_MORE_DISCOUNT",
			"EXCESS_BILLING",
			"CNG_VEHICLE",
			"TOTAL_LOSS_OR_DAMAGE",
			"NO_SPECIFIC_REASON",
			"OTHERS",
		];
		if (reasons.indexOf(event.value) !== -1) {
			this.showremarks = true;
			this.showVehicleForm = false;
			this.showNewCarForm = false;
			this.showServices = false;
			this.showpinCode = false;
			this.showLocation = false;
		} else if (event.value === "TRANSFER_TO_ANOTHER_CITY") {
			this.showLocation = true;
			this.showremarks = true;
			this.showVehicleForm = false;
			this.showNewCarForm = false;
			this.showServices = false;
			this.showpinCode = false;
		} else if (event.value === "TOO_FAR_FROM_DEALER_SCENARIO") {
			this.showpinCode = true;
			this.showLocation = false;
			this.showremarks = true;
			this.showVehicleForm = false;
			this.showNewCarForm = false;
			this.showServices = false;
		} else if (event.value === "ALREADY_SERVICED") {
			this.showServices = true;
			this.showpinCode = false;
			this.showLocation = false;
			this.showremarks = false;
			this.showNewCarForm = false;
			this.showVehicleForm = false;
		} else if (event.value === "PURCHASED_ANOTHER_CAR") {
			this.showNewCarForm = true;
			this.showServices = false;
			this.showpinCode = false;
			this.showLocation = false;
			this.showremarks = false;
			this.showVehicleForm = false;
		} else if (event.value === "VEHICLE_SOLD") {
			this.showVehicleForm = true;
			this.showNewCarForm = false;
			this.showServices = false;
			this.showpinCode = false;
			this.showLocation = false;
			this.showremarks = false;
		}
		this.showSave = true;
	}

	public goBack() {
		this.location.back();
	}

	private prepareData(seletedReason) {
		const data = {
			id: this.followUpForm.value.followUpActivityId,
			startDate: this.followUpForm.value.startDate,
			endDate: this.followUpForm.value.endDate,
			assignCRE: this.followUpForm.value.cre.id,
			creRemarks: this.followUpForm.value.creRemarks,
			customerRemarks: this.followUpForm.value.customerRemarks,
			followUpDate: new Date(),
			followUpResultCapture: this.reasonSpecificData(seletedReason),
			followUpActivityStatus: "CLOSED",
			followUpActivityResult: "CUSTOMER_NOT_INTERESTED",
			followUpId: this.followUpForm.value.followUpId,
		};
		return data;
	}

	private reasonSpecificData(selectedReason = null) {
		if (selectedReason === null) {
			selectedReason = this.selectedReason;
		}
		let data = {};
		const reasons = [
			"APPOINTMENT_BOOKING",
			"OUT_OF_STATION",
			"EXPECTING_MORE_DISCOUNT",
			"EXCESS_BILLING",
			"CNG_VEHICLE",
			"TOTAL_LOSS_OR_DAMAGE",
			"NO_SPECIFIC_REASON",
			"DISTANCE_FROM_DEALER_LOCATION",
			"OTHERS",
		];
		if (reasons.indexOf(selectedReason) !== -1) {
			data = {
				reason: this.selectedReason,
				creRemarks: this.creRemarks,
			};
			return data;
		} else if (selectedReason === "VEHICLE_SOLD") {
			data = {
				reason: this.selectedReason,
				creRemarks: this.creRemarks,
				customerRequest: this.vehicleForm.value,
			};
			return data;
		} else if (selectedReason === "PURCHASED_ANOTHER_CAR") {
			data = {
				reason: this.selectedReason,
				creRemarks: this.creRemarks,
				vehicleDetails: this.purchaseCarForm.value,
			};
			return data;
		} else if (selectedReason === "TRANSFER_TO_ANOTHER_CITY") {
			data = {
				reason: this.selectedReason,
				creRemarks: this.creRemarks,
				nameOfTheLocation: this.locationName,
			};
			return data;
		} else if (selectedReason === "TOO_FAR_FROM_DEALER_SCENARIO") {
			data = {
				reason: this.selectedReason,
				creRemarks: this.creRemarks,
				newAreaPinCode: this.pinCode,
				preferredDoorStepService: this.doorService,
			};
			return data;
		} else if (selectedReason === "ALREADY_SERVICED") {
			data = {
				reason: this.selectedReason,
				creRemarks: this.creRemarks,
				servicedAt: this.serviceForm.value.serviceDealerType,
				nameOfTheDealerOrWorkshop: this.serviceForm.value.delearName,
				vehicleServiceHistoryRequest: {},
				customer: {},
			};
			return data;
		} else if (selectedReason === "NO_RESPONSE") {
			data = {
				reason: selectedReason,
				creRemarks: this.creRemarks,
				customerDissatisfiedRequest: {
					details: {
						CRE_Remarks: this.creRemarks,
						Home_Visted_Reson: this.homeVisitReason,
					},
				},
			};
			return data;
		} else if (selectedReason === "CUSTOMER_DISSATISFIED") {
			if (this.selectedDistasified === "Excess Billing") {
				data = {
					reason: selectedReason,
					creRemarks: this.creRemarksDisatisfied,
					escalate: false,
					reasonForDissatisfaction: this.selectedDistasified,
					department: null,
					complaint: null,
					feedback: null,
					customerDissatisfiedRequest: {
						details: {
							CRE_Remarks: this.creRemarksDisatisfied,
						},
					},
				};
			} else if (this.selectedDistasified === "Escalation") {
				data = {
					reason: selectedReason,
					creRemarks: this.creRemarksDisatisfied,
					escalate: false,
					reasonForDissatisfaction: this.selectedDistasified,
					department: null,
					complaint: this.escalationForm.value.complanints,
					feedback: this.escalationForm.value.feedback,
					customerDissatisfiedRequest: {
						details: {
							ourWorkShopNotIntersted: this.escalationForm.value
								.ourWorkShopNotIntersted,
							escaltionMatrix: this.escalationForm.value
								.escaltionMatrix,
							complanints: this.escalationForm.value.complanints,
							feedback: this.escalationForm.value.feedback,
							cceRemarks: this.escalationForm.value.cceRemarks,
						},
					},
				};
			} else if (
				this.selectedDistasified ===
				"Dissatisfied with Previous Service"
			) {
				data = {
					reason: selectedReason,
					creRemarks: this.creRemarksDisatisfied,
					escalate: false,
					reasonForDissatisfaction: this.selectedDistasified,
					department: null,
					complaint: null,
					feedback: null,
					customerDissatisfiedRequest: {
						details: {
							lastServiceDate: this
								.disStaisFiedWithPreviousServiceForm.value
								.lastServiceDate,
							serviceAdvisor: this
								.disStaisFiedWithPreviousServiceForm.value
								.serviceAdvisor,
							assignTo: this.disStaisFiedWithPreviousServiceForm
								.value.assignTo,
							reasonforDissatisfaction: this
								.disStaisFiedWithPreviousServiceForm.value
								.reasonforDissatisfaction,
							customerFeedback: this
								.disStaisFiedWithPreviousServiceForm.value
								.customerFeedback,
							creRemarks: this.disStaisFiedWithPreviousServiceForm
								.value.creRemarks,
						},
					},
				};
			}
			return data;
		}
	}
	noResponceClick() {
		this.noResponce = true;
		this.showSaveNoResponce = true;
		this.hideButtons = false;
		this.showremarksNoResponce = true;
	}

	cancelNoResponce() {
		this.noResponce = false;
		this.hideButtons = true;
		this.showSaveNoResponce = false;
		this.showremarksNoResponce = false;
	}
	submitNoResponce() {
		this.SaveNotInterestedDetails("NO_RESPONSE");
	}

	private openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 5000,
		});
	}
	noClick() {
		this.hideButtons = true;
		this.showNoButton = true;
		this.showYesButton = false;
	}
	yesClick() {
		this.hideButtons = true;
		this.showNoButton = false;
		this.showYesButton = true;
	}
	dissatisfiedClick() {
		this.hideButtons = false;
		this.fillDisStatisfiedReasons();
	}
	fillDisStatisfiedReasons() {
		this.dissatisfiedList = [
			"Excess Billing",
			"Dissatisfied with Previous Service",
			// "Dissatisfied",
			"Escalation",
		];
	}
	distasifiedSelectionChange(event) {
		if (event.value === "Excess Billing") {
			this.showremarksDisatisfied = true;
			this.showEscalationForm = false;
			this.showdisStaisFiedWithPreviousServiceForm = false;
		} else if (event.value === "Escalation") {
			this.showEscalationForm = true;
			this.showremarksDisatisfied = false;
			this.showdisStaisFiedWithPreviousServiceForm = false;
		} else if (event.value === "Dissatisfied with Previous Service") {
			this.showdisStaisFiedWithPreviousServiceForm = true;
			this.showremarksDisatisfied = false;
			this.showEscalationForm = false;
		} else if (event.value === "Dissatisfied") {
		}
	}
	SaveDissatisfiedDetails() {
		this.SaveNotInterestedDetails("CUSTOMER_DISSATISFIED");
	}
	cancelDisatisfied() {
		this.dissatisfiedList = [];
		this.hideButtons = true;
	}

	getEmployees() {
		this.cceService.getAllEmployeeInfo().subscribe((data) => {
			this.employeeData = [
				...data.body["Tele Caller"],
				...data.body["Customer Care Manager"],
			];
			this.cd.detectChanges();
		});
	}
}
