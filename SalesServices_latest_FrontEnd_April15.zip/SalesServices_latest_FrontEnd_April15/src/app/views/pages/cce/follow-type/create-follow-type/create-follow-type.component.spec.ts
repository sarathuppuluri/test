import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateFollowTypeComponent } from './create-follow-type.component';

describe('CreateFollowTypeComponent', () => {
  let component: CreateFollowTypeComponent;
  let fixture: ComponentFixture<CreateFollowTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateFollowTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateFollowTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
