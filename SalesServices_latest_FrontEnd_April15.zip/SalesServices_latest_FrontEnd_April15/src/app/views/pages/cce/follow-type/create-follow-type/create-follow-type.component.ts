import { Component, OnInit, Inject } from "@angular/core";
import {
	MatDialog,
	MatDialogRef,
	MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { FormBuilder, FormGroup } from "@angular/forms";

@Component({
	selector: "kt-create-follow-type",
	templateUrl: "./create-follow-type.component.html",
	styleUrls: ["./create-follow-type.component.scss"],
})
export class CreateFollowTypeComponent implements OnInit {
  followUpForm: FormGroup;
  followupReasons: any = [];

	constructor(
		public dialogRef: MatDialogRef<CreateFollowTypeComponent>,
		@Inject(MAT_DIALOG_DATA) public data,
		private fb: FormBuilder
	) {}

	ngOnInit() {
    this.followupReasons =  this.data.followupReasons;
		this.createForm();
	}

	public createForm() {
		this.followUpForm = this.fb.group({
			startDate: [''],
			endDate: [''],
			followUpReason: [''],
		  assignCRE: this.data.assignedCRE,
			creRemarks: [''],
			customerRemarks: [''],
			followUpId: this.data.followUpId,
		});
  }
  
  public save() {
    this.dialogRef.close(this.followUpForm.value);
  }

  public close() {
    this.dialogRef.close();
  }
}
