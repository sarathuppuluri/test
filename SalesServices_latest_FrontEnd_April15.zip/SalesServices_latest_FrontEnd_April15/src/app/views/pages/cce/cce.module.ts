// Angular
import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
// Core Module
import { CoreModule } from "../../../core/core.module";
import { PartialsModule } from "../../partials/partials.module";
import { MatIconModule } from "@angular/material/icon";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import {
	MatTabsModule,
	MatCardModule,
	MatInputModule,
	MatFormFieldModule,
	MatExpansionModule,
	MatStepperModule,
	MatCheckboxModule,
	MatButtonModule,
	MatAutocompleteModule,
	MatMenuModule,
	MatSelectModule,
	MatRadioModule,
	MatPaginatorModule,
} from "@angular/material";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { FlexLayoutModule } from "@angular/flex-layout";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { CCEComponent } from "./cce.component";
import { CCEService } from "../../../core/e-commerce/_services/cce.service";
import { CceListComponent } from "./cce-list/cce-list.component";
import { FollowTypeComponent } from "./follow-type/follow-type.component";
import { CreateFollowTypeComponent } from "./follow-type/create-follow-type/create-follow-type.component";

@NgModule({
	imports: [
		CommonModule,
		PartialsModule,
		CoreModule,
		MatIconModule,
		NgbModule,
		MatTabsModule,
		MatMenuModule,
		MatCardModule,
		FormsModule,
		MatPaginatorModule,
		ReactiveFormsModule,
		MatFormFieldModule,
		MatStepperModule,
		MatRadioModule,
		MatButtonModule,
		MatCheckboxModule,
		MatAutocompleteModule,
		MatInputModule,
		MatExpansionModule,
		MatSelectModule,
		ReactiveFormsModule,
		FlexLayoutModule,
		MatDatepickerModule,
		RouterModule.forChild([
			{
				path: "call-list/:type",
				component: CceListComponent,
			},
			{
				path: "follow-up/:activityId/:followUpId",
				component: FollowTypeComponent,
			},
			{
				path: "",
				component: CCEComponent,
			},
		]),
	],
	providers: [CCEService],
	declarations: [
		CCEComponent,
		CceListComponent,
		FollowTypeComponent,
		CreateFollowTypeComponent,
	],
	entryComponents: [CreateFollowTypeComponent],
	exports: [MatExpansionModule,MatFormFieldModule, MatInputModule ],
})
export class CCEModule {}
