import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CCEComponent } from './cce.component';

describe('CCEComponent', () => {
  let component: CCEComponent;
  let fixture: ComponentFixture<CCEComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CCEComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CCEComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
