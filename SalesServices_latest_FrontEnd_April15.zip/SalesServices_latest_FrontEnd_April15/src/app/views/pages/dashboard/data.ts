export const multi = [
	{
	  "name": "E2B",
	  "series": [
		{
		  "name": "Pipeline Target",
		  "value": 60
		},
		{
		  "name": "Pipeline Actual",
		  "value": 100
		}
	  ]
	},
  
	{
	  "name": "B2R",
	  "series": [
		{
			"name": "Pipeline Target",
		  "value": 56
		},
		{
			"name": "Pipeline Actual",
			"value": 100
		}
	  ]
	},
  
	{
	  "name": "E2R",
	  "series": [
		{
			"name": "Pipeline Target",
		  "value": 78
		},
		{
			"name": "Pipeline Actual",
			"value": 100
		}
	  ]
	},
  
	{
		"name": "HV",
		"series": [
			{
				"name": "Pipeline Target",
			  "value": 34
			},
			{
				"name": "Pipeline Actual",
				"value": 100
			}
		]
	  },
	  {
		"name": "Exc",
		"series": [
			{
				"name": "Pipeline Target",
			  "value": 88
			},
			{
				"name": "Pipeline Actual",
				"value": 100
			}
		]
	  },
	  {
		"name": "TD",
		"series": [
			{
				"name": "Pipeline Target",
			  "value": 90
			},
			{
				"name": "Pipeline Actual",
				"value": 100
			}
		]
	  },
	  {
		"name": "Fin",
		"series": [
			{
				"name": "Pipeline Target",
			  "value": 27
			},
			{
				"name": "Pipeline Actual",
				"value": 100
			}
		]
	  }, 
  ];

  

  export const single = [
		{
			name: 'Germany',
			value: 40632,
			extra: {
				code: 'de',
			},
		},
		{
			name: 'United States',
			value: 50000,
			extra: {
				code: 'us',
			},
		},
		{
			name: 'France',
			value: 36745,
			extra: {
				code: 'fr',
			},
		},
		{
			name: 'United Kingdom',
			value: 36240,
			extra: {
				code: 'uk',
			},
		},
		{
			name: 'Spain',
			value: 33000,
			extra: {
				code: 'es',
			},
		},
		{
			name: 'Italy',
			value: 35800,
			extra: {
				code: 'it',
			},
		},
  ];
  
  
  