import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EMIService } from '../../../core/e-commerce/_services/emi.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'kt-emicalculator',
  templateUrl: './emicalculator.component.html',
  styleUrls: ['./emicalculator.component.scss']
})
export class EmicalculatorComponent implements OnInit {
  title = 'emi-calculator';
  principle;
  tenure;
  interestRate;
  processFee;
  emiCalculateForm: FormGroup;
  namesList: any = [
    'SL.NO', 'EMI', 'Principle', 'Interest', 'Balance Principle Amount'
  ];

  constructor(private fb: FormBuilder, private emiService: EMIService, private routeData: ActivatedRoute) {
    this.principle = (this.routeData.snapshot.paramMap.get('principle'));
    this.tenure = (this.routeData.snapshot.paramMap.get('tenure'));
    this.interestRate = (this.routeData.snapshot.paramMap.get('interestRate'));
    this.processFee = (this.routeData.snapshot.paramMap.get('processFee'));
  }
  ngOnInit(): void {
    this.emiCalculateForm = this.fb.group({
      principle: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9,]*$')])],
      tenure: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9,]*$')])],
      interestRate: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9,]*$')])],
      processFee: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9,]*$')])]
    });

    this.submitEmi(this.principle, this.tenure, this.interestRate, this.processFee);
  }

  submitEmi(principle, tenure, interestRate, processFee) {
    let P = principle;
    const R = interestRate;
    const N = tenure;
    const monthlyInterstRatio = (R / 100) / 12;
    const top = Math.pow((1 + monthlyInterstRatio), N);
    const bottom = top - 1;
    const sp = top / bottom;
    const emi = ((P * monthlyInterstRatio) * sp);
    const full = N * emi;
    const interest = full - P;
    let int_pge = (interest / full) * 100;
    const div1 = document.getElementById('tableDiv');
    const tbl = document.createElement('table');
    let interestPaid;
    let principlePaid;
    let newBalance;
    const row1 = document.createElement('tr');
    for (let i = 0; i < this.namesList.length; i++) {
      const cell = document.createElement('td');
      const cellText = document.createTextNode(this.namesList[i]);
      cell.appendChild(cellText);
      row1.appendChild(cell);
    }
    tbl.appendChild(row1);
    for (let r = 0; r < N; r++) {
      const row = document.createElement('tr');
      for (let c = 0; c < 5; c++) {
        if (c === 1) {
          const cell = document.createElement('td');
          const cellText = document.createTextNode(JSON.stringify(Math.round(emi)));
          cell.appendChild(cellText);
          row.appendChild(cell);
        } else if (c === 2) {
          principlePaid = Math.round(emi - (monthlyInterstRatio * P));
          const cell = document.createElement('td');
          const cellText = document.createTextNode(JSON.stringify(principlePaid));
          cell.appendChild(cellText);
          row.appendChild(cell);
        } else if (c === 3) {
          interestPaid = Math.round(monthlyInterstRatio * P);
          // debugger;
          const cell = document.createElement('td');
          const cellText = document.createTextNode(JSON.stringify(interestPaid));
          cell.appendChild(cellText);
          row.appendChild(cell);
        } else if (c === 4) {
          newBalance = Math.round(P - principlePaid);
          P = newBalance;
          if (newBalance < 10) {
            newBalance = 0;
          }
          const cell = document.createElement('td');
          const cellText = document.createTextNode(JSON.stringify(newBalance));
          cell.appendChild(cellText);
          row.appendChild(cell);
        } else if (c === 0) {
          const cell = document.createElement('td');
          const cellText = document.createTextNode(JSON.stringify(r + 1));
          cell.appendChild(cellText);
          row.appendChild(cell);
        }
      }
      tbl.appendChild(row);
    }
    div1.appendChild(tbl);
  }
}
