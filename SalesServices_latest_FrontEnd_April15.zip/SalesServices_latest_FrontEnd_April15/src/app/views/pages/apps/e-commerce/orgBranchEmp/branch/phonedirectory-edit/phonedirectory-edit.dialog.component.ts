// Angular
import { Component, OnInit, Inject, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
// Material
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
// RxJS
import { Subscription } from 'rxjs';
// Services
import { BranchService } from '../../../../../../../core/e-commerce/_services/branch.service';
import { QueryParamsModel } from '../../../../../../../core/_base/crud';


@Component({
	// tslint:disable-next-line:component-selector
	selector: 'kt-phonedirectory-edit-dialog',
	templateUrl: './phonedirectory-edit.dialog.component.html',
	styleUrls: ['./phonedirectory-edit.dialog.component.scss']
})
export class PhoneDirectoryEditDialogComponent implements OnInit, OnDestroy {

	/**
	 * Component constructor
	 *
	 * @param dialogRef: MatDialogRef<CustomerEditDialogComponent>
	 * @param data: any
	 * @param fb: FormBuilder
	 * @param store: Store<AppState>
	 * @param typesUtilsService: TypesUtilsService
	 */
	constructor(public dialogRef: MatDialogRef<PhoneDirectoryEditDialogComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any,
		private fb: FormBuilder,
		private branchService: BranchService,
		private changeDetectorRef: ChangeDetectorRef) {
	}
	// Public properties
	hasFormErrors = false;
	viewLoading = false;
	phoneDirectoryEdit: any;

	// Private properties
	private componentSubscriptions: Subscription;

	phoneDirectoryForm: FormGroup;

	hasSubmitted = false;
	message = '';


	tempData = [];
	AllDataBranch: any = [];

	ngOnInit() {
		this.phoneDirectoryEdit = this.data.editPhoneDirectory;
		this.loadBranchById();
		this.createForm();
		if (this.phoneDirectoryEdit.branch_id > 0) {
			this.phoneDirectoryForm.get('branch_id').disable({ onlySelf: true });
		} else {
			this.phoneDirectoryForm.get('branch_id').enable({ onlySelf: true });
		}
		this.phoneDirectoryEdit.contact_details.forEach((element, i) => {
			this.getPhoneDirectoryFields.push(this.addOtherFields());
			let temp = (this.phoneDirectoryForm.controls.contact_details as FormArray).at(i);
			temp.patchValue(element);
		});
	}

	/**
	 * Load Branch List from service
	 */
	loadBranchById() {
		const queryParams = new QueryParamsModel({}, '', '', 0, 100);
		this.branchService.getBranchById(this.phoneDirectoryEdit.organization_id, queryParams).subscribe(res => {
			this.tempData = res.branchInquiryInfos.content;
			this.changeDetectorRef.detectChanges();
		}, error => {
			console.log('All Data of Branch error::' + error);
			this.changeDetectorRef.detectChanges();
		});
	}

	createForm() {
		this.phoneDirectoryForm = this.fb.group({
			branch_id: [(this.phoneDirectoryEdit.branch_id > 0) ? this.phoneDirectoryEdit.branch_id : '', Validators.required],
			contact_details: this.fb.array([this.addOtherFields()])
		});
	}

	// Getter Method
	get getPhoneDirectoryFields() {
		return this.phoneDirectoryForm.get('contact_details') as FormArray;
	}

	// Add FormGroups
	addOtherFields() {
		return this.fb.group({
			type: [''],
			phone: ['']
		});
	}

	// Add Fields Method
	addPhoneDirectoryFields() {
		this.getPhoneDirectoryFields.push(this.addOtherFields());
	}

	// Remove Fields Method
	removeFields(index) {
		this.getPhoneDirectoryFields.removeAt(index);
	}


	/**
	 * On destroy
	 */
	ngOnDestroy() {
		if (this.componentSubscriptions) {
			this.componentSubscriptions.unsubscribe();
		}
	}


	/**
	* Checking control validation
	*
	* @param controlName: string => Equals to formControlName
	* @param validationType: string => Equals to valitors name
	*/
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.phoneDirectoryForm.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}

	// Add Phone Directory Fields
	addPhoneDirectory(directoryForm, index) {
		if (this.phoneDirectoryEdit.contact_details.length > 0 && this.phoneDirectoryEdit.contact_details[index]) {
			this.phoneDirectoryEdit.contact_details.forEach((element, i) => {
				if (i === index) {
					element.type = directoryForm.value.type;
					element.phone = directoryForm.value.phone;
					return;
				}
			});
		} else {
			let tempObj: any = {};
			tempObj.type = directoryForm.value.type;
			tempObj.phone = directoryForm.value.phone;
			this.phoneDirectoryEdit.contact_details.push(tempObj);
		}
	}

	// Remove Phone Directory Array Value
	removePhoneDirectory(index) {
		this.phoneDirectoryEdit.contact_details.splice(index, 1);
	}


	onSubmit() {
		this.hasSubmitted = true;
		this.hasFormErrors = false;
		const controls = this.phoneDirectoryForm.controls;
		if (this.phoneDirectoryForm.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		}
		this.phoneDirectoryEdit.branch_id = controls.branch_id.value;

		if (this.phoneDirectoryEdit.id > 0) {
			this.updatePhoneDirectory(this.phoneDirectoryEdit);
		} else {
			this.createPhoneDirectory(this.phoneDirectoryEdit);
		}
	}

	createPhoneDirectory(phoneDirectoryData) {
		this.branchService.createPhoneDirectory(phoneDirectoryData).subscribe(response => {
			this.hasSubmitted = false;
			if (!response) {
				return;
			}
			this.dialogRef.close({ response, isEdit: false });
		});
	}

	updatePhoneDirectory(editPhoneDirectory) {
		this.branchService.updatePhoneDirectory(editPhoneDirectory).subscribe(response => {
			this.hasSubmitted = false;
			if (!response) {
				return;
			}

			this.dialogRef.close({ response, isEdit: true });
		});
	}

	/** Alect Close event */
	onAlertClose() {
		this.hasFormErrors = false;
	}
}
