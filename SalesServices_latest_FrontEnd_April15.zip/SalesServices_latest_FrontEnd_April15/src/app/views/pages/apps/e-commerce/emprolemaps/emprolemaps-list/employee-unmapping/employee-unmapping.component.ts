import { Component, OnInit, ChangeDetectorRef } from "@angular/core";
import { SelectionModel } from "@angular/cdk/collections";
import { MyRolesService } from "../../../../../../../core/e-commerce/_services/myroles.service";
import { EmpRoleMapModel } from "../../../../../../../core/e-commerce";
import { ActivatedRoute, Router } from "@angular/router";

@Component({
	selector: "kt-employee-unmapping",
	templateUrl: "./employee-unmapping.component.html",
	styleUrls: ["./employee-unmapping.component.scss"],
})
export class EmployeeUnmappingComponent implements OnInit {
	selection = new SelectionModel<EmpRoleMapModel>(true, []);
	rolesList = [];
	empId = "";
	employeeDetails;
	selectedEmployee;
	loginEmployee: any;
	constructor(
		private myroleservice: MyRolesService,
		private changeDetectorRef: ChangeDetectorRef,
		private route: ActivatedRoute,
		private router: Router
	) {}

	ngOnInit() {
		this.empId = this.route.snapshot.paramMap.get("id");
		this.getEmployeeRoleData();
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
	}
	getEmployeeRoleData() {
		this.myroleservice
			.getRolesByEmployeeId(
				this.empId,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((data) => {
				this.rolesList = data.dmsRoleDtoList;
				this.employeeDetails = data.employeeDto;
				this.changeDetectorRef.detectChanges();
			});
	}

	masterToggle() {
		if (this.selection.selected.length === this.rolesList.length) {
			this.selection.clear();
		} else {
			this.rolesList.forEach((row) => this.selection.select(row));
		}
	}

	unmapRolesToEmployee() {
		const roleIds = [];
		this.selection.selected.forEach((elem: any) => {
			roleIds.push(elem.roleId);
		});
		const object = {
			empId: this.employeeDetails.empId,
			userName: this.employeeDetails.empName,
			roleIds,
		};
		this.myroleservice
			.unmapRoleFromEmp(
				object,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe(
				(response) => {
					this.selection.clear();
					this.getEmployeeRoleData();
				},
				(error) => {
					this.selection.clear();
					this.getEmployeeRoleData();
				}
			);
	}

	isAllSelected(): boolean {
		const numSelected = this.selection.selected.length;
		const numRows = this.rolesList.length;
		return numSelected === numRows;
	}
	back() {
		this.router.navigate(["/employeeManagement/employees/"]);
	}
}
