import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeUnmappingComponent } from './employee-unmapping.component';

describe('EmployeeUnmappingComponent', () => {
  let component: EmployeeUnmappingComponent;
  let fixture: ComponentFixture<EmployeeUnmappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeUnmappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeUnmappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
