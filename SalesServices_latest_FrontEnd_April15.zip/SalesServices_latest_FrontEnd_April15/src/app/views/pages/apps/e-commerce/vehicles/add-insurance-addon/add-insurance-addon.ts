// Angular
import { Component, OnInit, Input, EventEmitter, ElementRef, ViewChild, ChangeDetectionStrategy, OnDestroy, ChangeDetectorRef } from '@angular/core';
// Material
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort, MatSnackBar, MatDialog } from '@angular/material';
// RXJS
import { debounceTime, distinctUntilChanged, tap, skip, delay, take } from 'rxjs/operators';
import { fromEvent, merge, Subscription, of } from 'rxjs';
// Translate Module
import { TranslateService } from '@ngx-translate/core';
// NGRX
import { Store } from '@ngrx/store';
import { AppState } from '../../../../../../core/reducers';
// CRUD
import { LayoutUtilsService, QueryParamsModel } from '../../../../../../core/_base/crud';
// Services and Models
import { VehicleModel } from '../../../../../../core/e-commerce';

// Components
import { VehiclesService } from '../../../../../../core/e-commerce/_services/vehicles.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { VehicleListService } from '../../../../../../core/e-commerce/_services/VehiclesList.service';
import { url } from 'inspector';
import { DomSanitizer } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
//import * as fileSaver from 'file-saver';
import { FormGroup, FormBuilder } from '@angular/forms';
declare let require: any

import * as _ from 'lodash';
@Component({
	selector: 'kt-add-insurance-addon',
	templateUrl: './add-insurance-addon.html',
	styleUrls: ['./add-insurance-addon.scss']

})
export class AddInsuranceAddonComponent implements OnInit, OnDestroy {
	// Table fields
	message = '';
	displayedColumns = ['vehicle', 'model', 'brand', 'actions'];
	@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
	@ViewChild('sort1', { static: true }) sort: MatSort;
	// Filter fields
	@ViewChild('searchInput', { static: true }) searchInput: ElementRef;
	filterStatus = '';
	filterType = '';
	// Selection
	selection = new SelectionModel<VehicleModel>(true, []);
	vehiclesResult: VehicleModel[] = [];
	// Subscriptions
	private subscriptions: Subscription[] = [];

	VechiclesListData = [];
	insuranceDetailId: any;
	isLoaded = false;
	vehicleId: any;
	public imagesUrl;
	vehiclesForm: FormGroup;
	warrantyForm: FormGroup;
	insuranceDetailForm: FormGroup;
	insuranceMapForm: FormGroup;
	vehicleIdSelected: any;
	varientsList: any = [];
	vehicleSelected: any;
	varientSelected: any;
	varientIdSelected: any = [];
	vehicleSelected1: any;
	varientSelected1: any;
	warrantyCount = 1;
	warrantyArray = [];
	vehicleList = [];
	addonpriceList: any = [];
	noRecord: boolean = true;
	insurnaceName: string;
	insuranceCost: string;
	insuraneRetreived = false;
	insuraneRetreived1 = false;
	warrantyListRetrieved: any = [];
	vehiclesList: any;
	varient: any;
	tempActions: Array<any> = [
		{ actionName: 'editInsurance' },
		{ actionName: 'deleteInsurance' }];
	tempActions1: Array<any> = [
		{ actionName: 'editInsuranceDetail' },
		{ actionName: 'deleteInsuranceDetail' }];

	insuranceIdRetrieved: any;
	insuranceAddOns: any = [];
	insuranceRetreived: any;
	insuranceAddonForm: FormGroup;
	type: any;
	type1: any;
	insuranceDetails: any = [];
	statusList: Array<any> = ["Active", "Inactive"]
	insuranceMapId: any;
	insuranceName1: any;
	policyStatus: any;
	varientMapId: any;
	insuranceIdRetrieved1: any;
	insuranceMappings: any = [];
	editMap: boolean = false;
	type2: string;
	insuranceMapId1: any;
	insuranceId1: any;
	varientIdSelected1: any;
	deleteMap: any;
	deleteMapId: any;
	selected1: any;
	selected2: any;
	selected3: any;

	page = 0;
	pageSize = 10;

	isLoading = false;
	scope: any = {};
	loginEmployee: any;
	vehId: any;

	/**
	 * Component constructor
	 *
	 * @param dialog: MatDialog
	 * @param snackBar: MatSnackBar
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 * @param store: Store<AppState>
	 */
	constructor(
		public dialog: MatDialog,
		private vehSer: VehicleListService,
		public snackBar: MatSnackBar,
		private layoutUtilsService: LayoutUtilsService,
		private translate: TranslateService,
		private store: Store<AppState>,
		private vechileService: VehiclesService,
		private changeDetectorRef: ChangeDetectorRef,
		public modalService: NgbModal,
		private sanitizer: DomSanitizer,
		private router: Router,
		private fb: FormBuilder
	) { }

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));

		this.insuranceAddonForm = this.fb.group({
			vehicleName: [],
			varient: []
		})
		this.insuranceDetailForm = this.fb.group({
			policyName: [],
			status: []
		})
		this.insuranceMapForm = this.fb.group({
			vehicleName: [],
			varient: [],
			cost: [],
			status: []
		})
		this.vehSer.getAllVehiclesData(this.loginEmployee.orgId).subscribe(
			(res) => {
				this.vehicleList = res;

				this.changeDetectorRef.detectChanges();
			},
			(error) => {
				console.log("All Data of organisation error::" + error);
				this.changeDetectorRef.detectChanges();
			},
			() => {}
		);

		this.getInsuranceList();
	}

	getInsuranceAddOnsList() {
		this.insuraneRetreived = false;
		this.insuranceDetails = [];
		const queryParams = new QueryParamsModel({}, '', '', this.page, this.pageSize);
		this.vehSer.getAllInsuranceAddOns(this.loginEmployee.orgId, queryParams).subscribe(res => {
			if (res) {
				this.scope = res;
				this.insuranceDetails = res.insuranceAddons;
				this.insuraneRetreived = true;
				this.changeDetectorRef.detectChanges();
			}
		});
	}

	paginatorEventsAddOns(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.getInsuranceAddOnsList();
	}

	getInsuranceList() {
		this.insuraneRetreived1 = false;
		this.insuranceDetails = [];
		const queryParams = new QueryParamsModel({}, '', '', this.page, this.pageSize);
		this.vehSer.getAllInsuranceDetails(this.loginEmployee.orgId, queryParams).subscribe(res => {
			if (res) {
				this.scope = res;
				this.insuranceDetails = res.insurances;
				this.insuraneRetreived1 = true;
				this.changeDetectorRef.detectChanges();
			}
		});
	}

	paginatorEventsInsurance(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.getInsuranceList();
	}

	openLarge(content) {
		this.modalService.open(content, {
			size: 'lg'
		});
	}

	Variants(vehId) {
		this.vehicleId = vehId;
		localStorage.setItem("vehIdData", this.vehicleId);
		this.router.navigate(['/vehicleManagement/vehicles/variantsList']);
	}

	changeModel(event, val1, val2) {
		this.vehicleSelected = this.vehicleList.find(o => o.model === event.target.innerText);
		this.vehicleIdSelected = this.vehicleSelected.vehicleId;
		this.varientsList = [];
		this.varientIdSelected = [];
		if (this.vehicleSelected.varients != []) {
			this.varientsList = this.vehicleSelected.varients;
		}
	}
	changeStatus(event) {
		this.insuranceDetailForm.controls.status.setValue(event.target.innerText);
	}
	changeVarient(event) {
		this.varientIdSelected = this.varientsList.find(o => o.name === event.target.innerText).id;
	}

	arrayOne(n: number): any[] {
		return Array(n);
	}

	submitInsurance(val1, val2) {
		if (this.addonpriceList.findIndex(element => (element.document_name === val1)) === -1) {
			this.addonpriceList.push({ document_name: val1, cost: val2 });
		} else {
			this.addonpriceList[this.addonpriceList.findIndex(element => (element.document_name === val1))].cost = val2;
		}

		(document.getElementById('insuranceName') as HTMLInputElement).value = '';
		(document.getElementById('insuranceCost') as HTMLInputElement).value = '';

	}
	submitFinalInsurance() {

		if (this.type === 'Edit') {
			let formObj = {
				"insuranceAddOn": {
					"add_on_price": this.addonpriceList,
					"id": this.insuranceIdRetrieved,
					"organization_id": 1,
					"varient_id": this.varientIdSelected,
					"vehicle_id": this.vehicleIdSelected
				}
			}
			this.vehSer.updateInsurance(formObj).subscribe(res => {
				this.getInsuranceAddOnsList();
			});
			this.modalService.dismissAll();
		} else {
			let formObj = {
				"insuranceAddOn": {
					"add_on_price": this.addonpriceList,
					"id": 0,
					"organization_id": 1,
					"varient_id": this.varientIdSelected,
					"vehicle_id": this.vehicleIdSelected
				}
			}
			this.vehSer.saveInsurance(formObj).subscribe(res => {
				this.getInsuranceAddOnsList();
			});
			this.modalService.dismissAll();

		}
		this.addonpriceList = [];
		this.insuranceAddonForm.reset();
	}

	openModal(content) {
		this.modalService.open(content, {
			size: 'lg'
		});
		this.addonpriceList = [];
		this.addonpriceList.push({ document_name: 'Zero Dip', cost: 0 })
		this.insuranceAddonForm.reset();
		this.type = 'Submit';
	}

	openModal1(content) {
		this.modalService.open(content, {
			size: 'lg'
		});
		this.insuranceDetailForm.reset();
		this.type1 = 'Submit';
	}
	submitInsuranceDetail(val) {
		if (this.type1 === 'Edit') {
			let formObj = {
				"insuranceDetails": {
					"id": this.insuranceDetailId,
					"organizationId": 1,
					"policy_name": val.controls.policyName.value,
					"status": val.controls.status.value
				}
			}
			this.vehSer.updateInsuranceDetail(formObj).subscribe(res => {
				this.getInsuranceList();
			});
			this.modalService.dismissAll();
		} else {
			let formObj = {
				"insuranceDetails": {
					"id": 0,
					"organizationId": 1,
					"policy_name": val.controls.policyName.value,
					"status": val.controls.status.value
				}
			}
			this.vehSer.saveInsuranceDetail(formObj).subscribe(res => {
				this.getInsuranceList();
			});
			this.modalService.dismissAll();

		}
		this.addonpriceList = [];
		this.insuranceAddonForm.reset();
	}

	closeLarge() {
		this.modalService.dismissAll();
	}

	editInsurance(val, content, type) {
		this.type = 'Edit';
		this.modalService.open(content, {
			size: 'lg'
		})

		this.addonpriceList = val.addOn.add_on_price;
		this.insuranceIdRetrieved = val.addOn.id;
		this.vehicleSelected1 = this.vehicleList.find(o => o.model === val.vehicleDetails.vehicleDetails.model);
		this.varientsList = this.vehicleSelected1.varients;
		this.vehicleIdSelected = this.vehicleSelected1.vehicleId;
		this.varientSelected1 = this.vehicleSelected1.varients.find(o => o.name === val.vehicleDetails.varient.name);
		this.varientIdSelected = this.varientSelected1.id
		this.insuranceAddonForm.controls.varient.setValue(this.varientSelected1.name);
		this.insuranceAddonForm.controls.vehicleName.setValue(this.vehicleSelected1.model);

	}

	editInsuranceDetail(val, content, type) {
		this.type1 = 'Edit';
		this.modalService.open(content, {
			size: 'lg'
		})
		this.insuranceDetailId = val.id
		this.insuranceDetailForm.controls.policyName.setValue(val.policy_name);
		this.insuranceDetailForm.controls.status.setValue(val.status);
	}

	deleteInsuranceDetail(val, content) {

		this.insuranceDetailId = val.id;
		this.modalService.open(content, {
			size: 'lg'
		});
	}

	deleteInsuranceDetailConfirm(val) {
		if (val === 'true') {
			this.vehSer.insuranceDetailDelete(this.insuranceDetailId).subscribe((result) => {
				this.getInsuranceList();
			});
		}
		this.closeLarge();
	}

	deleteInsurance(val, content) {

		this.insuranceRetreived = val.addOn;
		this.modalService.open(content, {
			size: 'lg'
		});
	}

	deleteInsuranceConfirm(val) {

		if (val === 'true') {
			this.vehSer.insuranceDelete(this.insuranceRetreived.id).subscribe((result) => {
				this.getInsuranceAddOnsList();
			});
		}
		this.closeLarge();
	}

	editInsurance1(val, ndx) {
		(document.getElementById('insuranceName') as HTMLInputElement).value = val.document_name;
		(document.getElementById('insuranceCost') as HTMLInputElement).value = val.cost;
	}

	deleteInsurance1(val, ndx) {

		this.addonpriceList.splice(ndx, 1);

	}

	openMappingModal(content, val) {
		this.modalService.open(content, {
			size: 'lg'
		});

		this.insuranceIdRetrieved1 = val.id;
		this.vehSer.getInsuranceMapping(this.insuranceIdRetrieved1).subscribe(res => {
			this.insuranceMappings = res.insuranceMappingss;
			this.changeDetectorRef.detectChanges();
		},
			error => {
				////
				console.log("All Data of organisation error::" + error);
				this.changeDetectorRef.detectChanges();
			},
			() => {  }
		);
		this.insuranceName1 = val.policy_name;
		this.policyStatus = val.status;
		this.insuranceMapForm.reset();
		this.editMap = false;
	}

	submitInsuranceMap(val, type) {
		if (this.type2 === 'edit') {
			let formObj = {
				"insuranceMapping": {
					"cost": this.insuranceMapForm.controls.cost.value,
					"id": this.insuranceMapId1,
					"insurence_id": this.insuranceId1,
					"policy_name": this.insuranceName1,
					"status": this.insuranceMapForm.controls.status.value,
					"varient_id": this.varientIdSelected1
				}
			}
			this.vehSer.updateInsuranceMappings(formObj).subscribe(res => {
				this.changeDetectorRef.detectChanges();
			},
				error => {
					////
					console.log("All Data of organisation error::" + error);
					this.changeDetectorRef.detectChanges();
				},
				() => {  }
			);

		} else {

			this.varientMapId = this.varientsList.find(o => o.name === val.controls.varient.value).id;
			let formObj = {
				"insuranceMapping": {
					"cost": val.controls.cost.value,
					"id": 0,
					"insurence_id": this.insuranceIdRetrieved1,
					"policy_name": this.insuranceName1,
					"status": val.controls.status.value,
					"varient_id": this.varientMapId
				}
			}
			this.vehSer.saveInsuranceMappings(formObj).subscribe(res => {
				this.changeDetectorRef.detectChanges();
				this.editMap = false;
			},
				error => {
					////
					console.log("All Data of organisation error::" + error);
					this.changeDetectorRef.detectChanges();
				},
				() => {  }
			);
		}
		this.type2 == 'submit';
		this.modalService.dismissAll();
	}

	edtiMapping(val, index) {
		this.editMap = true;
		this.insuranceMapForm.controls.cost.setValue(val.cost);
		this.insuranceMapForm.controls.status.setValue(val.status);
		this.insuranceMapId1 = val.id;
		this.insuranceId1 = val.insurence_id;
		this.varientIdSelected1 = val.varient_id;
		this.type2 = 'edit';
	}

	deleteMapping(content, val, index) {

		this.modalService.open(content, {
			size: 'lg'
		});
		this.deleteMap = val;
		this.deleteMapId = val.id;
	}

	deleteMappingTrue(val) {
		if (val === 'true') {

			this.vehSer.deleteInsuranceMapping(this.deleteMapId).subscribe(res => {
				this.changeDetectorRef.detectChanges();
			},
				error => {
					////
					console.log("All Data of organisation error::" + error);
					this.changeDetectorRef.detectChanges();
				},
				() => {  }
			);
		}
		this.modalService.dismissAll();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(el => el.unsubscribe());
	}
}
