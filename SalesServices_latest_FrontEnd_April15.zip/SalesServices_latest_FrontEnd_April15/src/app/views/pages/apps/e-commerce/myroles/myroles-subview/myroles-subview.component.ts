// Angular
import {
	Component,
	OnInit,
	ElementRef,
	ViewChild,
	ChangeDetectionStrategy,
	OnDestroy,
	ChangeDetectorRef,
} from "@angular/core";
// Material
import { SelectionModel } from "@angular/cdk/collections";
import {
	MatPaginator,
	MatSort,
	MatSnackBar,
	MatDialog,
} from "@angular/material";
// RXJS
import {
	debounceTime,
	distinctUntilChanged,
	tap,
	skip,
	delay,
	take,
} from "rxjs/operators";
import { fromEvent, merge, Subscription, of } from "rxjs";
// Translate Module
import { TranslateService } from "@ngx-translate/core";
// NGRX
import { Store, ActionsSubject } from "@ngrx/store";
import { AppState } from "../../../../../../core/reducers";
// CRUD
import {
	LayoutUtilsService,
	MessageType,
	QueryParamsModel,
} from "../../../../../../core/_base/crud";
// Services and Models
import { MyRoleModel } from "../../../../../../core/e-commerce";
// Components
import { MyRoleEditDialogComponent } from "../myrole-edit/myrole-edit.dialog.component";

import { MyRolesService } from "../../../../../../core/e-commerce/_services";
import { ActivatedRoute, Router } from "@angular/router";
import { each, find, some } from "lodash";
import { MenuAsideService } from "../../../../../../core/_base/layout/services/menu-aside.service";

@Component({
	selector: "kt-myroles-subview",
	templateUrl: "./myroles-subview.component.html",
})
export class MyRolesSubViewComponent implements OnInit, OnDestroy {
	// Table fields
	displayedColumns = ["empname", "designation"];
	displayedColumnsPolicyGroup = [
		"groupname",
		"displayName",
		"description",
		"actions",
	];
	@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
	@ViewChild("sort1", { static: true }) sort: MatSort;
	@ViewChild("sort2", { static: true }) sort2: MatSort;
	// Selection
	selection = new SelectionModel<MyRoleModel>(true, []);
	myrolesResult: MyRoleModel[] = [];
	// Subscriptions
	private subscriptions: Subscription[] = [];
	role_id = "";
	selectedRole: any;
	empData: any = [];
	noData = false;
	isEmpDataLoaded = false;
	policyGroup = [];
	isLoaded = false;
	isLoading = false;
	page = 0;
	pageSize = 10;

	roleId = "";
	roleDetails = [];
	roleEmployeesMapData = [];
	roleMenuMapData = [];

	roleObject = {};
	tempActions = [];
	saveDisablingStatus = false;

	/**
	 * Component constructor
	 *
	 * @param dialog: MatDialog
	 * @param snackBar: MatSnackBar
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 * @param store: Store<AppState>
	 */
	constructor(
		public dialog: MatDialog,
		public snackBar: MatSnackBar,
		private layoutUtilsService: LayoutUtilsService,
		private translate: TranslateService,
		private store: Store<AppState>,
		private myroleservice: MyRolesService,
		private routeData: ActivatedRoute,
		private route: Router,
		private changeDetectorRef: ChangeDetectorRef,
		private menuAsideService: MenuAsideService,
		private router: Router
	) {
		this.roleId = this.routeData.snapshot.paramMap.get("roleId");
	}

	ngOnInit() {
		this.menuAsideService.tempList.forEach((element) => {
			if (element.menuName === "employeeManagement") {
				element.submenu.forEach((subelement) => {
					if (subelement.menuName === "roles") {
						this.tempActions = subelement.actions;
						this.tempActions.forEach((element) => {
							if (element.actionName === "addEmployee") {
							}
						});
					}
				});
			}
		});

		this.loadMyMappingDataByRole();
	}

	/**
	 * On Destroy
	 */
	ngOnDestroy() {
		this.subscriptions.forEach((el) => el.unsubscribe());
	}

	loadMyMappingDataByRole() {
		this.isEmpDataLoaded = false;
		this.myroleservice.getRoleMappingById(this.roleId).subscribe(
			(res) => {
				this.isEmpDataLoaded = true;
				this.roleObject = res;
				this.noData = false;
				this.changeDetectorRef.detectChanges();
			},
			(err) => {
				this.noData = true;
				this.isEmpDataLoaded = true;
				this.changeDetectorRef.detectChanges();
			}
		);
	}

	goBack() {
		this.router.navigate(["/employeeManagement/roles"]);
	}

	scope: any = {};

	unmapEmployeesToRole() {
		const empIds = [];
		this.selection.selected.forEach((elem) => {
			empIds.push(elem["empId"]);
		});
		let object = {
			roleId: this.roleId,
			userName: this.menuAsideService.userName,
			empIds,
		};
		this.myroleservice.unmapEmporRoleDev(object).subscribe(
			(response) => {
				this.selection.clear();
				this.loadMyMappingDataByRole();
			},
			(error) => {
				this.selection.clear();
				this.loadMyMappingDataByRole();
			}
		);
	}

	fetchMyRoles() {
		const messages = [];
		this.selection.selected.forEach((elem) => {
			messages.push({
				text: `${elem.roleName}, ${elem.createdBy}`,
				id: elem.id.toString(),
				status: elem.status,
			});
		});
		this.layoutUtilsService.fetchElements(messages);
	}

	/**
	 * Show UpdateStatuDialog for selected myroles
	 */
	updateStatusForMyRoles() {
		const _title = this.translate.instant(
			"ECOMMERCE.POLICIES.UPDATE_STATUS.TITLE"
		);
		const _updateMessage = this.translate.instant(
			"ECOMMERCE.POLICIES.UPDATE_STATUS.MESSAGE"
		);
		const _statuses = [
			{ value: 0, text: "Suspended" },
			{ value: 1, text: "Active" },
			{ value: 2, text: "Pending" },
		];
		const _messages = [];

		this.selection.selected.forEach((elem) => {
			_messages.push({
				text: `${elem.roleName}, ${elem.createdBy}`,
				id: elem.id.toString(),
			});
		});

		const dialogRef = this.layoutUtilsService.updateStatusForEntities(
			_title,
			_statuses,
			_messages
		);
		dialogRef.afterClosed().subscribe((res) => {
			if (!res) {
				this.selection.clear();
				return;
			}
			this.layoutUtilsService.showActionNotification(
				_updateMessage,
				MessageType.Update,
				10000,
				true,
				true
			);
			this.selection.clear();
		});
	}

	addEmployeeToRole() {
		this.route.navigate([
			"/employeeManagement/roles/subview/emp/",
			this.roleId,
		]);
	}

	addPolicyGroupToRole() {
		this.route.navigate([
			"/employeeManagement/roles/subview/polgrp/",
			this.role_id,
		]);
	}

	/**
	 * Check all rows are selected
	 */
	isAllSelected(): boolean {
		const numSelected = this.selection.selected.length;
		const numRows = this.roleObject["dmsEntity"].employees.length;
		return numSelected === numRows;
	}

	/**
	 * Toggle all selections
	 */
	masterToggle() {
		if (
			this.selection.selected.length ===
			this.roleObject["dmsEntity"].employees.length
		) {
			this.selection.clear();
		} else {
			this.roleObject["dmsEntity"].employees.forEach((row) =>
				this.selection.select(row)
			);
		}
	}

	/** UI */
	/**
	 * Retursn CSS Class Name by status
	 *
	 * @param status: number
	 */
	getItemCssClassByStatus(status: number = 0): string {
		switch (status) {
			case 0:
				return "danger";
			case 1:
				return "success";
			case 2:
				return "metal";
		}
		return "";
	}

	/**
	 * Returns Item Status in string
	 * @param status: number
	 */
	getItemStatusString(status: number = 0): string {
		switch (status) {
			case 0:
				return "Suspended";
			case 1:
				return "Active";
			case 2:
				return "Pending";
		}
		return "";
	}

	/**
	 * Returns CSS Class Name by type
	 * @param status: number
	 */
	getItemCssClassByType(status: number = 0): string {
		switch (status) {
			case 0:
				return "accent";
			case 1:
				return "primary";
			case 2:
				return "";
		}
		return "";
	}

	/**
	 * Returns Item Type in string
	 * @param status: number
	 */
	getItemTypeString(status: number = 0): string {
		switch (status) {
			case 0:
				return "Business";
			case 1:
				return "Individual";
		}
		return "";
	}

	onSubmit() {
		this.saveDisablingStatus = false;
		this.myroleservice.updateMapping(this.roleObject).subscribe((res) => {
			if (res.success === true) {
				this.layoutUtilsService.showActionNotification(
					"SuccessFully Saved",
					MessageType.Create
				);
			} else {
				this.layoutUtilsService.showActionNotification(
					"Error Saving, Try Again",
					MessageType.Create
				);
			}
		});
	}

	isSelectedChanged($event, menu: any) {
		this.saveDisablingStatus = true;

		if (menu.submenu) {
			if (menu.submenu.length > 0 && menu.mappedToRole) {
				each(menu.submenu, (item: any) => {
					item.mappedToRole = true;
					if (item.actions.length > 0 && item.mappedToRole) {
						each(item.actions, (subItem: any) => {
							subItem.mappedToRole = true;
						});
					}
				});
				return;
			}
		} else if (menu.actions) {
			if (menu.actions.length > 0 && menu.mappedToRole) {
				each(menu.actions, (item: any) => {
					item.mappedToRole = true;
				});
				return;
			}
		}

		if (menu.submenu) {
			if (menu.submenu.length > 0 && !menu.mappedToRole) {
				each(menu.submenu, (item: any) => {
					item.mappedToRole = false;
					if (item.actions.length > 0 && !item.mappedToRole) {
						each(item.actions, (subItem: any) => {
							subItem.mappedToRole = false;
						});
					}
				});
				return;
			}
		} else if (menu.actions) {
			if (menu.actions.length > 0 && !menu.mappedToRole) {
				each(menu.actions, (item: any) => {
					item.mappedToRole = false;
				});
				return;
			}
		}
	}

	resetPermission() {
		this.loadMyMappingDataByRole();
	}
}
