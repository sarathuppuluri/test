// Angular
import {
	Component,
	OnInit,
	ElementRef,
	ViewChild,
	ChangeDetectionStrategy,
	OnDestroy,
	ChangeDetectorRef,
} from "@angular/core";
// Material
import { SelectionModel } from "@angular/cdk/collections";
import {
	MatPaginator,
	MatSort,
	MatSnackBar,
	MatDialog,
} from "@angular/material";
// RXJS
import {
	debounceTime,
	distinctUntilChanged,
	tap,
	skip,
	delay,
	take,
} from "rxjs/operators";
import { fromEvent, merge, Subscription, of } from "rxjs";
// Translate Module
import { TranslateService } from "@ngx-translate/core";
// NGRX
import { Store, ActionsSubject } from "@ngrx/store";
import { AppState } from "../../../../../../core/reducers";
// CRUD
import {
	LayoutUtilsService,
	MessageType,
	QueryParamsModel,
} from "../../../../../../core/_base/crud";
// Services and Models
import { MyRoleModel } from "../../../../../../core/e-commerce";

import { MyRolesService } from "../../../../../../core/e-commerce/_services";
import { Router, ActivatedRoute } from "@angular/router";
import { MenuAsideService } from "../../../../../../core/_base/layout/services/menu-aside.service";

import { FormGroup, FormBuilder } from "@angular/forms";

@Component({
	selector: "kt-myroles-subview-emp",
	templateUrl: "./myroles-subview-emp.component.html",
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MyRolesSubViewEmpComponent implements OnInit, OnDestroy {
	isObjectValue: boolean;

	/**
	 * Component constructor
	 *
	 * @param dialog: MatDialog
	 * @param snackBar: MatSnackBar
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 * @param store: Store<AppState>
	 */
	constructor(
		public dialog: MatDialog,
		public snackBar: MatSnackBar,
		private layoutUtilsService: LayoutUtilsService,
		private translate: TranslateService,
		private store: Store<AppState>,
		private myroleservice: MyRolesService,
		private router: Router,
		private routeData: ActivatedRoute,
		private menuAsideService: MenuAsideService,
		private changeDetectorRef: ChangeDetectorRef,
		private formBuilder: FormBuilder
	) {}
	// Table fields
	displayedColumns = ["select", "empName", "designation"];
	@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
	@ViewChild("sort1", { static: true }) sort: MatSort;
	// Selection
	selection = new SelectionModel<MyRoleModel>(true, []);
	myrolesResult: MyRoleModel[] = [];
	role_id = "";
	// Subscriptions
	private subscriptions: Subscription[] = [];

	empData: any = [];
	tempData: any = [];
	empRoleMappedData: any = [];
	mappedEmployees: any = [];
	selectedList = [];
	list: any = [];
	isLoaded = false;

	tempActions = [];
	page = 0;
	pageSize = 10;

	scope: any = {};

	employeesList: any = [];
	isLoading = false;

	searchFormGroup: FormGroup;
	searchProgress = false;
	message = "";

	ngOnInit() {
		this.role_id = this.routeData.snapshot.paramMap.get("roleId");

		this.menuAsideService.tempList.forEach((element) => {
			if (element.menuName === "employeeManagement") {
				element.submenu.forEach((subelement) => {
					if (subelement.menuName === "employees") {
						this.myroleservice.readUrl = subelement.apiUrl;
					}
				});
			}
		});
		this.searchForm();
		this.loadEmployeesList();
	}
	loadEmployeesList() {
		this.employeesList = [];
		this.isLoading = true;
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize
		);
		this.myroleservice
			.getEmpNotMappedOnce(this.role_id, queryParams)
			.subscribe(
				(response) => {
					if (response && response.dmsEntity) {
						this.scope = response.dmsEntity.employeesPage;
						this.employeesList =
							response.dmsEntity.employeesPage.content;
					} else {
						this.scope.totalElements = 0;
					}
					this.isLoading = false;
					this.isObjectValue = false;
					this.changeDetectorRef.detectChanges();
				},
				(error) => {
					this.isLoading = false;
					this.isObjectValue = false;
					this.scope.totalElements = 0;
					this.changeDetectorRef.detectChanges();
				}
			);
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.loadEmployeesList();
	}

	// search role
	searchForm() {
		this.searchFormGroup = this.formBuilder.group({
			name: [""],
			empId: [""],
		});
	}

	// submit search role name
	onSubmit() {
		this.searchProgress = true;
		const controls = this.searchFormGroup.controls;
		this.message = "";
		this.employeesList = [];
		this.myroleservice
			.getEmployeesNameOrIdRoles(
				controls.name.value,
				controls.empId.value,
				this.role_id
			)
			.subscribe(
				(res) => {
					this.searchProgress = false;
					if (res.statusCode !== 400 && res.status !== 500) {
						if (
							Array.isArray(res.dmsEntity.employeeDTOs) === false
						) {
							if (res.status !== 500) {
								this.employeesList.push(
									res.dmsEntity.employeeDTOs
								);
							} else {
								this.message = "No Employees Found";
							}
						} else {
							this.isObjectValue = true;
							this.employeesList = res.dmsEntity.employeeDTOs;
							this.scope.totalElements = this.employeesList.length;
						}
					} else {
						this.employeesList = [];
						this.scope.totalElements = 0;
					}
					this.changeDetectorRef.detectChanges();
				},
				(error) => {
					this.searchProgress = false;
					this.employeesList = [];
					this.scope.totalElements = 0;
					this.changeDetectorRef.detectChanges();
				}
			);
	}

	// reset serach role name
	onReset() {
		this.searchFormGroup.reset();
		this.message = "";
		this.loadEmployeesList();
	}

	mapEmployeesToRole() {
		const empIds = [];
		this.selection.selected.forEach((elem) => {
			empIds.push(elem["empId"]);
		});
		let object = {
			roleId: this.role_id,
			userName: this.menuAsideService.userName,
			empIds,
		};
		this.myroleservice.mapEmpOrRoleDev(object).subscribe(
			(response) => {
				this.router.navigate([
					"/employeeManagement/roles/subview/",
					this.role_id,
				]);
			},
			(error) => {
				this.router.navigate([
					"/employeeManagement/roles/subview/",
					this.role_id,
				]);
			}
		);
	}

	/**
	 * On Destroy
	 */
	ngOnDestroy() {
		this.subscriptions.forEach((el) => el.unsubscribe());
	}

	/**
	 * Load MyRoles List from service through data-source
	 */
	loadMyRolesList() {
		this.selection.clear();
		const queryParams = new QueryParamsModel(
			this.filterConfiguration(),
			this.sort.direction,
			this.sort.active,
			this.paginator.pageIndex,
			this.paginator.pageSize
		);
		// Call request from server
		// this.store.dispatch(new MyRolesPageRequested({ page: queryParams }));
		this.selection.clear();
	}

	/**
	 * Returns object for filter
	 */
	filterConfiguration(): any {
		const filter: any = {};
	}

	/** ACTIONS */
	/**
	 * Delete myrole
	 *
	 * @param _item: MyRoleModel
	 */
	deleteMyRole(_item: MyRoleModel) {
		const _title: string = this.translate.instant(
			"ECOMMERCE.POLICIES.DELETE_POLICY_SIMPLE.TITLE"
		);
		const _description: string = this.translate.instant(
			"ECOMMERCE.POLICIES.DELETE_POLICY_SIMPLE.DESCRIPTION"
		);
		const _waitDesciption: string = this.translate.instant(
			"ECOMMERCE.POLICIES.DELETE_POLICY_SIMPLE.WAIT_DESCRIPTION"
		);
		const _deleteMessage = this.translate.instant(
			"ECOMMERCE.POLICIES.DELETE_POLICY_SIMPLE.MESSAGE"
		);

		const dialogRef = this.layoutUtilsService.deleteElement(
			_title,
			_description,
			_waitDesciption
		);
		dialogRef.afterClosed().subscribe((res) => {
			if (!res) {
				return;
			}

			this.layoutUtilsService.showActionNotification(
				_deleteMessage,
				MessageType.Delete
			);
		});
	}

	/**
	 * Delete selected myroles
	 */
	deleteMyRoles() {
		const _title: string = this.translate.instant(
			"ECOMMERCE.POLICIES.DELETE_POLICY_MULTY.TITLE"
		);
		const _description: string = this.translate.instant(
			"ECOMMERCE.POLICIES.DELETE_POLICY_MULTY.DESCRIPTION"
		);
		const _waitDesciption: string = this.translate.instant(
			"ECOMMERCE.POLICIES.DELETE_POLICY_MULTY.WAIT_DESCRIPTION"
		);
		const _deleteMessage = this.translate.instant(
			"ECOMMERCE.POLICIES.DELETE_POLICY_MULTY.MESSAGE"
		);

		const dialogRef = this.layoutUtilsService.deleteElement(
			_title,
			_description,
			_waitDesciption
		);
		dialogRef.afterClosed().subscribe((res) => {
			if (!res) {
				return;
			}

			const idsForDeletion: number[] = [];
			for (let i = 0; i < this.selection.selected.length; i++) {
				idsForDeletion.push(this.selection.selected[i].id);
			}
			this.layoutUtilsService.showActionNotification(
				_deleteMessage,
				MessageType.Delete
			);
			this.selection.clear();
		});
	}

	/**
	 * Fetch selected myroles
	 */
	fetchMyRoles() {
		const messages = [];
		this.selection.selected.forEach((elem) => {
			messages.push({
				text: `${elem.roleName}, ${elem.createdBy}`,
				id: elem.id.toString(),
				status: elem.status,
			});
		});
		this.layoutUtilsService.fetchElements(messages);
	}

	/**
	 * Show UpdateStatuDialog for selected myroles
	 */
	updateStatusForMyRoles() {
		const _title = this.translate.instant(
			"ECOMMERCE.POLICIES.UPDATE_STATUS.TITLE"
		);
		const _updateMessage = this.translate.instant(
			"ECOMMERCE.POLICIES.UPDATE_STATUS.MESSAGE"
		);
		const _statuses = [
			{ value: 0, text: "Suspended" },
			{ value: 1, text: "Active" },
			{ value: 2, text: "Pending" },
		];
		const _messages = [];

		this.selection.selected.forEach((elem) => {
			_messages.push({
				text: `${elem.roleName}, ${elem.createdBy}`,
				id: elem.id.toString(),
			});
		});

		const dialogRef = this.layoutUtilsService.updateStatusForEntities(
			_title,
			_statuses,
			_messages
		);
		dialogRef.afterClosed().subscribe((res) => {
			if (!res) {
				this.selection.clear();
				return;
			}

			this.layoutUtilsService.showActionNotification(
				_updateMessage,
				MessageType.Update,
				10000,
				true,
				true
			);
			this.selection.clear();
		});
	}

	/**
	 * Show add myrole dialog
	 */
	addMyRole() {
		const newMyRole = new MyRoleModel();
		newMyRole.clear(); // Set all defaults fields
		this.editMyRole(newMyRole);
	}

	/**
	 * Show Edit myrole dialog and save after success close result
	 * @param myrole: MyRoleModel
	 */
	editMyRole(myrole: MyRoleModel) {
		let saveMessageTranslateParam = "ECOMMERCE.POLICIES.EDIT.";
		saveMessageTranslateParam +=
			myrole.id > 0 ? "UPDATE_MESSAGE" : "ADD_MESSAGE";
		const _saveMessage = this.translate.instant(saveMessageTranslateParam);
		const _messageType =
			myrole.id > 0 ? MessageType.Update : MessageType.Create;
	}

	/**
	 * Check all rows are selected
	 */
	isAllSelected(): boolean {
		const numSelected = this.selection.selected.length;
		const numRows = this.employeesList.length;
		return numSelected === numRows;
	}

	/**
	 * Toggle all selections
	 */
	masterToggle() {
		if (this.selection.selected.length === this.employeesList.length) {
			this.selection.clear();
		} else {
			this.employeesList.forEach((row) => this.selection.select(row));
		}
	}

	/** UI */
	/**
	 * Retursn CSS Class Name by status
	 *
	 * @param status: number
	 */
	getItemCssClassByStatus(status: number = 0): string {
		switch (status) {
			case 0:
				return "danger";
			case 1:
				return "success";
			case 2:
				return "metal";
		}
		return "";
	}

	/**
	 * Returns Item Status in string
	 * @param status: number
	 */
	getItemStatusString(status: number = 0): string {
		switch (status) {
			case 0:
				return "Suspended";
			case 1:
				return "Active";
			case 2:
				return "Pending";
		}
		return "";
	}

	/**
	 * Returns CSS Class Name by type
	 * @param status: number
	 */
	getItemCssClassByType(status: number = 0): string {
		switch (status) {
			case 0:
				return "accent";
			case 1:
				return "primary";
			case 2:
				return "";
		}
		return "";
	}

	/**
	 * Returns Item Type in string
	 * @param status: number
	 */
	getItemTypeString(status: number = 0): string {
		switch (status) {
			case 0:
				return "Business";
			case 1:
				return "Individual";
		}
		return "";
	}
}
