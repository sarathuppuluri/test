// Angular
import {
	Component,
	OnInit,
	Input,
	EventEmitter,
	ElementRef,
	ViewChild,
	ChangeDetectionStrategy,
	OnDestroy,
	ChangeDetectorRef,
	Inject,
	AfterViewInit,
} from "@angular/core";
import { DatePipe } from "@angular/common";
// Material
import { SelectionModel } from "@angular/cdk/collections";
import {
	MatPaginator,
	MatSort,
	MatSnackBar,
	MatTableDataSource,
	MatSelect,
} from "@angular/material";
import {
	MatDialog,
	MatDialogRef,
	MAT_DIALOG_DATA,
	MatDialogConfig,
} from "@angular/material/dialog";
// RXJS
import {
	debounceTime,
	distinctUntilChanged,
	tap,
	skip,
	delay,
	take,
} from "rxjs/operators";
import { fromEvent, merge, Subscription, of } from "rxjs";
// Translate Module
import { TranslateService } from "@ngx-translate/core";
// NGRX
import { Store, ActionsSubject } from "@ngrx/store";
import { AppState } from "../../../../../../core/reducers";
// CRUD
import {
	LayoutUtilsService,
	MessageType,
	QueryParamsModel,
} from "../../../../../../core/_base/crud";
// Services and Models
import {
	VehicleModel,
	Lead360Service,
} from "../../../../../../core/e-commerce";

// Components
import { VehiclesService } from "../../../../../../core/e-commerce/_services/vehicles.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { VehicleListService } from "../../../../../../core/e-commerce/_services/VehiclesList.service";
import { url } from "inspector";
import { DomSanitizer } from "@angular/platform-browser";
import { NavigationEnd, Router } from "@angular/router";
//import * as fileSaver from 'file-saver';
import { saveAs } from "file-saver";
import { HttpResponse } from "@angular/common/http";
import {
	FormGroup,
	FormBuilder,
	FormArray,
	Validators,
	FormControl,
} from "@angular/forms";
import { AdminService } from "../../../../../../core/e-commerce/_services/admin.service";

declare let require: any;
const FileSaver = require("file-saver");

import * as _ from "lodash";
import { NgStyle } from "@angular/common";
import { element } from "protractor";
import moment from "moment";
import { deleteConfirmationDialog } from "../accessories/delete-confirmation-dialog.component";

export interface AccessoriesData {
	category: string;
	cost: number;
	createdBy: number;
	createdDate: string;
	id: number;
	imageUrl: string;
	item: string;
	modifiedBy: string;
	modifiedDate: string;
	origanistionId: number;
	partName: string;
	partNo: string;
	vehicleId: number;
}

@Component({
	// tslint:disable-next-line:component-selector
	selector: "kt-demo-vehicles",
	templateUrl: "./demo-vehicles.component.html",
	styleUrls: ["./demo-vehicles.component.scss"],
})
export class DemoVehiclesComponent implements OnInit, AfterViewInit, OnDestroy {
	status: string;
	type: string;
	loginEmployee: any = [];

	@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
	@ViewChild(MatSort, { static: true }) sortTable: MatSort;
	// Filter fields
	@ViewChild("searchInput", { static: true }) searchInput: ElementRef;
	filterStatus = "";
	filterType = "";
	// Selection
	selection = new SelectionModel<VehicleModel>(true, []);
	vehiclesResult: VehicleModel[] = [];
	// Subscriptions
	private subscriptions: Subscription[] = [];

	VechiclesListData = [];
	isLoaded = false;
	vehicleId: any;

	vehiclesForm: FormGroup;
	demoVehicleForm: FormGroup;
	externalFileName: any;
	internalFileName: any;
	exterior360FileName: any;
	interior360FileName: any;
	edocsName: any;
	vehicleDetails: {};
	deleteIndex: any;
	editIndex: any;
	editModelName: any;
	editedModelObj: any;
	exteriorUrl: any;
	interiorUrl: any;
	interiorOrExterior: any;
	interiorOrExteriorUrl: any;
	accessoriesDataSource: MatTableDataSource<AccessoriesData>;
	vehId: any;
	vehicId: any;
	/**
	 * Component constructor
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 * @param store: Store<AppState>
	 */
	constructor(
		public dialog: MatDialog,
		private vehSer: VehicleListService,
		public snackBar: MatSnackBar,
		private layoutUtilsService: LayoutUtilsService,
		private translate: TranslateService,
		private store: Store<AppState>,
		private vechileService: VehiclesService,
		private changeDetectorRef: ChangeDetectorRef,
		private modalService: NgbModal,
		private sanitizer: DomSanitizer,
		private router: Router,
		private fb: FormBuilder
	) {}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));

		this.demoVehicleForm = this.fb.group({
			category: [null, Validators.required],
			imageUrl: ["", Validators.required],
			partName: ["", Validators.required],
			partNo: ["", Validators.required],
			item: ["", Validators.required],
			cost: ["", Validators.required],
		});
		this.getDemoVehicles();
		const data = "some text";
		const blob = new Blob([data], { type: "application/octet-stream" });
		this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
			window.URL.createObjectURL(blob)
		);
	}

	Variants(vehId) {
		this.vehicleId = vehId;
		localStorage.setItem("vehIdData", this.vehicleId);
		this.router.navigate(["/vehicleManagement/vehicles/variantsList"]);
	}

	ngAfterViewInit() {
		this.vehicId = localStorage.getItem("vehIdData");
	}

	tempData = [];
	AllDataBranch: any = [];
	vehicleList: any = [];
	eBroucher: any = [];
	fuelType: any = [];
	fuelNames: any = [];
	FuelData: any = [];
	eBroucherFile: any = [];
	transmissionType: any = [];
	FiltertransmissionType: any = [];
	transmissionTypeData: any = [];
	docfiles: any = [];
	docNameType: any = [];
	docs: any = [];
	docUrl: any = [];
	docData: any = [];
	ebroucher = [];
	ebroucherDataUrl = [];
	ebroucherDataUrlTwo = [];
	ebroucherName = [];
	ebroucherDataNameTwo = [];
	eBroucherDownload: any = [];
	interiorImages: any = [];
	intLeng: any = [];

	downloadFiles: any = [];
	docObj: any = [];
	fileUrl;
	files = [];
	downloadFile(dataDoc) {
		dataDoc.forEach((ele) => {
			FileSaver.saveAs(ele.url, ele.document_name);
		});
	}
	brouchureDocOpen(val) {
		val.forEach((ele) => {
			if (ele.document_name === "Vehicle_Sepcifications")
				window.open(ele.url);
		});
	}
	compareDocOpen(val) {
		val.forEach((ele) => {
			if (ele.document_name === "Comparison") window.open(ele.url);
		});
	}
	/**
	 * On Destroy
	 */

	ngOnDestroy() {
		this.subscriptions.forEach((el) => el.unsubscribe());
	}

	deleteModel(i, content) {
		this.modalService.open(content, {
			size: "lg",
		});
		this.deleteIndex = i;
	}

	dismissModal() {
		this.modalService.dismissAll();
	}

	addDemoVehicle() {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		dialogConfig.width = "900px";
		dialogConfig.height = "auto";
		dialogConfig.panelClass = "custom-modalbox";
		dialogConfig.data = {};
		const dialogRef = this.dialog.open(
			CreateDemoVehicleDialog,
			dialogConfig
		);
		dialogRef.afterClosed().subscribe((result) => {
			if (result === "success") {
				this.getDemoVehicles();
			}
		});
	}

	updateDemoVehicles(demoVehicle) {
		if (demoVehicle.id != "") {
			const dialogConfig = new MatDialogConfig();
			dialogConfig.disableClose = false;
			dialogConfig.autoFocus = true;
			dialogConfig.width = "900px";
			//dialogConfig.height='480px';
			dialogConfig.data = demoVehicle;

			const dialogRef = this.dialog.open(
				CreateDemoVehicleDialog,
				dialogConfig
			);

			dialogRef.afterClosed().subscribe((result) => {
				if (result === "success") {
					this.getDemoVehicles();
				}
			});
		}
		// this.modalService.dismissAll();
	}

	deleteDemoVehicle(accessoryObj) {
		if (accessoryObj.id != "") {
			const dialogConfig = new MatDialogConfig();
			dialogConfig.disableClose = false;
			dialogConfig.autoFocus = true;
			dialogConfig.width = "400px";
			//dialogConfig.height='480px';
			dialogConfig.data = {
				message: "Are you sure want to delete?",
				buttonText: { ok: "Yes", cancel: "No" },
			};
			const dialogRef = this.dialog.open(
				deleteConfirmationDialog,
				dialogConfig
			);
			dialogRef.afterClosed().subscribe((confirmed: boolean) => {
				if (confirmed) {
					this.vehSer
						.deleteDemoVehicle(accessoryObj.id)
						.subscribe((res: any) => {
							if (res.status === "SUCCESS") {
								this.openSnackBar(
									accessoryObj.vehicleInfo.model +
										" - Demo Vehicle has been deleted.",
									"SUCCESS"
								);
								this.getDemoVehicles();
								this.changeDetectorRef.detectChanges();
							} else {
								this.openSnackBar(
									res.status,
									res.statusDescription
								);
							}
						});
				}
			});
		}
	}

	limit: number = 10;
	offset: number = 0;
	totalElements: number = 0;
	isLoading: boolean = true;
	demoVehiclesList: any = [];
	sltdModelObj: any;
	displayedAccessoriesColumns: string[] = [
		"imageUrl",
		"partName",
		"partNo",
		"category",
		"item",
		"cost",
		"id",
	];
	getDemoVehicles() {
		this.status = "";
		this.type = "";
		this.isLoading = true;
		this.vehSer
			.getAllDemoVehicles(
				this.loginEmployee.branchId,
				this.loginEmployee.orgId,
				this.limit,
				this.offset
			)
			.subscribe((res) => {
				this.isLoading = false;
				if (res.status === "SUCCESS") {
					this.demoVehiclesList = res.vehicles;
					this.totalElements = res.totalCount;
					this.changeDetectorRef.detectChanges();
				} else {
					this.openSnackBar(res.statusDescription, res.status);
				}
			});
	}

	public paginatorEvents(event) {
		this.limit = event.pageSize;
		this.offset = event.pageIndex;
		this.getDemoVehicles();
	}

	openSnackBar(message: string, action: string) {
		this.snackBar.open(message, action, {
			duration: 2000,
		});
	}
}

/********************************************************************************************CreateDemoVehicleDialog*********************************************************************************** */

@Component({
	selector: "create-demovehicle-dialog",
	templateUrl: "./create-demovehicle-dialog.html",
	styleUrls: ["./demo-vehicles.component.scss"],
})
export class CreateDemoVehicleDialog {
	loginEmployee: any;
	allSelected = false;
	otherimagepush: Array<any> = [];
	attachmentUrl: any = [];

	demoVehicleForm = this.formBuilder.group({
		model: [null, Validators.required],
		variant: [null, Validators.required],
		color: [null, ""],
		chassisNo: ["", Validators.required],
		engineno: ["", Validators.required],
		rcNo: ["", Validators.required],
		kmsReading: [""],
		insurenceNo: ["", Validators.required],
		insurenceCompany: ["", Validators.required],
		type: [null, Validators.required],
		status: [null, Validators.required],
		remarks: ["", ""],
		demoVehicleAttachments: this.formBuilder.array([]),
	});
	get docArray(): FormArray {
		return this.demoVehicleForm.get("demoVehicleAttachments") as FormArray;
	}
	selectedObj: any;
	startDate;
	searchMsg: string = "";

	isLoading: boolean;
	_subscription;

	vechilesData: any = [];
	vechileModelsList = [];
	variantsList = [];
	colorsList = [];
	fuelTypeList = [];
	variantRecord = [];

	@ViewChild("myModels", { static: true }) skillSel: MatSelect;

	constructor(
		private el: ElementRef,
		private formBuilder: FormBuilder,
		private _snackBar: MatSnackBar,
		private changeDetectorRef: ChangeDetectorRef,
		private lead360Service: Lead360Service,
		private vehicleListService: VehicleListService,
		public dialogRef: MatDialogRef<CreateDemoVehicleDialog>,
		@Inject(MAT_DIALOG_DATA) data
	) {
		this.selectedObj = data;
		this.startDate = new Date(
			new Date().getFullYear(),
			new Date().getMonth(),
			new Date().getDate()
		);
	}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.getVehicleDetails(this.loginEmployee.orgId);
		if (this.selectedObj.id) {
			this.patchForm();
		}
	}
	AddOtherIMG() {
		this.docArray.push(this.addOtherGroup());
		this.otherimagepush.push("");
	}
	removeOtherIMG(index) {
		this.docArray.removeAt(index);
		this.otherimagepush.splice(index, 1);
		this.attachmentUrl.splice(index, 1);
	}
	// add other images
	addOtherGroup() {
		return this.formBuilder.group({
			documentName: [],
			url: [],
		});
	}

	otherImagesOnFileSelected(event, idx) {
		const formData = new FormData();
		formData.append("uploadFile", event.target.files[0]);
		this.vehicleListService
			.uploadDemoVehicleDocs(formData, "demovehicles")
			.subscribe((res: any) => {
				this.attachmentUrl[idx] = res.confirmationId;
				this.changeDetectorRef.detectChanges();
				this.otherimagepush[idx] = {
					documentName: this.demoVehicleForm.value
						.demoVehicleAttachments[idx].documentName,
					url: this.attachmentUrl[idx],
				};
			});
	}
	/**
	 * this method is for patch the form with exsiting test Obj info.
	 */
	public patchForm() {
		this.demoVehicleForm.controls["chassisNo"].setValue(
			this.selectedObj.chassisNo
		);
		this.demoVehicleForm.controls["engineno"].setValue(
			this.selectedObj.engineno
		);
		this.demoVehicleForm.controls["rcNo"].setValue(this.selectedObj.rcNo);
		this.demoVehicleForm.controls["kmsReading"].setValue(
			this.selectedObj.kmsReading
		);
		this.demoVehicleForm.controls["insurenceNo"].setValue(
			this.selectedObj.insurenceNo
		);
		this.demoVehicleForm.controls["insurenceCompany"].setValue(
			this.selectedObj.insurenceCompany
		);

		this.demoVehicleForm.controls["type"].setValue(this.selectedObj.type);
		this.demoVehicleForm.controls["status"].setValue(
			this.selectedObj.status
		);
		this.demoVehicleForm.controls["remarks"].setValue(
			this.selectedObj.remarks
		);

		this.selectedObj.documents.forEach((element, i) => {
			this.docArray.push(this.addOtherGroup());
			this.attachmentUrl.push(element.url);
			let temp = (<FormArray>(
				this.demoVehicleForm.controls["demoVehicleAttachments"]
			)).at(i);
			temp.patchValue({
				documentName: element.docType,
			});
		});
		this.otherimagepush = this.selectedObj.documents;
		this.changeDetectorRef.detectChanges();
	}
	// Get vechiles Details
	getVehicleDetails(orgid) {
		this.lead360Service.getAllVehicleDetails(orgid).subscribe((data) => {
			this.vechilesData = data;
			if (this.vechilesData.length > 0) {
				let currentModel = null;
				if (this.selectedObj.id) {
					for (let vechileObj of this.vechilesData) {
						if (
							vechileObj.vehicleId === this.selectedObj.vehicleId
						) {
							currentModel = vechileObj;
							this.demoVehicleForm.patchValue({
								model: currentModel,
							});
						}
					}

					let currentVarientObj = null;
					for (let currentVarient of currentModel.varients) {
						if (currentVarient.id === this.selectedObj.varientId) {
							currentVarientObj = currentVarient;
							this.demoVehicleForm.patchValue({
								variant: currentVarientObj,
							});
						}
					}
					setTimeout(() => {
						this.colorsList = currentVarientObj.vehicleImages;
						for (let currentColor of currentVarientObj.vehicleImages) {
							if (
								currentColor.vehicleImageId ===
								this.selectedObj.colorId
							) {
								this.demoVehicleForm.patchValue({
									color: currentColor,
								});
								this.changeDetectorRef.detectChanges();
							}
						}
					}, 1500);
				}
			}
			this.changeVechileModel();
		});
	}

	//Change Vechile Model
	changeVechileModel() {
		this.variantRecord = [];
		this.colorsList = [];
		const selectedModel = this.demoVehicleForm.controls.model.value;
		const promise = new Promise((resolve) => {
			if (
				selectedModel !== null &&
				selectedModel !== "Select" &&
				selectedModel !== ""
			) {
				resolve(selectedModel);
			}
		});

		promise.then(() => {
			let tempData = this.vechilesData
				.filter((record) => record.model === selectedModel.model)
				.map((obj) => {
					return {
						variantsList: obj.varients,
					};
				})[0];
			tempData = tempData;
			this.variantsList = tempData.variantsList || [];
		});
	}
	// Change Variant
	changeVariant() {
		this.variantRecord = [];
		this.colorsList = [];
		const selectedVariant = this.demoVehicleForm.controls.variant.value;
		const promise = new Promise((resolve) => {
			if (
				selectedVariant !== null &&
				selectedVariant !== "Select" &&
				selectedVariant !== ""
			) {
				this.variantRecord = this.variantsList.filter(
					(record) => record.name === selectedVariant.name
				);
				this.colorsList = this.variantRecord[0].vehicleImages;
				resolve(this.colorsList);
			}
		});

		promise.then(() => {
			this.colorsList = this.variantRecord[0].vehicleImages;
		});
	}

	loadMyRolesListView() {
		this.isLoading = true;
	}
	// File Upload for Lead Attachments
	fileUploadObj: any;
	fileChoose(event, docType) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			const formData = new FormData();
			formData.append("file", file);
			formData.append("model", this.selectedObj.modelName);
			formData.append("documentType", docType);
			this.vehicleListService
				.uploadAccessory(formData)
				.subscribe((res) => {
					if (res.documentPath) {
						this.demoVehicleForm
							.get("imageUrl")
							.setValue(res.documentPath);

						this.fileUploadObj = res;
					} else {
						this.demoVehicleForm.controls["imageUrl"].setValue("");
						this.fileUploadObj = {};
					}
					this.changeDetectorRef.detectChanges();
				});
		}
	}

	saveDemoVehicle(type) {
		const invalidControl = this.el.nativeElement.querySelector(
			".ng-invalid"
		);
		if (invalidControl) {
			invalidControl.focus();
		}
		if (this.demoVehicleForm.value.model === null) {
			this.openSnackBar("Please select the Model.", "");
			return null;
		}
		if (this.demoVehicleForm.value.variant === null) {
			this.openSnackBar("Please select the Variant.", "");
			return null;
		}
		if (this.demoVehicleForm.value.color === null) {
			this.openSnackBar("Please select the Color.", "");
			return null;
		}
		if (this.demoVehicleForm.value.chassisNo === "") {
			//( < any > this.demoVehicleForm.get('chassisNo')).nativeElement.focus();
			this.openSnackBar(
				"Chassis No field should not be empty.Please enter.",
				""
			);
			return null;
		}
		if (this.demoVehicleForm.value.engineno === "") {
			this.openSnackBar(
				"Engine Number field should not be empty.Please enter.",
				""
			);
			return null;
		}
		if (this.demoVehicleForm.value.rcNo === "") {
			this.openSnackBar(
				"RC Number field should not be empty.Please enter.",
				""
			);
			return null;
		}
		if (this.demoVehicleForm.value.insurenceNo === "") {
			this.openSnackBar(
				"Insurence Number field should not be empty.Please enter.",
				""
			);
			return null;
		}
		if (this.demoVehicleForm.value.insurenceCompany === "") {
			this.openSnackBar(
				"Insurence Company field should not be empty.Please enter.",
				""
			);
			return null;
		}
		if (this.demoVehicleForm.value.type === null) {
			this.openSnackBar("Please select the Type.", "");
			return null;
		}
		if (this.demoVehicleForm.value.status === null) {
			this.openSnackBar("Please select the Status.", "");
			return null;
		}

		let objNewDemoVehicle = {};
		if (type === "created") {
			objNewDemoVehicle = {
				branchId: this.loginEmployee.branchId,
				orgId: this.loginEmployee.orgId,
				userInfo: null,
				userId: this.loginEmployee.empName,
				id: 0,
				chassisNo: this.demoVehicleForm.value.chassisNo,
				colorId: this.demoVehicleForm.value.color
					? this.demoVehicleForm.value.color.vehicleImageId
					: null,
				createdBy: this.loginEmployee.empId,
				createdDatetime: moment().format("DD-MM-YYYY HH:mm:ss"),
				modifiedBy: null,
				modifiedDatetime: null,
				rcNo: this.demoVehicleForm.value.rcNo,
				remarks: this.demoVehicleForm.value.remarks,
				status: this.demoVehicleForm.value.status,
				type: this.demoVehicleForm.value.type,
				vehicleId: this.demoVehicleForm.value.model.vehicleId,
				varientId: this.demoVehicleForm.value.variant.id,
				engineno: this.demoVehicleForm.value.engineno,
				insurenceCompany: this.demoVehicleForm.value.insurenceCompany,
				insurenceNo: this.demoVehicleForm.value.insurenceNo,
				kmsReading:
					this.demoVehicleForm.value.kmsReading == null
						? 0
						: this.demoVehicleForm.value.kmsReading,
			};
			let docs = [];
			this.otherimagepush.forEach((element) => {
				if (element.url && element.url != "") {
					docs.push({
						url: element.url,
						docType: element.documentName,
					});
				}
			});
			objNewDemoVehicle["documents"] = docs;
		}
		if (type === "updated") {
			objNewDemoVehicle = {
				id: this.selectedObj.id,
				branchId: this.selectedObj.branchId,
				orgId: this.selectedObj.orgId,
				userInfo: null,
				userId: this.loginEmployee.empName,
				createdBy: this.selectedObj.createdBy,
				createdDatetime: this.selectedObj.createdDatetime,
				modifiedBy: this.loginEmployee.empName,
				modifiedDatetime: moment().format("DD-MM-YYYY HH:mm:ss"),

				colorId: this.demoVehicleForm.value.color
					? this.demoVehicleForm.value.color.vehicleImageId
					: null,
				chassisNo: this.demoVehicleForm.value.chassisNo,
				rcNo: this.demoVehicleForm.value.rcNo,
				remarks: this.demoVehicleForm.value.remarks,
				status: this.demoVehicleForm.value.status,
				type: this.demoVehicleForm.value.type,
				vehicleId: this.demoVehicleForm.value.model.vehicleId,
				varientId: this.demoVehicleForm.value.variant.id,
				engineno: this.demoVehicleForm.value.engineno,
				insurenceCompany: this.demoVehicleForm.value.insurenceCompany,
				insurenceNo: this.demoVehicleForm.value.insurenceNo,
				kmsReading:
					this.demoVehicleForm.value.kmsReading == null
						? 0
						: this.demoVehicleForm.value.kmsReading,
			};
			let docs = [];
			this.otherimagepush.forEach((element, idx) => {
				if (element.url && element.url != "") {
					docs.push({
						url: element.url,
						docType: this.demoVehicleForm.value
							.demoVehicleAttachments[idx].documentName,
					});
				}
			});
			objNewDemoVehicle["documents"] = docs;
		}
		const vehicleObj = { vehicle: objNewDemoVehicle };
		this.vehicleListService.addDemoVehicle(vehicleObj, type).subscribe(
			(res: any) => {
				if (res.status === "SUCCESS") {
					this.openSnackBar(
						"DemoVehicle has been " + type + " successfully.",
						res.status
					);
					this.dialogRef.close("success");
				} else {
					this.openSnackBar(
						"Oops! DemoVehicle has not been " +
							type +
							"." +
							res.statusDescription,
						res.status
					);
					this.dialogRef.close();
				}
			},
			(err) => {
				console.log("result: ", err);
				this.openSnackBar(err["message"], err["status"]);
			}
		);
		//this.resetForm();
	}
	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 2000,
		});
	}

	onNoClick(): void {
		this.dialogRef.close();
	}

	numericOnly(event): boolean {
		// restrict e,+,-,E characters in  input type number
		const charCode = event.which ? event.which : event.keyCode;
		if (
			charCode === 101 ||
			charCode === 69 ||
			charCode === 45 ||
			charCode === 43
		) {
			return false;
		}
		return true;
	}
}
