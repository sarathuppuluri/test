// Angular
import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
// RXJS
import { Subscription } from 'rxjs';
// Components
import { VehiclesService } from '../../../../../../core/e-commerce/_services/vehicles.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { VehicleListService } from '../../../../../../core/e-commerce/_services/VehiclesList.service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
	selector: 'kt-vehicles-list',
	templateUrl: './vehicles-list.component.html',
	styleUrls: ['./vehicles-list.component.scss']
})
export class VehiclesListComponent implements OnInit, OnDestroy {
	constructor(
		private vehSer: VehicleListService,
		private vechileService: VehiclesService,
		private changeDetectorRef: ChangeDetectorRef,
		private modalService: NgbModal,
		private router: Router,
		private fb: FormBuilder
	) { }
	// Subscriptions
	private subscriptions: Subscription[] = [];

	vehicleId: any;
	vehiclesForm: FormGroup;
	externalFileName: any;
	internalFileName: any;
	exterior360FileName: any;
	interior360FileName: any;
	edocsName: any;
	vehicleDetails: {};
	deleteIndex: any;
	editIndex: any;
	editModelName: any;
	editedModelObj: any;
	exteriorUrl: any;
	interiorUrl: any;
	interiorOrExterior: any;
	interiorOrExteriorUrl: any;
	vehicleImageName: any;

	indexValue: number;
	loginEmployee: any;
	videoUrls = [];
	exteriorImages = [];
	interiorImages = [];

	editExterior360File = [];
	editInterior360File = [];
	editUploadVideo=[];
	editEdocs: any;
	editComparisonDoc: any;

	vehId: any;
	vehicId: any;

	vehicleList: any = [];
	fuelType: any = [];
	FuelData: any = [];
	transmissionType: any = [];
	FiltertransmissionType: any = [];
	transmissionTypeData: any = [];
	ebroucher = [];
	ebroucherDataUrl = [];
	ebroucherDataUrlTwo = [];
	ebroucherName = [];
	ebroucherDataNameTwo = [];
	eBroucherDownload: any = [];
	imageType = '';


	vehicleModel = {
		vehicleId: 0,
		organizationId: 0,
		type: 'Car',
		model: '',
		imageUrl: '',
		createdDate: '',
		createdBy: null,
		modifiedBy: null,
		modifiedDate: '',
		status: 'Active',
		booking_amount: null,
		vehicleEdocuments: [
			{
				id: 0,
				vehicleId: 0,
				oragnizationId: 0,
				edocument: []
			}
		],
		gallery: [],
		varients: [],
		waiting_period: null,
		description: null,
		typeCategory: null,
		priceRange: null
	};

	/**
	 * On init
	 */
	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.vehiclesForm = this.fb.group({
			model: ['', Validators.required],
			interior360FileName: [{ value: '', disabled: true }],
			exterior360FileName: [{ value: '', disabled: true }],
			internalFileName: [{ value: '', disabled: true }],
			externalFileName: [{ value: '', disabled: true }],
			vehicleImageName: [{ value: '', disabled: true }],
			edocsName: [{ value: '', disabled: true }],
			compareDoc: [{ value: '', disabled: true }],
			video: [{ value: '', disabled: true }]
		});
		this.loadModelDetails();
	}

	/**
	* Checking control validation
	*
	* @param controlName: string => Equals to formControlName
	* @param validationType: string => Equals to valitors name
	*/
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.vehiclesForm.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}

	openLarge(content) {
		this.vehiclesForm.reset();
		this.modalService.open(content, {
			size: 'lg'
		});
	}

	Variants(vehId) {
		this.vehicleId = vehId;
		localStorage.setItem('vehIdData', this.vehicleId);
		this.router.navigate(['/adminPanel/newVehicles/variantsList']);
	}

	loadModelDetails() {
		this.vehicleList = [];
		this.interiorImages = [];
		this.exteriorImages = [];
		this.videoUrls = [];
		this.FuelData = [];
		this.transmissionType = [];
		this.vehSer.getAllVehiclesData(this.loginEmployee.orgId).subscribe(
			(res) => {
				this.vehicleList = res;
				let filterFuelType;
				let FiltertransmissionType;

				this.vehicleList.forEach((data, i) => {
					this.interiorImages.push([]);
					this.exteriorImages.push([]);
					data.gallery.forEach((ele) => {
						if (ele.type === "interior_image") {
							this.interiorImages[i].push(ele.path);
						}

						if (ele.type === "exterior_image") {
							this.exteriorImages[i].push(ele.path);
						}

						if (ele.type === "video") {
							this.videoUrls.push(ele.path);
						}
					});
					data.varients.forEach((varData) => {
						this.fuelType.push(varData.fuelType);
						filterFuelType = Array.from(new Set(this.fuelType));
						this.transmissionType.push(varData.transmission_type);
						FiltertransmissionType = Array.from(
							new Set(this.transmissionType)
						);
					});
					this.FuelData.push(filterFuelType);
					this.transmissionTypeData.push(FiltertransmissionType);
				});
				this.changeDetectorRef.detectChanges();
			},
				(error) => {
					console.log("All Data of organisation error::" + error);
					this.changeDetectorRef.detectChanges();
				}
		);
	}

	brouchureDocOpen(val) {
		val.forEach((ele) => {
			if (ele.document_name === 'Vehicle_Sepcifications') {
				window.open(ele.url);
			}
		});
	}

	compareDocOpen(val) {
		val.forEach((ele) => {
			if (ele.document_name === 'Comparison') {
				window.open(ele.url);
			}
		});
	}

	/**
	 * On Destroy
	 */
	ngOnDestroy() {
		this.subscriptions.forEach(el => el.unsubscribe());
	}

	openLarge360(content, val) {
		this.modalService.open(content, {
			size: 'lg'
		});
		this.interiorOrExterior = val;
	}

	click360(val1) {
		if (val1 === 'true') {
			this.interiorOrExterior.forEach(element => {
				if (element.document_name === '360_exterior') {
					this.exteriorUrl = element.url;
				}
			});
			if (this.exteriorUrl !== '') {
				window.open(this.exteriorUrl);
				this.modalService.dismissAll();
			} else { this.modalService.dismissAll(); }
		} else {
			this.interiorOrExterior.forEach(element => {
				if (element.document_name === '360_interior') {
					this.interiorUrl = element.url;
				}
			});
			if (this.interiorUrl !== '') {
				window.open(this.interiorUrl);
				this.modalService.dismissAll();
			} else { this.modalService.dismissAll(); }
		}
	}

	openVideoModel(content) {
		this.modalService.open(content, {
			size: 'lg'
		});
	}

	openGalleryModel(content, index, imageType) {
		this.indexValue = index;
		this.imageType = imageType;
		this.modalService.open(content, {
			size: 'lg'
		});
	}

	deleteModel(i, content) {
		this.modalService.open(content, {
			size: 'lg'
		});
		this.deleteIndex = i;
	}

	deleteModelYes() {
		this.vechileService.delete(this.deleteIndex).subscribe(res => {
			this.loadModelDetails();
			this.modalService.dismissAll();
		});
	}

	editModel(i, content, index) {
		this.vehiclesForm.reset();
		this.indexValue = index;
		this.modalService.open(content, {
			size: 'lg'
		});
		this.vehicleList.forEach((element) => {
			if (element.vehicleId === i) {
				this.vehiclesForm.patchValue(element);
				this.editedModelObj = element;
			}
		});
		this.editIndex = i;

		this.editEdocs='';
		this.editComparisonDoc='';
		this.editedModelObj.vehicleEdocuments[0].edocument.forEach((element) => {
			if(element.document_name==='Vehicle_Sepcifications'){
				this.editEdocs=element.url;
			}
			if(element.document_name==='Comparison'){
				this.editComparisonDoc=element.url;
			}
		});
		this.editExterior360File=[];
		this.editInterior360File=[];
		this.editUploadVideo=[];
		this.editedModelObj.gallery.forEach((ele) => {
			if (ele.type === 'interior_image') {
				this.editInterior360File.push(ele.path);
			}
			if (ele.type === 'exterior_image') {
				this.editExterior360File.push(ele.path);
			}
			if (ele.type === 'video') {
				this.editUploadVideo.push(ele.path);
			}
		});
	}

	dismissModal() {
		this.modalService.dismissAll();
	}


	createModelDetails(fileName, formName, event) {
		const tempFormData = new FormData();
		let tempName = '';
		for (let i = 0; i < event.target.files.length; i++) {
			tempFormData.append('uploadFiles', event.target.files[i]);
			tempName = tempName.concat(event.target.files[i].name, (i === ((event.target.files.length) - 1)) ? '' : ', ');
			this.vehiclesForm.get(formName).patchValue(tempName);
		}
		this.vechileService.saveMultipleVehicleDetails(tempFormData,formName).subscribe(res => {
			if (fileName === 'vehicle_image') {
				res.uploadFiles.forEach((element, i) => {
					this.vehicleModel.imageUrl = res.uploadFiles[i].url;
				});
			} else if ((fileName === 'interior_image') || (fileName === 'exterior_image') || (fileName === 'video')) {
				res.uploadFiles.forEach((element, i) => {
					const tempObj: any = {};
					tempObj.id = 0;
					tempObj.organizationId = this.loginEmployee.orgId;
					tempObj.path = res.uploadFiles[i].url;
					tempObj.priority = 0;
					tempObj.type = fileName;
					tempObj.vehicleId = 0;
					this.vehicleModel.gallery.push(tempObj);
				});
			} else {
				res.uploadFiles.forEach((element, i) => {
					const tempObj: any = {};
					tempObj.url = res.uploadFiles[i].url;
					tempObj.document_name = fileName;
					this.vehicleModel.vehicleEdocuments[0].edocument.push(tempObj);
				});
			}
		});
	}


	saveModal() {
		/** check form */
		const controls = this.vehiclesForm.controls;
		if (this.vehiclesForm.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);

			return;
		}
		this.vehicleModel.model = this.vehiclesForm.value.model;
		this.vehicleModel.organizationId = this.loginEmployee.orgId;
		this.vehicleModel.vehicleEdocuments[0].oragnizationId = this.loginEmployee.orgId;
		this.vechileService.updateVehicleDetails(this.vehicleModel).subscribe(res => {
			this.loadModelDetails();
			this.modalService.dismissAll();
		});
	}

	updateModal() {
		/** check form */
		const controls = this.vehiclesForm.controls;
		if (this.vehiclesForm.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);

			return;
		}
		this.editedModelObj.model = this.vehiclesForm.value.model;
		this.vechileService.updateVehicleDetails(this.editedModelObj).subscribe(res => {
			this.loadModelDetails();
			this.modalService.dismissAll();
		});
	}

	uploadMulFiles(fileName, formName, event) {
		const tempFormData = new FormData();
		let tempName = '';
		for (let i = 0; i < event.target.files.length; i++) {
			tempFormData.append('uploadFiles', event.target.files[i]);
			tempName = tempName.concat(event.target.files[i].name, (i === ((event.target.files.length) - 1)) ? '' : ', ');
			this.vehiclesForm.get(formName).patchValue(tempName);
		}
		this.vechileService.saveMultipleVehicleDetails(tempFormData,formName).subscribe(res => {
			if ((fileName === 'interior_image') || (fileName === 'exterior_image') || (fileName === 'video')) {
				res.uploadFiles.forEach((element, i) => {
					const tempObj: any = {};
					tempObj.id = 0;
					tempObj.organizationId = this.loginEmployee.orgId;
					tempObj.path = res.uploadFiles[i].url;
					tempObj.priority = 0;
					tempObj.type = fileName;
					tempObj.vehicleId = this.editedModelObj.vehicleId;
					this.editedModelObj.gallery.push(tempObj);
				});
			} else {
				res.uploadFiles.forEach((element, i) => {
					const tempObj: any = {};
					tempObj.url = res.uploadFiles[i].url;
					tempObj.document_name = fileName;
					this.editedModelObj.vehicleEdocuments[0].edocument.push(tempObj);
				});
			}
		});
	}
}
