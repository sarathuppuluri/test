// Angular
import { Component, OnInit, Input, EventEmitter, ElementRef, ViewChild, ChangeDetectionStrategy, OnDestroy, ChangeDetectorRef, Inject, AfterViewInit } from '@angular/core';
// Material
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort, MatSnackBar, MatTableDataSource, MatSelect } from '@angular/material';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material/dialog';
// RXJS
import { debounceTime, distinctUntilChanged, tap, skip, delay, take } from 'rxjs/operators';
import { fromEvent, merge, Subscription, of } from 'rxjs';
// Translate Module
import { TranslateService } from '@ngx-translate/core';
// NGRX
import { Store, ActionsSubject } from '@ngrx/store';
import { AppState } from '../../../../../../core/reducers';
// CRUD
import { LayoutUtilsService, MessageType, QueryParamsModel } from '../../../../../../core/_base/crud';
// Services and Models
import { VehicleModel } from '../../../../../../core/e-commerce';

// Components
import { VehiclesService } from '../../../../../../core/e-commerce/_services/vehicles.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { VehicleListService } from '../../../../../../core/e-commerce/_services/VehiclesList.service';
import { url } from 'inspector';
import { DomSanitizer } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
//import * as fileSaver from 'file-saver';
import { saveAs } from "file-saver";
import { HttpResponse } from '@angular/common/http';
import { FormGroup, FormBuilder, FormArray, Validators, FormControl } from '@angular/forms';
import { AdminService } from '../../../../../../core/e-commerce/_services/admin.service';
import { deleteConfirmationDialog } from './delete-confirmation-dialog.component';

declare let require: any
const FileSaver = require('file-saver');

import * as _ from 'lodash';
import { NgStyle } from '@angular/common';
import { element } from 'protractor';

export interface AccessoriesData {
	category: string;
	cost: number;
	createdBy: number;
	createdDate: string;
	id: number;
	imageUrl: string;
	item: string;
	modifiedBy: string;
	modifiedDate: string;
	origanistionId: number;
	partName: string;
	partNo: string;
	vehicleId: number;
}

@Component({
	selector: 'kt-vehicles-models',
	templateUrl: './accessories-models.component.html',
	styleUrls: ['./accessories-models.component.scss']

})
export class AccessoriesModelsComponent implements OnInit, AfterViewInit, OnDestroy {
	viewModels: boolean = true;
	pageNo: number = 0;
	pageSize: number = 10;
	selectedModel: any = "";
	loginEmployee: any = [];
	isAccessories: boolean = true;
	ListOfModelKits: any = [];


	@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
	@ViewChild(MatSort, { static: true }) sortTable: MatSort;
	// Filter fields
	@ViewChild('searchInput', { static: true }) searchInput: ElementRef;
	filterStatus = '';
	filterType = '';
	// Selection
	selection = new SelectionModel<VehicleModel>(true, []);
	vehiclesResult: VehicleModel[] = [];
	// Subscriptions
	private subscriptions: Subscription[] = [];

	VechiclesListData = [];
	isLoaded = false;
	vehicleId: any;

	vehiclesForm: FormGroup;
	accessoryForm: FormGroup;
	externalFileName: any;
	internalFileName: any;
	exterior360FileName: any;
	interior360FileName: any;
	edocsName: any;
	vehicleDetails: {};
	deleteIndex: any;
	editIndex: any;
	editModelName: any;
	editedModelObj: any;
	exteriorUrl: any;
	interiorUrl: any;
	interiorOrExterior: any;
	interiorOrExteriorUrl: any;
	accessoriesDataSource: MatTableDataSource<AccessoriesData>;

	/**
	 * Component constructor
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 * @param store: Store<AppState>
	 */
	constructor(
		public dialog: MatDialog,
		private vehSer: VehicleListService,
		public snackBar: MatSnackBar,
		private layoutUtilsService: LayoutUtilsService,
		private translate: TranslateService,
		private store: Store<AppState>,
		private vechileService: VehiclesService,
		private changeDetectorRef: ChangeDetectorRef,
		private modalService: NgbModal,
		private sanitizer: DomSanitizer,
		private router: Router,
		private fb: FormBuilder
	) { }

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));

		this.accessoryForm = this.fb.group({
			category: [null, Validators.required],
			imageUrl: ['', Validators.required],
			partName: ['', Validators.required],
			partNo: ['', Validators.required],
			item: ['', Validators.required],
			cost: ['', Validators.required],
		});
		this.loadAllModels();
		const data = 'some text';
		const blob = new Blob([data], { type: 'application/octet-stream' });
		this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));

	}


	addAccessory() {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		dialogConfig.width = '700px';
		//dialogConfig.height='480px';
		dialogConfig.data = {
			modelId: this.sltdModelObj.vehicleId,
			modelName: this.sltdModelObj.model,
		};
		const dialogRef = this.dialog.open(CreateAccessoriesDialog, dialogConfig);
		dialogRef.afterClosed().subscribe(result => {
			if (result === 'success') {
				this.viewAccessories(this.sltdModelObj);
			}
		});
	}
	addKit() {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		dialogConfig.width = '98%';
		dialogConfig.height = '95%';
		dialogConfig.data = {
			modelId: this.sltdModelObj.vehicleId,
			modelName: this.sltdModelObj.model,
			accessoriesList: this.accessoriesList
		};
		const dialogRef = this.dialog.open(CreateKitDialog, dialogConfig);
		dialogRef.afterClosed().subscribe(result => {
			if (result === 'success') {
				this.viewAccessories(this.sltdModelObj);
			}
		});
	}


	vehId: any;
	Variants(vehId) {
		this.vehicleId = vehId;
		localStorage.setItem("vehIdData", this.vehicleId);
		this.router.navigate(['/vehicleManagement/vehicles/variantsList']);
	}
	vehicId: any;

	ngAfterViewInit() {
		this.vehicId = localStorage.getItem("vehIdData");
	}

	hasLoaded: any;
	selectedValue: any;
	tempData = [];
	AllDataBranch: any = [];
	vehicleList: any = [];
	eBroucher: any = [];
	fuelType: any = [];
	fuelNames: any = [];
	FuelData: any = [];
	eBroucherFile: any = [];
	transmissionType: any = [];
	FiltertransmissionType: any = [];
	transmissionTypeData: any = [];
	docfiles: any = [];
	docNameType: any = [];
	docs: any = [];
	docUrl: any = [];
	docData: any = [];
	ebroucher = [];
	ebroucherDataUrl = [];
	ebroucherDataUrlTwo = [];
	ebroucherName = [];
	ebroucherDataNameTwo = [];
	eBroucherDownload: any = [];
	interiorImages: any = [];
	intLeng: any = [];
	loadAllModels() {
		this.vehSer.getAllVehiclesData(this.loginEmployee.orgId).subscribe(
			(res) => {
				this.vehicleList = res;

				let filterFuelType;
				let FiltertransmissionType;
				let docfiles;
				let docNameType;
				let docUrl;
				let ebroucherDataUrl;
				let ebroucherName;

				this.vehicleList.forEach((data, i) => {
					data.gallery.forEach((ele) => {
						this.intLeng.push(data.gallery.length);
						if (ele.type === "interior_image") {
							this.interiorImages.push(ele.path);
						}
					});
					data.varients.forEach((varData, i) => {
						this.fuelType.push(varData.fuelType);
						filterFuelType = Array.from(new Set(this.fuelType));
						this.transmissionType.push(varData.transmission_type);
						FiltertransmissionType = Array.from(
							new Set(this.transmissionType)
						);
					});

					this.FuelData.push(filterFuelType);
					this.transmissionTypeData.push(FiltertransmissionType);
					data.vehicleEdocuments.forEach((doc, i) => {
						this.ebroucher = doc.edocument;

						this.ebroucher.forEach((data) => {
							this.ebroucherDataUrl.push(data.url);
							this.ebroucherName.push(data.document_name);
							this.ebroucherDataUrl = Array.from(
								this.ebroucherDataUrl
							);
							this.ebroucherName = Array.from(this.ebroucherName);
						});
						this.eBroucherDownload.push({
							name: this.ebroucherName,
							file: this.ebroucherDataUrl,
						});
					});
				});
				this.changeDetectorRef.detectChanges();
			},
			(error) => {
				console.log("All Data of organisation error::" + error);
				this.changeDetectorRef.detectChanges();
			},
			() => {}
		);
	}

	downloadFiles: any = [];
	docObj: any = [];
	fileUrl;
	files = [];
	downloadFile(dataDoc) {
		dataDoc.forEach((ele) => {
			FileSaver.saveAs(ele.url, ele.document_name);
		})
	}
	brouchureDocOpen(val) {
		val.forEach((ele) => {
			if (ele.document_name === "Vehicle_Sepcifications")
				window.open(ele.url);
		})
	}
	compareDocOpen(val) {
		val.forEach((ele) => {
			if (ele.document_name === "Comparison")
				window.open(ele.url);
		})
	}

	ngOnDestroy() {
		this.subscriptions.forEach(el => el.unsubscribe());
	}

	deleteModel(i, content) {
		this.modalService.open(content, {
			size: 'lg'
		})
		this.deleteIndex = i;
	}

	dismissModal() {
		this.modalService.dismissAll();
	}

	updateAccessories(accessoryObj) {
		if (accessoryObj.id != "") {
			const dialogConfig = new MatDialogConfig();
			dialogConfig.disableClose = false;
			dialogConfig.autoFocus = true;
			dialogConfig.width = '700px';
			dialogConfig.data = {
				modelId: this.sltdModelObj.vehicleId,
				modelName: this.sltdModelObj.model,
				accessoryObj: accessoryObj
			};

			const dialogRef = this.dialog.open(CreateAccessoriesDialog, dialogConfig);

			dialogRef.afterClosed().subscribe(result => {
				this.viewAccessories(this.sltdModelObj);
			});
		}
	}

	deleteAccessories(accessoryObj) {
		if (accessoryObj.id != "") {
			const dialogConfig = new MatDialogConfig();
			dialogConfig.disableClose = false;
			dialogConfig.autoFocus = true;
			dialogConfig.width = '400px';
			dialogConfig.data = {
				message: 'Are you sure want to delete?',
				buttonText: { ok: 'Yes', cancel: 'No' }
			};
			const dialogRef = this.dialog.open(deleteConfirmationDialog, dialogConfig);
			dialogRef.afterClosed().subscribe((confirmed: boolean) => {
				if (confirmed) {
					this.vehSer.deleteAccessory(accessoryObj.id).subscribe((res: any) => {
						if (res.success === true) {
							this.openSnackBar(accessoryObj.partName + " - has been deleted successfully", res.success);
							this.viewAccessories(this.sltdModelObj);
							this.changeDetectorRef.detectChanges();
						} else {
							this.openSnackBar(res.errorMessage, res.error);
						}
					});
				}
			});
		}
	}
	deleteKit(kit) {
		if (kit.id != "") {
			const dialogConfig = new MatDialogConfig();
			dialogConfig.disableClose = false;
			dialogConfig.autoFocus = true;
			dialogConfig.width = '400px';
			//dialogConfig.height='480px';
			dialogConfig.data = {
				message: 'Are you sure want to delete?',
				buttonText: { ok: 'Yes', cancel: 'No' }
			};
			const dialogRef = this.dialog.open(deleteConfirmationDialog, dialogConfig);
			dialogRef.afterClosed().subscribe((confirmed: boolean) => {
				if (confirmed) {
					this.vehSer.deleteKit(kit.id).subscribe((res: any) => {
						if (res && res.success == true) {
							this.openSnackBar(kit.kitName + " - has been deleted successfully", res.success);
							this.viewAccessories(this.sltdModelObj);
							this.changeDetectorRef.detectChanges();
						} else {
							this.openSnackBar(res.errorMessage, res.error);
						}
					});
				}
			});
		}
	}
	updateKit(kit) {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		dialogConfig.width = '98%';
		dialogConfig.height = '95%';
		dialogConfig.data = {
			modelId: this.sltdModelObj.vehicleId,
			modelName: this.sltdModelObj.model,
			accessoriesList: this.accessoriesList,
			kitObj: kit
		};
		const dialogRef = this.dialog.open(CreateKitDialog, dialogConfig);
		dialogRef.afterClosed().subscribe(result => {
			if (result === 'success') {
				this.viewAccessories(this.sltdModelObj);
			}
		});
	}


	goToModels() {
		this.viewModels = true;
		this.selectedModel = "";
	}
	limit: number = 10;
	skip: number = 0;
	totalLength: number = 0;
	pageIndex: number = 0;
	pageLimit: number[] = [10, 20, 50];
	// if(this.totalLength === 0){
	// this.totalLength = data.total;
	// }

	accessoriesList: any = [];
	sltdModelObj: any;
	displayedAccessoriesColumns: string[] = ['imageUrl', 'partName', 'partNo', 'category', 'item', 'cost', 'id'];
	viewAccessories(selectedModelObj) {
		this.sltdModelObj = selectedModelObj;
		this.selectedModel = selectedModelObj.model;
		this.viewModels = false;
		this.vehSer.getAllAccessoriesByVehicle(selectedModelObj.vehicleId, this.pageNo, this.pageSize, this.loginEmployee.orgId).subscribe(res => {
			if (res.success === true) {
				this.accessoriesList = res.accessorylist;
				this.ListOfModelKits = res.accessoryMappingDto;
				this.accessoriesDataSource = new MatTableDataSource<AccessoriesData>(this.accessoriesList);

				this.accessoriesDataSource.paginator = this.paginator;
				this.accessoriesDataSource.sort = this.sortTable;

				this.changeDetectorRef.detectChanges();
			}
			else {
				this.openSnackBar(res.errorMessage, res.error);
			}
		});
	}

	onChangedPageSize(event) {

	}


	openSnackBar(message: string, action: string) {
		this.snackBar.open(message, action, {
			duration: 2000,
		});
	}

}

/********************************************************************************************CreateAccessoriesDialog*********************************************************************************** */

@Component({
	selector: 'create-accessories-dialog',
	templateUrl: './create-accessories-dialog.html',
	styleUrls: ['./accessories-models.component.scss'],
})
export class CreateAccessoriesDialog {
	loginEmployee: any;
	allSelected = false;
	selectedValue: any;

	accessoryForm = this.formBuilder.group({
		category: [null, Validators.required],
		imageUrl: [{ value: '', disabled: true }],
		partName: ['', Validators.required],
		partNo: ['', Validators.required],
		item: ['', Validators.required],
		cost: [0, Validators.required],
	});
	selectedObj: any;
	startDate;
	searchMsg: string = "";

	isLoading: boolean;
	myrolesResult: any = [];
	vechilesData: any = [];
	page: number = 150;
	pageSize: number = 0;
	@ViewChild('myModels', { static: true }) skillSel: MatSelect;

	constructor(
		private formBuilder: FormBuilder,
		private _snackBar: MatSnackBar,
		private changeDetectorRef: ChangeDetectorRef,
		private AdminService: AdminService,
		private vehicleListService: VehicleListService,
		public dialogRef: MatDialogRef<CreateAccessoriesDialog>,
		@Inject(MAT_DIALOG_DATA) data) {
		this.selectedObj = data;
		this.startDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
	}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		if (this.selectedObj.accessoryObj) {
			this.patchForm();
		}
	}
	loadMyRolesListView() {
		this.myrolesResult = [];
		this.isLoading = true;
	}
	// File Upload for Lead Attachments
	fileUploadObj: any;
	fileChoose(event, docType) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			const formData = new FormData();
			formData.append('file', file);
			formData.append('model', this.selectedObj.modelName);
			formData.append('documentType', docType);
			this.vehicleListService.uploadAccessory(formData).subscribe(res => {
				if (res.documentPath) {
					this.accessoryForm.get('imageUrl').setValue(res.documentPath);

					this.fileUploadObj = res;
				} else {
					this.accessoryForm.controls['imageUrl'].setValue("");
					this.fileUploadObj = {};
				}
				this.changeDetectorRef.detectChanges();
			});
		}
	}

    /**
    * this method is for patch the form with exsiting test accessoryObj info.
    */
	public patchForm() {
		this.accessoryForm.controls['category'].setValue(this.selectedObj.accessoryObj.category);
		this.accessoryForm.controls['imageUrl'].setValue(this.selectedObj.accessoryObj.imageUrl);
		this.accessoryForm.controls['partName'].setValue(this.selectedObj.accessoryObj.partName);
		this.accessoryForm.controls['partNo'].setValue(this.selectedObj.accessoryObj.partNo);
		this.accessoryForm.controls['item'].setValue(this.selectedObj.accessoryObj.item);
		this.accessoryForm.controls['cost'].setValue(this.selectedObj.accessoryObj.cost);
		this.fileUploadObj["documentPath"] = this.selectedObj.accessoryObj.imageUrl;

		this.changeDetectorRef.detectChanges();
	}


	saveAccessory(type) {
		    if (this.accessoryForm.value.category=== null) {
		        this.openSnackBar("Please select the Category.", "");
		        return null;
		    }
		    if (this.accessoryForm.value.partName === "") {
		        this.openSnackBar("Part Name should not be empty.", "");
		        return null;
		    }
		    if (this.accessoryForm.value.partNo === "") {
		        this.openSnackBar("Part Number should not be empty.", "");
		        return null;
		    }
		    if (this.accessoryForm.value.cost === "" ||  this.accessoryForm.value.cost===null) {
		        this.openSnackBar("Cost field should not be empty.Please enter.", "");
		        return null;
		    }
		let objNewAccessory = {};
		if (type === 'created') {
			objNewAccessory = {
				vehicleId: this.selectedObj.modelId,
				origanistionId: this.loginEmployee.orgId,
				//branchId: this.loginEmployee.branchId,
				createdBy: this.loginEmployee.empId,
				modifiedBy: this.loginEmployee.empId,
				createdDate: Date.parse(Date()),
				modifiedDate: null,
				category: this.accessoryForm.value.category,
				imageUrl: this.accessoryForm.controls.imageUrl.value,
				partName: this.accessoryForm.value.partName,
				partNo: this.accessoryForm.value.partNo,
				item: this.accessoryForm.value.item,
				cost: this.accessoryForm.value.cost
			};
		}
		if (type === 'updated') {
			objNewAccessory = {
				id: this.selectedObj.accessoryObj.id,
				vehicleId: this.selectedObj.accessoryObj.vehicleId,
				origanistionId: this.selectedObj.accessoryObj.origanistionId,
				createdBy: this.selectedObj.accessoryObj.createdBy,
				createdDate: this.selectedObj.accessoryObj.createdDate,

				modifiedBy: this.loginEmployee.empId,
				modifiedDate: Date.parse(Date()),
				category: this.accessoryForm.value.category,
				imageUrl: this.accessoryForm.controls.imageUrl.value,
				partName: this.accessoryForm.value.partName,
				partNo: this.accessoryForm.value.partNo,
				item: this.accessoryForm.value.item,
				cost: this.accessoryForm.value.cost
			};
		}

		this.vehicleListService.addAccessories(objNewAccessory, type).subscribe((res: any) => {
			if (res.success === true) {
				this.openSnackBar("Accessory has been " + type + " successfully.", "success");
				this.dialogRef.close('success');
			}
			else {
				this.openSnackBar("Oops! Accessory has not been " + type + "." + res.errorMessage, res.error);
				this.dialogRef.close();
			}
		},
			(err) => {
				this.openSnackBar(err['message'], err["status"]);
			}
		);
		//this.resetForm();
	}
	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 2000,
		});
	}



	onNoClick(): void {
		this.dialogRef.close();
	}

	numericOnly(event): boolean { // restrict e,+,-,E characters in  input type number
		const charCode = (event.which) ? event.which : event.keyCode;
		if (charCode === 101 || charCode === 69 || charCode === 45 || charCode === 43) {
			return false;
		}
		return true;
	}

}


/****************************************************************************************CreateKitDialog************************************************************************************* */
@Component({
	selector: 'create-kit-dialog',
	templateUrl: './create-kit-dialog.html',
	styleUrls: ['./accessories-models.component.scss'],
})
export class CreateKitDialog {
	dailogObj: any;
	selectedKitObj: any;
	loginEmployee: any;
	leftAccessoriesList: any;
	headerText: string = "Create Kit";
	checked = true;
	copyAccessoriesList: any;

	kitName: string = "";
	cost: number = 0;
	sltdAccessoriesList: any = [];

	kitForm = this.formBuilder.group({
		kitName: ['', Validators.required],
		cost: ['', Validators.required],
		accessoriesList: [],
		//accessoriesList: this.formBuilder.array([]),
	});

	constructor(
		private formBuilder: FormBuilder,
		private _snackBar: MatSnackBar,
		private changeDetectorRef: ChangeDetectorRef,
		private AdminService: AdminService,
		private vehicleListService: VehicleListService,
		public dialogRef: MatDialogRef<CreateKitDialog>,
		@Inject(MAT_DIALOG_DATA) data) {
		this.dailogObj = data;
		if (this.dailogObj.kitObj) {
		 	this.sltdAccessoriesList=this.dailogObj.kitObj.accessory;
			this.dailogObj.accessoriesList.forEach((element,idx) => {
				element.isExist="false";
				this.dailogObj.kitObj.accessory.forEach((element1, ix) => {
					if(element1.id===element.id){
						element.isExist="true";
					}
				});
			});
		}
		else{
			this.sltdAccessoriesList=[];
			this.dailogObj.accessoriesList.forEach((element,idx) => {
				element.isExist="false";
			});
		}
	}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		if (this.dailogObj.accessoriesList) {
			this.leftAccessoriesList = this.dailogObj.accessoriesList;
		}

		if (this.dailogObj.kitObj) {
			this.headerText = "Update Kit";
			this.patchForm();
		}

		this.changeDetectorRef.detectChanges();
	}

	patchForm() {
		this.kitName=this.dailogObj.kitObj.kitName;
		this.cost=this.dailogObj.kitObj.cost;
	}


	getSelectedAccessory(accessory, e) {
		if (e.checked === true) {
			this.sltdAccessoriesList.push(accessory);
		} else if (e.checked === false) {
			this.sltdAccessoriesList = this.sltdAccessoriesList.filter(item => item.id !== accessory.id);
		}
	}

	saveKit(type) {
		if (this.kitName.trim() === "") {
			this.openSnackBar("Kit Name should not be empty.", "");
			return null;
		}
		if (this.cost===0 || this.cost===null) {
			this.openSnackBar("Cost should not be empty or zero. Please enter.", "");
			return null;
		}
		let selectedListOfAccessories = "";
		this.sltdAccessoriesList.forEach((element, idx) => {
			if (idx === 0) {
				selectedListOfAccessories = element.id;
			}
			else {
				selectedListOfAccessories = selectedListOfAccessories + "|" + element.id
			}
		});
		if (selectedListOfAccessories === "") {
			this.openSnackBar("Please select at least one accessory", "");
			return null;
		}

		let objNewKit = {};
		if (type === 'created') {
			objNewKit = {
				vehicleId: this.dailogObj.modelId,
				organisationId: this.loginEmployee.orgId,

				createdBy: this.loginEmployee.empId,
				modifiedBy: this.loginEmployee.empId,
				createdDate: Date.parse(Date()),
				modifiedDate: null,

				kitName: this.kitName,
				cost: this.cost,
				accessoriesList: selectedListOfAccessories
			};
		}
		if (type === 'updated') {
			objNewKit = {
				id: this.dailogObj.kitObj.id,
				vehicleId: this.dailogObj.kitObj.vehicleId,
				organisationId: this.dailogObj.kitObj.organisationId,
				createdBy: this.dailogObj.kitObj.createdBy,
				createdDate: this.dailogObj.kitObj.createdDate,

				modifiedBy: this.loginEmployee.empId,
				modifiedDate: Date.parse(Date()),

				kitName: this.kitName,
				cost: this.cost,
				accessoriesList: selectedListOfAccessories
			};
		}

		this.vehicleListService.saveKit(JSON.parse(JSON.stringify(objNewKit)), type).subscribe((res: any) => {
			if (res.success === true) {
				this.openSnackBar("KIT has been " + type + " successfully.", "success");
				this.dialogRef.close('success');
			}
			else {
				this.openSnackBar("Oops! KIT has not been " + type + "." + res.errorMessage, res.error);
				this.dialogRef.close();
			}
		},
			(err) => {
				console.log('result: ', err);
				this.openSnackBar(err['message'], err["status"]);
			}
		);
	}

	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 2000,
		});
	}
	onNoClick(): void {
		this.dialogRef.close();
	}
}
