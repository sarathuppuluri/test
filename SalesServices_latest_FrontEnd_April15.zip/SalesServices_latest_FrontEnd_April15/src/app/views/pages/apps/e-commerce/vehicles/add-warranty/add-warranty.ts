// Angular
import { Component, OnInit, Input, EventEmitter, ElementRef, ViewChild, ChangeDetectionStrategy, OnDestroy, ChangeDetectorRef } from '@angular/core';
// Material
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort, MatSnackBar, MatDialog } from '@angular/material';
// RXJS
import { debounceTime, distinctUntilChanged, tap, skip, delay, take } from 'rxjs/operators';
import { fromEvent, merge, Subscription, of } from 'rxjs';
// Translate Module
import { TranslateService } from '@ngx-translate/core';
// NGRX
import { Store } from '@ngrx/store';
import { AppState } from '../../../../../../core/reducers';
// CRUD
import { LayoutUtilsService, QueryParamsModel } from '../../../../../../core/_base/crud';
// Services and Models
import { VehicleModel } from '../../../../../../core/e-commerce';

// Components
import { VehiclesService } from '../../../../../../core/e-commerce/_services/vehicles.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { VehicleListService } from '../../../../../../core/e-commerce/_services/VehiclesList.service';
import { url } from 'inspector';
import { DomSanitizer } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import { FormGroup, FormBuilder , FormControl, Validators} from '@angular/forms';
declare let require: any;

import * as _ from 'lodash';
import { NgStyle } from '@angular/common';

@Component({
	selector: 'kt-add-warranty',
	templateUrl: './add-warranty.html',
	styleUrls: ['./add-warranty.scss']

})
export class AddWarrantyComponent implements OnInit, OnDestroy {
	loginEmployee: any;
	/**
	 * Component constructor
	 *
	 * @param dialog: MatDialog
	 * @param snackBar: MatSnackBar
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 * @param store: Store<AppState>
	 */
	constructor(
		public dialog: MatDialog,
		private vehSer: VehicleListService,
		public snackBar: MatSnackBar,
		private layoutUtilsService: LayoutUtilsService,
		private translate: TranslateService,
		private store: Store<AppState>,
		private vechileService: VehiclesService,
		private changeDetectorRef: ChangeDetectorRef,
		private modalService: NgbModal,
		private sanitizer: DomSanitizer,
		private router: Router,
		private fb: FormBuilder
	) { }
	// Table fields
	message = '';
	showError = false;
	displayedColumns = ['vehicle', 'model', 'brand', 'actions'];
	@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
	@ViewChild('sort1', { static: true }) sort: MatSort;
	// Filter fields
	@ViewChild('searchInput', { static: true }) searchInput: ElementRef;
	filterStatus = '';
	filterType = '';
	type: any;
	// Selection
	selection = new SelectionModel<VehicleModel>(true, []);
	vehiclesResult: VehicleModel[] = [];
	// Subscriptions
	private subscriptions: Subscription[] = [];

	VechiclesListData = [];
	isLoaded = false;
	vehicleId: any;
	public imagesUrl;
	vehiclesForm: FormGroup;
	warrantyForm: FormGroup;
	vehicleIdSelected: any;
	varientsList: any = [];
	vehicleSelected: any;
	varientSelected: any;
	varientIdSelected: any = [];
	warrantyCount = 1;
	warrantyArray = [];
	vehicleList = [];
	warrantyList: any = [];
	noRecord = true;
	warrantyName: string;
	warrantyCost: string;
	warrantyRetreived = false;
	warrantyListRetrieved: any = [];
	vehiclesList: any;
	varient: any;
	tempActions: Array<any> = [
		{ actionName: 'editWarranty' },
		{ actionName: 'deleteWarranty' }];
	warantyIdRetrieved: any;
	vehicleSelected1: any;
	varientSelected1: any;
	selected1: any;
	selected2: any;

	page = 0;
	pageSize = 10;
	isLoading = false;
	scope: any = {};


	vehId: any;

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));

		this.warrantyForm = this.fb.group({
			vehicleName: [],
			varient: [],
		});

		this.vehSer.getAllVehiclesData(this.loginEmployee.orgId).subscribe(
			(res) => {
				this.vehicleList = res;
				this.warrantyRetreived = true;
				this.changeDetectorRef.detectChanges();
			},(error) => {
					console.log("All Data of organisation error::" + error);
					this.changeDetectorRef.detectChanges();
				});
		this.getWarrantyList();
	}

	getWarrantyList() {
		this.isLoading = true;
		const queryParams = new QueryParamsModel({}, '', '', this.page, this.pageSize);
		this.vehSer.getAllWarranty(this.loginEmployee.orgId, queryParams).subscribe(res => {
			if (res) {
				this.isLoading = false;
				this.scope = res;
				this.warrantyListRetrieved = res.waranties;
				this.changeDetectorRef.detectChanges();
			}
		});
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.getWarrantyList();
	}

	openLarge(content) {
		this.modalService.open(content, {
			size: 'lg'
		});
	}

	Variants(vehId) {
		this.vehicleId = vehId;
		localStorage.setItem('vehIdData', this.vehicleId);
		this.router.navigate(['/vehicleManagement/vehicles/variantsList']);
	}

	changeModel(event, val1, val2) {
		this.vehicleSelected = this.vehicleList.find(o => o.model === event.target.innerText);
		this.vehicleIdSelected = this.vehicleSelected.vehicleId;
		this.varientsList = [];
		this.varientIdSelected = [];
		if (this.vehicleSelected.varients !== []) {
			this.varientsList = this.vehicleSelected.varients;
		}
	}

	changeVarient(event) {
		this.varientIdSelected = this.varientsList.find(o => o.name === event.target.innerText).id;
	}

	arrayOne(n: number): any[] {
		return Array(n);
	}



	submitWarranty(val1, val2) {
		this.warrantyList.push({ document_name: val1, cost: val2 });
		(document.getElementById('warrantyName') as HTMLInputElement).value = '';
		(document.getElementById('warrantyCost') as HTMLInputElement).value = '';

	}

	submitFinalWarranty() {
		if (this.type === 'Edit') {
			const formObj = {
				extendedWarranty: {
					id: this.warantyIdRetrieved,
					organization_id: 1,
					varient_id: this.varientIdSelected,
					vehicle_id: this.vehicleIdSelected,
					warranty: this.warrantyList
				}
			};

			this.vehSer.updateWarrant(formObj).subscribe(res => {
				this.getWarrantyList();
			});
			this.modalService.dismissAll();
		} else {
			const formObj = {
				extendedWarranty: {
					id: 0,
					organization_id: 1,
					varient_id: this.varientIdSelected,
					vehicle_id: this.vehicleIdSelected,
					warranty: this.warrantyList
				}
			};
			this.vehSer.saveWarranty(formObj).subscribe(res => {
				this.getWarrantyList();
			});
			this.modalService.dismissAll();

		}
		this.warrantyList = [];
		this.warrantyForm.reset();
	}

	openModal(content, type) {
		this.modalService.open(content, {
			size: 'lg'
		});
		this.warrantyForm.reset();
		this.warrantyList = [];
		this.type = 'Submit';
	}

	closeLarge() {
		this.modalService.dismissAll();
	}

	editWarranty(val, content, type) {
		this.type = 'Edit';
		this.modalService.open(content, {
			size: 'lg'
		});
		this.warrantyList = val.waranty.warranty;
		this.warantyIdRetrieved = val.waranty.id;
		this.vehicleSelected1 = this.vehicleList.find(o => o.model === val.vehicleDetails.vehicleDetails.model);
		this.varientsList = this.vehicleSelected1.varients;
		this.vehicleIdSelected = this.vehicleSelected1.vehicleId;
		this.varientSelected1 = this.vehicleSelected1.varients.find(o => o.name === val.vehicleDetails.varient.name);
		this.varientIdSelected = this.varientSelected1.id;
		this.warrantyForm.controls.vehicleName.setValue(this.vehicleSelected1.model);
		this.warrantyForm.controls.varient.setValue(this.varientSelected1.name);
	}

	deleteWarranty(val, content) {
		this.modalService.open(content, {
			size: 'lg'
		});
		this.warantyIdRetrieved = val.waranty.id;
	}

	deleteWarrantyConfirm(val) {
		if (val === 'true') {
			this.vehSer.warrantyDelete(this.warantyIdRetrieved).subscribe((result) => {
				this.getWarrantyList();
			});
		}
		this.closeLarge();
	}

	editWarranty1(val, ndx) {
		this.warrantyList.splice(ndx, 1);
		(document.getElementById('warrantyName') as HTMLInputElement).value = val.document_name;
		(document.getElementById('warrantyCost') as HTMLInputElement).value = val.cost;
	}

	deleteWarranty1(val, ndx) {
		this.warrantyList.splice(ndx, 1);
	}

	ngOnDestroy() {
		this.subscriptions.forEach(el => el.unsubscribe());
	}



}
