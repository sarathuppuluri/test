import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VehiclesVariantListComponent } from './vehicles-variant-list.component';

describe('VehiclesVariantListComponent', () => {
  let component: VehiclesVariantListComponent;
  let fixture: ComponentFixture<VehiclesVariantListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VehiclesVariantListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VehiclesVariantListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
