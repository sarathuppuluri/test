import { PreenquiryService } from '../../../../../core/e-commerce/_services/pre-enquiry.service';
import { Component, OnInit, Inject } from '@angular/core';
import { SMSEMAILDialogModel } from '../../../../../core/e-commerce/_models/smsemail-dialog-model';
import { FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SMSEMAILEnums } from '../../../../../core/e-commerce/_consts/smsemail-dialog-enums';

@Component({
  selector: 'kt-sms-email-dialog',
  templateUrl: './sms-email-dialog.component.html'
})
export class SMSEMAILDialogComponent implements OnInit {

  selected = '';

  contentData: SMSEMAILDialogModel;
  responseData: SMSEMAILDialogModel = {};

  dialogConfirmationControl = new FormControl('', [
    Validators.required,
  ]);

  pcSelectControl = new FormControl('', [
    Validators.required,
  ]);

  phoneNumberControl = new FormControl('', [
  ]);

  inputRequired /*= LABEL_INPUT_REQUIRED*/;
  selectRequired /*= LABEL_SELECT_REQUIRED*/;

  nodeTypeSelectData = [];

  emailSubject; emailText;
  editEmailText = false;
  dealerName = 'Bharat Hyundai';
  dealerCity = 'Khammam';
  custName = 'Sai';
  deliveryDate = '25-02-2020';
  dseMobNo = '9848022338';
  ccmEmailId = 'sai.reddy@focalcxm.com';
  creName = this.dealerName;

  constructor(
    private dialogRef: MatDialogRef<SMSEMAILDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: SMSEMAILDialogModel,
    private preenquiryservice: PreenquiryService
  ) { }

  ngOnInit() {
    this.contentData = this.dialogData;
    if (this.contentData.dialogType === SMSEMAILEnums.pcDialogType.PROMPT) {
      if (this.contentData.responseData) {
        this.dialogConfirmationControl.setValue(this.contentData.responseData);
      }
    } else if (this.contentData.dialogType === SMSEMAILEnums.pcDialogType.EMAIL) {
      this.dialogData.email.templateTypes.forEach(emailData => {
        const type = emailData['Name'];
        let obj = { key: type.replace('_', ' '), value: type };
        this.nodeTypeSelectData.push(obj);
      });
    }
  }



  bindData(data) {
    data = data.replace('{{dealerName}}', this.dealerName);
    data = data.replace('{{dealerCity}}', this.dealerCity);
    data = data.replace('{{custName}}', this.custName);
    data = data.replace('{{deliveryDate}}', this.deliveryDate);
    data = data.replace('{{dseMobNo}}', this.dseMobNo);
    data = data.replace('{{ccmEmailId}}', this.ccmEmailId);
    data = data.replace('{{creName}}', this.creName);
    return data;
  }

  save() {
    let resultData: boolean | SMSEMAILDialogModel;

    if (this.contentData.dialogType === SMSEMAILEnums.pcDialogType.PROMPT) {
      if (this.dialogConfirmationControl.invalid) {
        this.dialogConfirmationControl.markAsDirty();
        return;
      }

      if (this.dialogConfirmationControl.value.trim().length <= 0) {
        this.dialogConfirmationControl.setValue('');
        this.dialogConfirmationControl.markAsDirty();
        return;
      }

      this.responseData = {
        responseData: this.dialogConfirmationControl.value.trim(),
        dialogType: this.contentData.dialogType
      };
      resultData = this.responseData;
    } else if (this.contentData.dialogType === SMSEMAILEnums.pcDialogType.DROP_DOWN) {
      if (this.pcSelectControl.invalid) {
        this.pcSelectControl.markAsDirty();
        return;
      }

      if (this.pcSelectControl.value.trim().length <= 0) {
        this.pcSelectControl.setValue('');
        this.pcSelectControl.markAsDirty();
        return;
      }

      this.responseData = {
        responseData: this.pcSelectControl.value.trim(),
        dialogType: this.contentData.dialogType
      };
      resultData = this.responseData;
    } else if (this.contentData.dialogType === SMSEMAILEnums.pcDialogType.EMAIL) {
      const emailId = this.dialogData.email.emailId;
      const templateName = this.pcSelectControl.value.trim();
      const emailSubject = this.emailSubject;
      const emailText = this.emailText;

      const emailDataToReturn = {
        emailId: emailId,
        templateName: templateName,
        emailSubject: emailSubject,
        emailText: emailText
      };

      this.responseData = {
        responseData: JSON.stringify(emailDataToReturn),
        dialogType: this.contentData.dialogType
      };
      resultData = JSON.parse(this.responseData.responseData);
    } else if (this.contentData.dialogType === SMSEMAILEnums.pcDialogType.SMS) {
      const smsData = {
        Message: this.dialogConfirmationControl.value.trim(),
        phoneNumber: this.phoneNumberControl.value.trim()
      };
      this.responseData = {
        responseData: JSON.stringify(smsData),
        dialogType: this.contentData.dialogType
      };
      resultData = JSON.parse(this.responseData.responseData);
    } else {
      resultData = true;
    }

    this.dialogRef.close(resultData);
  }

  close() {
    this.dialogRef.close(false);
  }

}
