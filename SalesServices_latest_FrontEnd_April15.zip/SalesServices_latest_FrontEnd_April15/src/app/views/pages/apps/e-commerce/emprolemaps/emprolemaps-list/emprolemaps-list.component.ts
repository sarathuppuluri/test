// Angular
import {
	Component,
	OnInit,
	ElementRef,
	ViewChild,
	ChangeDetectionStrategy,
	OnDestroy,
	ChangeDetectorRef,
} from "@angular/core";
// Material
import { SelectionModel } from "@angular/cdk/collections";
import {
	MatPaginator,
	MatSort,
	MatSnackBar,
	MatDialog,
} from "@angular/material";
// RXJS
import {
	debounceTime,
	distinctUntilChanged,
	tap,
	skip,
	delay,
	take,
} from "rxjs/operators";
import { fromEvent, merge, Subscription, of } from "rxjs";
// Translate Module
import { TranslateService } from "@ngx-translate/core";
// NGRX
import { Store, ActionsSubject } from "@ngrx/store";
import { AppState } from "../../../../../../core/reducers";
// CRUD
import {
	LayoutUtilsService,
	MessageType,
	QueryParamsModel,
} from "../../../../../../core/_base/crud";
// Services and Models
import { EmpRoleMapModel } from "../../../../../../core/e-commerce";
import { Lead360Service } from "../../../../../../core/e-commerce/_services";
import { Router, ActivatedRoute } from "@angular/router";
import { MyRolesService } from "../../../../../../core/e-commerce/_services/myroles.service";
import { MenuAsideService } from "../../../../../../core/_base/layout/services/menu-aside.service";
import { FormGroup, FormBuilder } from "@angular/forms";

@Component({
	selector: "kt-emprolemaps-list",
	templateUrl: "./emprolemaps-list.component.html",
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EmpRoleMapsListComponent implements OnInit, OnDestroy {
	searchFormGroup: FormGroup;
	searchProgress = false;
	message = "";
	rolesList = [];
	// Selection
	selection = new SelectionModel<EmpRoleMapModel>(true, []);
	emprolemapsResult: EmpRoleMapModel[] = [];
	// Subscriptions
	private subscriptions: Subscription[] = [];
	selectedEmployee;
	tempActions = [];
	page = 0;
	pageSize = 10;
	loginEmployee: any;
	step;
	scope: any = {};
	isObjectValue: boolean;

	/**
	 * Component constructor
	 *
	 * @param dialog: MatDialog
	 * @param snackBar: MatSnackBar
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 * @param store: Store<AppState>
	 */
	constructor(
		public dialog: MatDialog,
		public snackBar: MatSnackBar,
		private layoutUtilsService: LayoutUtilsService,
		private translate: TranslateService,
		private store: Store<AppState>,
		private myroleservice: MyRolesService,
		private lead360service: Lead360Service,
		private router: Router,
		private routeData: ActivatedRoute,
		private changeDetectorRef: ChangeDetectorRef,
		private menuAsideService: MenuAsideService,
		private formBuilder: FormBuilder
	) {}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.menuAsideService.tempList.forEach((element) => {
			if (element.menuName === "employeeManagement") {
				element.submenu.forEach((subelement) => {
					if (subelement.menuName === "employees") {
						this.myroleservice.readUrl = subelement.apiUrl;
						this.tempActions = subelement.actions;
						this.tempActions.forEach((element) => {
							if (element.actionName === "viewEmployee") {
								// this.myroleservice.readUrl = element.apiUrl;
							} else if (
								element.actionName === "createEmployee"
							) {
								this.myroleservice.createUrl = element.apiUrl;
							} else if (element.actionName === "editEmployee") {
								this.myroleservice.updateUrl = element.apiUrl;
							} else if (
								element.actionName === "deleteEmployee"
							) {
								this.myroleservice.deleteUrl = element.apiUrl;
							}
						});
					}
				});
			}
		});
		this.searchForm();
		this.loadEmployeesList();
	}

	/**
	 * On Destroy
	 */
	ngOnDestroy() {
		this.subscriptions.forEach((el) => el.unsubscribe());
	}

	employeesList: any = [];
	isLoading = false;
	loadEmployeesList() {
		this.employeesList = [];
		this.isLoading = true;
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize
		);
		this.myroleservice
			.getRedsignedEmployees(
				queryParams,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((response) => {
				if (response.dmsEntity && response.dmsEntity.employeeDTOPage) {
					this.employeesList =
						response.dmsEntity.employeeDTOPage.content;
					this.scope = response.dmsEntity.employeeDTOPage;
				} else {
					this.employeesList = [];
					this.scope.totalElements = 0;
				}
				this.isLoading = false;
				this.isObjectValue = false;
				this.changeDetectorRef.detectChanges();
			});
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		// this.loadLeadsShowroomById();
		this.loadEmployeesList();
	}

	// search role
	searchForm() {
		this.searchFormGroup = this.formBuilder.group({
			name: [""],
			empId: [""],
		});
	}

	// submit search role name
	onSubmit() {
		this.searchProgress = true;
		const controls = this.searchFormGroup.controls;
		this.message = "";
		this.employeesList = [];
		this.myroleservice
			.getEmployeesNameOrId(controls.name.value, controls.empId.value)
			.subscribe(
				(res) => {
					this.searchProgress = false;
					if (res.statusCode !== 400 && res.status !== 500) {
						if (
							Array.isArray(res.dmsEntity.employeeDTOs) === false
						) {
							if (res.status !== 500) {
								this.employeesList.push(
									res.dmsEntity.employeeDTOs
								);
							} else {
								this.message = "No Employees Found";
							}
						} else {
							this.isObjectValue = true;
							this.employeesList = res.dmsEntity.employeeDTOs;
							this.scope.totalElements = this.employeesList.length;
						}
					} else {
						this.employeesList = [];
						this.scope.totalElements = 0;
					}
					this.changeDetectorRef.detectChanges();
				},
				(error) => {
					this.searchProgress = false;
					this.employeesList = [];
					this.scope.totalElements = 0;
					this.changeDetectorRef.detectChanges();
				}
			);
	}

	// reset serach role name
	onReset() {
		this.searchFormGroup.reset();
		this.message = "";
		this.loadEmployeesList();
	}

	/** ACTIONS */
	/**
	 * Delete emprolemap
	 *
	 * @param _item: EmpRoleMapModel
	 */
	deleteEmpRoleMap(employee) {
		const _title: string = this.translate.instant("Employee Delete");
		const _description: string = this.translate.instant(
			"Are you sure to permanently delete this Employee?"
		);
		const _waitDesciption: string = this.translate.instant(
			"Employee is deleting..."
		);
		const _deleteMessage = this.translate.instant("SuccessFully deleted.");

		const dialogRef = this.layoutUtilsService.deleteElement(
			_title,
			_description,
			_waitDesciption
		);
		dialogRef.afterClosed().subscribe((res) => {
			if (!res) {
				return;
			}
			this.myroleservice
				.deleteRedsignedRole(employee.empId)
				.subscribe((res) => {
					this.layoutUtilsService
						.showActionNotification(
							_deleteMessage,
							MessageType.Delete
						)
						.afterOpened()
						.subscribe((res) => {
							this.page =
								this.employeesList.length === 1
									? this.page - 1
									: this.page;
							this.loadEmployeesList();
						});
				});
		});
	}

	getRowData(data) {
		this.router.navigate([
			"/employeeManagement/employees/subview",
			data.id,
		]);
	}

	routeToUnMapping(emprolemap) {
		this.router.navigate([
			"/employeeManagement/employees/unMapping",
			emprolemap.empId,
		]);
	}
}
