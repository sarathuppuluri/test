import { Component, OnInit, ChangeDetectorRef } from "@angular/core";
import { OffersService } from "../../../../../core/e-commerce/_services/offers.service";
import { Router, ActivatedRoute } from "@angular/router";

@Component({
	selector: "kt-offer-mapings-list",
	templateUrl: "./offer-mapings-list.component.html",
	styleUrls: ["./offer-mapings-list.component.scss"],
})
export class OfferMapingsListComponent implements OnInit {
	offersMappings: any;
	isLoading = false;
	offerId;
	constructor(
		private offersService: OffersService,
		private router: Router,
		private route: ActivatedRoute,
		private changeDetectorRef: ChangeDetectorRef
	) {}

	ngOnInit() {
		this.offerId = this.route.snapshot.paramMap.get("id");
		this.getAllOfferMappingsById();
	}

	getAllOfferMappingsById() {
		this.offersService
			.getOfferMappingsByOfferId(this.offerId)
			.subscribe((data) => {
				this.offersMappings = data;
				this.changeDetectorRef.detectChanges();
			});
	}

	getRowData(offer) {
	}

	deleteOffer(offerMapping) {
		this.offersService
			.deleteOfferMapping(offerMapping)
			.subscribe((data) => {
				this.getAllOfferMappingsById();
			});
	}
	createOffer() {
		this.router.navigateByUrl("adminPanel/offers/mapping/create/" + this.offerId);
	}

	goBack() {
		this.router.navigateByUrl("adminPanel/offers");
	}

	editOffer(offerMapping) {
		this.offersService.offer = offerMapping;
		this.router.navigateByUrl(
			"adminPanel/offers/mapping/" + offerMapping.id + "/" + true
		);
	}
}
