import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferMapingsListComponent } from './offer-mapings-list.component';

describe('OfferMapingsListComponent', () => {
  let component: OfferMapingsListComponent;
  let fixture: ComponentFixture<OfferMapingsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfferMapingsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferMapingsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
