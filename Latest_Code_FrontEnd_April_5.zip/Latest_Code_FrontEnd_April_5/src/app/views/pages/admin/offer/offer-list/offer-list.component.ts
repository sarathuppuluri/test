import { Component, OnInit, ChangeDetectorRef } from "@angular/core";
import { OffersService } from "../../../../../core/e-commerce/_services/offers.service";
import { Router } from "@angular/router";

@Component({
	selector: "kt-offer-list",
	templateUrl: "./offer-list.component.html",
	styleUrls: ["./offer-list.component.scss"],
})
export class OfferListComponent implements OnInit {
	offers: any;
	corpOffers: any;
	selectedIndex = 0;
	isLoading = false;
	page = 0;
	pageSize = 10;
	pageCorp = 0;
	pageSizeCorp = 10;
	scope: any = {};
	scopeCorporate: any = {};
	constructor(
		private offersService: OffersService,
		private router: Router,
		private changeDetectorRef: ChangeDetectorRef
	) {}

	ngOnInit() {
		this.getAllOffers();
	}

	getAllOffers() {
		this.offersService
			.getAllOffers(this.page, this.pageSize)
			.subscribe((data) => {
				this.offers = data.offerDetail.content;
				this.scope = data.offerDetail;
				this.corpOffers = data.offerCorporates.content;
				this.scopeCorporate = data.offerCorporates;
				this.changeDetectorRef.detectChanges();
			});
	}

	getRowData(offer) {
		this.router.navigateByUrl("adminPanel/offers/mappings/" + offer.id);
	}

	deleteOffer(offer) {
		this.offersService.deleteOffer(offer).subscribe((data) => {
			this.getAllOffers();
			this.offers = [];
			this.corpOffers = [];
			this.changeDetectorRef.detectChanges();
		});
	}

	deleteCropOffer(offer) {
		offer.offerCorporates = "[]";
		this.offersService.deleteCropOffer(offer).subscribe((data) => {
			this.getAllOffers();
			this.offers = [];
			this.corpOffers = [];
			this.changeDetectorRef.detectChanges();
		});
	}

	createOffer() {
		if (this.selectedIndex === 0) {
			this.router.navigateByUrl("adminPanel/offers/create");
		} else {
			this.router.navigateByUrl("adminPanel/offers/corp-offer/create");
		}
	}



	editOffer(offer) {
		this.offersService.offer = offer;
		const type = this.selectedIndex === 0 ? "GENERAL" : "CORPORATE";
		if (this.selectedIndex === 0) {
			this.router.navigateByUrl("adminPanel/offers/offer/" + type + "/" + offer.id);
		} else {
			this.router.navigateByUrl(
				"adminPanel/offers/corp-offer/" + type + "/" + offer.id
			);
		}
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.getAllOffers();
	}

	paginatorEventsCrop(event) {
		this.pageCorp = event.pageIndex;
		this.pageSizeCorp = event.pageSize;
		this.getAllOffers();
	}
}
