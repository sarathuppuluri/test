import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorpOfferComponent } from './corp-offer.component';

describe('CorpOfferComponent', () => {
  let component: CorpOfferComponent;
  let fixture: ComponentFixture<CorpOfferComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorpOfferComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorpOfferComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
