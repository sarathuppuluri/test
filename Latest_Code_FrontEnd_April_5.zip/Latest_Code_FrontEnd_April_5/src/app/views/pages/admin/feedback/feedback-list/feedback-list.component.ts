import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-feedback-list',
  templateUrl: './feedback-list.component.html',
  styleUrls: ['./feedback-list.component.scss']
})
export class FeedbackListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
