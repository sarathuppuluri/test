import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import * as moment from 'moment';
import { AdminService } from '../../../../core/e-commerce/_services/admin.service';

@Component({
  selector: 'kt-add-alert',
  templateUrl: './add-alert.component.html',
  styleUrls: ['./add-alert.component.scss']
})
export class AddAlertComponent implements OnInit {
  rowCount = 0;
  alertsArray : Array<any> = [];
  alertsInfo: Array<any> = [];
  newAttribute : any = { 'newRow' : true, 'alertsInfo': [{
    "id": 0,
    "title": '',
    "dueDate": ''
  }]};
  title;
  dueDate;
  alertsInfoForm : FormGroup;
  infoArray = [];
  constructor(private fb: FormBuilder, private AdminService: AdminService) {
    let now = moment();
   }

  ngOnInit() {
    this.alertsInfoForm = this.fb.group({
			id: [''],
			title: [''],
			dueDate: ['']
    });
    const custId = 11;
    this.AdminService.getAllNotification(custId).subscribe((result) => {
      });
  }
  newRow() {
    this.rowCount++;
    if(this.alertsArray.length === 0){
      this.alertsArray.push(this.newAttribute);
    }
    this.alertsInfo = this.newAttribute.alertsInfo;
  }
  titelChange(event){
    this.alertsInfoForm.patchValue({title: event.target.value});
  }
  dateCal(event){
    this.dueDate = Date.parse(event.target.value);
		this.alertsInfoForm.patchValue({ dueDate: moment(this.dueDate).format('YYYY-MM-DD')});
  }
  submitAlert(formObj, index){
    let object = {
      "id": index,
      "title": formObj.title,
      "dueDate": formObj.dueDate
    }
    this.alertsInfo.push(object);
  }


}
