import { Component, OnInit, ChangeDetectorRef } from "@angular/core";
import { TaxCalculationService } from "../../../../../core/e-commerce/_services/taxCalculation.service";
import { Router } from "@angular/router";
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
	selector: "kt-tax-calculation-list",
	templateUrl: "./tax-calculation-list.component.html",
	styleUrls: ["./tax-calculation-list.component.scss"],
})
export class TaxCalculationListComponent implements OnInit {
	limit: number = 10;
	offset: number = 0;
	taxes;
	isLoading = false;
	scope;
	constructor(
		public taxCalculationService: TaxCalculationService,
		public router: Router,
		private _snackBar: MatSnackBar,
		private cd: ChangeDetectorRef
	) {}

	ngOnInit() {
		this.getTaxes();
	}

	getTaxes() {
		this.isLoading = true;
		this.taxCalculationService
			.getTaxes(this.limit, this.offset)
			.subscribe((data) => {
				this.isLoading = false;
				this.taxes = null;
				this.cd.detectChanges();
				if (data && data.roadtaxList[0]) {
					this.taxes = data.roadtaxList[0];
					this.scope = data;
				}
			});
	}

	deleteTax() {
		const id = this.taxes.id;
		this.taxCalculationService.deleteTax(id).subscribe((data) => {
			this.openSnackBar("Tax Details Deleteds Successfully", "Success");
			this.getTaxes();
		});
	}

	create() {
		this.router.navigateByUrl("adminPanel/Taxrate/create");
	}

	Update() {
		const id = this.taxes.id;
		this.router.navigateByUrl("adminPanel/Taxrate/edit/" + id);
	}

	private openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 5000,
		});
	}
}
