import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxCalculationListComponent } from './tax-calculation-list.component';

describe('TaxCalculationListComponent', () => {
  let component: TaxCalculationListComponent;
  let fixture: ComponentFixture<TaxCalculationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaxCalculationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxCalculationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
