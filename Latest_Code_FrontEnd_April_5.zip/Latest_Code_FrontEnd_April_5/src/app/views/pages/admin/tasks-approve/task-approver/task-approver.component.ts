import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { TaskApproverService } from "../../../../../core/e-commerce/_services/taskApprover.service";

@Component({
	selector: "kt-task-approver",
	templateUrl: "./task-approver.component.html",
	styleUrls: ["./task-approver.component.scss"],
})
export class TaskApproverComponent implements OnInit {
	taskApproverForm: FormGroup;
	loginEmployee: any;
	empid: any;
	taskId: any;
	showError = false;
	taskTypes = [];
	desginationTypes = [];
	departmentTypes = [];
	employees = [];
	reporties = [];
	constructor(
		private fb: FormBuilder,
		public taskApproverService: TaskApproverService,
		private route: ActivatedRoute,
		private router: Router
	) {}

	ngOnInit() {
		this.createForm();
		this.taskId = this.route.snapshot.paramMap.get("id");
		this.empid = this.route.snapshot.paramMap.get("empid");
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.getTaskDefinitions();
		this.getDepartments();
		if (this.taskId) {
			if (this.taskApproverService.rowObject) {
				this.getReporties(
					this.taskApproverService.rowObject.empGrade,
					this.taskApproverService.rowObject.empDepartmentId
				);
			} else {
				this.router.navigateByUrl("adminPanel/taskApprover");
			}
		}
	}

	createForm() {
		this.taskApproverForm = this.fb.group({
			deptId: [""],
			designationId: [""],
			approverId: [""],
			branchid: [""],
			empid: [""],
			id: [""],
			orgid: [""],
			taskDefId: [""],
		});
	}

	getTaskApproverByid() {
		this.taskApproverService
			.getTasksApproverById(this.taskId, this.empid)
			.subscribe((data) => {
				this.taskApproverForm.patchValue(
					data.dmsEntity.taskApproverModel
				);
			});
	}

	getTaskDefinitions() {
		this.taskApproverService.getTaskDefinitions().subscribe((data) => {
			this.taskTypes = data;
		});
	}

	getDepartments() {
		this.taskApproverService.getDepartments().subscribe((data) => {
			this.departmentTypes = data.dmsEntity.department;
			this.desginationTypes = data.dmsEntity.designations;
		});
	}

	getEmployeeByDept(deptId, desigId) {
		if (deptId && desigId) {
			this.taskApproverService
				.getEmployeeByDept(deptId, desigId)
				.subscribe((data) => {
					if (data.dmsEntity && data.dmsEntity.employees) {
						this.employees = data.dmsEntity.employees;
					} else {
						alert("No Employee are mapped in selected degination");
					}
				});
		}
	}

	getReporties(gradeId, deptId) {
		this.taskApproverService
			.getReporties(gradeId, deptId)
			.subscribe((data) => {
				if (data.dmsEntity && data.dmsEntity.employees) {
					this.reporties = data.dmsEntity.employees;
					if (this.taskApproverService.rowObject) {
						this.getTaskApproverByid();
					}
				} else {
					alert(
						"No Reporties are mapped in selected employee and selected desgination"
					);
				}
			});
	}

	goBack() {
		this.router.navigateByUrl("adminPanel/taskApprover");
	}

	changeDestination() {
		this.getEmployeeByDept(
			this.taskApproverForm.value.deptId,
			this.taskApproverForm.value.designationId
		);
	}
	changeEmployee(event) {
		const employee = this.employees.filter(
			(a) => a.empId === event.value
		)[0];
		this.getReporties(employee.gradeId, employee.departmentId);
	}
	submit() {
		const request = {
			approverId: this.taskApproverForm.value.approverId,
			branchid: this.loginEmployee.branchId,
			empid: this.taskApproverForm.value.empid,
			id: this.taskApproverForm.value.id,
			orgid: this.loginEmployee.orgId,
			taskDefId: this.taskApproverForm.value.taskDefId,
		};
		if (this.empid) {
			this.taskApproverService
				.updateTaskApprover(JSON.stringify(request))
				.subscribe((data) => {
					this.router.navigateByUrl("adminPanel/taskApprover");
				});
		} else {
			this.taskApproverService
				.createTaskApprover(request)
				.subscribe((data) => {
					this.router.navigateByUrl("adminPanel/taskApprover");
				});
		}
	}

	clear() {
		this.createForm();
	}
	isSubmitDisabled() {
		if (this.empid) {
			if (
				!this.taskApproverForm.value.taskDefId ||
				!this.taskApproverForm.value.approverId
			) {
				return true;
			} else {
				return false;
			}
		} else {
			if (
				!this.taskApproverForm.value.empid ||
				!this.taskApproverForm.value.taskDefId ||
				!this.taskApproverForm.value.approverId ||
				!this.taskApproverForm.value.deptId ||
				!this.taskApproverForm.value.designationId
			) {
				return true;
			} else {
				return false;
			}
		}
	}
}
