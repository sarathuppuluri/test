import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskApproverComponent } from './task-approver.component';

describe('TaskApproverComponent', () => {
  let component: TaskApproverComponent;
  let fixture: ComponentFixture<TaskApproverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskApproverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskApproverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
