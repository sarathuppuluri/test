import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
	MatInputModule,
	MatPaginatorModule,
	MatProgressSpinnerModule,
	MatSortModule,
	MatTableModule,
	MatSelectModule,
	MatMenuModule,
	MatProgressBarModule,
	MatButtonModule,
	MatCheckboxModule,
	MatDialogModule,
	MatTabsModule,
	MatNativeDateModule,
	MatCardModule,
	MatRadioModule,
	MatIconModule,
	MatDatepickerModule,
	MatAutocompleteModule,
	MatSnackBarModule,
	MatTooltipModule,
	MatExpansionModule,
} from "@angular/material";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { RouterModule } from "@angular/router";
import { TaskApproverComponent } from "./task-approver/task-approver.component";
import { TaskApproverListComponent } from "./task-approver-list/task-approver-list.component";
import { TaskApproverService } from "../../../../core/e-commerce/_services/taskApprover.service";

@NgModule({
	declarations: [TaskApproverListComponent, TaskApproverComponent],
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatInputModule,
		MatPaginatorModule,
		MatProgressSpinnerModule,
		MatSortModule,
		MatTableModule,
		MatSelectModule,
		MatMenuModule,
		MatProgressBarModule,
		MatButtonModule,
		MatCheckboxModule,
		MatDialogModule,
		MatTabsModule,
		MatNativeDateModule,
		MatCardModule,
		MatRadioModule,
		MatIconModule,
		MatDatepickerModule,
		MatAutocompleteModule,
		MatSnackBarModule,
		MatTooltipModule,
		MatExpansionModule,
		NgbModule,
		RouterModule.forChild([
			{
				path: "",
				component: TaskApproverListComponent,
			},
			{
				path: "create",
				component: TaskApproverComponent,
			},
			{
				path: "edit/:id/:empid",
				component: TaskApproverComponent,
			},
		]),
	],
	providers: [TaskApproverService],
})
export class TaxApproveModule {}
