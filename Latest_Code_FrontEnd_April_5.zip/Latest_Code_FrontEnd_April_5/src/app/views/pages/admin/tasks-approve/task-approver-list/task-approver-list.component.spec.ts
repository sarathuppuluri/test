import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskApproverListComponent } from './task-approver-list.component';

describe('TaskApproverListComponent', () => {
  let component: TaskApproverListComponent;
  let fixture: ComponentFixture<TaskApproverListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskApproverListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskApproverListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
