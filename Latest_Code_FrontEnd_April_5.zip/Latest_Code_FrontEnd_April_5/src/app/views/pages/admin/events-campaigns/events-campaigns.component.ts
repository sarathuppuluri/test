import {
	Component,
	OnInit,
	ChangeDetectorRef,
	Input,
	EventEmitter,
	Output,
	Inject,
} from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";

import { MatSnackBar } from "@angular/material/snack-bar";
import {
	MatDialog,
	MatDialogRef,
	MAT_DIALOG_DATA,
	MatDialogConfig,
} from "@angular/material/dialog";
import moment from "moment";
import { performanceConfirmationDialog } from "../../performance-repoting/confirmation-dialog.component";
import { VehiclesService } from "../../../../core/e-commerce/_services/vehicles.service";
import {
	BranchService,
	EventsCampaignsService,
} from "../../../../core/e-commerce/_services";
@Component({
	selector: "kt-events-campaigns",
	templateUrl: "./events-campaigns.component.html",
	styleUrls: ["./events-campaigns.component.scss"],
})
export class EventsCampaignsComponent implements OnInit {
	globalDataObject: any = {};

	public page: number = 0;
	public pageSize: number = 10;
	public totalCount: number;
	loginEmployee: any;

	latestEventsCampaignsObj: any = [];
	isLoading = false;

	notificationTemplates: any = [];
	status: string = "Active";
	constructor(
		private eventsCampaignsService: EventsCampaignsService,
		private changeDetectorRef: ChangeDetectorRef,
		private _snackBar: MatSnackBar,
		public dialog: MatDialog
	) {}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));

		this.eventsCampaignsService
			.getAllNotificationTemplates(
				this.loginEmployee.branchId,
				this.loginEmployee.orgId,
				this.status
			)
			.subscribe((res) => {
				if (res.status === "SUCCESS") {
					this.notificationTemplates = res.templateMasters;
				}
			});

		this.getEventsCampaignsData();
	}
	getEventsCampaignsData() {
		this.isLoading = true;
		this.latestEventsCampaignsObj = [];

		this.eventsCampaignsService
			.getAllEventsCampaignsData(
				this.pageSize,
				this.page,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res) => {
				this.isLoading = false;
				if (res.status === "SUCCESS") {
					this.globalDataObject = res;
					this.latestEventsCampaignsObj = res.bannerNotifications;
				}
				this.changeDetectorRef.detectChanges();
			});
	}

	getTemplateName(id) {
		let str: any = "";
		this.notificationTemplates.filter((obj) => {
			if (obj.id === id) {
				str = obj.channelType + " - " + obj.taskType;
			}
		});
		return str;
	}

	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 3000,
		});
	}

	paginatorLatestNews(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.getEventsCampaignsData();
	}

	deleteNews(obj) {
		if (obj.id != "") {
			const dialogConfig = new MatDialogConfig();
			dialogConfig.disableClose = false;
			dialogConfig.autoFocus = true;
			dialogConfig.width = "400px";
			//dialogConfig.height='480px';
			dialogConfig.data = {
				message: "Are you sure want to delete?",
				buttonText: { ok: "Yes", cancel: "No" },
			};
			const dialogRef = this.dialog.open(
				performanceConfirmationDialog,
				dialogConfig
			);
			dialogRef.afterClosed().subscribe((confirmed: boolean) => {
				if (confirmed) {
					this.eventsCampaignsService
						.deleteEventsCampaigns(obj.id)
						.subscribe((res: any) => {
							if (res.status === "SUCCESS") {
								this.openSnackBar(
									obj.eventName +
										" - has been deleted successfully",
									"SUCCESS"
								);
								this.getEventsCampaignsData();
								this.changeDetectorRef.detectChanges();
							} else {
								this.openSnackBar(
									res.statusDescription,
									res.status
								);
							}
						});
				}
			});
		}
	}

	editNews(Obj) {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		dialogConfig.width = "700px";
		//dialogConfig.height='480px';
		dialogConfig.data = Obj;

		const dialogRef = this.dialog.open(
			CreateEventsCampaignsDialog,
			dialogConfig
		);

		dialogRef.afterClosed().subscribe((result) => {
			if (result === "success") {
				this.getEventsCampaignsData();
			}
			this.changeDetectorRef.detectChanges();
		});
	}

	/* **********************************Popup code starts here************************************************ */

	createLatestNews(): void {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		dialogConfig.width = "700px";
		//dialogConfig.height='480px';
		dialogConfig.data = {
			animal: "string",
			name: "string",
		};

		const dialogRef = this.dialog.open(
			CreateEventsCampaignsDialog,
			dialogConfig
		);

		dialogRef.afterClosed().subscribe((result) => {
			if (result === "success") {
				this.getEventsCampaignsData();
			}
		});
	}
}
/******************************************************************Dailog Window********************************************* */
export interface DialogData {
	animal: string;
	name: string;
}

@Component({
	selector: "create-events-campaigns-dialog",
	templateUrl: "create-events-campaigns-dialog.html",
	styleUrls: ["./events-campaigns.component.scss"],
})
export class CreateEventsCampaignsDialog {
	loginEmployee: any;
	eventsCampaignsObj: any;
	isUpdate: boolean = false;
	url: any;
	fileTyle: string = "";

	status: string = "Active";
	notificationTemplates: any = [];
	departmentObj: any = [];
	startDate;
	EventsCampaignsFormGroup = this.formBuilder.group({
		template: ["", Validators.required],
		department: ["", Validators.required],

		startDate: ["", Validators.required],
		endDate: ["", Validators.required],
		eventName: ["", Validators.required],
		title: ["", Validators.required],
		email: ["", Validators.required],
		phone: ["", Validators.required],
		description: ["", Validators.required],
		imageUrl: ["", Validators.required],
		locationLat: ["", Validators.required],
		locationLong: ["", Validators.required],
		status: ["", Validators.required],
	});

	constructor(
		private vehSer: VehiclesService,
		private formBuilder: FormBuilder,
		private changeDetectorRef: ChangeDetectorRef,
		private eventsCampaignsService: EventsCampaignsService,
		private branchService: BranchService,
		private _snackBar: MatSnackBar,
		public dialog: MatDialog,
		public dialogRef: MatDialogRef<CreateEventsCampaignsDialog>,
		@Inject(MAT_DIALOG_DATA) public data
	) {
		this.eventsCampaignsObj = data;
		this.startDate = new Date(
			new Date().getFullYear(),
			new Date().getMonth(),
			new Date().getDate()
		);
	}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.eventsCampaignsService
			.getAllNotificationTemplates(
				this.loginEmployee.branchId,
				this.loginEmployee.orgId,
				this.status
			)
			.subscribe((res) => {
				if (res.status === "SUCCESS") {
					this.notificationTemplates = res.templateMasters;
				} else {
					this.openSnackBar(
						"Oops! Failed to get Notification Templates",
						"fail"
					);
				}
				this.changeDetectorRef.detectChanges();
			});
		this.branchService
			.getDepartmentDesignation(
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res) => {
				if (res.success === true) {
					this.departmentObj = res.dmsEntity.department;
				} else {
					this.openSnackBar(
						"Oops! Failed to get All Departments",
						"fail"
					);
				}
				this.changeDetectorRef.detectChanges();
			});

		if (this.eventsCampaignsObj.id) {
			this.isUpdate = true;

			if (this.eventsCampaignsObj.imageUrl != "") {
				this.url = this.eventsCampaignsObj.imageUrl;
				this.fileTyle = "image/jpeg";
			}
			this.patchForm();
		}
	}

	public patchForm() {
		if (this.eventsCampaignsObj.emailTemplateId != 0) {
			this.EventsCampaignsFormGroup.controls["template"].setValue(
				this.eventsCampaignsObj.emailTemplateId
			);
		} else if (this.eventsCampaignsObj.smsTemplateId != 0) {
			this.EventsCampaignsFormGroup.controls["template"].setValue(
				this.eventsCampaignsObj.smsTemplateId
			);
		}

		this.EventsCampaignsFormGroup.controls["department"].setValue(
			this.eventsCampaignsObj.department
		);
		this.EventsCampaignsFormGroup.controls["eventName"].setValue(
			this.eventsCampaignsObj.eventName
		);

		this.EventsCampaignsFormGroup.controls["title"].setValue(
			this.eventsCampaignsObj.title
		);
		this.EventsCampaignsFormGroup.controls["email"].setValue(
			this.eventsCampaignsObj.email
		);

		this.EventsCampaignsFormGroup.controls["endDate"].setValue(
			this.fromJsonDate(this.eventsCampaignsObj.endDate)
		);
		this.EventsCampaignsFormGroup.controls["startDate"].setValue(
			this.fromJsonDate(this.eventsCampaignsObj.startDate)
		);

		this.EventsCampaignsFormGroup.controls["phone"].setValue(
			this.eventsCampaignsObj.phone
		);
		this.EventsCampaignsFormGroup.controls["status"].setValue(
			this.eventsCampaignsObj.status
		);

		this.EventsCampaignsFormGroup.controls["locationLat"].setValue(
			this.eventsCampaignsObj.locationLat
		);
		this.EventsCampaignsFormGroup.controls["locationLong"].setValue(
			this.eventsCampaignsObj.locationLong
		);

		this.EventsCampaignsFormGroup.controls["description"].setValue(
			this.eventsCampaignsObj.description
		);
	}
	fromJsonDate(jDate): string {
		const bDate: Date = new Date(jDate);
		return bDate.toISOString().substring(0, 10); //Ignore time
	}

	onSave() {
		if (this.EventsCampaignsFormGroup.value.department === "") {
			this.openSnackBar("Please select the Department.", "");
			return null;
		}
		if (
			this.EventsCampaignsFormGroup.value.eventName === "" ||
			this.EventsCampaignsFormGroup.value.eventName === null
		) {
			this.openSnackBar("Event Name should not be empty.", "");
			return null;
		}
		if (this.EventsCampaignsFormGroup.value.startDate === "") {
			this.openSnackBar("Start Date should not be empty.", "");
			return null;
		}
		if (this.EventsCampaignsFormGroup.value.endDate === "") {
			this.openSnackBar("End Date should not be empty.", "");
			return null;
		}
		if (this.EventsCampaignsFormGroup.value.title === "") {
			this.openSnackBar("Title should not be empty.", "");
			return null;
		}
		if (this.EventsCampaignsFormGroup.value.status === "") {
			this.openSnackBar("Please select the Status.", "");
			return null;
		}
		if (this.EventsCampaignsFormGroup.value.description == "") {
			this.openSnackBar("Description should not be empty.", "");
			return null;
		}

		let requestObj = {
			bannerNotification: {
				branchId: this.loginEmployee.branchId,
				createdDatetime: Date.parse(Date()),
				createdBy: this.loginEmployee.empName,
				modifiedDatetime: Date.parse(Date()),
				modifiedBy: this.loginEmployee.empName,
				id: 0,
				orgId: this.loginEmployee.orgId,

				department: this.EventsCampaignsFormGroup.value.department,
				eventName: this.EventsCampaignsFormGroup.value.eventName,

				title: this.EventsCampaignsFormGroup.value.title,
				email: this.EventsCampaignsFormGroup.value.email,

				endDate: this.EventsCampaignsFormGroup.value.endDate,
				startDate: this.EventsCampaignsFormGroup.value.startDate,

				phone: this.EventsCampaignsFormGroup.value.phone,
				status: this.EventsCampaignsFormGroup.value.status,

				locationLat: this.EventsCampaignsFormGroup.value.locationLat,
				locationLong: this.EventsCampaignsFormGroup.value.locationLong,

				imageUrl: this.url,

				description: this.EventsCampaignsFormGroup.value.description,

				smsTemplateId: 0,
				emailTemplateId: 0,
			},
		};
		if (
			this.EventsCampaignsFormGroup.value.template != undefined &&
			this.EventsCampaignsFormGroup.value.template != ""
		) {
			let tempObj = this.filterTemplateObjById(
				this.EventsCampaignsFormGroup.value.template
			);
			if (tempObj[0].channelType === "EMAIL") {
				requestObj.bannerNotification.emailTemplateId = tempObj[0].id;
			}
			if (tempObj[0].channelType === "SMS") {
				requestObj.bannerNotification.smsTemplateId = tempObj[0].id;
			}
		} else {
			this.openSnackBar("Please select the Notification Template.", "");
			return null;
		}

		this.eventsCampaignsService.saveEventsCampaigns(requestObj).subscribe(
			(res) => {
				if (res.status === "SUCCESS") {
					this.openSnackBar(
						"Event/Campaign  has been saved successfully.",
						"success"
					);
					this.dialogRef.close("success");
				} else {
					this.openSnackBar(
						"Oops! Event/Campaign has not been saved.",
						"fail"
					);
				}
			},
			(err) => {
				this.openSnackBar(err["message"], err["status"]);
			}
		);
	}
	filterTemplateObjById(id) {
		return this.notificationTemplates.filter((x) => x.id === id);
	}

	onUpdate() {
		if (this.EventsCampaignsFormGroup.value.department === "") {
			this.openSnackBar("Please select the Department.", "");
			return null;
		}
		if (
			this.EventsCampaignsFormGroup.value.eventName === "" ||
			this.EventsCampaignsFormGroup.value.eventName === null
		) {
			this.openSnackBar("Event Name should not be empty.", "");
			return null;
		}
		if (this.EventsCampaignsFormGroup.value.startDate === "") {
			this.openSnackBar("Start Date should not be empty.", "");
			return null;
		}
		if (this.EventsCampaignsFormGroup.value.endDate === "") {
			this.openSnackBar("End Date should not be empty.", "");
			return null;
		}
		if (this.EventsCampaignsFormGroup.value.title === "") {
			this.openSnackBar("Title should not be empty.", "");
			return null;
		}
		if (this.EventsCampaignsFormGroup.value.status === "") {
			this.openSnackBar("Please select the Status.", "");
			return null;
		}

		let requestObj = {
			bannerNotification: {
				branchId: this.eventsCampaignsObj.branchId,
				createdDatetime: this.eventsCampaignsObj.createdDatetime,
				createdby: this.eventsCampaignsObj.createdby,
				modifiedDatetime: Date.parse(Date()),
				modifiedby: this.loginEmployee.empName,
				id: this.eventsCampaignsObj.id,
				orgId: this.eventsCampaignsObj.orgId,

				department: this.EventsCampaignsFormGroup.value.department,
				eventName: this.EventsCampaignsFormGroup.value.eventName,

				title: this.EventsCampaignsFormGroup.value.title,
				email: this.EventsCampaignsFormGroup.value.email,

				endDate: this.EventsCampaignsFormGroup.value.endDate,
				startDate: this.EventsCampaignsFormGroup.value.startDate,

				phone: this.EventsCampaignsFormGroup.value.phone,
				status: this.EventsCampaignsFormGroup.value.status,

				locationLat: this.EventsCampaignsFormGroup.value.locationLat,
				locationLong: this.EventsCampaignsFormGroup.value.locationLong,

				imageUrl: this.url,

				description: this.EventsCampaignsFormGroup.value.description,

				smsTemplateId: 0,
				emailTemplateId: 0,
			},
		};
		if (
			this.EventsCampaignsFormGroup.value.template != undefined &&
			this.EventsCampaignsFormGroup.value.template != ""
		) {
			let tempObj = this.filterTemplateObjById(
				this.EventsCampaignsFormGroup.value.template
			);
			if (tempObj[0].channelType === "EMAIL") {
				requestObj.bannerNotification.emailTemplateId = tempObj[0].id;
			}
			if (tempObj[0].channelType === "SMS") {
				requestObj.bannerNotification.smsTemplateId = tempObj[0].id;
			}
		} else {
			this.openSnackBar("Please select the Notification Template.", "");
			return null;
		}

		this.eventsCampaignsService.updateEventsCampaigns(requestObj).subscribe(
			(res) => {
				if (res.status === "SUCCESS") {
					this.openSnackBar(
						"Events/Campaigns has been updated successfully.",
						"success"
					);
					this.dialogRef.close("success");
				} else {
					this.openSnackBar(
						"Oops! Events/Campaigns has not been updated.",
						"fail"
					);
				}
			},
			(err) => {
				this.openSnackBar(err["message"], err["status"]);
			}
		);
	}
	isMatSpinner: boolean = false;

	fileChoose(event, docType) {
		if (event.target.files.length > 0) {
			const tempFormData = new FormData();
			let tempName = "";
			for (let i = 0; i < event.target.files.length; i++) {
				tempFormData.append("uploadFiles", event.target.files[i]);
				tempName = tempName.concat(
					event.target.files[i].name,
					i === event.target.files.length - 1 ? "" : ", "
				);
			}

			this.isMatSpinner = true;
			this.vehSer
				.saveMultipleVehicleDetails(tempFormData, "eventscampaigns")
				.subscribe((res) => {
					this.isMatSpinner = false;
					this.url = res.uploadFiles[0].url;
					this.changeDetectorRef.detectChanges();
				});
		}
	}

	deleteUrl() {
		this.url = "";
		this.fileTyle = "";
	}
	resetForm() {
		this.EventsCampaignsFormGroup.reset();
	}

	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 3000,
		});
	}
	onNoClick(): void {
		this.dialogRef.close();
	}
}
