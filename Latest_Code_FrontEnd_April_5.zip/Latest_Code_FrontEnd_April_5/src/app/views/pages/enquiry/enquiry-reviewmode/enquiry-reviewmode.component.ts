import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { EnquiryService, MyRolesService, Lead360Service } from './../../../../core/e-commerce/_services';
import { ActivatedRoute, Router } from '@angular/router';
import { LayoutUtilsService } from '../../../../core/_base/crud/utils/layout-utils.service';

@Component({
  selector: 'kt-enquiry-reviewmode',
  templateUrl: './enquiry-reviewmode.component.html',
  styleUrls: ['./enquiry-reviewmode.component.scss']
})
export class EnquiryReviewmodeComponent implements OnInit {
  panelOpenState = false;
  leadId = '';
  getLeadData: any = {};
  getContactOrAccount: any = {};
  leadObject: any = {};
  getEmpAllocation: any = [];
  hasLoaded = false;
  loginEmployee: any;

  popCheck = false;
  testDrive = '';
  homeVisit = '';
  evaluation = '';
  isTestDrive = false;
  isHomeVisit = false;
  isEvaluation = false;

  constructor(private enquiryservice: EnquiryService,
    private layoutUtilsService: LayoutUtilsService,
    private myroleService: MyRolesService,
    private lead360Service: Lead360Service,
    private routeData: ActivatedRoute,
    private router: Router,
    private changeDetectorRef: ChangeDetectorRef) {
    this.leadId = this.routeData.snapshot.paramMap.get('leadId');
    this.getLeadByUniversalID();
  }

  ngOnInit() {
    this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
  }

  // Get Lead By Universal ID
  getLeadByUniversalID() {
    this.enquiryservice.getLeadByUniversalID(this.leadId).subscribe(res => {
      this.leadObject = res.dmsEntity;
      delete this.leadObject.dmsEmployeeAllocationDtos;
      this.getContactOrAccount = res.dmsEntity.dmsContactDto ? res.dmsEntity.dmsContactDto : res.dmsEntity.dmsAccountDto;
      this.getLeadData = res.dmsEntity.dmsLeadDto;
      this.getEmpAllocation = res.dmsEntity.dmsEmployeeAllocationDtos;
      this.hasLoaded = true;
      this.changeDetectorRef.detectChanges();

      if (this.getLeadData.leadStatus === 'ENQUIRYCOMPLETED') {
        // Lead360 Tasks
        this.myroleService.getAllTasksUniversalID(this.getLeadData.crmUniversalId, 'Enquiry').subscribe(taskRes => {
          taskRes.dmsEntity.tasks.forEach((element) => {
            if (element.taskName === 'Test Drive' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')) {
              this.testDrive = 'Test Drive : Pending';
              this.isTestDrive = true;
            }
            if (element.taskName === 'Home Visit' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')) {
              this.homeVisit = 'Home Visit : Pending';
              this.isHomeVisit = true;
            }
            if (element.taskName === 'Evaluation' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')
              && this.getLeadData.buyerType === 'Replacement Buyer') {
              this.evaluation = 'Evaluation : Pending';
              this.isEvaluation = true;
            }

            if (element.universalId === this.leadId && element.taskName === 'Proceed to Pre Booking'
              && element.assignee.empId === this.loginEmployee.empId) {
              this.lead360Service.selectedTaskObj = element;
              // this.router.navigate(['/lead360']);
              this.popCheck = true;
              return;
            }
          });
        });
      }
    });
  }

  goBack() {
    this.router.navigate(['/ems/enquiry']);
  }

  proceedToEdit() {
    this.router.navigate(['/ems/enquiry/emsform', this.leadId]);
  }

  dropEnquiry() {
    if (this.leadObject.dmsContactDto) {
      this.leadObject.dmsContactDto.status = 'DROPPED';
    } else {
      this.leadObject.dmsAccountDto.status = 'DROPPED';
    }
    this.leadObject.dmsLeadDto.leadStage = 'DROPPED';
    this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
      this.goBack();
    });
  }

  proceedPreBooking() {
    if (this.testDrive || this.homeVisit || this.evaluation) {
      this.pendingTasksStatus();
    } else {
      if (!this.popCheck) {
        this.updateStatusMessage();
      } else {
        this.router.navigate(['/lead360']);
        this.popCheck = false;
      }
    }
  }

  // Pop-Up To Show Pending Tasks
  pendingTasksStatus() {
    let _title = '';
    _title = 'Pending Tasks';
    const _description = [this.testDrive, this.homeVisit, this.evaluation];
    const dialogRef = this.layoutUtilsService.taskRoute(_title, _description);
    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      this.isTestDrive = false;
      this.isHomeVisit = false;
      this.isEvaluation = false;
      this.testDrive = '';
      this.homeVisit = '';
      this.evaluation = '';
      if (!this.popCheck) {
        this.updateStatusMessage();
      } else {
        this.router.navigate(['/lead360']);
        this.popCheck = false;
      }
    });
  }

  // Pop-Up after Enquiry Submission
  updateStatusMessage() {
    let _title = '';
    _title = '';
    const _description = `Permission Denied`;
    const dialogRef = this.layoutUtilsService.updateRoute(_title, _description);
    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      this.goBack();
      this.popCheck = false;
    });
  }
}
