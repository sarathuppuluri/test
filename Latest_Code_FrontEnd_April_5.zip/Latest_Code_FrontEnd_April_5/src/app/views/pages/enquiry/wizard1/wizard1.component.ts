import { Component, ElementRef, OnInit, OnDestroy, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgControlStatus } from '@angular/forms';
import { EnquiryService, SharedService, MyRolesService, Lead360Service } from './../../../../core/e-commerce/_services';
import { ActivatedRoute, Router } from '@angular/router';
import { LayoutUtilsService } from '../../../../core/_base/crud/utils/layout-utils.service';
import { Brands } from '../../../../core/e-commerce/_models/vehiclesData.model';
import { Subject, Subscription } from 'rxjs';
import { switchMap, takeUntil } from 'rxjs/operators';

@Component({
	selector: 'kt-wizard1',
	templateUrl: './wizard1.component.html',
	styleUrls: ['./wizard1.component.scss']
})

export class Wizard1Component implements OnInit, OnDestroy {
	brands = Brands;

	startDate;
	message: any;
	onRoadPrice: any;
	loginEmployee: any;
	dropClicked = false;
	dropLeadDetails: any = { dmsLeadDropInfo: {} };
	ocrMsg: string;

	// Subscriptions
	private subscriptions: Subscription[] = [];

	private unsubscribe = new Subject<void>();

	constructor(private fb: FormBuilder,
		private enquiryservice: EnquiryService,
		private myroleService: MyRolesService,
		private lead360Service: Lead360Service,
		private routeData: ActivatedRoute,
		private layoutUtilsService: LayoutUtilsService,
		private sharedService: SharedService,
		private router: Router,
		private changedetectorref: ChangeDetectorRef) {
		this.leadId = this.routeData.snapshot.paramMap.get('leadId');
		this.startDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
	}

	tempvalue;
	_subscription;

	EnquiryEditForm: FormGroup;
	EnquiryEditForm2: FormGroup;
	EnquiryEditForm21: FormGroup;
	EnquiryEditForm3: FormGroup;
	EnquiryEditForm4: FormGroup;
	EnquiryEditForm5: FormGroup;
	EnquiryEditForm6: FormGroup;
	EnquiryEditForm7: FormGroup;
	DropEnquiryForm: FormGroup;
	hasFormErrors = false;

	submitted = false;
	leadId = '';
	localUrl = [];

	vechilesData = [];
	vechileModelsList = [];
	variantsList = [];
	colorsList = [];
	fuelTypeList = [];
	variantRecord = [];

	customerTypeDropDown = [];
	showImageCheck = true;
	hasSubmitted = false;
	endAutoSave = false;
	statusShow = false;

	second = 1000;
	minute = this.second * 60;
	hour = this.minute * 60;
	day = this.hour * 24;
	month = this.day * 30;
	year = this.day * 365;

	leadObject: any = {};

	documentsObject = [];
	// Lead Attachments Object
	tempObjDoc = {
		branchId: '',
		contentSize: 0,
		createdBy: Date.now(),
		description: '',
		documentNumber: '',
		documentPath: '',
		documentType: '',
		documentVersion: 0,
		fileName: '',
		gstNumber: '',
		id: 0,
		isActive: 0,
		isPrivate: 0,
		keyName: '',
		modifiedBy: '',
		orgId: '',
		ownerId: '',
		ownerName: '',
		parentId: '',
		tinNumber: ''
	};

	previewURL = [];
	docKeyNames = [];

	previewURLBuyer = [];
	customerDocuments = [];
	regNoDocumentPath = '';
	regNokeyName = '';
	insuranceDocumentPath = '';
	insuranceDocumentKeyName = '';


	imageUrl;

	modelList = [];

	docsPath: any = {};

	popCheck = false;
	testDrive = '';
	homeVisit = '';
	evaluation = '';
	isTestDrive = false;
	isHomeVisit = false;
	isEvaluation = false;

	ngOnInit() {
		this.endAutoSave = false;
		this.statusShow = false;
		this.enquiryForm();
		this.getVechilesDetails();
		this.getLeadDetailsUniversalId();
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
	}

	ngOnDestroy(): void {
		// Called once, before the instance is destroyed.
		// Add 'implements OnDestroy' to the class.
		this.endAutoSave = true;
		this.statusShow = false;
		this.subscriptions.forEach(el => el.unsubscribe());
		this.unsubscribe.next();
	}

	changeInitialValues() {
		if (this.leadObject.dmsLeadDto.enquirySegment === 'Personal') {
			this.customerTypeDropDown = this.sharedService.customerTypeDropDownOne;
		} else if (this.leadObject.dmsLeadDto.enquirySegment === 'Commercial') {
			this.customerTypeDropDown = this.sharedService.customerTypeDropDownTwo;
		} else if (this.leadObject.dmsLeadDto.enquirySegment === 'Company') {
			this.customerTypeDropDown = this.sharedService.customerTypeDropDownThree;
		}
		this.changedetectorref.detectChanges();
	}

	changeCustomerTypeValues() {
		if (this.EnquiryEditForm.controls.enquirySegment.value === 'Personal') {
			this.customerTypeDropDown = this.sharedService.customerTypeDropDownOne;
		} else if (this.EnquiryEditForm.controls.enquirySegment.value === 'Commercial') {
			this.customerTypeDropDown = this.sharedService.customerTypeDropDownTwo;
		} else if (this.EnquiryEditForm.controls.enquirySegment.value === 'Company') {
			this.customerTypeDropDown = this.sharedService.customerTypeDropDownThree;
		}
	}

	assignAddress(event) {
		if (this.EnquiryEditForm2.controls.sameAsCommunicationAddress.value === true) {
			this.EnquiryEditForm21.patchValue(this.EnquiryEditForm2.value);
		}
	}

	enquiryForm() {
		this.EnquiryEditForm = this.fb.group({
			salutation: ['', Validators.required],
			firstName: [{ value: '', disabled: true }],
			lastName: [{ value: '', disabled: true }],
			gender: ['', Validators.required],
			relation: [''],
			relationName: [''],
			dateOfBirth: [''],
			age: ['', Validators.required],
			anniversaryDate: [''],
			phone: [{ value: '', disabled: true }],
			secondaryPhone: [''],
			email: [''],

			occupation: [''],
			designation: [''],
			enquirySegment: [{ value: '', disabled: true }],
			customerType: [{ value: '', disabled: true }],
			company: [''],
			sourceOfEnquiry: [{ value: '', disabled: true }],
			subSource: [''],
			eventCode: [''],
			referedByFirstname: [''],
			referedByLastname: [''],
			refferedMobileNo: [''],
			refferedSource: [''],
			reffered_Sourcelocation: [''],
			expected_delivery_date: ['', Validators.required],
			enquiryCategory: [''],
			buyerType: ['', Validators.required],
			kmsTravelledInMonth: [''],
			whoDrives: [''],
			membersInFamily: [''],
			primeExpectationFromCar: ['']
		});

		this.EnquiryEditForm2 = this.fb.group({
			pincode: ['', Validators.required],
			houseNo: ['', Validators.required],
			street: ['', Validators.required],
			address: [''],
			village: ['', Validators.required],
			city: ['', Validators.required],
			district: ['', Validators.required],
			state: ['', Validators.required],
			urban: [''],
			sameAsCommunicationAddress: ['']
		});

		this.EnquiryEditForm21 = this.fb.group({
			pincode: ['', Validators.required],
			houseNo: ['', Validators.required],
			street: ['', Validators.required],
			address: [''],
			village: ['', Validators.required],
			city: ['', Validators.required],
			district: ['', Validators.required],
			state: ['', Validators.required],
			urban: ['']
		});

		this.EnquiryEditForm3 = this.fb.group({
			pan: [''],
			panFileName: [''],
			aadhar: [''],
			aadharFileName: [''],
			imaCertificate: [''],
			imaCertificateFileName: [''],
			employeeId: [''],
			employeeIdFileName: [''],
			payslips: [''],
			payslipsFileName: [''],
			pattaPassBook: [''],
			pattaPassBookFileName: [''],
			pensionLetter: [''],
			pensionLetterFileName: [''],
			leasingConfirmationLetter: [''],
			leasingConfirmationLetterFileName: [''],
			addressProof: [''],
			addressProofFileName: [''],
			gstNumber: ['']
		});

		this.EnquiryEditForm4 = this.fb.group({
			model: ['', Validators.required],
			variant: ['', Validators.required],
			color: ['', Validators.required],
			fuel: ['', Validators.required],
			transimmisionType: ['', Validators.required]
		});

		this.EnquiryEditForm5 = this.fb.group({
			regNum: ['', this.requiredIfValidator(() => this.EnquiryEditForm.get('buyerType').value === 'Replacement Buyer')],
			regNoFileName: [''],
			regNoD: [''],
			brand: [''],
			otherMake: [''],
			model: [''],
			otherModel: [''],
			varient: [''],
			color: [''],
			fuelType: [''],
			transmission: [''],
			yearofManufacture: [''],
			kiloMeters: [''],
			hypothicationRequirement: [''],
			hypothication: [''],
			hypothicationBranch: [''],
			expectedPrice: [''],
			registrationDate: [''],
			registrationValidityDate: [''],
			insuranceAvailable: [''],
			insuranceDocumentAvailable: [''],
			insuranceFileName: [''],
			insurance: [''],
			insuranceType: [''],
			insuranceFromDate: [''],
			insuranceToDate: [''],
			insuranceCompanyName: ['']
		});

		this.EnquiryEditForm6 = this.fb.group({
			financeType: ['', Validators.required],
			financeCategory: [''],
			downPayment: [''],
			loanAmount: [''],
			financeCompany: [''],
			expectedTenureYears: [''],
			annualIncome: [''],
			location: [''],
			rateOfInterest: [''],
			emi: ['']
		});

		this.EnquiryEditForm7 = this.fb.group({
			lookingForAnyOtherBrand: [''],
			brand: [''],
			otherMake: [''],
			model: [''],
			otherModel: [''],
			variant: [''],
			color: [''],
			fuel: [''],
			transmissionType: [''],
			priceRange: [''],
			onRoadPriceanyDifference: [''],
			dealershipName: [''],
			dealershipLocation: [''],
			decisionPendingReason: [''],
			customerFrom: [''],
			village: [''],
			hamlet: [''],
			mandal: [''],
			mandalHq: [''],
			town: [''],
			dist: [''],
			distHq: [''],
			voiceofCustomerRemarks: ['']
		});

		this.DropEnquiryForm = this.fb.group({
			dropReason: [''],
			dealerName: [''],
			brandName: [''],
			otherReason: [''],
			additionalRemarks: [''],
			location: [''],
			model: ['']
		});
	}

	autoSave(form) {
		form.valueChanges.pipe(
			switchMap(async () => this.updateLeadDetails(this.EnquiryEditForm.value)),
			takeUntil(this.unsubscribe)
		).subscribe(() => {});
	}

	ageCal() {
		const millisecondsDiff = (Date.now() - Date.parse(this.EnquiryEditForm.controls.dateOfBirth.value));
		const age = Math.round(millisecondsDiff / this.year);
		this.EnquiryEditForm.patchValue({ age });
	}

	enquiryCategoryCal() {
		const millisecondsDiff = (Date.parse(this.EnquiryEditForm.controls.expected_delivery_date.value) - Date.now());
		const days = Math.round(millisecondsDiff / this.day);
		if (days <= 5 && days >= 0) {
			this.EnquiryEditForm.patchValue({ enquiryCategory: 'Hot' });
		} else if (days <= 10 && days > 5) {
			this.EnquiryEditForm.patchValue({ enquiryCategory: 'Warm' });
		} else if (days > 10) {
			this.EnquiryEditForm.patchValue({ enquiryCategory: 'Cold' });
		}
	}

	/**
	* Checking control validation
	*
	* @param controlName: string => Equals to formControlName
	* @param validationType: string => Equals to valitors name
	*/
	isControlHasError(controlName: string, validationType: string, formName): boolean {
		const control = this[formName].controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}

	/**
	 * Conditional Check Validator. Check the required only if a value is selected
	 */
	requiredIfValidator(predicate) {
		return (formControl => {
			if (!formControl.parent) {
				return null;
			}
			if (predicate()) {
				return Validators.required(formControl);
			}
			return null;
		});
	}

	mobileNumberKeyPress(event: any) {
		const pattern = /[0-9]/;
		// const pattern = /[0-9\+\-\ ]/;
		// const pattern = "^((\\+91-?)|0)?[0-9]{10}$";

		const inputChar = String.fromCharCode(event.charCode);
		if (event.keyCode != 8 && !pattern.test(inputChar)) {
			event.preventDefault();
		}
	}

	onSubmit() {
		this.hasSubmitted = true;
		this.hasFormErrors = false;
		this.endAutoSave = true;
		this.statusShow = true;
		this.updateLeadDetails(this.EnquiryEditForm.value);
	}

	// Get Lead Details By UniversalID
	getLeadDetailsUniversalId() {
		const getLeadUniversalId = this.enquiryservice.getLeadByUniversalID(this.leadId).subscribe(res => {
			if (!res) {
				return;
			}
			delete res.dmsEntity.dmsEmployeeAllocationDtos;
			this.leadObject = res.dmsEntity;
			this.changeInitialValues();
			this.EnquiryEditForm.patchValue(this.leadObject.dmsContactDto ? this.leadObject.dmsContactDto : this.leadObject.dmsAccountDto);
			this.EnquiryEditForm.patchValue({
				dateOfBirth: (new Date(this.leadObject.dmsContactDto ? this.leadObject.dmsContactDto.dateOfBirth : this.leadObject.dmsAccountDto.dateOfBirth)).toISOString(),
				anniversaryDate: (new Date(this.leadObject.dmsContactDto ? this.leadObject.dmsContactDto.anniversaryDate : this.leadObject.dmsAccountDto.anniversaryDate)).toISOString(),
				expected_delivery_date: (new Date(this.leadObject.dmsLeadDto.dmsExpectedDeliveryDate ? this.leadObject.dmsLeadDto.dmsExpectedDeliveryDate : null)).toISOString()
			});
			this.EnquiryEditForm.patchValue(this.leadObject.dmsLeadDto);
			this.EnquiryEditForm.patchValue({ sourceOfEnquiry: this.leadObject.dmsLeadDto.enquirySource });
			// this.changeCustomerTypeValues();
			this.EnquiryEditForm4.patchValue({
				model: this.leadObject.dmsLeadDto.model
			});

			if (this.leadObject.dmsLeadDto.dmsAddresses.length > 0) {
				this.EnquiryEditForm2.patchValue(this.leadObject.dmsLeadDto.dmsAddresses[0]);
				this.pincodeSearch(this.leadObject.dmsLeadDto.dmsAddresses[0].pincode, this.EnquiryEditForm2);
			}
			if (this.leadObject.dmsLeadDto.dmsAddresses.length > 1) {
				this.EnquiryEditForm21.patchValue(this.leadObject.dmsLeadDto.dmsAddresses[1]);
				this.pincodeSearch(this.leadObject.dmsLeadDto.dmsAddresses[0].pincode, this.EnquiryEditForm21);
			}

			if (this.leadObject.dmsLeadDto.dmsAttachments.length > 0) {
				this.documentsObject = this.leadObject.dmsLeadDto.dmsAttachments;
				const customerDocs = this.leadObject.dmsLeadDto.dmsAttachments.reduce((acc, record) => {
					acc[record.documentType] = (record.documentNumber === '' ? record.fileName : record.documentNumber);
					acc[record.documentType + 'doc'] = record.documentPath;
					acc[record.documentType + 'key'] = record.keyName;
					return acc;
				}, {});
				const test = {
					panFileName: customerDocs.pan,
					aadharFileName: customerDocs.aadhar,
					imaCertificateFileName: customerDocs.imaCertificate,
					employeeIdFileName: customerDocs.employeeId,
					payslipsFileName: customerDocs.payslips,
					pattaPassBookFileName: customerDocs.pattaPassBook,
					addressProofFileName: customerDocs.addressProof,
					pensionLetterFileName: customerDocs.pensionLetter,
					leasingConfirmationLetterFileName: customerDocs.leasingConfirmationLetter,
					gstNumber: customerDocs.gstNumber
					// 'tinNumber': customerDocs.tinNumber
				};
				this.docsPath = {
					panDocPath: customerDocs.pandoc,
					panKey: customerDocs.pankey,
					aadharDocPath: customerDocs.aadhardoc,
					aadharKey: customerDocs.aadharkey,
					imaCertificateDocPath: customerDocs.imaCertificatedoc,
					imaCertificateKey: customerDocs.imaCertificatekey,
					employeeIdDocPath: customerDocs.employeeIddoc,
					employeeIdKey: customerDocs.employeeIdkey,
					payslipsDocPath: customerDocs.payslipsdoc,
					payslipsKey: customerDocs.payslipskey,
					pattaPassBookDocPath: customerDocs.pattaPassBookdoc,
					pattaPassBookKey: customerDocs.pattaPassBookkey,
					addressProofDocPath: customerDocs.addressProofdoc,
					addressProofKey: customerDocs.addressProofkey,
					pensionLetterDocPath: customerDocs.pensionLetterdoc,
					pensionLetterKey: customerDocs.pensionLetterkey,
					leasingConfirmationLetterDocPath: customerDocs.leasingConfirmationLetterdoc,
					leasingConfirmationLetterKey: customerDocs.leasingConfirmationLetterkey
				}
				this.previewURL[1] = this.docsPath.panDocPath;
				this.previewURL[2] = this.docsPath.aadharDocPath;
				this.previewURL[3] = this.docsPath.imaCertificateDocPath;
				this.previewURL[4] = this.docsPath.employeeIdDocPath;
				this.previewURL[5] = this.docsPath.payslipsDocPath;
				this.previewURL[6] = this.docsPath.pattaPassBookDocPath;
				this.previewURL[7] = this.docsPath.pensionLetterDocPath;
				this.previewURL[8] = this.docsPath.leasingConfirmationLetterDocPath;
				this.previewURL[9] = this.docsPath.addressProofDocPath;
				this.EnquiryEditForm3.patchValue(test);
			}

			if (this.leadObject.dmsLeadDto.dmsLeadProducts.length > 0) {
				this.EnquiryEditForm4.patchValue({
					model: (this.leadObject.dmsLeadDto.dmsLeadProducts[0].model !== null) ? this.leadObject.dmsLeadDto.dmsLeadProducts[0].model : this.leadObject.dmsLeadDto.model,
					variant: this.leadObject.dmsLeadDto.dmsLeadProducts[0].variant,
					color: this.leadObject.dmsLeadDto.dmsLeadProducts[0].color,
					fuel: this.leadObject.dmsLeadDto.dmsLeadProducts[0].fuel,
					transimmisionType: this.leadObject.dmsLeadDto.dmsLeadProducts[0].transimmisionType
				});
			}
			if (this.leadObject.dmsLeadDto.dmsExchagedetails.length > 0) {
				this.EnquiryEditForm5.patchValue(this.leadObject.dmsLeadDto.dmsExchagedetails[0]);
				this.changeModel();
				const url = this.leadObject.dmsLeadDto.dmsExchagedetails[0].insuranceDocumentKey;
				const urlRegNo = this.leadObject.dmsLeadDto.dmsExchagedetails[0].regDocumentKey;
				this.EnquiryEditForm5.patchValue({
					regNum: this.leadObject.dmsLeadDto.dmsExchagedetails[0].regNo,
					regNoFileName: urlRegNo === null ? null : url.split('/').pop(),
					insuranceFileName: url === null ? null : url.split('/').pop()
				});
				this.insuranceDocumentPath = this.leadObject.dmsLeadDto.dmsExchagedetails[0].insuranceDocumentPath;
				this.insuranceDocumentKeyName = this.leadObject.dmsLeadDto.dmsExchagedetails[0].insuranceDocumentKey;
				this.regNoDocumentPath = this.leadObject.dmsLeadDto.dmsExchagedetails[0].regDocumentPath;
				this.regNokeyName = this.leadObject.dmsLeadDto.dmsExchagedetails[0].regDocumentKey;
				this.previewURLBuyer[1] = this.regNoDocumentPath;
				this.previewURLBuyer[2] = this.insuranceDocumentPath;
			}
			if (this.leadObject.dmsLeadDto.dmsfinancedetails.length > 0) {
				this.EnquiryEditForm6.patchValue(this.leadObject.dmsLeadDto.dmsfinancedetails[0]);
			}
			if (this.leadObject.dmsLeadDto.dmsLeadScoreCards.length > 0) {
				this.EnquiryEditForm7.patchValue(this.leadObject.dmsLeadDto.dmsLeadScoreCards[0]);
				this.changeModelAnalysis();
			}

			if (this.leadObject.dmsLeadDto.leadStatus === 'ENQUIRYCOMPLETED') {
				// Lead360 Tasks
				const allTasks = this.myroleService.getAllTasksUniversalID(this.leadObject.dmsLeadDto.crmUniversalId, 'Enquiry').subscribe(taskRes => {
					taskRes.dmsEntity.tasks.forEach((element) => {
						if (element.taskName === 'Test Drive' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')) {
							this.testDrive = 'Test Drive : Pending';
							this.isTestDrive = true;
						}
						if (element.taskName === 'Home Visit' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')) {
							this.homeVisit = 'Home Visit : Pending';
							this.isHomeVisit = true;
						}
						if (element.taskName === 'Evaluation' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')
							&& this.leadObject.dmsLeadDto.buyerType === 'Replacement Buyer') {
							this.evaluation = 'Evaluation : Pending';
							this.isEvaluation = true;
						}

						if (element.universalId === this.leadId && element.taskName === 'Proceed to Pre Booking'
							&& element.assignee.empId === this.loginEmployee.empId) {
							this.lead360Service.selectedTaskObj = element;
							// this.router.navigate(['/lead360']);
							this.popCheck = true;
							return;
						}
					});
				});
				this.subscriptions.push(allTasks);
			}

			this.autoSave(this.EnquiryEditForm);
			this.autoSave(this.EnquiryEditForm2);
			this.autoSave(this.EnquiryEditForm21);
			this.autoSave(this.EnquiryEditForm3);
			this.autoSave(this.EnquiryEditForm4);
			this.autoSave(this.EnquiryEditForm5);
			this.autoSave(this.EnquiryEditForm6);
			this.autoSave(this.EnquiryEditForm7);
		});
		this.subscriptions.push(getLeadUniversalId);
	}

	// Post Lead Details
	updateLeadDetails(controls) {
		if (this.endAutoSave) {
			const tempArray = [
				this.EnquiryEditForm.controls,
				this.EnquiryEditForm2.controls,
				this.EnquiryEditForm21.controls,
				this.EnquiryEditForm3.controls,
				this.EnquiryEditForm4.controls,
				this.EnquiryEditForm5.controls,
				this.EnquiryEditForm6.controls,
				this.EnquiryEditForm7.controls
			]
			/** check form */
			if (this.EnquiryEditForm.invalid) {
				Object.keys(tempArray[0]).forEach(controlName =>
					tempArray[0][controlName].markAsTouched()
				);

				this.hasFormErrors = true;
				this.hasSubmitted = false;
				return;
			} else if (this.EnquiryEditForm2.invalid) {
				Object.keys(tempArray[1]).forEach(controlName =>
					tempArray[1][controlName].markAsTouched()
				);

				this.hasFormErrors = true;
				this.hasSubmitted = false;
				return;
			} else if (this.EnquiryEditForm21.invalid) {
				Object.keys(tempArray[2]).forEach(controlName =>
					tempArray[2][controlName].markAsTouched()
				);

				this.hasFormErrors = true;
				this.hasSubmitted = false;
				return;
			} else if (this.EnquiryEditForm3.invalid) {
				Object.keys(tempArray[3]).forEach(controlName =>
					tempArray[3][controlName].markAsTouched()
				);

				this.hasFormErrors = true;
				this.hasSubmitted = false;
				return;
			} else if (this.EnquiryEditForm4.invalid) {
				Object.keys(tempArray[4]).forEach(controlName =>
					tempArray[4][controlName].markAsTouched()
				);

				this.hasFormErrors = true;
				this.hasSubmitted = false;
				return;
			} else if (this.EnquiryEditForm5.invalid) {
				Object.keys(tempArray[5]).forEach(controlName =>
					tempArray[5][controlName].markAsTouched()
				);

				this.hasFormErrors = true;
				this.hasSubmitted = false;
				return;
			} else if (this.EnquiryEditForm6.invalid) {
				Object.keys(tempArray[6]).forEach(controlName =>
					tempArray[6][controlName].markAsTouched()
				);

				this.hasFormErrors = true;
				this.hasSubmitted = false;
				return;
			} else if (this.EnquiryEditForm7.invalid) {
				Object.keys(tempArray[7]).forEach(controlName =>
					tempArray[7][controlName].markAsTouched()
				);

				this.hasFormErrors = true;
				this.hasSubmitted = false;
				return;
			}
		}

		if (this.leadObject.dmsContactDto) {
			this.leadObject.dmsContactDto.salutation = controls.salutation;
			this.leadObject.dmsContactDto.gender = controls.gender;
			this.leadObject.dmsContactDto.relation = controls.relation;
			this.leadObject.dmsContactDto.relationName = controls.relationName;
			this.leadObject.dmsContactDto.dateOfBirth = Date.parse(controls.dateOfBirth);
			this.leadObject.dmsContactDto.age = controls.age;
			this.leadObject.dmsContactDto.occupation = controls.occupation;
			this.leadObject.dmsContactDto.designation = controls.designation;
			this.leadObject.dmsContactDto.anniversaryDate = Date.parse(controls.anniversaryDate);
			this.leadObject.dmsContactDto.company = controls.company;
			this.leadObject.dmsContactDto.referedByFirstname = controls.referedByFirstname;
			this.leadObject.dmsContactDto.referedByLastname = controls.referedByLastname;
			this.leadObject.dmsContactDto.refferedMobileNo = controls.refferedMobileNo;
			this.leadObject.dmsContactDto.refferedSource = controls.refferedSource;
			this.leadObject.dmsContactDto.reffered_Sourcelocation = controls.reffered_Sourcelocation;
			this.leadObject.dmsContactDto.kmsTravelledInMonth = controls.kmsTravelledInMonth;
			this.leadObject.dmsContactDto.whoDrives = controls.whoDrives;
			this.leadObject.dmsContactDto.membersInFamily = controls.membersInFamily;
			this.leadObject.dmsContactDto.primeExpectationFromCar = controls.primeExpectationFromCar;
		} else {
			this.leadObject.dmsAccountDto.salutation = controls.salutation;
			this.leadObject.dmsAccountDto.gender = controls.gender;
			this.leadObject.dmsAccountDto.relation = controls.relation;
			this.leadObject.dmsAccountDto.relationName = controls.relationName;
			this.leadObject.dmsAccountDto.dateOfBirth = Date.parse(controls.dateOfBirth);
			this.leadObject.dmsAccountDto.age = controls.age;
			this.leadObject.dmsAccountDto.occupation = controls.occupation;
			this.leadObject.dmsAccountDto.designation = controls.designation;
			this.leadObject.dmsAccountDto.anniversaryDate = Date.parse(controls.anniversaryDate);
			this.leadObject.dmsAccountDto.company = controls.company;

			this.leadObject.dmsAccountDto.referedByFirstname = controls.referedByFirstname;
			this.leadObject.dmsAccountDto.referedByLastname = controls.referedByLastname;
			this.leadObject.dmsAccountDto.refferedMobileNo = controls.refferedMobileNo;
			this.leadObject.dmsAccountDto.refferedSource = controls.refferedSource;
			this.leadObject.dmsAccountDto.reffered_Sourcelocation = controls.reffered_Sourcelocation;
			this.leadObject.dmsAccountDto.kmsTravelledInMonth = controls.kmsTravelledInMonth;
			this.leadObject.dmsAccountDto.whoDrives = controls.whoDrives;
			this.leadObject.dmsAccountDto.membersInFamily = controls.membersInFamily;
			this.leadObject.dmsAccountDto.primeExpectationFromCar = controls.primeExpectationFromCar;
		}

		this.leadObject.dmsLeadDto.buyerType = controls.buyerType;
		this.leadObject.dmsLeadDto.dmsExpectedDeliveryDate = Date.parse(controls.expected_delivery_date);
		this.leadObject.dmsLeadDto.enquiryCategory = controls.enquiryCategory;
		this.leadObject.dmsLeadDto.subSource = controls.subSource;
		this.leadObject.dmsLeadDto.eventCode = controls.eventCode;
		this.leadObject.dmsLeadDto.dmsAddresses = this.sendCommunicationDetails(this.EnquiryEditForm2.value, this.EnquiryEditForm21.value);
		this.leadObject.dmsLeadDto.dmsLeadProducts = this.sendModelSelection(this.EnquiryEditForm4.value);
		if (this.EnquiryEditForm.controls.buyerType.value === 'Replacement Buyer' || this.EnquiryEditForm.controls.buyerType.value === 'Additional Buyer') {
			this.leadObject.dmsLeadDto.dmsExchagedetails = this.sendBuyerDetails(this.EnquiryEditForm5.value);
		}
		this.leadObject.dmsLeadDto.dmsfinancedetails = this.sendFinanceDetails(this.EnquiryEditForm6.value);
		this.leadObject.dmsLeadDto.dmsLeadScoreCards = this.sendScoreCardDetails(this.EnquiryEditForm7.value);
		if (this.endAutoSave) {
			this.leadObject.dmsLeadDto.dmsAttachments = this.documentsObject;
		}

		const sendEnq = this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
			if (res.statusCode !== 500) {
				this.message = '';
				this.leadObject = res.dmsEntity;
				this.documentsObject = this.leadObject.dmsLeadDto.dmsAttachments;
				this.hasSubmitted = false;
				if (this.endAutoSave) {

					this.leadObject.dmsLeadDto.leadStatus = 'ENQUIRYCOMPLETED';
					const sendEnqDet = this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
					});
					this.subscriptions.push(sendEnqDet);
					if (this.statusShow) {
						this.updateStatusMessage('Enquiry Updated Successfully');
					}
				} else {
				}
				this.changedetectorref.detectChanges();
			} else {
				this.hasSubmitted = false;
				this.message = res.message;
				this.gotoTop();
				this.changedetectorref.detectChanges();
			}
		});
		this.subscriptions.push(sendEnq);
	}

	// Get OnRoad Price Details
	onRoadPriceDetails() {
		const onRoadPriceDet = this.enquiryservice.getOnRoadPriceDetails(this.variantRecord[0].id, this.loginEmployee.orgId).subscribe(res => {
			this.onRoadPrice = res;
			this.changedetectorref.detectChanges();
		});
		this.subscriptions.push(onRoadPriceDet);
	}

	// Loan Amount Calculator
	loanAmountCal() {
		this.EnquiryEditForm6.patchValue({ loanAmount: Math.round(this.onRoadPrice.ex_showroom_price - this.EnquiryEditForm6.value.downPayment) });
		this.emiCal(this.EnquiryEditForm6.value.loanAmount, this.EnquiryEditForm6.value.expectedTenureYears, this.EnquiryEditForm6.value.rateOfInterest);
	}

	// EMI Calculation
	emiCal(principle, tenure, interestRate) {
		if (principle !== '' && tenure !== '' && interestRate !== '') {
			let P = principle;
			const R = interestRate;
			const N = tenure;
			const monthlyInterstRatio = (R / 100) / 12;
			const top = Math.pow((1 + monthlyInterstRatio), N);
			const bottom = top - 1;
			const sp = top / bottom;
			const emi = ((P * monthlyInterstRatio) * sp);
			const full = N * emi;
			const interest = full - P;
			let int_pge = (interest / full) * 100;
			this.EnquiryEditForm6.patchValue({ emi: Math.round(emi) });
		}
	}

	// Lead Address Object
	sendCommunicationDetails(controls1, controls2) {
		const comData = [
			{
				addressType: 'Communication',
				houseNo: controls1.houseNo,
				// address: controls1.address,
				street: controls1.street,
				city: controls1.city,
				district: controls1.district,
				pincode: controls1.pincode,
				state: controls1.state,
				village: controls1.village,
				county: 'India',
				rural: (controls1.urban === 'rural') ? true : false,
				urban: (controls1.urban === 'urban') ? true : false,
				id: this.leadObject.dmsLeadDto.dmsAddresses[0] ? this.leadObject.dmsLeadDto.dmsAddresses[0].id : 0
			},
			{
				addressType: 'Permanent',
				houseNo: controls2.houseNo,
				// address: controls2.address,
				street: controls2.street,
				city: controls2.city,
				district: controls2.district,
				pincode: controls2.pincode,
				state: controls2.state,
				village: controls2.village,
				county: 'India',
				rural: (controls2.urban === 'rural') ? true : false,
				urban: (controls2.urban === 'urban') ? true : false,
				id: this.leadObject.dmsLeadDto.dmsAddresses[1] ? this.leadObject.dmsLeadDto.dmsAddresses[1].id : 0
			}
		];

		return comData;
	}

	// Lead Attachments Number Object
	documentNumber(type, docNumber) {
		const index = this.documentsObject.findIndex(element => element.documentType === type);
		if (index !== -1) {
			this.documentsObject[index].documentNumber = docNumber;
		} else {
			this.tempObjDoc.documentNumber = docNumber;
			this.tempObjDoc.documentType = type;
			this.tempObjDoc.id = 0;
			this.tempObjDoc.branchId = this.loginEmployee.branchId;
			this.tempObjDoc.orgId = this.loginEmployee.orgId;
			this.documentsObject.push(this.tempObjDoc);
		}
	}

	/**
	 * File Upload for Lead Attachments
	 */
	onFileSelect(event, docType, formEle, i) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			this.EnquiryEditForm3.get(formEle).setValue(file.name);
			const formData = new FormData();
			formData.append('file', file);
			formData.append('universalId', this.leadId);
			formData.append('documentType', docType);
			const createCustDoc = this.enquiryservice.createCustomerDoc(formData).subscribe(res => {
				const index = this.documentsObject.findIndex(element => element.documentType === docType);
				if (index !== -1) {
					this.documentsObject[index].documentPath = res.documentPath;
					this.documentsObject[index].fileName = res.fileName;
					this.documentsObject[index].keyName = res.keyName;
				} else {
					this.tempObjDoc.documentPath = res.documentPath;
					this.tempObjDoc.documentType = docType;
					this.tempObjDoc.fileName = res.fileName;
					this.tempObjDoc.keyName = res.keyName;
					this.tempObjDoc.id = 0;
					this.tempObjDoc.branchId = this.loginEmployee.branchId;
					this.tempObjDoc.orgId = this.loginEmployee.orgId;
					this.tempObjDoc.modifiedBy = this.loginEmployee.empName;
					this.tempObjDoc.ownerName = this.loginEmployee.empName;
					let tempStuctObj = Object.assign({}, this.tempObjDoc);
					this.documentsObject.push(tempStuctObj);
					tempStuctObj = null;
				}
				this.previewURL[i] = res.documentPath;
				this.docKeyNames[i] = res.keyName;
				this.changedetectorref.detectChanges();
			});
			this.subscriptions.push(createCustDoc);
		}
	}

	// Delete Documents from S3 Bucket
	deleteDocument(docName, formEle, i) {
		if (docName !== undefined) {
			const deleteDoc = this.enquiryservice.deleteDocument(docName).subscribe(res => {
				docName = undefined;
			}, (err) => {
				console.log(err);
				docName = undefined;
			});
			this.subscriptions.push(deleteDoc);
		}
		this.EnquiryEditForm3.get(formEle).reset();
		this.documentsObject.forEach((element, index) => {
			if (element.documentPath.length === this.previewURL[i].length) {
				this.documentsObject.splice(index, 1);
			}
		});
		this.previewURL[i] = null;
	}

	// Lead Products Object
	sendModelSelection(controls) {
		const objData = [
			{
				color: controls.color,
				model: controls.model,
				fuel: controls.fuel,
				transimmisionType: controls.transimmisionType,
				variant: controls.variant,
				id: this.leadObject.dmsLeadDto.dmsLeadProducts[0] ? this.leadObject.dmsLeadDto.dmsLeadProducts[0].id : 0
			}
		];

		return objData;
	}

	// Lead Exchange Details Document Upload
	buyerTypeFileSelect(event, docType, formEle, i) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			this.EnquiryEditForm5.get(formEle).patchValue(file.name);
			const formData = new FormData();
			formData.append('file', file);
			formData.append('universalId', this.leadId);
			formData.append('documentType', docType);
			const createCustDoc = this.enquiryservice.createCustomerDoc(formData).subscribe(res => {
				if (i === 1) {
					this.regNoDocumentPath = res.documentPath;
					this.regNokeyName = res.keyName;
				} else {
					this.insuranceDocumentPath = res.documentPath;
					this.insuranceDocumentKeyName = res.keyName;
				}
				this.previewURLBuyer[i] = res.documentPath;
				this.changedetectorref.detectChanges();
			});
			this.subscriptions.push(createCustDoc);
		}
	}

	// Delete Documents from S3 Bucket
	deleteReplacementDocument(docName, formEle, i) {
		if (docName !== undefined) {
			const deleteDoc = this.enquiryservice.deleteDocument(docName).subscribe(res => {
				docName = undefined;
			}, (err) => {
				console.log(err);
				docName = undefined;
			});
			this.subscriptions.push(deleteDoc);
		}
		this.EnquiryEditForm5.get(formEle).reset();
		if (i === 1) {
			this.regNoDocumentPath = '';;
			this.regNokeyName = '';
		} else if (i === 2) {
			this.insuranceDocumentPath = '';
			this.insuranceDocumentKeyName = '';
		}
		this.previewURLBuyer[i] = null;
	}

	// Lead Exchange Details Object
	sendBuyerDetails(controls) {
		const objData = [
			{
				buyerType: this.EnquiryEditForm.controls.buyerType.value,
				brand: controls.brand,
				varient: controls.varient,
				fuelType: controls.fuelType,
				regNo: controls.regNum,
				kiloMeters: controls.kiloMeters,
				hypothication: controls.hypothication,
				loanAmountDue: controls.loanAmountDue,
				challansPending: controls.challansPending,
				nocClearanceExpenses: controls.nocClearanceExpenses,
				otherExpenses: controls.otherExpenses,
				model: controls.model,
				color: controls.color,
				transmission: controls.transmission,
				yearofManufacture: controls.yearofManufacture,
				insuranceExpiryDate: controls.insuranceExpiryDate,
				hypothicationBranch: controls.hypothicationBranch,
				noofOwners: controls.noofOwners,
				challansAmount: controls.challansAmount,
				ccClearanceExpenses: controls.ccClearanceExpenses,
				hypothicationRequirement: controls.hypothicationRequirement,
				expectedPrice: controls.expectedPrice,
				registrationDate: controls.registrationDate,
				registrationValidityDate: controls.registrationValidityDate,
				insuranceAvailable: controls.insuranceAvailable,
				insuranceDocumentAvailable: controls.insuranceDocumentAvailable,
				insuranceType: controls.insuranceType,
				insuranceFromDate: controls.insuranceFromDate,
				insuranceToDate: controls.insuranceToDate,
				insuranceCompanyName: controls.insuranceCompanyName,
				insuranceDocumentPath: this.insuranceDocumentPath,
				insuranceDocumentKey: this.insuranceDocumentKeyName,
				regDocumentPath: this.regNoDocumentPath,
				regDocumentKey: this.regNokeyName,
				id: this.leadObject.dmsLeadDto.dmsExchagedetails[0] ? this.leadObject.dmsLeadDto.dmsExchagedetails[0].id : 0
			}
		];

		return objData;
	}

	// Lead Finance Details Object
	sendFinanceDetails(controls) {
		const objDataFin = [
			{
				financeType: controls.financeType,
				financeCategory: controls.financeCategory,
				downPayment: controls.downPayment,
				loanAmount: controls.loanAmount,
				financeCompany: controls.financeCompany,
				expectedTenureYears: controls.expectedTenureYears,
				annualIncome: controls.annualIncome,
				location: controls.location,
				rateOfInterest: controls.rateOfInterest,
				emi: controls.emi,
				id: this.leadObject.dmsLeadDto.dmsfinancedetails[0] ? this.leadObject.dmsLeadDto.dmsfinancedetails[0].id : 0
			}
		];

		return objDataFin;
	}

	// Lead Scorecard Details
	sendScoreCardDetails(controls) {
		const scoreBody = [
			{
				lookingForAnyOtherBrand: controls.lookingForAnyOtherBrand,
				brand: controls.brand,
				otherMake: controls.otherMake,
				model: controls.model,
				otherModel: controls.otherModel,
				variant: controls.variant,
				color: controls.color,
				fuel: controls.fuel,
				dealershipName: controls.dealershipName,
				dealershipLocation: controls.dealershipLocation,
				priceRange: controls.priceRange,
				decisionPendingReason: controls.decisionPendingReason,
				onRoadPriceanyDifference: controls.onRoadPriceanyDifference,
				customerFrom: controls.customerFrom,
				village: controls.village,
				hamlet: controls.hamlet,
				mandal: controls.mandal,
				mandalHq: controls.mandalHq,
				town: controls.town,
				dist: controls.dist,
				distHq: controls.distHq,
				voiceofCustomerRemarks: controls.voiceofCustomerRemarks,
				id: this.leadObject.dmsLeadDto.dmsLeadScoreCards[0] ? this.leadObject.dmsLeadDto.dmsLeadScoreCards[0].id : 0
			}
		];

		return scoreBody;
	}

	// Pop-Up after Enquiry Submission
	updateStatusMessage(msg) {
		let _title = /*'Enquiry Updated Successfully';*/ msg;
		const _description = `Enquiry Number: ${this.leadObject.dmsLeadDto.referencenumber}`;
		const dialogRef = this.layoutUtilsService.updateRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.router.navigate(['/ems/enquiry']);
		});
	}

	// pincode search Method for Address
	pincodeSearch(event, form) {
		if (event.length === 6) {
			if (this.EnquiryEditForm2.controls.sameAsCommunicationAddress.value !== true) {
				const locationPincode = this.enquiryservice.getLocationUsingPincode(event).subscribe(res => {
					form.patchValue({
						state: res[0].PostOffice[0].State,
						district: res[0].PostOffice[0].District
					});
				});
				this.subscriptions.push(locationPincode);
			}
		}
	}

	// Change Vechile Model
	changeVechileModel() {
		const selectedModel = this.EnquiryEditForm4.controls.model.value;
		const promise = new Promise((resolve) => {
			if ((selectedModel !== null) && (selectedModel !== 'Select') && (selectedModel !== '')) {
				resolve();
			}
		});

		promise.then(() => {
			let tempData = this.vechilesData.filter(record => record.model === selectedModel)
				.map(obj => {
					return {
						variantsList: obj.varients,
					};
				})[0];
			tempData = tempData;
			this.variantsList = tempData.variantsList || [];
			this.changeVariant();
			this.showImageCheck = true;
		});
	}

	// Image display based on Model
	swapImage() {
		this.showImageCheck = false;
	}

	// Change Variant
	changeVariant() {
		this.variantRecord = [];
		const selectedVariant = this.EnquiryEditForm4.controls.variant.value;
		const promise = new Promise((resolve) => {
			if ((selectedVariant !== null) && (selectedVariant !== 'Select') && (selectedVariant !== '')) {
				this.variantRecord = this.variantsList.filter(record => record.name === selectedVariant);
				resolve();
			}
		});

		promise.then(() => {
			this.showImageCheck = false;
			this.onRoadPriceDetails();
		});
	}

	// Get vechiles Details
	getVechilesDetails() {
		this._subscription = this.sharedService.vechileDetailsChange.subscribe((value) => {
			this.vechilesData = value;
			this.changeVechileModel();
		});
	}

	// Change Model for Brands in Exchange Details
	changeModel() {
		const brand = this.EnquiryEditForm5.controls.brand.value;
		this.modelList = this.brands.filter(record => record.brand === brand).map(obj => {
			return obj.Variant;
		})[0];
	}

	// Change Model for Brands in ScoreCard Details
	changeModelAnalysis() {
		const scoreBrand = this.EnquiryEditForm7.controls.brand.value;
		this.modelList = this.brands.filter(record => record.brand === scoreBrand).map(obj => {
			return obj.Variant;
		})[0];
	}

	goBack() {
		this.router.navigate(['/ems/enquiry']);
	}

	dropEnquiry() {
		this.dropClicked = true;
	}

	// Proceed to Drop
	proceedToCancel() {
		this.dropLeadDetails.dmsLeadDropInfo.additionalRemarks = this.DropEnquiryForm.value.additionalRemarks;
		this.dropLeadDetails.dmsLeadDropInfo.branchId = this.loginEmployee.branchId;
		this.dropLeadDetails.dmsLeadDropInfo.brandName = this.DropEnquiryForm.value.brandName;
		this.dropLeadDetails.dmsLeadDropInfo.dealerName = this.DropEnquiryForm.value.dealerName;
		this.dropLeadDetails.dmsLeadDropInfo.enquiryCategory = this.DropEnquiryForm.value.enquiryCategory;
		this.dropLeadDetails.dmsLeadDropInfo.leadId = this.leadObject.dmsLeadDto.id;
		this.dropLeadDetails.dmsLeadDropInfo.crmUniversalId = this.leadId;
		this.dropLeadDetails.dmsLeadDropInfo.lostReason = this.DropEnquiryForm.value.dropReason;
		this.dropLeadDetails.dmsLeadDropInfo.organizationId = this.loginEmployee.orgId;
		this.dropLeadDetails.dmsLeadDropInfo.otherReason = '';
		this.dropLeadDetails.dmsLeadDropInfo.droppedBy = this.loginEmployee.empId;
		this.dropLeadDetails.dmsLeadDropInfo.location = this.DropEnquiryForm.value.location;
		this.dropLeadDetails.dmsLeadDropInfo.model = this.DropEnquiryForm.value.model;
		this.dropLeadDetails.dmsLeadDropInfo.stage = 'ENQUIRY';
		this.dropLeadDetails.dmsLeadDropInfo.status = 'ENQUIRY';
		const sendDropDet = this.enquiryservice.sendDropDetails(this.dropLeadDetails).subscribe(res => {
			if (res.statusCode === '200') {
				this.leadObject.dmsLeadDto.leadStage = 'DROPPED';
				const sendLeadEnq = this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
				});
				this.subscriptions.push(sendLeadEnq);
			}
			if (res.approver === this.loginEmployee.empName) {
				this.lead360Service.getAllTasksByUniversalId(this.leadId);
				this.updateStatusMessage('Successfully Dropped Lead');
			} else {
				this.lead360Service.getAllApprovalTasksByUniversalId(this.leadId);
				this.updateStatusMessage('Sent For Approval');
			}
		});
		this.subscriptions.push(sendDropDet);
	}

	proceedPreBooking() {
		if (this.testDrive || this.homeVisit || this.evaluation) {
			this.pendingTasksStatus();
		} else {
			if (!this.popCheck) {
				this.updateStatusMessagePermission();
			} else {
				this.router.navigate(['/lead360']);
				this.popCheck = false;
			}
		}
	}

	// Pop-Up To Show Pending Tasks
	pendingTasksStatus() {
		let _title = '';
		_title = 'Pending Tasks';
		const _description = [this.testDrive, this.homeVisit, this.evaluation];
		const dialogRef = this.layoutUtilsService.taskRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.isTestDrive = false;
			this.isHomeVisit = false;
			this.isEvaluation = false;
			this.testDrive = '';
			this.homeVisit = '';
			this.evaluation = '';
			if (!this.popCheck) {
				this.updateStatusMessagePermission();
			} else {
				this.router.navigate(['/lead360']);
				this.popCheck = false;
			}
		});
	}

	// Pop-Up after Enquiry Submission
	updateStatusMessagePermission() {
		let _title = '';
		_title = '';
		const _description = `Permission Denied`;
		const dialogRef = this.layoutUtilsService.updateRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.goBack();
			this.popCheck = false;
		});
	}

	gotoTop() {
		window.scroll({
			top: 0,
			left: 0,
			behavior: 'smooth'
		});
	}
}
