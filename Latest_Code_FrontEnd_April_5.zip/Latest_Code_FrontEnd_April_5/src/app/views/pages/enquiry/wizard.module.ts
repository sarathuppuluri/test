// Angular
import { NgModule, } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
// Metronic
import { PartialsModule } from '../../partials/partials.module';
import { CoreModule } from '../../../core/core.module';

import { UpdateEntityDialogComponent, TaskEntityDialogComponent } from '../../partials/content/crud';
// Components
import { WizardComponent } from './wizard.component';
import { Wizard1Component } from './wizard1/wizard1.component';
import { EnquiryReviewmodeComponent } from './enquiry-reviewmode/enquiry-reviewmode.component';
import { EnquiryLeadsComponent } from './enquiry-leads/enquiry-leads.component';
// Material   // Imported By Me...
import {
	MatInputModule,
	MatPaginatorModule,
	MatProgressSpinnerModule,
	MatSortModule,
	MatTableModule,
	MatSelectModule,
	MatMenuModule,
	MatProgressBarModule,
	MatButtonModule,
	MatCheckboxModule,
	MatDialogModule,
	MatTabsModule,
	MatNativeDateModule,
	MatCardModule,
	MatRadioModule,
	MatIconModule,
	MatDatepickerModule,
	MatAutocompleteModule,
	MAT_DIALOG_DEFAULT_OPTIONS,
	MatSnackBarModule,
	MatTooltipModule,
	MatExpansionModule,
	MAT_DATE_LOCALE
} from '@angular/material';

@NgModule({
	declarations: [
		WizardComponent,
		Wizard1Component,
		EnquiryReviewmodeComponent,
		EnquiryLeadsComponent
	],
	imports: [
		CommonModule,
		FormsModule,
		PartialsModule,
		CoreModule,
		RouterModule.forChild([
			{
				path: '',
				component: WizardComponent,
				children: [
					{
						path: 'enquiry',
						component: EnquiryLeadsComponent
					},
					{
						path: 'enquiry/overview/:leadId',
						component: EnquiryReviewmodeComponent
					},
					{
						path: 'enquiry/emsform/:leadId',
						component: Wizard1Component
					}
				]
			},
		]),
		MatInputModule,
		MatPaginatorModule,
		MatProgressSpinnerModule,
		MatSortModule,
		MatTableModule,
		MatSelectModule,
		MatMenuModule,
		MatProgressBarModule,
		MatButtonModule,
		MatCheckboxModule,
		MatDialogModule,
		MatTabsModule,
		MatNativeDateModule,
		MatCardModule,
		MatRadioModule,
		MatIconModule,
		MatDatepickerModule,
		MatAutocompleteModule,
		MatSnackBarModule,
		MatTooltipModule,
		ReactiveFormsModule,
		MatExpansionModule
	],
	entryComponents: [
		UpdateEntityDialogComponent,
		TaskEntityDialogComponent
	],
	providers: [
		{ provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
		{
			provide: MAT_DIALOG_DEFAULT_OPTIONS,
			useValue: {
				hasBackdrop: true,
				panelClass: 'kt-mat-dialog-container__wrapper',
				height: 'auto',
				width: '900px'
			}
		}
	]
})
export class WizardModule {
}
