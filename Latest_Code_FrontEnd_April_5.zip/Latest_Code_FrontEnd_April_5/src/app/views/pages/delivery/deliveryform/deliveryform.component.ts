import { Component, ElementRef, OnInit, OnDestroy, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgControlStatus, FormArray } from '@angular/forms';
import { EnquiryService, Lead360Service, SharedService } from '../../../../core/e-commerce/_services';
import { ActivatedRoute, Router } from '@angular/router';
import { LayoutUtilsService } from '../../../../core/_base/crud/utils/layout-utils.service';
import { QueryParamsModel } from '../../../../../app/core/_base/crud';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { findIndex } from 'rxjs/operators';
import { Subscription } from 'rxjs';

@Component({
	selector: 'kt-deliveryform',
	templateUrl: './deliveryform.component.html',
	styleUrls: ['./deliveryform.component.scss']
})
export class DeliveryformComponent implements OnInit, OnDestroy {
	// Used in the MatPicker
	startDate;
	message: any;
	loginEmployee: any;
	warranty: any;
	insuranceType = 0;
	addOnCovers = 0;
	warrantyElement = 0;
	onRoadPriceCalculator = 0;
	onRoadPriceDiscountCalculator: any;
	accessoryCost = 0;
	addSelectedAccessoryCost = 0;
	accessoriesArray = [];
	slectedCorporateOfferCost: any;
	corporateOfferPrice: any;
	pendingAmount: number;
	amountPaidTemp: any;

	dropClicked = false;
	dropLeadDetails: any = { dmsLeadDropInfo: {} };

	// Subscriptions
	private subscriptions: Subscription[] = [];

	constructor(private fb: FormBuilder,
		private enquiryservice: EnquiryService,
		private routeData: ActivatedRoute,
		private layoutUtilsService: LayoutUtilsService,
		private lead360Service: Lead360Service,
		private sharedService: SharedService,
		private router: Router,
		private changedetectorref: ChangeDetectorRef,
		private modalService: NgbModal) {
		this.leadId = this.routeData.snapshot.paramMap.get('id');
		this.startDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
	}

	_subscription;

	EnquiryEditForm: FormGroup;
	EnquiryEditForm4: FormGroup;

	PreBookingForm: FormGroup;
	DeliveryForm: FormGroup;
	DropEnquiryForm: FormGroup;
	hasFormErrors = false;

	submitted = false;
	leadId = '';

	vechilesData = [];
	vechileModelsList = [];
	variantsList = [];
	colorsList = [];
	fuelTypeList = [];
	variantRecord = [];

	customerTypeDropDown = [];
	showImageCheck = true;
	hasSubmitted = false;
	endAutoSave = false;
	statusShow = false;

	second = 1000;
	minute = this.second * 60;
	hour = this.minute * 60;
	day = this.hour * 24;
	month = this.day * 30;
	year = this.day * 365;

	leadObject: any = {};
	postOnRoadPriceTable: any = {};
	vehicleAllotementBody: any = {};
	invoiceDetails: any = {};
	deliveryObject: any = {};
	deliveryCheckList: any = {};

	page = 0;
	pageSize = 10;
	scope: any = {};

	tempAmountReceived = 0;

	ngOnInit() {
		this.endAutoSave = false;
		this.statusShow = false;
		this.enquiryForm();
		this.getVechilesDetails();
		this.getLeadDetailsUniversalId();
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		// this.onRoadPriceDetails();
		// this.offerDetails();

		// this.onRoadPriceDiscountCalculator = localStorage.getItem('OnRoadPrice');
		// this.amountPaidTemp = localStorage.getItem('AmountPaid');
	}

	ngOnDestroy(): void {
		// Called once, before the instance is destroyed.
		// Add 'implements OnDestroy' to the class.
		this.endAutoSave = true;
		this.statusShow = false;
		this.subscriptions.forEach(el => el.unsubscribe());
	}

	enquiryForm() {
		this.EnquiryEditForm = this.fb.group({
			challanNo: [''],
			challanDate: [new Date(Date.now()).toLocaleDateString()],
			referencenumber: [''],

			firstName: [''],
			lastName: [''],

			vinno: [''],
			engineNo: [''],
			keyNo: [''],
			invoiceDate: ['']
		});

		this.EnquiryEditForm4 = this.fb.group({
			model: [''],
			variant: [''],
			color: [''],
			fuel: [''],
			transimmisionType: ['']
		});

		this.PreBookingForm = this.fb.group({
			onRoadPrice: [''],
			totalPayment: [''],
			payableAmount: [''],

			pendingAccessoriesList: this.fb.array([])
		});

		this.DeliveryForm = this.fb.group({
			hypothicatedTo: [''],
			insuranceCompany: [''],
			insurancePolicyNo: [''],
			insuranceDate: [''],
			insurenceExpDate: [''],
			rcNo: [''],
			etdWarrantyNo: [''],
			fastTagNo: [''],

			originalKey: [''],
			duplicateKey: [''],
			userManual: [''],
			serviceBooklet: [''],
			toolKit: [''],
			jack: [''],
			jackRod: [''],
			spareWheel: [''],
			insurenceCopy: [''],
			trCopy: [''],
			deliveryCheckList: this.fb.array([])
		});

		this.DropEnquiryForm = this.fb.group({
			dropReason: [''],
			dealerName: [''],
			brandName: [''],
			otherReason: [''],
			additionalRemarks: [''],
			location: [''],
			model: ['']
		});
	}

	// Getter Method
	get getDeliveryFields() {
		return this.DeliveryForm.get('deliveryCheckList') as FormArray;
	}

	// Add FormGroups
	addOtherFields() {
		return this.fb.group({
			deliveryItem: [''],
			deliveryCheck: ['']
		});
	}

	// Add Fields Method
	addDeliveryFields() {
		this.getDeliveryFields.push(this.addOtherFields());
	}

	// Remove Fields Method
	removeFields(index) {
		this.getDeliveryFields.removeAt(index);
	}

	// Getter Method
	get getAccessoriesFields() {
		return this.PreBookingForm.get('pendingAccessoriesList') as FormArray;
	}

	// Add FormGroups
	addOtherPendingAccessory() {
		return this.fb.group({
			accessoryName: ['']
		});
	}

	// Add Fields Method
	addOtherPendingAccessoryFields() {
		this.getAccessoriesFields.push(this.addOtherPendingAccessory());
	}

	// Remove Fields Method
	removePendingAccessoryFields(index) {
		this.getAccessoriesFields.removeAt(index);
	}

	/**
	* Checking control validation
	*
	* @param controlName: string => Equals to formControlName
	* @param validationType: string => Equals to valitors name
	*/
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.EnquiryEditForm.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}

	onSubmit() {
		this.hasSubmitted = true;
		this.endAutoSave = true;
		this.statusShow = true;
		this.updateLeadDetails(this.EnquiryEditForm.value);
	}

	// Get Lead Details By UniversalID
	getLeadDetailsUniversalId() {
		this.enquiryservice.getLeadByUniversalID(this.leadId).subscribe(res => {
			if (!res) {
				return;
			}
			this.leadObject = res.dmsEntity;
			this.EnquiryEditForm.patchValue(this.leadObject.dmsContactDto ? this.leadObject.dmsContactDto : this.leadObject.dmsAccountDto);
			this.EnquiryEditForm.patchValue(this.leadObject.dmsLeadDto);
			this.EnquiryEditForm4.patchValue({
				model: this.leadObject.dmsLeadDto.model
			});

			if (this.leadObject.dmsLeadDto.dmsLeadProducts.length > 0) {
				this.EnquiryEditForm4.patchValue({
					model: (this.leadObject.dmsLeadDto.dmsLeadProducts[0].model !== null) ? this.leadObject.dmsLeadDto.dmsLeadProducts[0].model : this.leadObject.dmsLeadDto.model,
					variant: this.leadObject.dmsLeadDto.dmsLeadProducts[0].variant,
					color: this.leadObject.dmsLeadDto.dmsLeadProducts[0].color,
					fuel: this.leadObject.dmsLeadDto.dmsLeadProducts[0].fuel,
					transimmisionType: this.leadObject.dmsLeadDto.dmsLeadProducts[0].transimmisionType
				});
			}

			// get OnRoadPrice Table Posted Data
			this.enquiryservice.getOnRoadPricePosted(this.leadObject.dmsLeadDto.id).subscribe(response => {
				if (response.dmsEntity.dmsOnRoadPriceDtoList.length > 0) {
					this.postOnRoadPriceTable = response.dmsEntity.dmsOnRoadPriceDtoList[0];
					this.PreBookingForm.patchValue({ onRoadPrice: this.postOnRoadPriceTable.finalPrice });
				}
			});

			// get Vehicle Allotment Details
			this.enquiryservice.getVehicleAllocation(this.leadObject.dmsLeadDto.id).subscribe(response => {
				if (response.dmsEntity.dmsAllotmentDtoList.length > 0) {
					this.vehicleAllotementBody = response.dmsEntity.dmsAllotmentDtoList[0];
					this.EnquiryEditForm.patchValue(this.vehicleAllotementBody);
				}
			});

			// get Invoice Details
			this.enquiryservice.getInvoiceDetails(this.leadObject.dmsLeadDto.id).subscribe(response => {
				if (response.dmsEntity.dmsInvoiceDtoList.length > 0) {
					this.invoiceDetails = response.dmsEntity.dmsInvoiceDtoList[0];
					this.EnquiryEditForm.patchValue({
						invoiceDate: (new Date(this.invoiceDetails.invoiceDate ? this.invoiceDetails.invoiceDate : null)).toISOString()
					});
				}
			});

			// get Booking Amount Received Details
			this.enquiryservice.getBookingAmount(this.leadObject.dmsLeadDto.id).subscribe(response => {
				response.dmsEntity.dmsBookingAmountReceivedDtoList.forEach(element => {
					this.tempAmountReceived = this.tempAmountReceived + element.amount;
					this.PreBookingForm.patchValue({
						totalPayment: this.tempAmountReceived,
						payableAmount: (this.postOnRoadPriceTable.finalPrice - this.tempAmountReceived)
					});
				});
			});

			// get Delivery Details
			this.enquiryservice.getDeliveryDetails(this.leadObject.dmsLeadDto.id).subscribe(response => {
				if (response.dmsEntity.dmsDeliveryDtoList.length > 0) {
					this.deliveryObject = response.dmsEntity.dmsDeliveryDtoList[0];
					this.DeliveryForm.patchValue(this.deliveryObject);
					this.DeliveryForm.patchValue({
						insuranceDate: (new Date(this.deliveryObject.insuranceDate ? this.deliveryObject.insuranceDate : null)).toISOString(),
						insurenceExpDate: (new Date(this.deliveryObject.insurenceExpDate ? this.deliveryObject.insurenceExpDate : null)).toISOString()
					});
				}
			});

			// get Delivery CheckList Details
			this.enquiryservice.getDeliveryDetailsCheckList(this.leadObject.dmsLeadDto.id).subscribe(response => {
				this.deliveryCheckListArray = response.dmsEntity.dmsDeliveryCheckListDtoList;
				response.dmsEntity.dmsDeliveryCheckListDtoList.forEach((element, i) => {
					this.getDeliveryFields.push(this.addOtherFields());
					let temp = (<FormArray>this.DeliveryForm.controls['deliveryCheckList']).at(i);
					temp.patchValue({
						deliveryItem: response.dmsEntity.dmsDeliveryCheckListDtoList[i].itemName,
						deliveryCheck: response.dmsEntity.dmsDeliveryCheckListDtoList[i].checkList
					});
				});
			});

			this.EnquiryEditForm.get('referencenumber').disable({ onlySelf: true });
			// this.EnquiryEditForm.disable();
			this.EnquiryEditForm4.disable();

			this.EnquiryEditForm.patchValue({
				challanDate: new Date(Date.now()).toISOString()
			});
		});
	}

	// Post Lead Details
	updateLeadDetails(controls) {
		if (this.leadObject.dmsContactDto) {
			this.leadObject.dmsContactDto.firstName = controls.firstName;
			this.leadObject.dmsContactDto.lastName = controls.lastName;
		} else {
			this.leadObject.dmsAccountDto.firstName = controls.firstName;
			this.leadObject.dmsAccountDto.lastName = controls.lastName;
		}
		this.leadObject.dmsLeadDto.firstName = controls.firstName;
		this.leadObject.dmsLeadDto.lastName = controls.lastName;
		this.leadObject.dmsLeadDto.dmsLeadProducts = this.sendModelSelection(this.EnquiryEditForm4.value);

		// Delivery Object
		this.deliveryObject.id = this.deliveryObject.id ? this.deliveryObject.id : 0;
		this.deliveryObject.leadId = this.leadObject.dmsLeadDto.id;
		this.deliveryObject.bookingId = this.leadObject.dmsLeadDto.dmsBooking.id;
		this.deliveryObject.invoiceId = this.invoiceDetails.id;
		this.deliveryObject.challanNo = this.EnquiryEditForm.value.challanNo;
		this.deliveryObject.challanDate = Date.parse(this.EnquiryEditForm.value.challanDate);
		this.deliveryObject.hypothicatedTo = this.DeliveryForm.value.hypothicatedTo;
		this.deliveryObject.insuranceCompany = this.DeliveryForm.value.insuranceCompany;
		this.deliveryObject.insurancePolicyNo = this.DeliveryForm.value.insurancePolicyNo;
		this.deliveryObject.insuranceDate = Date.parse(this.DeliveryForm.value.insuranceDate);
		this.deliveryObject.insurenceExpDate = Date.parse(this.DeliveryForm.value.insurenceExpDate);
		this.deliveryObject.rcNo = this.DeliveryForm.value.rcNo;
		this.deliveryObject.etdWarrantyNo = this.DeliveryForm.value.etdWarrantyNo;
		this.deliveryObject.fastTagNo = this.DeliveryForm.value.fastTagNo;
		this.deliveryObject.originalKey = this.DeliveryForm.controls.originalKey.touched === false ? false : this.DeliveryForm.value.originalKey;
		this.deliveryObject.duplicateKey = this.DeliveryForm.controls.duplicateKey.touched === false ? false : this.DeliveryForm.value.duplicateKey;
		this.deliveryObject.serviceBooklet = this.DeliveryForm.controls.serviceBooklet.touched === false ? false : this.DeliveryForm.value.serviceBooklet;
		this.deliveryObject.toolKit = this.DeliveryForm.controls.toolKit.touched === false ? false : this.DeliveryForm.value.toolKit;
		this.deliveryObject.jack = this.DeliveryForm.controls.jack.touched === false ? false : this.DeliveryForm.value.jack;
		this.deliveryObject.jackRod = this.DeliveryForm.controls.jackRod.touched === false ? false : this.DeliveryForm.value.jackRod;
		this.deliveryObject.spareWheel = this.DeliveryForm.controls.spareWheel.touched === false ? false : this.DeliveryForm.value.spareWheel;
		this.deliveryObject.insurenceCopy = this.DeliveryForm.controls.insurenceCopy.touched === false ? false : this.DeliveryForm.value.insurenceCopy;
		this.deliveryObject.trCopy = this.DeliveryForm.controls.trCopy.touched === false ? false : this.DeliveryForm.value.trCopy;

		this.enquiryservice.sendDeliveryDetails(this.deliveryObject).subscribe(response => {
			if (!response) {
				return;
			}
			if (response.success === false || response.statusCode === 400) {
				this.message = response.message;
				this.gotoTop();
				this.changedetectorref.detectChanges();
				return;
			}
			this.deliveryObject = response.dmsEntity.dmsDeliveryDto;
			this.enquiryservice.sendDeliveryDetailsCheckList(this.deliveryCheckListArray).subscribe(checkListRes => {
				if (!checkListRes) {
					return;
				}
				if (checkListRes.success === false || checkListRes.statusCode === 400) {
					this.message = checkListRes.message;
					this.gotoTop();
					this.changedetectorref.detectChanges();
					return;
				}
				this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
					if (res.statusCode !== 500) {
						this.message = '';
						this.leadObject = res.dmsEntity;
						this.hasSubmitted = false;
						if (this.endAutoSave) {
							this.leadObject.dmsLeadDto.leadStatus = 'DELIVERYCOMPLETED';
							this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
							});
							if (this.statusShow) {
								this.updateStatusMessage('Delivery Updated Successfully');
							}
						}
						this.changedetectorref.detectChanges();
						return;
					} else {
						this.hasSubmitted = false;
						this.message = res.message;
						this.gotoTop();
						this.changedetectorref.detectChanges();
						return;
					}
				});
			});
		});
	}

	accessoriesAllotement(event, accessory) {
		this.leadObject.dmsLeadDto.dmsAccessories.forEach(element => {
			if (element.id === accessory.id) {
				if (event.checked === true) {
					element.allotementStatus = true;
				} else {
					element.allotementStatus = false;
				}
			}
		});
	}

	deliveryCheckListArray = [];
	// Delivery Check List Array
	addDeliveryCheckList(checkListForm, index) {
		if (this.deliveryCheckListArray.length > 0 && this.deliveryCheckListArray[index]) {
			this.deliveryCheckListArray.forEach((element, i) => {
				if (i === index) {
					element.itemName = checkListForm.value.deliveryItem;
					element.checkList = (checkListForm.value.deliveryCheck === '') ? false : checkListForm.value.deliveryCheck;
					return;
				}
			});
		} else {
			this.deliveryCheckList.id = 0;
			this.deliveryCheckList.itemName = checkListForm.value.deliveryItem;
			this.deliveryCheckList.checkList = (checkListForm.value.deliveryCheck === '') ? false : checkListForm.value.deliveryCheck;
			this.deliveryCheckList.leadId = this.leadObject.dmsLeadDto.id;
			this.deliveryCheckList.deliveryId = this.deliveryObject.id;
			let tempBookingAmounObj = Object.assign({}, this.deliveryCheckList);
			this.deliveryCheckListArray.push(tempBookingAmounObj);
		}
	}

	// Delivery Check List Array value
	removeDeliveryCheckList(index) {
		this.deliveryCheckListArray.splice(index, 1);
	}

	// Lead Products Object
	sendModelSelection(controls) {
		const objData = [
			{
				color: controls.color,
				model: controls.model,
				fuel: controls.fuel,
				transimmisionType: controls.transimmisionType,
				variant: controls.variant,
				id: this.leadObject.dmsLeadDto.dmsLeadProducts[0] ? this.leadObject.dmsLeadDto.dmsLeadProducts[0].id : 0
			}
		];

		return objData;
	}

	// Pop-Up after Enquiry Submission
	updateStatusMessage(msg) {
		let _title = /*'Delivery Updated Successfully'*/ msg;
		const _description = `Delivery Number: ${this.leadObject.dmsLeadDto.referencenumber}`;
		const dialogRef = this.layoutUtilsService.updateRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			if (this.statusShow) {
				this.enquiryservice.sendDatafromSalestoServices({ "leadid": this.leadObject.dmsLeadDto.id }).subscribe(salToSerRes => {
				});
			}
			this.router.navigate(['/delivery/delivery']);
		});
	}

	// Change Vechile Model
	changeVechileModel() {
		const selectedModel = this.EnquiryEditForm4.controls.model.value;
		const promise = new Promise((resolve) => {
			if ((selectedModel !== null) && (selectedModel !== 'Select') && (selectedModel !== '')) {
				resolve();
			}
		});

		promise.then(() => {
			let tempData = this.vechilesData.filter(record => record.model === selectedModel)
				.map(obj => {
					return {
						variantsList: obj.varients,
					};
				})[0];
			tempData = tempData;
			this.variantsList = tempData.variantsList || [];
			this.changeVariant();
			this.showImageCheck = true;
		});
	}

	// Image display based on Model
	swapImage() {
		this.showImageCheck = false;
	}

	// Change Variant
	changeVariant() {
		this.variantRecord = [];
		const selectedVariant = this.EnquiryEditForm4.controls.variant.value;
		const promise = new Promise((resolve) => {
			if ((selectedVariant !== null) && (selectedVariant !== 'Select') && (selectedVariant !== '')) {
				this.variantRecord = this.variantsList.filter(record => record.name === selectedVariant);
				resolve();
			}
		});

		promise.then(() => {
			this.showImageCheck = false;
			// this.onRoadPriceDetails();
		});
	}

	// Get vechiles Details
	getVechilesDetails() {
		this._subscription = this.sharedService.vechileDetailsChange.subscribe((value) => {
			this.vechilesData = value;
			this.changeVechileModel();
		});
	}

	dropEnquiry() {
		this.dropClicked = true;
	}

	// Proceed to Drop
	proceedToCancel() {
		this.dropLeadDetails.dmsLeadDropInfo.additionalRemarks = this.DropEnquiryForm.value.additionalRemarks;
		this.dropLeadDetails.dmsLeadDropInfo.branchId = this.loginEmployee.branchId;
		this.dropLeadDetails.dmsLeadDropInfo.brandName = this.DropEnquiryForm.value.brandName;
		this.dropLeadDetails.dmsLeadDropInfo.dealerName = this.DropEnquiryForm.value.dealerName;
		this.dropLeadDetails.dmsLeadDropInfo.enquiryCategory = this.DropEnquiryForm.value.enquiryCategory;
		this.dropLeadDetails.dmsLeadDropInfo.leadId = this.leadObject.dmsLeadDto.id;
		this.dropLeadDetails.dmsLeadDropInfo.crmUniversalId = this.leadId;
		this.dropLeadDetails.dmsLeadDropInfo.lostReason = this.DropEnquiryForm.value.dropReason;
		this.dropLeadDetails.dmsLeadDropInfo.organizationId = this.loginEmployee.orgId;
		this.dropLeadDetails.dmsLeadDropInfo.otherReason = '';
		this.dropLeadDetails.dmsLeadDropInfo.droppedBy = this.loginEmployee.empId;
		this.dropLeadDetails.dmsLeadDropInfo.location = this.DropEnquiryForm.value.location;
		this.dropLeadDetails.dmsLeadDropInfo.model = this.DropEnquiryForm.value.model;
		this.dropLeadDetails.dmsLeadDropInfo.stage = 'DELIVERY';
		this.dropLeadDetails.dmsLeadDropInfo.status = 'DELIVERY';
		const sendDropDet = this.enquiryservice.sendDropDetails(this.dropLeadDetails).subscribe(res => {
			if (res.statusCode === '200') {
				this.leadObject.dmsLeadDto.leadStage = 'DROPPED';
				const sendLeadEnq = this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
				});
				this.subscriptions.push(sendLeadEnq);
			}
			if (res.approver === this.loginEmployee.empName) {
				this.lead360Service.getAllTasksByUniversalId(this.leadId);
				this.updateStatusMessage('Successfully Dropped Lead');
			} else {
				this.lead360Service.getAllApprovalTasksByUniversalId(this.leadId);
				this.updateStatusMessage('Sent For Approval');
			}
		});
		this.subscriptions.push(sendDropDet);
	}

	goBack() {
		this.router.navigate(['/delivery/delivery']);
	}

	gotoTop() {
		window.scroll({
			top: 0,
			left: 0,
			behavior: 'smooth'
		});
	}
}
