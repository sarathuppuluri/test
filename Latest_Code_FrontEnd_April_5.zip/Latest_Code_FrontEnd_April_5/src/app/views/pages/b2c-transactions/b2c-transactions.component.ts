import { Component, OnInit, ChangeDetectorRef } from "@angular/core";
import { B2CTransactionsService } from "../../../core/e-commerce/_services/b2cTransactions.service";
import { QueryParamsModel } from "../../../core/_base/crud";

@Component({
	selector: "kt-b2c-transactions",
	templateUrl: "./b2c-transactions.component.html",
	styleUrls: ["./b2c-transactions.component.scss"],
})
export class B2cTransactionsComponent implements OnInit {
	loginEmployee: any;
	page = 0;
	pageSize = 10;
	pageSize1 = 10;
	pageSize2 = 10;
	pageSize3 = 10;
	pageSize4 = 10;
	pageSize5 = 10;
	pageSize6 = 10;
	pageSize7 = 10;
	pageSize8 = 10;
	pageSize9 = 10;
	pageSize10 = 10;

	isLoading = false;

	globalDataContainer: any = [];
	globalDataObject: any = {};
	accessories: any = [];

	constructor(
		private changeDetectorRef: ChangeDetectorRef,
		private b2cTransactionService: B2CTransactionsService
	) {}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.getNewCarBookings();
	}

	// Get All New Car Bookings
	getNewCarBookings() {
		this.isLoading = true;
		this.globalDataContainer = [];
		this.globalDataObject = {};
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize1
		);
		this.b2cTransactionService
			.getNewCarBookings(
				this.loginEmployee.orgId,
				this.loginEmployee.branchId,
				queryParams
			)
			.subscribe((res) => {
				this.isLoading = false;
				this.globalDataObject = res;
				this.globalDataContainer = res.bookings;
				this.changeDetectorRef.detectChanges();
			});
	}

	paginatorEventsNewCar(event) {
		this.page = event.pageIndex;
		this.pageSize1 = event.pageSize;
		this.getNewCarBookings();
	}

	// Get All Used Cars
	getUsedCar() {
		this.isLoading = true;
		this.globalDataContainer = [];
		this.globalDataObject = {};
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize2
		);
		this.b2cTransactionService
			.getUsedCarBookings(
				this.loginEmployee.orgId,
				this.loginEmployee.branchId,
				queryParams
			)
			.subscribe((res) => {
				this.isLoading = false;
				this.globalDataObject = res;
				this.globalDataContainer = res.oldVehicleBookingInfos;
				this.changeDetectorRef.detectChanges();
			});
	}

	paginatorEventsUsedCar(event) {
		this.page = event.pageIndex;
		this.pageSize2 = event.pageSize;
		this.getUsedCar();
	}

	// Get All Services
	getServices() {
		this.isLoading = true;
		this.globalDataContainer = [];
		this.globalDataObject = {};
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize3
		);
		this.b2cTransactionService
			.getServices(this.loginEmployee.branchId, queryParams)
			.subscribe((res) => {
				this.isLoading = false;
				this.globalDataObject = res.body;
				this.globalDataContainer = res.body.content;
				this.changeDetectorRef.detectChanges();
			});
	}

	paginatorEventsServices(event) {
		this.page = event.pageIndex;
		this.pageSize3 = event.pageSize;
		this.getServices();
	}

	// Get All TestDrive History
	getTestDrive() {
		this.isLoading = true;
		this.globalDataContainer = [];
		this.globalDataObject = {};
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize4
		);
		this.b2cTransactionService
			.getTestDrive(
				this.loginEmployee.orgId,
				this.loginEmployee.branchId,
				queryParams
			)
			.subscribe((res) => {
				this.isLoading = false;
				this.globalDataObject = res;
				this.globalDataContainer = res.testDrives;
				this.changeDetectorRef.detectChanges();
			});
	}

	paginatorEventsTestDrive(event) {
		this.page = event.pageIndex;
		this.pageSize4 = event.pageSize;
		this.getTestDrive();
	}

	// Get All New Car Finance
	getNewCarFinance() {
		this.isLoading = true;
		this.globalDataContainer = [];
		this.globalDataObject = {};
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize5
		);
		this.b2cTransactionService
			.getNewCarFinance(this.loginEmployee.orgId, queryParams)
			.subscribe((res) => {
				this.isLoading = false;
				this.globalDataObject = res.pageNewCarFinance;
				this.globalDataContainer = res.pageNewCarFinance.content;
				this.changeDetectorRef.detectChanges();
				this.resetPagination();
			});
	}

	paginatorNewCarFinance(event) {
		this.page = event.pageIndex;
		this.pageSize5 = event.pageSize;
		this.getNewCarFinance();
	}

	// Get All Old Car Finance
	getOldCarFinance() {
		this.isLoading = true;
		this.globalDataContainer = [];
		this.globalDataObject = {};
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize6
		);
		this.b2cTransactionService
			.getOldCarFinance(this.loginEmployee.orgId, queryParams)
			.subscribe((res) => {
				this.isLoading = false;
				this.globalDataObject = res.pageOldCarFinance;
				this.globalDataContainer = res.pageOldCarFinance.content;
				this.changeDetectorRef.detectChanges();
				this.resetPagination();
			});
	}

	paginatorOldCarFinance(event) {
		this.page = event.pageIndex;
		this.pageSize6 = event.pageSize;
		this.getOldCarFinance();
	}

	// Get All Insurance
	getInsurance() {
		this.isLoading = true;
		this.globalDataContainer = [];
		this.globalDataObject = {};
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize7
		);
		this.b2cTransactionService
			.getInsurance(
				this.loginEmployee.orgId,
				queryParams,
				this.loginEmployee.branchId
			)
			.subscribe((res) => {
				this.isLoading = false;
				this.globalDataObject = res.pRenewInsurance;
				this.globalDataContainer = res.pRenewInsurance.content;
				this.changeDetectorRef.detectChanges();
				this.resetPagination();
			});
	}

	paginatorInsurance(event) {
		this.page = event.pageIndex;
		this.pageSize7 = event.pageSize;
		this.getInsurance();
	}

	// Get All Accessories
	getAccessories() {
		this.isLoading = true;
		this.globalDataContainer = [];
		this.globalDataObject = {};
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize8
		);
		this.b2cTransactionService
			.getAccessories(
				this.loginEmployee.orgId,
				this.loginEmployee.branchId,
				queryParams
			)
			.subscribe((res) => {
				this.isLoading = false;
				this.globalDataObject = res;
				this.globalDataContainer = res.accessories;
				this.globalDataContainer.forEach((element, i) => {
					Array.isArray(
						JSON.parse(element.accessoriesBooking.accessories)
					) === false
						? (this.globalDataContainer[
								i
						  ].accessoriesBooking.accessories = [
								JSON.parse(
									element.accessoriesBooking.accessories
								),
						  ])
						: (this.globalDataContainer[
								i
						  ].accessoriesBooking.accessories = JSON.parse(
								element.accessoriesBooking.accessories
						  ));
				});
				this.changeDetectorRef.detectChanges();
			});
	}

	getPartNo(element) {
		const partNo = [];
		element.forEach((subelem) => {
			partNo.push(subelem.partNo);
		});
		return partNo;
	}

	getPartName(element) {
		const partName = [];
		element.forEach((subelem) => {
			partName.push(subelem.partName);
		});
		return partName;
	}

	paginatorEventsAccessories(event) {
		this.page = event.pageIndex;
		this.pageSize8 = event.pageSize;
		this.getAccessories();
	}

	// Get All Old Car Evaluations
	getOldCarEvaluations() {
		this.globalDataContainer = [];
		this.globalDataObject = {};
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize9
		);
		this.b2cTransactionService
			.getOldCarEvalaution(
				this.loginEmployee.orgId,
				queryParams,
				this.loginEmployee.branchId
			)
			.subscribe((res) => {
				this.isLoading = false;
				this.globalDataObject = res.oldcar;
				this.globalDataContainer = res.oldcar.content;
				this.changeDetectorRef.detectChanges();
				this.resetPagination();
			});
	}

	paginatorOldCarEvaluations(event) {
		this.page = event.pageIndex;
		this.pageSize9 = event.pageSize;
		this.getOldCarEvaluations();
	}

	// Get All Roadside Assistance
	getRoadsideAssistance() {
		this.isLoading = true;
		this.globalDataContainer = [];
		this.globalDataObject = {};
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize10
		);
		this.b2cTransactionService
			.getRoadSideAssistance(this.loginEmployee.orgId, queryParams)
			.subscribe((res) => {
				this.isLoading = false;
				this.globalDataObject = res.customerRsas;
				this.globalDataContainer = res.customerRsas;
				this.changeDetectorRef.detectChanges();
				this.resetPagination();
			});
	}

	paginatorRoadsideAssistance(event) {
		this.page = event.pageIndex;
		this.pageSize10 = event.pageSize;
		this.getRoadsideAssistance();
	}

	resetPagination() {
		this.page = 0;
		this.pageSize = 10;
	}
}
