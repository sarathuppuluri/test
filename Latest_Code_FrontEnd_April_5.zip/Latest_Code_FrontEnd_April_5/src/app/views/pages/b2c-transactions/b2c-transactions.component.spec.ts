import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { B2cTransactionsComponent } from './b2c-transactions.component';

describe('B2cTransactionsComponent', () => {
  let component: B2cTransactionsComponent;
  let fixture: ComponentFixture<B2cTransactionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ B2cTransactionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(B2cTransactionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
