import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { InsuranceService } from '../../../../core/e-commerce/_services/insurance.service';

@Component({
	selector: 'kt-insurance',
	templateUrl: './insurance.component.html',
	styleUrls: ['./insurance.component.scss'],
})
export class InsuranceComponent implements OnInit {
	loginEmployee: any;
	insuranceId: any;
	showError = false;
	insuranceForm: FormGroup;
	insuranceValues = [];
	customerForm: FormGroup;
	constructor(
		private fb: FormBuilder,
		private insuranceService: InsuranceService,
		private route: ActivatedRoute,
		private router: Router
	) { }

	ngOnInit() {
		this.insuranceId = this.route.snapshot.paramMap.get('id');
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.createForm();
		this.insuranceValues = [
			{ text: 'New', value: 'NEW' },
			{ text: 'Renew', value: 'RENEW' },
		];
		if (this.insuranceId) {
			this.getInsuranceDetailsByid();
		}
	}

	getInsuranceDetailsByid() {
		this.insuranceService
			.getInsuranceById(this.insuranceId)
			.subscribe((data) => {
				this.insuranceForm.patchValue(data.insuranceDetail);
			});
	}
	goBack() {
		this.router.navigateByUrl('insurance');
	}
	createForm() {
		this.insuranceForm = this.fb.group({
			branchId: [''],
			createdDatetime: [''],
			customerName: [''],
			email: [''],
			id: [''],
			insurenceAddOn: [''],
			insurenceAddonName: [''],
			insurenceAmount: [''],
			insurenceCompany: [''],
			insurenceDate: [''],
			insurenceExpDate: [''],
			insurencePolicyNo: [''],
			insurenceType: [''],
			insurnceType: [''],
			leadId: [''],
			mobile: [''],
			modifiedDatetime: [''],
			orgId: [''],
			rcNo: [''],
		});
		this.customerForm = this.fb.group({
			branchId: [''],
			company: [''],
			createdBy: [''],
			customerType: [''],
			email: [''],
			enquirySource: [''],
			firstName: [''],
			lastName: [''],
			modifiedBy: [''],
			orgId: [''],
			ownerName: [''],
			phone: [''],
			secondaryPhone: [''],
			status: [''],
			eventCode: [''],
			dmsLeadDto: this.fb.group({
				branchId: [''],
				createdBy: [''],
				enquirySegment: [''],
				firstName: [''],
				lastName: [''],
				leadStage: [''],
				organizationId: [''],
				phone: [''],
				sourceOfEnquiry: [''],
				eventCode: [''],
				email: [''],
			}),
		});
	}

	clear() {
		this.createForm();
	}
	saveInsurance() {
		if (this.insuranceId) {
			this.insuranceForm.patchValue({
				modifiedDatetime: new Date(),
				orgId: this.loginEmployee.orgId,
				branchId: this.loginEmployee.branchId,
			});
			this.insuranceService
				.updateInsurance(JSON.stringify(this.insuranceForm.value))
				.subscribe((data) => {
					this.router.navigateByUrl('insurance');
				});
		} else {
			this.insuranceForm.patchValue({
				id: 0,
				orgId: this.loginEmployee.orgId,
				createdDatetime: new Date(),
				branchId: this.loginEmployee.branchId,
			});
			this.insuranceService
				.createInsurance(this.insuranceForm.value)
				.subscribe((data) => {
					this.router.navigateByUrl('insurance');
				});
		}
	}
	submit() {
		if (this.insuranceId) {
			this.saveInsurance();
		} else {
			this.insuranceService
				.createContact(this.createContactObject())
				.subscribe((data) => {
					this.insuranceForm.patchValue({
						leadId: data['dmsLeadDto'].id,
					});
					this.saveInsurance();
				});
		}
	}

	createContactObject() {
		const contact = {
			dmsContactDto: {
				branchId: this.loginEmployee.branchId,
				company: this.customerForm.value.company,
				createdBy: this.loginEmployee.empName,
				customerType: 'Individual',
				email: this.insuranceForm.value.email,
				enquirySource: this.customerForm.value.enquirySource,
				firstName: this.customerForm.value.firstName,
				lastName: this.customerForm.value.lastName,
				modifiedBy: this.loginEmployee.empName,
				orgId: this.loginEmployee.orgId,
				ownerName: this.loginEmployee.empName,
				phone: this.customerForm.value.phone,
				secondaryPhone: this.customerForm.value.secondaryPhone,
				status: 'PREENQUIRY',
			},
			dmsLeadDto: {
				branchId: this.loginEmployee.branchId,
				createdBy: this.loginEmployee.empName,
				enquirySegment: 'Personal',
				model: 'Elantra',
				firstName: this.customerForm.value.firstName,
				lastName: this.customerForm.value.lastName,
				leadStage: 'PREENQUIRY',
				organizationId: this.loginEmployee.orgId,
				phone: this.customerForm.value.phone,
				sourceOfEnquiry: this.customerForm.value.enquirySource,
				eventCode: this.customerForm.value.eventCode,
				email: this.insuranceForm.value.email,
			},
		};

		return JSON.stringify(contact);
	}
}
