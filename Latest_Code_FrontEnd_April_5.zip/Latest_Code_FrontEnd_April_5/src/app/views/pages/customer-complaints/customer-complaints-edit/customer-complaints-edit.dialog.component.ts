// Angular
import {
	Component,
	OnInit,
	ChangeDetectorRef,
	Inject,
	ChangeDetectionStrategy,
	ViewEncapsulation,
	ViewChild,
	ElementRef,
	OnDestroy,
} from "@angular/core";
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// Material
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
// RxJS
import { Subscription, of } from "rxjs";
import { delay } from "rxjs/operators";
// NGRX
import { Update } from "@ngrx/entity";
import { Store, select } from "@ngrx/store";
// CRUD
// import { TypesUtilsService } from '../../../../../../core/_base/crud';
import {
	LayoutUtilsService,
	MessageType,
	TypesUtilsService,
	QueryParamsModel,
} from "../../../../core/_base/crud";
// Services and Models
import { CustomerModel } from "../../../../core/e-commerce";
import { CustomerCompliantsModel } from "../../../../core/e-commerce/_models/customer-compliants.model";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import {
	CustomerComplaintsService,
	BranchService,
	MyRolesService,
} from "../../../../core/e-commerce/_services/";

declare let ol: any;

@Component({
	// tslint:disable-next-line:component-selector
	styleUrls: ["./customer-complaints-edit.dialog.component.scss"],
	selector: "kt-customer-complaints-edit-dialog",
	templateUrl: "./customer-complaints-edit.dialog.component.html",
})
export class CustomerComplaintsEditDialogComponent
	implements OnInit, OnDestroy {
	loginEmployee: any;
	employeeList: any = [];
	myrolesResult: any = [];

	/**
	 * Component constructor
	 *
	 * @param dialogRef: MatDialogRef<CustomerEditDialogComponent>
	 * @param data: any
	 * @param fb: FormBuilder
	 * @param store: Store<AppState>
	 * @param typesUtilsService: TypesUtilsService
	 */
	constructor(
		public dialogRef: MatDialogRef<CustomerComplaintsEditDialogComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any,
		private fb: FormBuilder,
		private changeDetectorRef: ChangeDetectorRef,
		private layoutUtilsService: LayoutUtilsService,
		private branchService: BranchService,
		private myroleservice: MyRolesService,
		private custComplService: CustomerComplaintsService
	) {}

	hasFormErrors = false;
	viewLoading = false;
	custComplEdit: any;

	CustomerCompliantForm: FormGroup;

	hasSubmitted = false;
	message = "";

	tempData = [];
	AllDataCustCompl: any = [];

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.loadEmployeeById();
		this.loadMyRolesListView();
		this.custComplEdit = this.data.editCustCompl;
		this.createForm();
	}

	/**
	 * Load Employee List from service
	 */
	loadEmployeeById() {
		const queryParams = new QueryParamsModel({}, "", "", 0, 1000);
		this.branchService
			.getEmployeeById(
				this.loginEmployee.orgId,
				this.loginEmployee.branchId,
				queryParams
			)
			.subscribe(
				(res) => {
					this.employeeList = res.employeeInquiryInfo.content;
					this.changeDetectorRef.detectChanges();
				},
				(error) => {
					console.log("All Data of Employee error::" + error);
					this.changeDetectorRef.detectChanges();
				}
			);
	}

	/**
	 * Load Roles List from service
	 */
	loadMyRolesListView() {
		const queryParams = new QueryParamsModel({}, "", "", 0, 1000);
		this.myroleservice
			.getRedsignedRolesNewChange(
				queryParams,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res) => {
				this.myrolesResult = res.dmsEntity.rolePage.content;
				this.changeDetectorRef.detectChanges();
			});
	}

	createForm() {
		this.CustomerCompliantForm = this.fb.group({
			complaintType: [this.custComplEdit.complaintType],
			// created_By: [this.custComplEdit.created_By],
			// customerId: [this.custComplEdit.customerId],
			customerName: [this.custComplEdit.customerName],
			customerRemarks: [this.custComplEdit.customerRemarks],
			department: [this.custComplEdit.department],
			employee: [this.custComplEdit.employee],
			employeeRemarks: [this.custComplEdit.employeeRemarks],
			role: [this.custComplEdit.role],
			statuscd: [this.custComplEdit.statuscd],
			// updated_By: [this.custComplEdit.updated_By]
		});
	}

	/**
	 * On destroy
	 */
	ngOnDestroy() {}

	/**
	 * Check control is invalid
	 * @param controlName: string
	 */
	isControlInvalid(controlName: string): boolean {
		const control = this.CustomerCompliantForm.controls[controlName];
		const result = control.invalid && control.touched;
		return result;
	}

	onSubmit() {
		this.hasSubmitted = true;
		this.hasFormErrors = false;
		const controls = this.CustomerCompliantForm.controls;
		if (this.CustomerCompliantForm.invalid) {
			Object.keys(controls).forEach((controlName) =>
				controls[controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		}

		this.custComplEdit.complaintType = controls.complaintType.value;
		this.custComplEdit.createdBy = this.loginEmployee.empName;
		this.custComplEdit.customerId = this.custComplEdit.customerId;
		this.custComplEdit.customerName = controls.customerName.value;
		this.custComplEdit.customerRemarks = controls.customerRemarks.value;
		this.custComplEdit.department = controls.department.value;
		this.custComplEdit.employee = controls.employee.value;
		this.custComplEdit.employeeRemarks = controls.employeeRemarks.value;
		this.custComplEdit.role = controls.role.value;
		this.custComplEdit.statuscd = controls.statuscd.value;
		this.custComplEdit.updatedBy = this.loginEmployee.empName;

		const custComplDataObj = this.custComplEdit;

		if (this.custComplEdit.id > 0) {
			this.updateCustCompl(custComplDataObj);
		} else {
			this.createCustCompl(custComplDataObj);
		}
	}

	createCustCompl(custComplData) {
		this.custComplService
			.createCustCompl(custComplData)
			.subscribe((response) => {
				this.hasSubmitted = false;
				if (!response) {
					return;
				}

				this.dialogRef.close({ response, isEdit: false });
			});
	}

	updateCustCompl(editCustCompl) {
		this.custComplService
			.updateCustCompl(editCustCompl)
			.subscribe((response) => {
				this.hasSubmitted = false;
				if (!response) {
					return;
				}

				this.dialogRef.close({ response, isEdit: true });
				// this.loadLeadsShowroomById();
			});
	}

	/** Alect Close event */
	onAlertClose() {
		this.hasFormErrors = false;
	}
}
