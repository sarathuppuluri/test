// Angular
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
// Core Module
import { CoreModule } from '../../../core/core.module';
import { PartialsModule } from '../../partials/partials.module';
import { Lead360Component } from './lead360.component';
import { MatIconModule } from '@angular/material/icon';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {
	MatTabsModule,
	MatCardModule,
	MatLabel,
	MatInputModule,
	MatFormFieldModule,
	MatExpansionModule,
	MatStepperModule,
	MatButtonModule,
	MatAutocompleteModule,
	MAT_DIALOG_DEFAULT_OPTIONS,
	MatDialogModule,
	MatCheckboxModule,
	MatRadioModule,
} from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { DynamicFormModule } from './dynamic-form/dynamic-form.module';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { EditEvaluatorComponent } from './evaluator-screen/evaluator-edit/evaluator-edit.component';
import { FinanceEditDialogComponent } from './financeDocs/finance-edit.dialog.component.ts/finance-edit.dialog.component.ts.component';

@NgModule({
	imports: [
		CommonModule,
		PartialsModule,
		CoreModule,
		MatIconModule,
		NgbModule,
		MatTabsModule,
		MatCardModule,
		FormsModule, ReactiveFormsModule,
		MatFormFieldModule,
		MatStepperModule,
		MatInputModule,
		MatButtonModule,
		MatAutocompleteModule,
		MatInputModule,
		MatExpansionModule,
		ReactiveFormsModule,
		FlexLayoutModule,
		DynamicFormModule,
		MatDatepickerModule,
		MatCheckboxModule,
		MatRadioModule,
		MatDialogModule,

		RouterModule.forChild([
			{
				path: '',
				component: Lead360Component
			},
		]),
	],
	entryComponents: [
		EditEvaluatorComponent,
		FinanceEditDialogComponent
	],
	providers: [
		{
			provide: MAT_DIALOG_DEFAULT_OPTIONS,
			useValue: {
				hasBackdrop: true,
				panelClass: 'kt-mat-dialog-container__wrapper',
				height: 'auto',
				width: '900px'
			}
		}
	],
	declarations: [
		Lead360Component,
		EditEvaluatorComponent,
		FinanceEditDialogComponent
	]
})
export class Lead360Module {}
