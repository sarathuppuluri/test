import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VerifyDocsEdit.DialogComponent } from './verify-docs-edit.dialog.component';

describe('VerifyDocsEdit.DialogComponent', () => {
  let component: VerifyDocsEdit.DialogComponent;
  let fixture: ComponentFixture<VerifyDocsEdit.DialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VerifyDocsEdit.DialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VerifyDocsEdit.DialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
