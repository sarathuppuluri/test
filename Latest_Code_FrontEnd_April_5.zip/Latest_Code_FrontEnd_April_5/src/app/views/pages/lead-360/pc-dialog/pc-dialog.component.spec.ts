import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PcDialogComponent } from './pc-dialog.component';

describe('PcDialogComponent', () => {
  let component: PcDialogComponent;
  let fixture: ComponentFixture<PcDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PcDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PcDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
