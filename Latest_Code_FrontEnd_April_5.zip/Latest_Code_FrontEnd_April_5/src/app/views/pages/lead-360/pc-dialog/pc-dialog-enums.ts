enum EnumDialogTypes {
    ALERT, PROMPT, CONFIRM, DROP_DOWN, EMAIL, SMS
}

export class PCEnums {
    static pcDialogType = EnumDialogTypes;
}