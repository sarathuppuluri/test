import { Component, OnInit, Inject } from '@angular/core';
import { PcDialogModel } from './pc-dialog-model';
import { FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PCEnums } from './pc-dialog-enums';
import { Lead360Service } from '../../../../core/e-commerce/_services';

@Component({
  selector: 'app-pc-dialog',
  templateUrl: './pc-dialog.component.html',
  styleUrls: ['./pc-dialog.component.scss']
})
export class PcDialogComponent implements OnInit {
  // content data ===== Data that is being injected into this dialog
  contentData: PcDialogModel;
  // response data ===== Data that is being sent from this
  responseData: PcDialogModel = {};

  dialogConfirmationControl = new FormControl('', [Validators.required]);

  pcSelectControl = new FormControl('', [Validators.required]);

  phoneNumberControl = new FormControl('', []);
  phoneNo:string;
  inputRequired = true;
  selectRequired = true;

  nodeTypeSelectData = [];

  emailSubject;
  emailText;
  editEmailText = false;
  dealerName = 'Bharat Hyundai';
  dealerCity = 'Khammam';
  custName = 'Sai';
  deliveryDate = '25-02-2020';
  dseMobNo = '9949092084';
  //ccmEmailId = 'abhilash.tatikonda@focalcxm.com';
  ccmEmailId = 'manohar922@gmail.com';
  creName = this.dealerName;

  constructor(
    private dialogRef: MatDialogRef<PcDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: PcDialogModel,
    private lead360Service: Lead360Service
  ) {}

  ngOnInit() {     
    this.contentData = this.dialogData;
   
    if (this.contentData.dialogType === PCEnums.pcDialogType.PROMPT) {
      if (this.contentData.responseData) {
        this.dialogConfirmationControl.setValue(this.contentData.responseData);
      }
    } else if (this.contentData.dialogType === PCEnums.pcDialogType.EMAIL) {
      this.dialogData.email.templateTypes.forEach(emailData => {
        const type = emailData['Name'];
        let obj = { key: type.replace('_', ' '), value: type };
        this.nodeTypeSelectData.push(obj);
      });
    }else if (this.contentData.dialogType === PCEnums.pcDialogType.SMS) {
    }
  }



  save() {
    let resultData: boolean | PcDialogModel;

    // if type===PROMPT
    if (this.contentData.dialogType === PCEnums.pcDialogType.PROMPT) {
      // , and the input field is invalid, just RETURN
      if (this.dialogConfirmationControl.invalid) {
        this.dialogConfirmationControl.markAsDirty();
        return;
      }

      // , and the input field is EMPTY or conatins only spaces, just RETURN
      if (this.dialogConfirmationControl.value.trim().length <= 0) {
        this.dialogConfirmationControl.setValue('');
        this.dialogConfirmationControl.markAsDirty();
        return;
      }

      // , and the input field is invalid, just RETURN
      this.responseData = {
        responseData: this.dialogConfirmationControl.value.trim(),
        dialogType: this.contentData.dialogType
      };
      resultData = this.responseData;
    } else if (this.contentData.dialogType === PCEnums.pcDialogType.DROP_DOWN) {
      // if type===DROP_DOWN
      if (this.pcSelectControl.invalid) {
        this.pcSelectControl.markAsDirty();
        return;
      }

      if (this.pcSelectControl.value.trim().length <= 0) {
        this.pcSelectControl.setValue('');
        this.pcSelectControl.markAsDirty();
        return;
      }

      this.responseData = {
        responseData: this.pcSelectControl.value.trim(),
        dialogType: this.contentData.dialogType
      };
      resultData = this.responseData;
    } else if (this.contentData.dialogType === PCEnums.pcDialogType.EMAIL) {
      const emailId = this.dialogData.email.emailId;
      const templateName = this.pcSelectControl.value.trim();
      const emailSubject = this.emailSubject;
      const emailText = this.emailText;

      const emailDataToReturn = {
        emailId: emailId,
        templateName: templateName,
        emailSubject: emailSubject,
        emailText: emailText
      };

      this.responseData = {
        responseData: JSON.stringify(emailDataToReturn),
        dialogType: this.contentData.dialogType
      };
      resultData = JSON.parse(this.responseData.responseData);
    } else if (this.contentData.dialogType === PCEnums.pcDialogType.SMS) {
      const smsData = {
        Message: this.dialogConfirmationControl.value.trim(),
        PhoneNumber: this.phoneNumberControl.value.trim()
      };
      this.responseData = {
        responseData: JSON.stringify(smsData),
        dialogType: this.contentData.dialogType
      };
      resultData = JSON.parse(this.responseData.responseData);
    } else {
      resultData = true;
    }

    this.dialogRef.close(resultData);
  }

  close() {
    this.dialogRef.close(false);
  }
}
