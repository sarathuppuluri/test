import { Injectable } from '@angular/core';
import { PcDialogModel } from './pc-dialog-model';
import { MatDialogRef, MatDialog } from '@angular/material';
import { PcDialogComponent } from './pc-dialog.component';
import { PCEnums } from './pc-dialog-enums';

@Injectable({
  providedIn: 'root'
})
export class PcDialogService {

  private dialogData: PcDialogModel;
  private dialogRef: MatDialogRef<PcDialogComponent>;

  constructor(
    private dialog: MatDialog,
  ) { }

  /**
   * Expects an INPUT to be present
   */
  prompt(data: PcDialogModel) {
    this.dialogData = data;
    this.dialogData.dialogType = PCEnums.pcDialogType.PROMPT;
    return this.openDialog();
  }

  alert(data: PcDialogModel) {
    this.dialogData = data;
    this.dialogData.dialogType = PCEnums.pcDialogType.ALERT;
    return this.openDialog();
  }

  confirm(data: PcDialogModel) {
    this.dialogData = data;
    this.dialogData.dialogType = PCEnums.pcDialogType.CONFIRM;
    return this.openDialog();
  }

  dropdown(data: PcDialogModel) {
    this.dialogData = data;
    this.dialogData.dialogType = PCEnums.pcDialogType.DROP_DOWN;
    return this.openDialog();
  }

  email(data: PcDialogModel) {
    this.dialogData = data;
    this.dialogData.dialogType = PCEnums.pcDialogType.EMAIL;
    return this.openDialog();
  }

  sms(data: PcDialogModel) {
    this.dialogData = data;
    this.dialogData.dialogType = PCEnums.pcDialogType.SMS;
    return this.openDialog();
  }


  private openDialog() {
    if (this.dialogRef) {
      this.dialogRef.close();
    }
    this.dialogRef = this.dialog.open(PcDialogComponent, {
      width: '35em',
      height:'70em',
      data: this.dialogData,
      closeOnNavigation: true,
      disableClose: this.dialogData.disableClose
    });
    this.dialogRef.afterClosed().subscribe(res => { });
    return this.dialogRef;
  }
}
