export interface PcDialogModel {
    disableClose?: boolean;
    titleString?: string;
    messageString?: string;
    responseData?: string;
    placeholderString?: string;
    okButtonString?: string;
    cancelButtonString?: string;
    dialogType?: number;
    maxLength?: number;
    email?: emailDialogModel;
    phoneNo?: string;
}

export interface emailDialogModel {
    emailTemplate?: string;
    emailId?: string;
    templateTypes?: emailData[]
}

export interface emailData {
    templateName: string;
    subjectName: string;
    emailText: string;
}