// Angular
import { Component, OnInit, OnDestroy, AfterViewInit, ViewChild, HostListener, ElementRef, Inject, Pipe, PipeTransform, Input, ChangeDetectorRef } from '@angular/core';
import { multi } from './data';
import { Lead360Service, EnquiryService, MyRolesService, PreenquiryService } from '../../../core/e-commerce/_services';
import { Router, ActivatedRoute } from '@angular/router';
//import { AppService } from '../../app.service';
import { PcDialogService } from './pc-dialog/pc-dialog.service';
//import { PcDialogService } from 'src/app/shared/pc-dialog/pc-dialog.service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { FieldConfig } from './dynamic-form/models/field-config.interface';
import { DynamicFormComponent } from './dynamic-form/containers/dynamic-form/dynamic-form.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material/dialog';
import { filter, startWith, map, switchMap } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Observable, Subscription } from 'rxjs';
import { relative } from 'path';
import { TdTestappointmentComponent } from './booking-testdrive/tdappointment.component';
import { EvaluatorPopUpComponent } from './evaluator-screen/evaluator-popup.component';
import { TestDriveDialogData } from './lead360.models';
import { EditEvaluatorComponent } from './evaluator-screen/evaluator-edit/evaluator-edit.component';
import moment from 'moment';
import { FinanceEditDialogComponent } from './financeDocs/finance-edit.dialog.component.ts/finance-edit.dialog.component.ts.component';
import { VerifyDocsEditDialogComponent } from './verify-docs-edit.dialog/verify-docs-edit.dialog.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NotificationService } from '../../../core/e-commerce/_services/notification.service';


@Component({
	selector: 'kt-lead360',
	templateUrl: './lead360.component.html',
	styleUrls: ['lead360.component.scss'],
})

export class Lead360Component implements OnInit, OnDestroy {

	dropClicked = false;
	dropLeadDetails: any = { dmsLeadDropInfo: {} };
	DropEnquiryForm: FormGroup;
	newleadsFormGroup: FormGroup;
	loginEmployee: any;

	// Subscriptions
	private subscriptions: Subscription[] = [];

	//@Input() taskObj:task;
	currentTaskId: number;
	userName: string;
	screenHeight: any;
	screenWidth: any;
	temptaskType: string;
	//pcDialogService: any;
	@HostListener('window:resize', ['$event'])
	onResize(event?) {
		this.screenHeight = window.innerHeight + 'px';
		this.screenWidth = window.innerWidth - 200 + "px";
	}
	isLinear = true;

	leadDetails: any;
	formdata: object;
	EnquiryEditForm2: FormGroup;
	EnquiryEditForm6: FormGroup;
	financeData: any;


	panelOpenState = false;
	hasLoaded: any = false;
	personalInfo: any;
	getLeadData: any = {};
	getContactOrAccount: any = {};
	postOnRoadPriceTable: any = {};
	// getEmpAllocation: any = [];



	showMoreTimeline: boolean = false;

	VechilesDetailsFormGroup: FormGroup;
	vechilesData: any = [];
	variantsList: any = [];
	vechilePriceList: any = [];
	VehicleComparision: any = [];
	LatestOffers: any = [];
	KnowledgeArticle: any = [];
	VechileOffersList: any = [];
	organizationId: number = 1;

	activiteFollowUpFormGroup: FormGroup;
	activiteDynamicData: any = [];

	txtTaskSearch: string; // input variable for task search
	txtTaskSearchUpNext: string;
	EnquiryFormGroup: FormGroup;
	taskType: string = 'followup';
	universalId: string = '';
	testDrivePopupData: TestDriveDialogData[] = [];
	totalLapsedDays: number;
	startDate;
	leadObject: any = {};
	employeesManualList: any = [];
	dseAllocated: string;



	//@ViewChild('widgetsContent', { static: false }) widgetsContent: ElementRef;
	@ViewChild('widgetsContent9', { static: false, read: ElementRef }) public widgetsContent9: ElementRef<any>;
	@ViewChild('widgetsContent', { static: false, read: ElementRef }) public widgetsContent: ElementRef<any>;
	//@ViewChild('widgetsContent', { read: ElementRef }) public widgetsContent: ElementRef<any>;

	public scrollRight1(): void {
		this.widgetsContent9.nativeElement.scrollTo({ left: (this.widgetsContent9.nativeElement.scrollLeft + 150), behavior: 'smooth' });
	}

	public scrollLeft1(): void {
		this.widgetsContent9.nativeElement.scrollTo({ left: (this.widgetsContent9.nativeElement.scrollLeft - 150), behavior: 'smooth' });
	}

	public scrollRight(): void {
		this.widgetsContent.nativeElement.scrollTo({ left: (this.widgetsContent.nativeElement.scrollLeft + 150), behavior: 'smooth' });
		//this.widgetsContent.nativeElement.scrollLeft += 150;
	}

	public scrollLeft(): void {
		this.widgetsContent.nativeElement.scrollTo({ left: (this.widgetsContent.nativeElement.scrollLeft - 150), behavior: 'smooth' });
		//this.widgetsContent.nativeElement.scrollLeft -= 150;
	}

	@ViewChild(DynamicFormComponent, { static: false }) form: DynamicFormComponent;
	data: any = "financeForm";
	configDynamicFields: FieldConfig[] = [];

	workflowProcess: any = [];

	employeeTimeline: any = [];
	$filterTimeLine: any = [];
	$filterTimeLineUpNext: any = [];
	taskHistoryObj: any = [];
	constructor(
		private router: Router,
		private lead360Service: Lead360Service,
		private pcDialogService: PcDialogService,
		private notificationService: NotificationService,
		private preEnquiryService: PreenquiryService,
		private enquiryservice: EnquiryService,
		private _formBuilder: FormBuilder,
		private fb: FormBuilder,
		public dialog: MatDialog,
		private _snackBar: MatSnackBar,
		private modalService: NgbModal,
		private changeDetectorRef: ChangeDetectorRef
	) {
		this.onResize();
		this.startDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
	}

	follwUpForm() {
		this.activiteFollowUpFormGroup = this.fb.group({
			entityStatus: [''],
			reason: [''],
			customerRemarks: [''],
			employeeRemarks: [''],
			taskStatus: ['Select'],
			actualStartDate: [''],
			actualEndDate: [''],
		});

	}

	enquiryForm() {
		this.newleadsFormGroup = this.fb.group({
			employee: ['']
		});

		this.VechilesDetailsFormGroup = this.fb.group({
			model: ['Select'],
			variant: ['Select'],
			color: ['Select'],
			fuel: ['Select'],
			transmissionType: ['Select'],
			testDrive: ['']
		});

		this.EnquiryEditForm2 = this.fb.group({
			pincode: [''],
			houseNo: [''],
			street: [''],
			address: [''],
			village: [''],
			city: [''],
			district: [''],
			state: [''],
			preferredBillingAddress: ['']
		});

		this.DropEnquiryForm = this.fb.group({
			dropReason: [''],
			dealerName: [''],
			brandName: [''],
			otherReason: [''],
			additionalRemarks: [''],
			location: [''],
			model: ['']
		});
	}

	openDialog() {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		dialogConfig.width = '600px';
		//dialogConfig.height='480px';
		dialogConfig.data = {
			id: this.getLeadData.id,
			firstName: this.getContactOrAccount.firstName,
			lastName: this.getContactOrAccount.lastName,
			middleName: this.getContactOrAccount.middleName,
			universalId: this.universalId,
		};

		const dialogRef = this.dialog.open(CreateTimelineDialog, dialogConfig);

		dialogRef.afterClosed().subscribe(result => {
			if (result === 'success') {
				this.getEmployeeTimelines();
			}
		});
	}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.activiteDynamicData = this.lead360Service.selectedTaskObj;
		this.currentTaskId = this.activiteDynamicData.taskId;
		if (this.currentTaskId) {
			this.getCurruntTaskById();
			this.getAllTaskHistoryById(this.currentTaskId);
		}
		this.lead360Service.selectedTaskObj = {};
		if (this.activiteDynamicData.universalId) {
			this.universalId = this.activiteDynamicData.universalId;
		}

		if (this.activiteDynamicData.taskType === "Manual" || this.activiteDynamicData.taskType === "General") {
			this.follwUpForm();
			this.configDynamicFields = [{
				type: 'input',
				label: 'Reason',
				name: 'reason',
				placeholder: 'Enter Reason',
				inputtype: 'text'
			}, {
				type: 'input',
				label: 'Customer Remarks',
				name: 'customerRemarks',
				placeholder: 'Enter Customer Remarks',
				inputtype: 'text'
			}, {
				type: 'input',
				label: 'Employee Remarks',
				name: 'employeeRemarks',
				placeholder: 'Enter Employee Remarks',
				inputtype: 'text'
			}, {
				label: 'Submit',
				name: 'submit',
				type: 'button',
			}];
		}

		this.userName = /*JSON.parse(localStorage.getItem('loginEmployee')).empName*/ this.loginEmployee.empName;
		this.enquiryForm();

		this.enquiryservice.getLeadByUniversalID(this.universalId).subscribe(res => {
			if (!res) {
				return;
			}
			this.leadObject = res.dmsEntity;
			this.getContactOrAccount = this.leadObject.dmsContactDto ? this.leadObject.dmsContactDto : this.leadObject.dmsAccountDto;
			this.getLeadData = this.leadObject.dmsLeadDto ? this.leadObject.dmsLeadDto : [];
			this.dseAllocated = this.getLeadData.salesConsultant;
			if (!this.getLeadData.dmsfinancedetails) {
				this.getLeadData['dmsfinancedetails'] = [];
			}
			if (!this.getLeadData.dmsAddresses) {
				this.getLeadData['dmsAddresses'] = [];
			}

			if (this.leadObject.dmsLeadDto.dmsAddresses.length > 0) {
				if (this.leadObject.dmsLeadDto.dmsAddresses[0].preferredBillingAddress === 'Communication') {
					this.EnquiryEditForm2.patchValue(this.leadObject.dmsLeadDto.dmsAddresses[0]);
				} else {
					this.EnquiryEditForm2.patchValue(this.leadObject.dmsLeadDto.dmsAddresses[1]);
				}
			}

			if (!this.getLeadData.dmsLeadProducts) {
				this.getLeadData['dmsLeadProducts'] = [];
			}
			if (!this.getLeadData.dmsExchagedetails) {
				this.getLeadData['dmsExchagedetails'] = [];
			}
			if (!this.getLeadData.dmsLeadScoreCards) {
				this.getLeadData['dmsLeadScoreCards'] = [];
			}

			// get OnRoadPrice Table Posted Data
			this.enquiryservice.getOnRoadPricePosted(this.leadObject.dmsLeadDto.id).subscribe(response => {
				if (response.dmsEntity.dmsOnRoadPriceDtoList.length > 0) {
					this.postOnRoadPriceTable = response.dmsEntity.dmsOnRoadPriceDtoList[0];
				}
			});
			this.EnquiryEditForm2.disable();
			this.changeDetectorRef.detectChanges();
		});
		this.getWorkflowProcess();
		//To get Employee Timelines
		this.getEmployeeTimelines();

		//this.lead360Service.getLead360Details();
		this.lead360Service.leadData.subscribe((data) => {
			this.leadDetails = this.lead360Service.leadDetails;
		});

		this.lead360Service.financeDataSubject.subscribe((data) => {
			this.formdata = this.lead360Service.financeData.financeDetails[0];
		});

		this.lead360Service.taskActivityDataSubject.subscribe((data) => {
			if (this.lead360Service.taskActivityData.dmsEntity[0].taskName === "FollowUp") {

			}
			else if (this.lead360Service.taskActivityData.dmsEntity[0].taskName === "FinanceDetails") {

			}
		});

		this.getVehicleDetails();
	}

	assignBillingAddress(i) {
		this.EnquiryEditForm2.patchValue(this.leadObject.dmsLeadDto.dmsAddresses[i]);
		if (i === 0) {
			this.EnquiryEditForm2.patchValue({ preferredBillingAddress: 'Communication' });
		} else {
			this.EnquiryEditForm2.patchValue({ preferredBillingAddress: '' });
		}
	}

	getAllTaskHistoryById(taskId) {
		this.lead360Service.getTaskHistoryById(taskId).subscribe((res) => {
			if (res.success == true) {
				this.taskHistoryObj = res.dmsEntity.dmsTaskHistoryList;
				this.taskHistoryObj.reverse();
				this.changeDetectorRef.detectChanges();
			}
		});
	}

	ngOnDestroy(): void {
		// Called once, before the instance is destroyed.
		// Add 'implements OnDestroy' to the class.
		this.subscriptions.forEach(el => el.unsubscribe());
	}

	getCurruntTaskById() {
		this.lead360Service.getCurruntTaskById(this.currentTaskId).subscribe((res: any) => {
			this.activiteDynamicData = res.dmsEntity.task;
			this.activiteFollowUpFormGroup.patchValue(this.activiteDynamicData);
			this.patchForm();
		});
	}
	public patchForm() {
		this.activiteFollowUpFormGroup.controls['actualStartDate'].setValue((new Date(this.activiteDynamicData.taskActualStartTime ? this.activiteDynamicData.taskActualStartTime : this.startDate)).toISOString());
		this.activiteFollowUpFormGroup.controls['actualEndDate'].setValue((new Date(this.activiteDynamicData.taskActualEndTime ? this.activiteDynamicData.taskActualEndTime : this.startDate)).toISOString());
	}
	//To get Workflow Process (stages)

	getWorkflowProcess() {
		this.lead360Service.getStatusOfStages(this.universalId).subscribe((res) => {
			if (res.success == true) {
				this.workflowProcess = [];
				res.dmsEntity.processes.forEach(e => {
					this.workflowProcess.push(new WorkflowProcessDetails(e.processId, e.processName, e.tasks, e.tasks, e.processStatus, e.processUpdatedTime, e));
				});
				this.changeDetectorRef.detectChanges();
			} else {
				this.openSnackBar(res.errorMessage, "Fail");
			}
		});
	}

	//To get employeeTimelines
	getEmployeeTimelines() {
		this.lead360Service.fetchTaskByLeadUniversalId(this.universalId).subscribe((res) => {
			this.employeeTimeline = res.dmsEntity.tasks;

			this.$filterTimeLine = this.employeeTimeline;
			this.$filterTimeLineUpNext = this.employeeTimeline;

			this.changeDetectorRef.detectChanges();
		});
	}

	getCustomerRemarksForStagePopup(taskObj) {
		let remarks = taskObj[taskObj.length - 1];
		return remarks.customerRemarks;
	}
	getEmployeeRemarksForStagePopup(taskObj) {
		let remarks = taskObj[taskObj.length - 1];
		return remarks.employeeRemarks;
	}
	getExecutionJobForStagePopup(taskObj) {
		let remarks = taskObj[taskObj.length - 1];
		return remarks.executionJob;
	}



	// VehicleComparision:any=[];
	// LatestOffers:any=[];
	// KnowledgeArticle:any=[];
	getVehicleDetails() {
		this.lead360Service.getAllVehicleDetails(1).subscribe((data) => {
			this.vechilesData = data;
			if (this.vechilesData.length > 0) {
				let currentModel = this.vechilesData[0];
				if (this.getLeadData.dmsLeadProducts && this.getLeadData.dmsLeadProducts.length > 0 && this.getLeadData.dmsLeadProducts[0].model != "") {
					for (let vechileObj of this.vechilesData) {
						if (vechileObj.model == this.getLeadData.dmsLeadProducts[0].model) {
							currentModel = vechileObj
						}
					}
				}
				this.VechilesDetailsFormGroup.patchValue({
					model: currentModel
				});
				this.VehicleComparision = this.vechilesData[0].vehicleEdocuments[0].edocument;
			}
			this.changeVechileModel();
		});
	};
	changeVechileModel() {
		this.variantsList = [];
		let selectedModel = this.VechilesDetailsFormGroup.controls.model.value;
		if ((selectedModel.model === null) || (selectedModel.model === 'Select')) {
			setTimeout(() => {
				this.changeVechileModel();
			}, 100);
		} else {
			let tempData = this.vechilesData.filter(record => record.model === selectedModel.model)
				.map(obj => {
					return {
						'variantsList': obj.varients,
						'colorsList': obj.vehicleImages
					}
				})[0]
			tempData = tempData;
			this.VehicleComparision = selectedModel['vehicleEdocuments'][0].edocument;
			this.variantsList = tempData.variantsList || [];
			this.VechileOffersList = [];
			this.changeVariant();
		}
	}
	changeVariant() {
		let selectedVariant = this.VechilesDetailsFormGroup.controls.variant.value;
		let selectedModel = this.VechilesDetailsFormGroup.controls.model.value;

		if (selectedVariant.id && selectedVariant.id != '') {
			this.lead360Service.getVehicleOnRoadPrice(1, selectedVariant.id).subscribe((data) => {
				this.vechilePriceList = data;
				this.getVehicleOffers(this.organizationId, selectedVariant.id, selectedModel.vehicleId);
			});
		}
		else {
			this.vechilePriceList = [];
			this.VechileOffersList = [];
		}

	}
	getVehicleOffers(orgId, varientId, vehicleId) {
		this.lead360Service.getVehicleOffers(orgId, varientId, vehicleId).subscribe((data) => {
			this.VechileOffersList = data;
			this.changeDetectorRef.detectChanges();
		});
	}

	stageTooltipOptions = {
		'placement': 'bottom',
		'show-delay': 10
	}

	showMoreAboutStage(stage) {
		const html = stage.processName;
		const div = document.createElement('div');
		div.innerHTML = html;
		return div.textContent || div.innerText || '';
	}
	sendEmail(event){}

	sendEmailViaSES(emailData) {
		if (!emailData) {
			return;
		}
		const toEmails = [];
		toEmails.push(emailData.emailId);
		const emaiObject = {
			to: toEmails,
			from: this.loginEmployee.branchEmail,
			fromName: this.loginEmployee.orgName,
			contentType: "html",
			content: emailData.emailText,
			subject: emailData.emailSubject,
		};
		this.notificationService.sendEmail(emaiObject).subscribe(response => {
		});
	}

	sendSMS(pno) {
		let phpneno: string;
		if (pno != '') {
			phpneno = pno
		}
		const smsObject = {
			dialogType: 5,
			phoneNo: phpneno
		};
		this.pcDialogService.sms(smsObject).afterClosed().subscribe(result => {
			const msgData = {
				message: result.Message,
				messageType: "",
				phoneNumber: result.PhoneNumber,
				senderId: "",
			};
			this.notificationService.sendSMS(msgData).subscribe(res => {
			});
		}, err => {
			console.log(err);
		});
	}

	calculateDiff(idx, st_date, end_date) {
		if (st_date != undefined && end_date != undefined) {
			let difference = st_date - end_date;
			difference = Math.abs(Math.round(difference));
			let one_day = 1000 * 60 * 60 * 24;
			let days = Math.abs(Math.round(difference / one_day));
			this.totalLapsedDays = this.totalLapsedDays + days;
			if (days == 1)
				return days + " day";
			else
				return days + " days";
		}
		else {
			return "";
		}
	}

	getStartTimeOfStages(idx, processActualEndTime) {
		let stDate = null;
		if (idx == 0) {
			stDate = this.workflowProcess[idx].stage.processCreatedTime;
			let dt = moment(stDate).format(" MMM DD, YYYY, h:mm:ss A");
			return dt;
		} else {
			this.workflowProcess.forEach((element, index) => {
				if (idx == index) {
					stDate = this.workflowProcess[idx - 1];
				}
			});
			let dt = moment(stDate.stage.processActualEndTime).format(" MMM DD, YYYY, h:mm:ss A");
			return dt;
		}
	}

	filterByName(event: any, taskname) {
		if (taskname != '' && this.employeeTimeline.length > 0) {
			this.$filterTimeLine = this.employeeTimeline.filter(data => data.taskName.toLowerCase().includes(taskname.toLowerCase()));
		} else {
			this.$filterTimeLine = this.employeeTimeline;
		}
	}

	filterByNameUpNext(event: any, taskname) {
		if (taskname != '' && this.employeeTimeline.length > 0) {
			this.$filterTimeLineUpNext = this.employeeTimeline.filter(data => data.taskName.toLowerCase().includes(taskname.toLowerCase()));
		} else {
			this.$filterTimeLineUpNext = this.employeeTimeline;
		}
	}

	sortList() {
		this.$filterTimeLine = this.$filterTimeLine.reverse();
	}

	// For DSE Allocation -- On Click of Create Enquiry
	allocateDSE(taskCategory, taskName, status, content) {
		const empSource = this.preEnquiryService.getEmployeesSource(this.leadObject.dmsLeadDto.sourceOfEnquiry).subscribe(res => {
			if (res.dmsEntity.employeeDTOs.length === 0) {
				this.saveActivityCreateEnquiry(taskCategory, taskName, status)
			} else {
				this.employeesManualList = res.dmsEntity.employeeDTOs;
				this.openLargeEmployee(content);
			}
		});
		this.subscriptions.push(empSource);
	}

	// Modal Open Employee
	openLargeEmployee(content) {
		this.modalService.open(content, {
			size: 'md'
		});
	}

	saveActivityCreateEnquiry(taskCategory, taskName, status) {
		let objNewFollowUpActivity = this.activiteDynamicData;
		objNewFollowUpActivity.taskStatus = status;
		this.lead360Service.saveFollowUpActivity(objNewFollowUpActivity).subscribe(
			(result) => {
				if (result['success']) {
					if (status == 'CLOSED') {
						this.leadStageUpdate(taskCategory, this.activiteDynamicData.universalId);
					}
					this.openSnackBar(this.activiteDynamicData.taskCategory.taskCategory + " Activity has been submited successfully.", "success");
					this.getWorkflowProcess();
					this.getEmployeeTimelines();
					this.getCurruntTaskById();
				}
				else {
					this.openSnackBar("Oops! Activity has not been submited.", "fail");
				}
			}, err => {
				this.openSnackBar(err['message'], err["status"]);
			});
	}

	sendEmployee(taskCategory, taskName, status) {
		this.leadObject.dmsLeadDto.salesConsultant = this.newleadsFormGroup.controls.employee.value;
		const empSource = this.preEnquiryService.sendEmployeesSource(this.leadObject.dmsLeadDto).subscribe(res => {
			this.saveActivityCreateEnquiry(taskCategory, taskName, status)
		});
		this.subscriptions.push(empSource);
	}

	leadStageUpdate(stage, universalId) {
		this.lead360Service.leadStageUpdate(stage, universalId).subscribe(
			(result) => {
				if (result['success']) {
					this.openSnackBar(this.activiteDynamicData.taskCategory.taskCategory + " stage has been updated successfully.", "success");
					if (stage === 'ENQUIRY') {
						this.modalService.dismissAll();
					}
					const refBody = {
						branchid: this.loginEmployee.branchId,
						leadstage: stage,
						orgid: this.loginEmployee.orgId
					}
					const refNumber = this.enquiryservice.sendOrgBranchStageRef(refBody).subscribe(refNo => {
						if (refNo.success === true) {
							this.leadObject.dmsLeadDto.leadStage = stage;
							this.leadObject.dmsLeadDto.referencenumber = refNo.dmsEntity.leadCustomerReference.referencenumber;
							const sendLeadEnq = this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
							});
							this.subscriptions.push(sendLeadEnq);
						}
					});
					this.subscriptions.push(refNumber);
				}
				else {
					this.openSnackBar("Oops! stage has not been updated.", "fail");
				}
			},
			(err) => {
				this.openSnackBar(err['message'], err["status"]);
			}
		);

	}

	saveActivity(taskCategory, taskName, status) {
		let objNewFollowUpActivity = this.activiteDynamicData;
		if (taskName != 'Create Enquiry') {
			objNewFollowUpActivity.reason = this.activiteFollowUpFormGroup.value.reason;
			objNewFollowUpActivity.customerRemarks = this.activiteFollowUpFormGroup.value.customerRemarks;
			objNewFollowUpActivity.employeeRemarks = this.activiteFollowUpFormGroup.value.employeeRemarks;
		}
		objNewFollowUpActivity.taskStatus = status;
		this.lead360Service.saveFollowUpActivity(objNewFollowUpActivity).subscribe(
			(result) => {
				if (result['success']) {
					if (this.activiteDynamicData.lastTask == true) {
						this.leadStageUpdate(taskCategory, this.activiteDynamicData.universalId);
					}
					this.openSnackBar(this.activiteDynamicData.taskCategory.taskCategory + " Activity has been submited successfully.", "success");
					this.getWorkflowProcess();
					this.getEmployeeTimelines();
					this.getCurruntTaskById();
					this.changeDetectorRef.detectChanges();
				}
				else {
					this.openSnackBar("Oops! Activity has not been submited.", "fail");
				}
			},
			(err) => {
				this.openSnackBar(err['message'], err["status"]);
			}
		);
	}

	saveActivityFollowUp(taskCategory, taskName, status) {
		if (this.activiteFollowUpFormGroup.value.employeeRemarks === '' || this.activiteFollowUpFormGroup.value.employeeRemarks === null) {
			this.openSnackBar("Employee Remarks should not be empty.", "");
			return "";
		}
		let objNewFollowUpActivity = this.activiteDynamicData;
		objNewFollowUpActivity.reason = this.activiteFollowUpFormGroup.value.reason;
		objNewFollowUpActivity.customerRemarks = this.activiteFollowUpFormGroup.value.customerRemarks;
		objNewFollowUpActivity.employeeRemarks = this.activiteFollowUpFormGroup.value.employeeRemarks;
		objNewFollowUpActivity.taskStatus = status;
		objNewFollowUpActivity.entityStatus = this.activiteFollowUpFormGroup.value.entityStatus;
		objNewFollowUpActivity.taskUpdatedTime = Date.parse(Date());
		if (status == 'RESCHEDULED') {
			if (this.activiteFollowUpFormGroup.value.actualStartDate == null || this.activiteFollowUpFormGroup.value.actualStartDate == "1970-01-01T00:00:00.000Z") {
				this.openSnackBar("Actual Start Date should not be empty.  (or) should not be invalid", "");
				return "";
			}
			if (this.activiteFollowUpFormGroup.value.actualEndDate == null || this.activiteFollowUpFormGroup.value.actualStartDate == "1970-01-01T00:00:00.000Z") {
				this.openSnackBar("Actual End Date should not be empty.  (or) should not be invalid", "");
				return "";
			}
			if ((Date.parse(this.activiteFollowUpFormGroup.value.actualEndDate) - Date.now()) < 0) {
				this.openSnackBar("Actual End Date should not be less than Today.  (or) should not be invalid", "");
				return "";
			}
			objNewFollowUpActivity.taskActualStartTime = Date.parse(this.activiteFollowUpFormGroup.value.actualStartDate);
			objNewFollowUpActivity.taskActualEndTime = Date.parse(this.activiteFollowUpFormGroup.value.actualEndDate);
		}

		this.lead360Service.saveFollowUpActivity(objNewFollowUpActivity).subscribe((result) => {
			if (result['success']) {
				if (this.activiteDynamicData.lastTask == true) {
					this.leadStageUpdate(taskCategory, this.activiteDynamicData.universalId);
				}
				this.openSnackBar(this.activiteDynamicData.taskCategory.taskCategory + " Activity has been submited successfully.", "success");
				this.getWorkflowProcess();
				this.getEmployeeTimelines();
				this.getCurruntTaskById();
				this.getAllTaskHistoryById(this.currentTaskId);
				this.changeDetectorRef.detectChanges();
			}
			else {
				this.openSnackBar("Oops! Activity has not been submited.", "fail");
			}
		},
			(err) => {
				this.openSnackBar(err['message'], err["status"]);
			}
		);

	}

	saveActivityHomeVisit(status) {
		if (this.activiteFollowUpFormGroup.value.employeeRemarks.trim() == "") {
			this.openSnackBar("Employee Remarks should not be empty.", "");
			return "";
		}

		const requestBody = {
			"universalId": this.activiteDynamicData.universalId,
			"taskId": this.activiteDynamicData.taskId,
			"remarks": this.activiteFollowUpFormGroup.value.employeeRemarks,
			"universalModuleId": "",
			"expectedStarttime": Date.parse(Date()),
			"status": status,
			"expectedEndTime": Date.parse(Date())
		}

		this.lead360Service.saveHomeVisitActivity(requestBody).subscribe(
			(result) => {
				if (result['success']) {
					this.openSnackBar(this.activiteDynamicData.taskCategory.taskCategory + " Activity has been submited successfully.", "success");
					this.getWorkflowProcess();
					this.getEmployeeTimelines();
					this.getCurruntTaskById();
				}
				else {
					this.openSnackBar("Oops! Activity has not been submited.", "fail");
				}
			},
			(err) => {
				this.openSnackBar(err['message'], err["status"]);
			}
		);

	}

	saveActivityEvalution(status) {
		if (this.activiteFollowUpFormGroup.value.employeeRemarks.trim() == "") {
			this.openSnackBar("Employee Remarks should not be empty.", "");
			return "";
		}

		const requestBody = {
			"universalId": this.activiteDynamicData.universalId,
			"taskId": this.activiteDynamicData.taskId,
			"remarks": this.activiteFollowUpFormGroup.value.employeeRemarks,
			"universalModuleId": "",
			"expectedStarttime": Date.parse(Date()),
			"status": status,
			"expectedEndTime": Date.parse(Date())
		}

		this.lead360Service.saveEvalutionActivity(requestBody).subscribe(
			(result) => {
				if (result['success']) {
					this.openSnackBar(this.activiteDynamicData.taskCategory.taskCategory + " Activity has been submited successfully.", "success");
					this.getWorkflowProcess();
					this.getEmployeeTimelines();
					this.getCurruntTaskById();
				}
				else {
					this.openSnackBar("Oops! Activity has not been submited.", "fail");
				}
			},
			(err) => {
				this.openSnackBar(err['message'], err["status"]);
			}
		);

	}

	saveActivityFinance(status) {
		if (this.activiteFollowUpFormGroup.value.employeeRemarks.trim() == "") {
			this.openSnackBar("Employee Remarks should not be empty.", "");
			return "";
		}

		const requestBody = {
			"universalId": this.activiteDynamicData.universalId,
			"taskId": this.activiteDynamicData.taskId,
			"remarks": this.activiteFollowUpFormGroup.value.employeeRemarks,
			"universalModuleId": "",
			"expectedStarttime": Date.parse(Date()),
			"status": status,
			"expectedEndTime": Date.parse(Date())
		}

		this.lead360Service.saveFinanceActivity(requestBody).subscribe(
			(result) => {
				if (result['success']) {
					this.openSnackBar(this.activiteDynamicData.taskCategory.taskCategory + " Activity has been submited successfully.", "success");
					this.getWorkflowProcess();
					this.getEmployeeTimelines();
					this.getCurruntTaskById();
				}
				else {
					this.openSnackBar("Oops! Activity has not been submited.", "fail");
				}
			},
			(err) => {
				this.openSnackBar(err['message'], err["status"]);
			}
		);

	}

	// Drop Analysis
	dropEnquiry(stage, taskType) {
		this.dropLeadDetails.dmsLeadDropInfo.stage = stage;
		this.dropLeadDetails.dmsLeadDropInfo.status = stage;
		this.temptaskType = taskType;
		this.dropClicked = true;
	}

	// Proceed to Drop
	proceedToCancel() {
		this.dropLeadDetails.dmsLeadDropInfo.additionalRemarks = this.DropEnquiryForm.value.additionalRemarks;
		this.dropLeadDetails.dmsLeadDropInfo.branchId = this.loginEmployee.branchId;
		this.dropLeadDetails.dmsLeadDropInfo.brandName = this.DropEnquiryForm.value.brandName;
		this.dropLeadDetails.dmsLeadDropInfo.dealerName = this.DropEnquiryForm.value.dealerName;
		this.dropLeadDetails.dmsLeadDropInfo.enquiryCategory = this.DropEnquiryForm.value.enquiryCategory;
		this.dropLeadDetails.dmsLeadDropInfo.leadId = this.leadObject.dmsLeadDto.id;
		this.dropLeadDetails.dmsLeadDropInfo.lostReason = this.DropEnquiryForm.value.dropReason;
		this.dropLeadDetails.dmsLeadDropInfo.organizationId = this.loginEmployee.orgId;
		this.dropLeadDetails.dmsLeadDropInfo.otherReason = '';
		this.dropLeadDetails.dmsLeadDropInfo.droppedBy = this.loginEmployee.empId;
		this.dropLeadDetails.dmsLeadDropInfo.location = this.DropEnquiryForm.value.location;
		this.dropLeadDetails.dmsLeadDropInfo.model = this.DropEnquiryForm.value.model;

		const sendDropDet = this.enquiryservice.sendDropDetails(this.dropLeadDetails).subscribe(res => {
			if (res.statusCode === '200') {
				this.leadObject.dmsLeadDto.leadStage = 'DROPPED';
				const sendLeadEnq = this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
				});
				this.subscriptions.push(sendLeadEnq);
			}
			if (res.approver === this.loginEmployee.empName) {
				this.$filterTimeLineUpNext.forEach(element => {
					if (element.taskStatus === 'ASSIGNED' || element.taskStatus === 'SENT_FOR_APPROVAL') {
						element.taskStatus = (element.lastTask === true) ? 'CANCELLED' : 'CLOSED';
						this.lead360Service.saveFollowUpActivity(element).subscribe((result: any) => {
							this.getWorkflowProcess();
							this.getEmployeeTimelines();
							this.getCurruntTaskById();
							this.dropClicked = false;
							this.changeDetectorRef.detectChanges();
						});
					}
				});
			} else {
				this.saveActivity(this.dropLeadDetails.dmsLeadDropInfo.stage, this.temptaskType, 'SENT_FOR_APPROVAL')
				this.dropClicked = false;
			}
		});
		this.subscriptions.push(sendDropDet);
	}

	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 5000,
		});
	}


	/* Booking Appointment for Test Drive starts here */
	appointmentTestDrive() {

		let testDriveData: any = {};
		testDriveData['customerDetails'] = this.getContactOrAccount;
		testDriveData['modelDetails'] = this.getLeadData.dmsLeadProducts ? this.getLeadData.dmsLeadProducts[0] : '';
		testDriveData['dmsAddresses'] = this.getLeadData.dmsAddresses ? this.getLeadData.dmsAddresses : '';
		testDriveData['crmUniversalId'] = this.getLeadData.crmUniversalId;
		testDriveData['entityModuleId'] = this.activiteDynamicData.entityModuleId;

		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		dialogConfig.panelClass = 'testDrivePopup';
		dialogConfig.data = {
			mobileNo: this.getContactOrAccount.phone,
			firstname: this.getContactOrAccount.firstName,
			email: this.getContactOrAccount.email,
			modelName: this.getLeadData.dmsLeadProducts.length > 0 ? this.getLeadData.dmsLeadProducts[0].model : '',
			crmUniversalId: this.getLeadData.crmUniversalId,
			entityModuleId: this.activiteDynamicData.entityModuleId,
			response: '',
		};


		const dialogRef = this.dialog.open(TdTestappointmentComponent, dialogConfig);

		dialogRef.afterClosed().subscribe(result => {
			if (result == 'success') {
				this.getCurruntTaskById();
			}
		});
	}
	/* Booking Appointment for Test Drive ends here */

	/* Create Evaluation starts here */
	createEvaluation(taskStatus, taskCategory, taskName) {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		dialogConfig.panelClass = 'createEvaluationPopup';
		dialogConfig.data = {
			crmUniversalId: this.getLeadData.crmUniversalId,
			entityModuleId: this.activiteDynamicData.entityModuleId,
			taskStatus,
			taskCategory,
			taskName,
			response: '',
		};
		const dialogRef = this.dialog.open(EvaluatorPopUpComponent, dialogConfig);

		dialogRef.afterClosed().subscribe(result => {
			if (result == 'success') {
				this.getCurruntTaskById();
				this.getWorkflowProcess();
				this.getEmployeeTimelines();
			}
		});

	}
	/* Create Evaluation ends here */

	/* edit Evaluation starts here */
	editEvaluation(taskStatus, taskCategory, taskName) {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		//dialogConfig.width = '600px';
		dialogConfig.height = '50rem';
		dialogConfig.panelClass = 'editEvaluationPopup';
		dialogConfig.data = {
			crmUniversalId: this.getLeadData.crmUniversalId,
			entityModuleId: this.activiteDynamicData.entityModuleId,
			taskStatus,
			taskCategory,
			taskName,
			response: '',
		};
		const dialogRef = this.dialog.open(EditEvaluatorComponent, dialogConfig);

		dialogRef.afterClosed().subscribe(result => {
			if (result == 'success') {
				this.getCurruntTaskById();
				this.getWorkflowProcess();
				this.getEmployeeTimelines();
			}
		});

	}
	/* Edit Evaluation ends here */

	/**
	 * Finance Documents Upload
	 */
	financeDocsPopUp(taskStatus) {
		const dialogRef = this.dialog.open(FinanceEditDialogComponent, { data: { crmUniversalId: this.getLeadData.crmUniversalId, status: taskStatus } });
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			// this.openSnackBar("Oops! Activity has not been submited.", "fail");
		});
	}

	/**
	 * Verify Documents
	 */
	verifyDocsPopUp() {
		const dialogRef = this.dialog.open(VerifyDocsEditDialogComponent, { data: { crmUniversalId: this.getLeadData.crmUniversalId } });
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			// this.openSnackBar("Oops! Activity has not been submited.", "fail");
		});
	}

}



export class WorkflowProcessDetails {
	constructor(
		private processId: number,
		private processName: string,
		private tasks: string,
		private processactivityTasks: any,
		private processStatus: any,
		private processUpdatedTime: any,
		private stage: any,
	) { }
}
export class EmployeeTimelineDetails {
	constructor(
		private processId: number,
		private processName: string,
		private status: string,
		private processactivityTasks: any
	) { }
}

export interface DialogData {
	id: number;
	firstName: string;
	lastName: string;
	middleName: string;
	universalId: string;
}
export interface Book {
	id: number;
	name: string;
	writer: string
}



@Component({
	selector: 'create-timeline-dialog',
	templateUrl: './create-timeline-dialog.html',
	styleUrls: ['./lead360.component.scss'],
})
export class CreateTimelineDialog {

	activityFormGroup = this.formBuilder.group({
		//book: [null, Validators.required],
		taskName: [""],
		isActivityMandatory: [true, ''],
		selectProcessDefinition: [null, Validators.required],
		selectTaskDefinition: [null, Validators.required],
		startDate: [''],
		endDate: [''],
		remarks: [''],
		wonerName: [''],
		wonerId: [''],
		selectedOwner: [null, Validators.required]
	});
	startDate;
	searchMsg: string = "";
	leadObj: DialogData;


	selectedStates: string;
	//$allBooks: Observable<Book[]>;
	//$filteredBooks: Observable<Book[]>;

	processDefinitions: any = [];
	taskDefinitionsList: any = [];
	taskDefinitions: any = [];

	taskWoners: any = [];


	// Receive user input and send to search method**
	onKey(value) {
		//this.selectedStates = this.search(value);
	}
	constructor(
		private formBuilder: FormBuilder,
		private lead360Service: Lead360Service, private _snackBar: MatSnackBar,
		private myroleservice: MyRolesService,
		public dialogRef: MatDialogRef<CreateTimelineDialog>,
		@Inject(MAT_DIALOG_DATA) public data: any) {
		this.leadObj = data;
		this.startDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
	}

	ngOnInit() {
		this.lead360Service.getProcessDifinitions().subscribe((res) => {
			if (res.success == true) {
				this.processDefinitions = res.dmsEntity.processDefs.length > 0 ? res.dmsEntity.processDefs : [];
			}
		});
		this.lead360Service.getTaskDifinitions().subscribe((res) => {
			this.taskDefinitionsList = res.length > 0 ? res : [];
		});
	}

	changeProcessDefinition(selectedValue) {
		let selectedStage = this.activityFormGroup.controls.selectProcessDefinition.value;
		if (selectedStage.processDefId === 'undefined') {
			this.taskDefinitions = [];
		}
		else if (selectedStage == 0) {
			setTimeout(() => {
				this.taskDefinitions = [{ "taskDefId": "0", "taskName": "Others" }];
			}, 100);
		} else {
			this.taskDefinitions = [];
			this.taskDefinitionsList.forEach((element, index) => {
				if (element.processDefinitionId === selectedStage.processDefId) {
					this.taskDefinitions.push({
						taskDefId: element.taskDefId,
						taskName: element.taskName
					})
				}
			});
		}
	}

	onFormSubmit() {
		if (this.activityFormGroup.value.taskName.trim() == "") {
			this.openSnackBar("Activity name should not be empty.", "");
			return null;
		}
		if (this.activityFormGroup.value.selectedOwner == null) {
			this.openSnackBar("Please select task owner.", "");
			return null;
		}
		if (this.activityFormGroup.value.isActivityMandatory && this.activityFormGroup.value.selectTaskDefinition == null) {
			this.openSnackBar("Please select Task Definition", "");
			return null;
		}

		const objNewActivity = {
			"taskName": this.activityFormGroup.value.taskName,
			"assignee": this.activityFormGroup.value.selectedOwner,
			"entityId": this.leadObj.id,
			"mandatoryTask": this.activityFormGroup.value.isActivityMandatory,
			"taskCreatedTime": Date.parse(Date()),
			"taskExpectedStartTime": this.activityFormGroup.value.startDate,
			"taskExpectedEndTime": this.activityFormGroup.value.endDate,
			"processDefintionId": this.activityFormGroup.value.selectProcessDefinition.processDefId,
			"taskType": "General",
			"taskDefinitionId": this.activityFormGroup.value.selectTaskDefinition,
			"employeeRemarks": this.activityFormGroup.value.remarks,
			"universalId": this.leadObj.universalId,
		};

		this.lead360Service.saveActivity(objNewActivity).subscribe(
			(result) => {
				if (result['success']) {
					this.openSnackBar("Task has been created successfully.", "success");
					this.dialogRef.close('success');
				}
				else {
					this.openSnackBar("Oops! Task has not been created.", "fail");
					this.dialogRef.close();
				}
			},
			(err) => {
				console.log('result: ', err);
				this.openSnackBar(err['message'], err["status"]);
			}
		);

		//this.resetForm();
	}

	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 5000,
		});
	}
	resetForm() {
		this.activityFormGroup.reset();
	}

	onNoClick(): void {
		this.dialogRef.close();
	}

	searchWoner() {
		this.searchMsg = "";
		let empName = '', empId = '';
		if (this.activityFormGroup.value.wonerName == '' && this.activityFormGroup.value.wonerId == '') {
			this.searchMsg = 'Please enter Employee name or/and Employee Id';
			return "";
		}
		if (this.activityFormGroup.value.wonerId != '' && this.activityFormGroup.value.wonerId != null && this.activityFormGroup.value.wonerId != 'null') {
			empId = this.activityFormGroup.value.wonerId;
			this.searchMsg = '';
		}
		if (this.activityFormGroup.value.wonerName != '') {
			empName = this.activityFormGroup.value.wonerName;
			this.searchMsg = '';
		}

		if (empName != "" || empId != '') {
			this.myroleservice.getEmployeesNameOrId(empName, empId).subscribe(res => {
				if (res.success == true) {
					this.taskWoners = res.dmsEntity.employeeDTOs.length > 0 ? res.dmsEntity.employeeDTOs : [];
				}
			}, err => {
				// Do stuff whith your error
				this.searchMsg = err.error.message;
			},
				() => {
					// Do stuff after completion
				});
		}
		else {
			this.searchMsg = 'Please enter Employee name or/and Employee Id';
			return "";
		}

	}
	numericOnly(event): boolean { // restrict e,+,-,E characters in  input type number
		const charCode = (event.which) ? event.which : event.keyCode;
		if (charCode == 101 || charCode == 69 || charCode == 45 || charCode == 43) {
			return false;
		}
		return true;

	}

}
