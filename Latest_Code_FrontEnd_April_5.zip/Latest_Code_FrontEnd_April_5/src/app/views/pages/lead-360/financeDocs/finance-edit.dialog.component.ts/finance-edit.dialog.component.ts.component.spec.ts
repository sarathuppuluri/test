import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinanceEditDialogComponent } from './finance-edit.dialog.component.ts.component';

describe('FinanceEdit.Dialog.Component.TsComponent', () => {
  let component: FinanceEditDialogComponent;
  let fixture: ComponentFixture<FinanceEditDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FinanceEditDialogComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinanceEditDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
