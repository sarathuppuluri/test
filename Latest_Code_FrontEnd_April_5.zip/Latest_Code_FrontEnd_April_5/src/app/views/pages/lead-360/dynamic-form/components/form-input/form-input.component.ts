import { Component, ViewContainerRef } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';

@Component({
  selector: 'form-input',
  styleUrls: ['form-input.component.scss'],
  template: `
    <div class="col-12  row-space  dynamic-field form-input"  [formGroup]="group">
      <mat-form-field>
        <mat-label>{{ config.label }}</mat-label>
        <input  matInput
        [attr.type]="config.inputtype"
          [attr.placeholder]="config.placeholder"
          [formControlName]="config.name">
      </mat-form-field>
    </div>
  `
})
export class FormInputComponent implements Field {
  config: FieldConfig;
  group: FormGroup;
}
