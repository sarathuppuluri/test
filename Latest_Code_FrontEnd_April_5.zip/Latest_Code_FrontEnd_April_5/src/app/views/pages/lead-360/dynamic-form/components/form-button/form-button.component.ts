import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';

@Component({
  selector: 'form-button',
  styleUrls: ['form-button.component.scss'],
  template: `
<<<<<<< HEAD
    <div 
=======
    <br/><br/><div 
>>>>>>> 7dd37dec56d354a0ecf75b9c82cc090cca492daa
      class=" row dynamic-field form-button"
      [formGroup]="group">
      <button      
        type="submit">
        {{ config.label }}
      </button>
    </div>
  `/* [disabled]="config.disabled" */
})
export class FormButtonComponent implements Field {
  config: FieldConfig;
  group: FormGroup;
}
