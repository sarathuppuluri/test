import { Component, OnInit, ChangeDetectorRef, Inject } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormArray } from '@angular/forms';
import { EvaluatorService, Lead360Service, EnquiryService } from '../../../../../core/e-commerce/_services';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DatePipe } from '@angular/common';
import moment from 'moment';

export interface DialogDataEval {
  id: number;
  crmUniversalId: string;
  entityModuleId: string;
  response: string;
  taskStatus: string;
  taskName: string;
  taskCategory: string;
}

@Component({
  selector: 'kt-evaluator-edit',
  templateUrl: './evaluator-edit.component.html',
  styleUrls: ['./evaluator-edit.component.scss']

})
export class EditEvaluatorComponent implements OnInit {
  bookingAmountReceivedArray = [];
  url: string | ArrayBuffer;

  registrationSearch: string; // input variable for registration search

  submitted = false;

  flag = false;
  flag1 = false;
  flag2 = false;
  flag3 = false;
  flag4 = false;
  flag5 = false;
  flag6 = false;
  flag7 = false;
  flag8 = false;
  image: boolean;
  // image1:boolean;
  url1: string | ArrayBuffer;
  url2: string | ArrayBuffer;
  valuesalll: Array<any>;
  url3: string | ArrayBuffer;

  url4: any;
  url5: any;
  url6: any;
  url7: any;
  url8: any;
  url9: any;
  url10: any;
  url11: any;
  url12: any;
  url13: any;
  url14: any;
  url15: any;
  url16: any;
  url17: any;
  url18: any;
  url19: any;
  valuesall1: Array<any> = [];
  valuesall2: Array<any> = [];
  valuesall3: Array<any> = [];
  valuesall4: Array<any> = [];
  valuesall5: Array<any> = [];
  valuesall6: Array<any> = [];
  valuesall7: Array<any> = [];
  imagepush: Array<any> = [];
  image1: boolean;
  image2: boolean;
  valuesall: Array<any> = [];
  value3: boolean;
  image3: boolean;
  image4: boolean;
  image5: boolean;
  image6: boolean;
  image7: boolean;
  image8: boolean;
  image9: boolean;
  image10: boolean;
  image11: boolean;
  image12: boolean;
  image13: boolean;
  image14: boolean;
  image15: boolean;
  image16: boolean;
  image17: boolean;
  image18: boolean;
  image19: boolean;
  // evalutorId = 23;
  // managerId = 24;
  role;
  crmUniversalId: string;
  evluation: any;
  $filterEvluation: any = [];
  page: number = 0;
  scope: any = {};
  pageSize = 10;
  definedOtherCosts: any;
  purl: any = [];
  id: any;
  evalution_status: any;
  updatedDate: any;
  profileForm: FormGroup;
  loginEmployee: any;
  flags = true;
  evalutorId: any;
  priceFinalisation: boolean;
  flags1: boolean;
  definedotherimage: any;
  rem: boolean;
  previewTotalRefurbishmentCost: any;
  previewtotalRefurbishmentCost: any;
  approveOrReject = false;
  getevluatorId: any;
  totalRefurbishmentCost: any;
  otherfieldsDoc: Array<any> = [];
  EvalObj: any;
  evalautionSubmitForm: any;


  constructor(
    private lead360Service: Lead360Service,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private evaluatorService: EvaluatorService,
    private enquiryservice: EnquiryService,
    private http: EvaluatorService,
    private fb: FormBuilder,
    private router: Router,
    private modalService: NgbModal,
    private changeDetectorRef: ChangeDetectorRef,
    public dialogRef: MatDialogRef<EditEvaluatorComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogDataEval) {
    this.role = JSON.parse(localStorage.getItem('loginEmployee'));
    this.http.role = this.role.hrmsRole;

    this.EvalObj = data;
  }


  addOtherfield() {
    return this.fb.group({
      name: [],
      cost: []
    });
  }

  get f() {
    return this.mangerForm.controls;
  }

  ngDoCheck() {
    this.addCost();
  }

  addCost() {
    const sumOfCost =
      this.previewForm.value.previewperiodicServiceCost +
      this.previewForm.value.previewinsuranceCost +
      this.previewForm.value.previewengineandtransmission +
      this.previewForm.value.previewregistrationCost +
      this.previewForm.value.previewsteeringandfluid +
      this.previewForm.value.previewvehicletransfercharges +
      this.previewForm.value.previewcoolantandfilter +
      this.previewForm.value.previewnocclearance +
      this.previewForm.value.previewremovalstains +
      this.previewForm.value.previewchallenamount +
      this.previewForm.value.previewdrycleaning +
      this.previewForm.value.previewCCClearance +
      this.previewForm.value.previewspareKeysCost +
      this.previewForm.value.previewpollutioncertificate +
      this.previewForm.value.previewrubbingPolishingCost +
      this.previewForm.value.previewengineroomcleaning;
  }
  close() {
    this.dialogRef.close();
  }

  // at present command
  edits() {
    // this.previewForm.value.otherfieldsDoc=[];
    (this.previewForm.get('otherfieldsDoc') as FormArray).clear();
    this.default1 = true;
    this.edited1 = true;
    this.flags = false;
    this.flags1 = true;
    this.value3 = true;
    this.defaultone = false;
    this.editone = true;
    let otherfieldsDoc = this.previewForm.controls.otherfieldsDoc as FormArray;
    this.definedOtherCosts.forEach((element) => {
      otherfieldsDoc.push(this.fb.group({
        name: element.name,
        cost: element.cost,
      }));
    });

  }
  delete(resvalue) {
    this.http.deldata(resvalue).subscribe(
      res => {
      }
    );
    window.alert('Deleted successfully');

  }
  defaultone: boolean;
  editone: boolean;
  edited1: boolean;
  default1: boolean;
  default2: boolean;
  mangerForm: FormGroup;
  // value3: boolean;
  previewForm: FormGroup;

  // imagepush: Array<any> = [];

  priceFinalisationRemarks() {
    this.submitted = true;
    if (this.mangerForm.invalid) {
      return;
    }
    this.priceFinalisation = true;

    let updatedimages = [
      { documentName: 'frontside', url: this.purl[0].url },
      { documentName: 'backside', url: this.purl[1].url },
      { documentName: 'leftside', url: this.purl[2].url },
      { documentName: 'rightside', url: this.purl[3].url },
      { documentName: 'speedometer', url: this.purl[4].url },
      { documentName: 'chassis', url: this.purl[5].url },
      { documentName: 'interiorfront', url: this.purl[6].url },
      { documentName: 'interiorback', url: this.purl[7].url },
      { documentName: 'rc front', url: this.purl[8].url },
      { documentName: 'rc back', url: this.purl[9].url },
      { documentName: 'insurance', url: this.purl[10].url },
      { documentName: 'invoice', url: this.purl[11].url },
      { documentName: 'extra fitment', url: this.purl[12].url },
      { documentName: 'scrach damage', url: this.purl[13].url },
      { documentName: 'dent damage', url: this.purl[14].url },
      { documentName: 'functions', url: this.purl[15].url },
      { documentName: 'break damage', url: this.purl[16].url },
      { documentName: 'number plate', url: this.purl[17].url },
      { documentName: 'bank finance old car/noc', url: this.purl[18].url }
    ]


    const mangerreject = {
      id: this.id,
      nameOnRC: this.previewForm.value.previewnameonRC,
      registrationNumber: this.previewForm.value.previewregistrationNumber,
      mobileNum: this.previewForm.value.previewmobileNum,
      customerId: this.crmUniversalId,
      regValidity: this.previewForm.value.previewregValidity,
      regDistrict: this.previewForm.value.previewregDistrict,
      regCity: this.previewForm.value.previewregCity,
      pincode: this.previewForm.value.previewpincode,
      regState: this.previewForm.value.previewregState,
      imageDocuments: updatedimages,
      model: this.previewForm.value.previewmodel,
      varient: this.previewForm.value.previewvariant,
      yearMonthOfManufacturing: this.previewForm.value.previewyearMonthOfManufacturing,
      vehicleType: this.previewForm.value.previewvehicleType,
      typeOfBody: this.previewForm.value.previewtypeOfBody,
      kmDriven: this.previewForm.value.previewkmDriven,
      frontWheelRight: this.previewForm.value.previewfrontWheelRight,
      frontWheelLeft: this.previewForm.value.previewfrontWheelLeft,
      rearWheelRight: this.previewForm.value.previewrearWheelRight,
      rearWheelLeft: this.previewForm.value.previewrearWheelLeft,
      spareDiskWheel: this.previewForm.value.previewspareDiskWheel,
      spareAlliWheel: this.previewForm.value.previewspareAlliWheel,
      anyMajorAccident: this.previewForm.value.previewminorAccident,
      anyMajorAccidentRemark: this.previewForm.value.previewmajorAccidentRemarks,
      anyMinorAccident: this.previewForm.value.previewminorAccident,
      anyMinorAccidentRemark: this.previewForm.value.previewminorAccidentRemarks,
      // "other":this.previewForm.value.
      updatedDate: this.updatedDate,
      make: this.previewForm.value.previewmake,
      fuelType: this.previewForm.value.previewfuelType,
      chassisNum: this.previewForm.value.previewchassisNum,
      noOfOwners: this.previewForm.value.previewnoOfOwners,
      colour: this.previewForm.value.previewcolour,
      transmission: this.previewForm.value.previewtransmission,
      // "evalution_status": "enum",
      evalutorId: this.previewForm.value.previewevalutorId,
      engineNumber: this.previewForm.value.previewengineNumber,
      regDate: this.previewForm.value.previewregDate,
      emission: this.previewForm.value.previewemission,
      challanPending: this.previewForm.value.previewchallanPending,
      hypothecation: this.previewForm.value.previewhypothecation,
      hypothecatedBranch: this.previewForm.value.previewhypothecatedBranch,
      hypothecatedCompletedDate: this.previewForm.value.previewhypothecatedCompletedDate,
      insuranceType: this.previewForm.value.previewinsuranceType,
      loanAmountDue: this.previewForm.value.previewloanAmountDue,
      insuranceCompanyName: this.previewForm.value.previewinsuranceCompanyName,
      policyNumber: this.previewForm.value.previewpolicyNumber,
      insFromDate: this.previewForm.value.previewinsFromDate,
      insToDate: this.previewForm.value.previewinsToDate,
      periodicService: this.previewForm.value.previewperiodicService,
      periodicServiceCost: this.previewForm.value.previewperiodicServiceCost,
      spareKey: this.previewForm.value.previewspareKey,
      spareKeyCost: this.previewForm.value.previewspareKeyCost,
      rubbingPolishing: this.previewForm.value.previewrubbingPolishing,
      role: this.role.hrmsRole,
      rubbingPolishingCost: this.previewForm.value.previewrubbingPolishingCost,
      image: this.imagepush,
      insurance: this.previewForm.value.previewinsurance,
      insuranceCost: this.previewForm.value.previewinsuranceCost,
      regDocument: this.previewForm.value.regDocument,
      regDocumentCharges: this.previewForm.value.regDocumentCharges,
      pollutionCertificate: this.previewForm.value.previewpollutionCertificate,
      pollutionCertificateCost: this.previewForm.value.previewpollutionCertificateCost,
      oilChanges: this.previewForm.value.previewoilChanges,
      oilChangesCost: this.previewForm.value.previewoilChangesCost,
      powerbrakefluidchange: this.previewForm.value.previewpowerbrakefluidchange,
      powerBrakeFluidChangeCost: this.previewForm.value.previewpowerBrakeFluidChangeCost,
      coolantFilterChange: this.previewForm.value.previewcoolantFilterChange,
      coolantFilterChangeCost: this.previewForm.value.previewcoolantFilterChangeCost,
      removalStainMarksStickers: this.previewForm.value.previewremovalStainMarksStickers,
      removalStainMarksStickersCost: this.previewForm.value.previewremovalStainMarksStickersCost,
      carpetCleaning: this.previewForm.value.previewcarpetCleaning,
      // "carpetCleaningCost": this.previewForm.value.previewcarpetCleaningCost,
      engineRoom: this.previewForm.value.previewengineRoom,
      engineRoomCost: this.previewForm.value.previewengineRoomCost,
      vehicleTransfer: this.previewForm.value.previewvehicleTransfer,
      vehicleTransferCharges: this.previewForm.value.previewvehicleTransferCharges,
      nocClearanceExpense: this.previewForm.value.previewnocClearanceExpense,
      nocClearanceExpenseCost: this.previewForm.value.previewnocClearanceExpenseCost,
      challanAmount: this.previewForm.value.previewchallanAmount,
      challanAmountCost: this.previewForm.value.previewchallanAmountCost,
      ccClearanceExpense: this.previewForm.value.previewccClearanceExpense,
      ccClearanceExpenseCost: this.previewForm.value.previewccClearanceExpenseCost,
      totalRefurbishmentCost: this.previewForm.value.previewtotalRefurbishmentCost,
      custExpectedPrice: this.previewForm.value.previewcustExpectedPrice,
      evaluatorOfferPrice: this.previewForm.value.previewevaluatorOfferPrice,
      managerId: this.role.approverId,
      managerpriceGap: this.mangerForm.value.managerpriceGap,
      managerOfferPrice: this.mangerForm.value.managercustOfferedPrice,
      evalutionStatus: 'Manager_Rejected',
      managerRemarks: this.mangerForm.value.managerrejectremarks,

    };
    this.http.editevaluationoldcardetails(this.previewForm.value.previewregistrationNumber, mangerreject).subscribe(
      res => {
        this.ngOnInit();
        this.router.navigate(['evaluator/evaluatorMenu']);
        this.modalService.dismissAll();

      }
    );
  }

  filterregistration() {
    this.evluation.filter(ele => {

    })
  }


  Remarks() {
    this.rem = true;
  }

  pincodeSearch(event, form) {
    this.http.getLocationUsingPincode(event).subscribe(res => {
      form.patchValue({
        registrationState: res[0].PostOffice[0].State,
        registrationDistrict: res[0].PostOffice[0].District
      });
    });
  }

  priceFinalisationRemarksHide() {
    this.submitted = true;
    if (this.mangerForm.invalid) {
      return;
    }
    window.alert('Manager Approved');
    this.priceFinalisation = false;

    let updatedimages = [
      { documentName: 'frontside', url: this.purl[0].url },
      { documentName: 'backside', url: this.purl[1].url },
      { documentName: 'leftside', url: this.purl[2].url },
      { documentName: 'rightside', url: this.purl[3].url },
      { documentName: 'speedometer', url: this.purl[4].url },
      { documentName: 'chassis', url: this.purl[5].url },
      { documentName: 'interiorfront', url: this.purl[6].url },
      { documentName: 'interiorback', url: this.purl[7].url },
      { documentName: 'rc front', url: this.purl[8].url },
      { documentName: 'rc back', url: this.purl[9].url },
      { documentName: 'insurance', url: this.purl[10].url },
      { documentName: 'invoice', url: this.purl[11].url },
      { documentName: 'extra fitment', url: this.purl[12].url },
      { documentName: 'scrach damage', url: this.purl[13].url },
      { documentName: 'dent damage', url: this.purl[14].url },
      { documentName: 'functions', url: this.purl[15].url },
      { documentName: 'break damage', url: this.purl[16].url },
      { documentName: 'number plate', url: this.purl[17].url },
      { documentName: 'bank finance old car/noc', url: this.purl[18].url }
    ]


    const managerapprove = {

      id: this.id,
      nameOnRC: this.previewForm.value.previewnameonRC,
      registrationNumber: this.previewForm.value.previewregistrationNumber,
      mobileNum: this.previewForm.value.previewmobileNum,
      // "customerId": "",
      regValidity: this.previewForm.value.previewregValidity,
      regDistrict: this.previewForm.value.previewregDistrict,
      regCity: this.previewForm.value.previewregCity,
      pincode: this.previewForm.value.previewpincode,
      regState: this.previewForm.value.previewregState,
      imageDocuments: updatedimages,
      model: this.previewForm.value.previewmodel,
      varient: this.previewForm.value.previewvariant,
      yearMonthOfManufacturing: this.previewForm.value.previewyearMonthOfManufacturing,
      vehicleType: this.previewForm.value.previewvehicleType,
      typeOfBody: this.previewForm.value.previewtypeOfBody,
      kmDriven: this.previewForm.value.previewkmDriven,
      frontWheelRight: this.previewForm.value.previewfrontWheelRight,
      frontWheelLeft: this.previewForm.value.previewfrontWheelLeft,
      rearWheelRight: this.previewForm.value.previewrearWheelRight,
      rearWheelLeft: this.previewForm.value.previewrearWheelLeft,
      spareDiskWheel: this.previewForm.value.previewspareDiskWheel,
      spareAlliWheel: this.previewForm.value.previewspareAlliWheel,
      anyMajorAccident: this.previewForm.value.previewminorAccident,
      anyMajorAccidentRemark: this.previewForm.value.previewmajorAccidentRemarks,
      anyMinorAccident: this.previewForm.value.previewminorAccident,
      anyMinorAccidentRemark: this.previewForm.value.previewminorAccidentRemarks,
      updatedDate: this.updatedDate,
      make: this.previewForm.value.previewmake,
      fuelType: this.previewForm.value.previewfuelType,
      chassisNum: this.previewForm.value.previewchassisNum,
      noOfOwners: this.previewForm.value.previewnoOfOwners,
      colour: this.previewForm.value.previewcolour,
      transmission: this.previewForm.value.previewtransmission,
      // "evalution_status": "enum",
      evalutorId: this.previewForm.value.previewevalutorId,
      engineNumber: this.previewForm.value.previewengineNumber,
      regDate: this.previewForm.value.previewregDate,
      emission: this.previewForm.value.previewemission,
      challanPending: this.previewForm.value.previewchallanPending,
      hypothecation: this.previewForm.value.previewhypothecation,
      hypothecatedBranch: this.previewForm.value.previewhypothecatedBranch,
      hypothecatedCompletedDate: this.previewForm.value.previewhypothecatedCompletedDate,
      insuranceType: this.previewForm.value.previewinsuranceType,
      loanAmountDue: this.previewForm.value.previewloanAmountDue,
      insuranceCompanyName: this.previewForm.value.previewinsuranceCompanyName,
      policyNumber: this.previewForm.value.previewpolicyNumber,
      insFromDate: this.previewForm.value.previewinsFromDate,
      insToDate: this.previewForm.value.previewinsToDate,
      periodicService: this.previewForm.value.previewperiodicService,
      periodicServiceCost: this.previewForm.value.previewperiodicServiceCost,
      spareKey: this.previewForm.value.previewspareKey,
      spareKeyCost: this.previewForm.value.previewspareKeyCost,
      rubbingPolishing: this.previewForm.value.previewrubbingPolishing,
      rubbingPolishingCost: this.previewForm.value.previewrubbingPolishingCost,
      image: this.imagepush,
      role: this.role.hrmsRole,
      insurance: this.previewForm.value.previewinsurance,
      insuranceCost: this.previewForm.value.previewinsuranceCost,
      regDocument: this.previewForm.value.regDocument,
      regDocumentCharges: this.previewForm.value.regDocumentCharges,
      pollutionCertificate: this.previewForm.value.previewpollutionCertificate,
      pollutionCertificateCost: this.previewForm.value.previewpollutionCertificateCost,
      oilChanges: this.previewForm.value.previewoilChanges,
      oilChangesCost: this.previewForm.value.previewoilChangesCost,
      powerbrakefluidchange: this.previewForm.value.previewpowerbrakefluidchange,
      powerBrakeFluidChangeCost: this.previewForm.value.previewpowerBrakeFluidChangeCost,
      coolantFilterChange: this.previewForm.value.previewcoolantFilterChange,
      coolantFilterChangeCost: this.previewForm.value.previewcoolantFilterChangeCost,
      removalStainMarksStickers: this.previewForm.value.previewremovalStainMarksStickers,
      removalStainMarksStickersCost: this.previewForm.value.previewremovalStainMarksStickersCost,
      // "role":this.role,
      carpetCleaning: this.previewForm.value.previewcarpetCleaning,
      // "carpetCleaningCost": this.previewForm.value.previewcarpetCleaningCost,
      engineRoom: this.previewForm.value.previewengineRoom,
      engineRoomCost: this.previewForm.value.previewengineRoomCost,
      vehicleTransfer: this.previewForm.value.previewvehicleTransfer,
      vehicleTransferCharges: this.previewForm.value.previewvehicleTransferCharges,
      nocClearanceExpense: this.previewForm.value.previewnocClearanceExpense,
      nocClearanceExpenseCost: this.previewForm.value.previewnocClearanceExpenseCost,
      challanAmount: this.previewForm.value.previewchallanAmount,
      challanAmountCost: this.previewForm.value.previewchallanAmountCost,
      ccClearanceExpense: this.previewForm.value.previewccClearanceExpense,
      ccClearanceExpenseCost: this.previewForm.value.previewccClearanceExpenseCost,
      totalRefurbishmentCost: this.previewForm.value.previewtotalRefurbishmentCost,
      custExpectedPrice: this.previewForm.value.previewcustExpectedPrice,
      evaluatorOfferPrice: this.previewForm.value.previewevaluatorOfferPrice,
      // managerId: this.role.reportingManagerId,
      managerId: this.role.approverId,
      managerpriceGap: this.mangerForm.value.managerpriceGap,
      managerOfferPrice: this.mangerForm.value.managercustOfferedPrice,
      evalutionStatus: 'Manager_Approved',
      managerRemarks: this.mangerForm.value.managerrejectremarks,

    };
    this.http.editevaluationoldcardetails(this.previewForm.value.previewregistrationNumber, managerapprove).subscribe(
      res => {
        this.ngOnInit();
        this.router.navigate(['evaluator/evaluatorMenu']);
        this.modalService.dismissAll();
      }
    );

  }

  // Booking Amount Received Array
  addBookingAmountReceived(controls, leadId) {
    const tempAdvance = [
      {
        id: (this.bookingAmountReceivedArray.length > 0) ? this.bookingAmountReceivedArray[0].id : 0,
        paymentName: 'Vehicle Exchange Amount',
        amount: controls.managercustOfferedPrice,
        leadId
      }
    ];

    return tempAdvance;
  }

  updateEvaluation(updateStatus) {
    // this.submitted = true;
    let status: string;
    if (updateStatus === 'APPROVED') {
      status = 'Manager_Approved';
    }
    else if (updateStatus === 'REJECTED') {
      status = 'Manager_Rejected';
    } else {
      status = this.evalution_status;
    }

    let updatedimages = [
      { documentName: 'frontside', url: this.purl[0].url },
      { documentName: 'backside', url: this.purl[1].url },
      { documentName: 'leftside', url: this.purl[2].url },
      { documentName: 'rightside', url: this.purl[3].url },
      { documentName: 'speedometer', url: this.purl[4].url },
      { documentName: 'chassis', url: this.purl[5].url },
      { documentName: 'interiorfront', url: this.purl[6].url },
      { documentName: 'interiorback', url: this.purl[7].url },
      { documentName: 'rc front', url: this.purl[8].url },
      { documentName: 'rc back', url: this.purl[9].url },
      { documentName: 'insurance', url: this.purl[10].url },
      { documentName: 'invoice', url: this.purl[11].url },
      { documentName: 'extra fitment', url: this.purl[12].url },
      { documentName: 'scrach damage', url: this.purl[13].url },
      { documentName: 'dent damage', url: this.purl[14].url },
      { documentName: 'functions', url: this.purl[15].url },
      { documentName: 'break damage', url: this.purl[16].url },
      { documentName: 'number plate', url: this.purl[17].url },
      { documentName: 'bank finance old car/noc', url: this.purl[18].url }
    ]
    this.evalautionSubmitForm.managerOfferPrice = this.mangerForm.value.managercustOfferedPrice;
    this.evalautionSubmitForm.managerRemarks = this.previewForm.value.remarks;
    this.evalautionSubmitForm.evalutionStatus = status;

    this.http.editevaluationoldcardetails(this.previewForm.value.previewregistrationNumber, this.evalautionSubmitForm).subscribe((res: any) => {
      if (res.statusCode === 'OK' && updateStatus === 'APPROVED') {
        this.enquiryservice.checkLeadAvailability(this.previewForm.value.previewregistrationNumber).subscribe(leadRes => {
          this.crmUniversalId = leadRes.crmUniversalId;
          if (leadRes.isSuccess === 'true') {
            // get Booking Amount Received Details
            this.enquiryservice.getBookingAmount(leadRes.leadId).subscribe(response => {
              if (response.dmsEntity.dmsBookingAmountReceivedDtoList.length > 0) {
                if (response.dmsEntity.dmsBookingAmountReceivedDtoList.length > 0) {
                  response.dmsEntity.dmsBookingAmountReceivedDtoList.forEach(element => {
                    if (element.paymentName === 'Vehicle Exchange Amount') {
                      this.bookingAmountReceivedArray = [element];
                    }
                  });
                }
              }
              // Advance Booking Amount -- in Booking received table
              this.bookingAmountReceivedArray = this.addBookingAmountReceived(this.mangerForm.value, Number(leadRes.leadId));
              this.enquiryservice.sendBookingAmount(this.bookingAmountReceivedArray).subscribe(bookingRes => {
                if (!bookingRes) {
                  return;
                }
                if (bookingRes.success === false) {
                  return;
                }
                // Taking res from evalutation submit to update task
                this.openSnackBar('Evaluation has been updated', 'success');
                this.updateTask(this.EvalObj.entityModuleId, updateStatus, this.mangerForm.value.remarks, 'Evaluation Approval');
              }, error => {
                console.log(error);
                window.alert('Failed to save Vehicle Approved Amount');
              });
            });
          }
        }, leadError => {
          console.log(leadError);
          window.alert('Network Error. Check you Network and Try Again');
        });
      } else if (res.statusCode === 'OK' && updateStatus === 'REJECTED') {
        this.openSnackBar('Evaluation has been updated', 'success');
        this.updateTask(this.EvalObj.entityModuleId, updateStatus, this.mangerForm.value.remarks, 'Evaluation Approval');
      } else {
        this.openSnackBar('Evaluation has not been updated', 'fail');
      }
    }, error => {
      this.openSnackBar('Server is down', 'editevaluationoldcardetails failed');
    });
  }//updatevalues


  /**
   * this method for task update.
   */
  public updateTask(confirmationId, status, remarks, taskName) {
    const requestBody = {
      universalId: this.crmUniversalId,
      taskId: null,
      remarks: remarks ? remarks : '',
      universalModuleId: confirmationId,
      evaluationApproverId: this.evalautionSubmitForm.managerId,
      status,
      taskName
    }
    this.lead360Service.updateEvaluationTask(requestBody).subscribe((res: any) => {
      if (res.success) {
        this.openSnackBar('Evaluation status updated in task.', 'success');
        this.dialogRef.close('success');
      } else if (res.statusCode === 500) {
        this.openSnackBar('Internal server error, statusCode:500 ', 'fail');
      } else if (res.success === 'fail') {
        this.openSnackBar('Oops! Evaluation status is not updated in task.', 'fail');
      } else {
        this.openSnackBar(res.errorMessage, 'fail');
      }
    }, error => {
      this.openSnackBar('Server is down', 'UpdateEvaluationTask failed');
    });
  }

  closeEvaluationTask(taskCategory, taskStatus, taskName) {

    this.evalautionSubmitForm.evalutionStatus = 'Closed';
    this.http.editevaluationoldcardetails(this.previewForm.value.previewregistrationNumber, this.evalautionSubmitForm).subscribe((res: any) => {
      const requestBody = {
        universalId: this.crmUniversalId,
        taskId: null,
        remarks: '',
        universalModuleId: this.EvalObj.entityModuleId,
        evaluationApproverId: this.role.approverId,
        status: 'CLOSED',
        taskName
      }
      this.lead360Service.updateEvaluationTask(requestBody).subscribe((res: any) => {
        if (res.success) {
          this.openSnackBar('Evaluation task has been closed.', 'success');
          this.dialogRef.close('success');
        } else if (res.statusCode == 500) {
          this.openSnackBar('Internal server error, statusCode:500 ', 'fail');
        } else if (res.success === 'fail') {
          this.openSnackBar('Oops! Evaluation task has not been closed.', 'fail');
        } else {
          this.openSnackBar(res.errorMessage, 'fail');
        }
      }, error => {
        this.openSnackBar('Server is down', 'closeEvaluationTask failed');
      });
    });
  }
  reSchedule(taskCategory, taskStatus, taskName) {

    const requestBody = {
      universalId: this.crmUniversalId,
      taskId: null,
      remarks: '',
      universalModuleId: this.EvalObj.entityModuleId,
      evaluationApproverId: this.role.approverId,
      status: 'SENT_FOR_APPROVAL',
      taskName,
    }
    this.lead360Service.updateEvaluationTask(requestBody).subscribe((res: any) => {
      if (res.success) {
        this.openSnackBar('Evaluation task has been Re-scheduled.', 'success');
        this.dialogRef.close('success');
      } else if (res.statusCode === 500) {
        this.openSnackBar('Internal server error, statusCode:500 ', 'fail');
      } else if (res.success === 'fail') {
        this.openSnackBar('Oops! Evaluation task has not been Re-scheduled.', 'fail');
      } else {
        this.openSnackBar(res.errorMessage, 'fail');
      }
    }, error => {
      this.openSnackBar('Server is down', 'reSchedule failed');
    });

  }



  call(event) {
    let previewcustExpectedPrice = this.mangerForm.controls['previewcustExpectedPrice'].value
    let managercustOfferedPrice = this.mangerForm.controls['managercustOfferedPrice'].value
    let total = previewcustExpectedPrice - managercustOfferedPrice;
    let managerpriceGap = this.mangerForm.controls['managerpriceGap'].setValue(total)

  }


  othercost() {
    this.otherDocfieldArray.push(this.addOtherfield());
  }
  removeOthercost(index) {
    this.otherDocfieldArray.removeAt(index);
    this.cal();
  }


  cal() {
    let previewperiodicServiceCost = this.previewForm.controls['previewperiodicServiceCost'].value
    let previewinsuranceCost = this.previewForm.controls['previewoilChangesCost'].value
    let previewengineandtransmission = this.previewForm.controls['previewpowerBrakeFluidChangeCost'].value
    let previewregistrationCost = this.previewForm.controls['previewcoolantFilterChangeCost'].value
    let previewsteeringandfluid = this.previewForm.controls['previewremovalStainMarksStickersCost'].value
    let previewvehicletransfercharges = this.previewForm.controls['previewcarpetCleaningCost'].value
    let previewcoolantandfilter = this.previewForm.controls['previewspareKeyCost'].value
    let previewnocclearance = this.previewForm.controls['previewrubbingPolishingCost'].value
    let previewremovalstains = this.previewForm.controls['previewengineRoomCost'].value
    let previewchallenamount = this.previewForm.controls['previewinsuranceCost'].value
    let previewdrycleaning = this.previewForm.controls['regDocumentCharges'].value
    let previewCCClearance = this.previewForm.controls['previewvehicleTransferCharges'].value
    let previewspareKeysCost = this.previewForm.controls['previewnocClearanceExpenseCost'].value
    let previewpollutioncertificate = this.previewForm.controls['previewchallanAmountCost'].value
    let previewrubbingPolishingCost = this.previewForm.controls['previewccClearanceExpenseCost'].value
    let previewengineroomcleaning = this.previewForm.controls['previewpollutionCertificateCost'].value;

    let total = previewperiodicServiceCost +
      previewinsuranceCost +
      previewengineandtransmission +
      previewregistrationCost +
      previewsteeringandfluid +
      previewvehicletransfercharges +
      previewcoolantandfilter +
      previewnocclearance +
      previewremovalstains +
      previewchallenamount +
      previewdrycleaning +
      previewCCClearance +
      previewspareKeysCost +
      previewpollutioncertificate +
      previewrubbingPolishingCost +
      previewengineroomcleaning;

    let resultArray = this.otherDocfieldArray.value.map(function (a) { return a['cost']; });
    if (resultArray.length > 0) {
      this.totalRefurbishmentCost = total + resultArray.reduce(this.sumofArray);
    } else {
      this.totalRefurbishmentCost = total;
    }
    this.previewForm.patchValue({
      previewtotalRefurbishmentCost: this.totalRefurbishmentCost
    });
  }
  sumofArray(sum, num) {
    return sum + num;
  }


  onFileSelected0(event) {
    this.image = true;
    this.default1 = false;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed

        this.purl[0].url = reader.result;
        this.imagepush.push({ documentName: 'frontside', url: this.purl[0].url });
      };
    }
  }

  onFileSelected1(event) {
    this.default1 = false;
    this.image1 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {

    });
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[1].url = reader.result;
        this.imagepush.push({ documentName: 'backside', url: this.purl[1].url });

      };
    }
  }
  onFileSelected2(event) {
    this.default1 = false;
    this.image2 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[2].url = reader.result;
        this.imagepush.push({ documentName: 'leftside', url: this.purl[2].url });
      };
    }
  }
  onFileSelected3(event) {
    this.default1 = false;
    this.image3 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[3].url = reader.result;
        this.imagepush.push({ documentName: 'rightside', url: this.purl[3].url });
      };
    }
  }
  onFileSelected4(event) {
    this.default1 = false;
    this.image4 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[4].url = reader.result;
        this.imagepush.push({ documentName: 'speedometer', url: this.purl[4].url });
      };
    }
  }
  onFileSelected5(event) {
    this.default1 = false;
    this.image5 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[5].url = reader.result;
        this.imagepush.push({ documentName: 'Chassis', url: this.purl[5].url });
      };
    }
  }
  onFileSelected6(event) {
    this.default1 = false;
    this.image6 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[6].url = reader.result;
        this.imagepush.push({ documentName: 'interior front', url: this.purl[6].url });
      };
    }
  }
  onFileSelected7(event) {
    this.default1 = false;
    this.image7 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[7].url = reader.result;
        this.imagepush.push({ documentName: 'interior back', url: this.purl[7].url });
      };
    }
  }
  onFileSelected8(event) {
    this.default1 = false;
    this.image8 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[8].url = reader.result;
        this.imagepush.push({ documentName: 'RC front', url: this.purl[8].url });
      };
    }
  }
  onFileSelected9(event) {
    this.default1 = false;
    this.image9 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[9].url = reader.result;
        this.imagepush.push({ documentName: 'RC back', url: this.purl[9].url });
      };
    }
  }
  onFileSelected10(event) {
    this.default1 = false;
    this.image10 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[10].url = reader.result;
        this.imagepush.push({ documentName: 'insurance', url: this.purl[10].url });
      };
    }
  }
  onFileSelected11(event) {
    this.default1 = false;
    this.image11 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[11].url = reader.result;
        this.imagepush.push({ documentName: 'invoice', url: this.purl[11].url });
      };
    }
  }
  onFileSelected12(event) {
    this.default1 = false;
    this.image12 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[12].url = reader.result;
        this.imagepush.push({ documentName: 'extra fitment', url: this.purl[12].url });
      };
    }
  }
  onFileSelected13(event) {
    this.default1 = false;
    this.image13 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[13].url = reader.result;
        this.imagepush.push({ documentName: 'scratch damage', url: this.purl[13].url });
      };
    }
  }
  onFileSelected14(event) {
    this.default1 = false;
    this.image14 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed

        this.purl[14].url = reader.result;
        this.imagepush.push({ documentName: 'dent damage', url: this.purl[14].url });
      };
    }
  }
  onFileSelected15(event) {
    this.default1 = false;
    this.image15 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[15].url = reader.result;
        this.imagepush.push({ documentName: 'funtions', url: this.purl[15].url });
      };
    }
  }
  onFileSelected16(event) {
    this.default1 = false;
    this.image16 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[16].url = reader.result;
        this.imagepush.push({ documentName: 'break damage', url: this.purl[16].url });
      };
    }
  }
  onFileSelected17(event) {
    this.default1 = false;
    this.image17 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[17].url = reader.result;
        this.imagepush.push({ documentName: 'number plate', url: this.purl[17].url });
      };
    }
  }
  onFileSelected18(event) {
    this.default1 = false;
    this.image18 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe(res => {
    });

    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = () => { // called once readAsDataURL is completed
        this.purl[18].url = reader.result;
        this.imagepush.push({ documentName: 'bank/finance old car NOC', url: this.purl[18].url });
      };
    }
  }




  openLarge(res) {
    this.definedOtherCosts = '';
    this.definedOtherCosts = res.otherCharges;
    this.definedotherimage = res.otherImages;
    this.previewTotalRefurbishmentCost = res.totalRefurbishmentCost;

    this.defaultone = true;
    this.editone = false;

    this.id = res.id;
    this.evalution_status = res.evalution_status;
    this.updatedDate = res.updatedDate;
    this.purl = res.imageDocuments;

    this.previewForm.patchValue({
      previewregistrationNumber: res.registrationNumber,
      previewnameonRC: res.nameOnRC,
      previewmake: res.make,
      previewmodel: res.model,
      previewvariant: res.varient,
      previewmobileNum: res.mobileNum,
      previewfuelType: res.fuelType,
      previewengineNumber: res.engineNumber,
      previewmajorAccident: res.anyMajorAccident,
      previewmajorAccidentRemarks: res.anyMajorAccidentRemark,
      previewminorAccident: res.anyMinorAccident,
      previewminorAccidentRemarks: res.anyMinorAccidentRemark,
      previewchallanPending: res.challanPending,
      previewchassisNum: res.chassisNum,
      previewcolour: res.colour,
      previewtotalRefurbishmentCost: res.totalRefurbishmentCost,
      previewcustExpectedPrice: res.custExpectedPrice,
      previewcustomerId: res.customerId,
      previewemission: res.emission,
      previewevaluatorOfferPrice: res.evaluatorOfferPrice,
      previewoilChanges: res.oilChanges,
      previewoilChangesCost: res.oilChangesCost,
      previewpowerbrakefluidchange: res.powerbrakefluidchange,
      previewpowerBrakeFluidChangeCost: res.powerBrakeFluidChangeCost,
      previewcoolantFilterChange: res.coolantFilterChange,
      previewcoolantFilterChangeCost: res.coolantFilterChangeCost,
      previewremovalStainMarksStickers: res.removalStainMarksStickers,
      previewremovalStainMarksStickersCost: res.removalStainMarksStickersCost,
      previewcarpetCleaning: res.carpetCleaning,
      previewcarpetCleaningCost: res.carpetCleaningCost,
      previewengineRoom: res.engineRoom,
      previewengineRoomCost: res.engineRoomCost,
      previewvehicleTransfer: res.vehicleTransfer,
      previewvehicleTransferCharges: res.vehicleTransferCharges,
      previewnocClearanceExpense: res.nocClearanceExpense,
      previewnocClearanceExpenseCost: res.nocClearanceExpenseCost,
      previewchallanAmount: res.challanAmount,
      previewchallanAmountCost: res.challanAmountCost,
      previewccClearanceExpense: res.ccClearanceExpense,
      previewccClearanceExpenseCost: res.ccClearanceExpenseCost,
      previewevalutorId: res.evalutorId,
      previewfrontWheelLeft: res.frontWheelLeft,
      previewfrontWheelRight: res.frontWheelRight,
      previewhypothecatedBranch: res.hypothecatedBranch,
      previewhypothecatedCompletedDate: res.hypothecatedCompletedDate,
      previewhypothecation: res.hypothecation,
      previewimageDocuments: res.imageDocuments,
      previewinsFromDate: res.insFromDate,
      previewinsToDate: res.insToDate,
      previewinsurance: res.insurance,
      previewinsuranceCompanyName: res.insuranceCompanyName,
      previewinsuranceCost: res.insuranceCost,
      previewinsuranceType: res.insuranceType,
      previewkmDriven: res.kmDriven,
      previewloanAmountDue: res.loanAmountDue,
      previewmanagerId: res.managerId,
      previewnoOfOwners: res.noOfOwners,
      previewperiodicService: res.periodicService,
      previewperiodicServiceCost: res.periodicServiceCost,
      previewpincode: res.pincode,
      previewpolicyNumber: res.policyNumber,
      previewpollutionCertificate: res.pollutionCertificate,
      previewpollutionCertificateCost: res.pollutionCertificateCost,
      previewrearWheelLeft: res.rearWheelLeft,
      previewrearWheelRight: res.rearWheelRight,
      previewregCity: res.regCity,
      previewregDate: res.regDate,
      previewregDistrict: res.regDistrict,
      role: res.role,
      regDocument: res.regDocument,
      regDocumentCharges: res.regDocumentCharges,
      previewregState: res.regState,
      previewregValidity: res.regValidity,
      previewrubbingPolishing: res.rubbingPolishing,
      previewrubbingPolishingCost: res.rubbingPolishingCost,
      previewspareAlliWheel: res.spareAlliWheel,
      previewspareDiskWheel: res.spareDiskWheel,
      previewspareKey: res.spareKey,
      previewspareKeyCost: res.spareKeyCost,
      previewtransmission: res.transmission,
      previewtypeOfBody: res.typeOfBody,
      updatedDate: '',
      previewvarient: res.variant,
      previewvehicleType: res.vehicleType,
      previewyearMonthOfManufacturing: res.yearMonthOfManufacturing,
      remarks: res.managerRemarks,


    });
    this.mangerForm.patchValue({
      previewcustExpectedPrice: res.custExpectedPrice,
      previewevaluatorOfferPrice: res.evaluatorOfferPrice,
    });

    let defaultcost = this.previewForm.value.previewperiodicServiceCost +
      this.previewForm.value.previewoilChangesCost +
      this.previewForm.value.previewpowerBrakeFluidChangeCost +
      this.previewForm.value.previewcoolantFilterChangeCost +
      this.previewForm.value.previewremovalStainMarksStickersCost +
      this.previewForm.value.previewcarpetCleaningCost +
      this.previewForm.value.previewspareKeyCost +
      this.previewForm.value.previewrubbingPolishingCost +
      this.previewForm.value.previewengineRoomCost +
      this.previewForm.value.previewinsuranceCost +
      this.previewForm.value.regDocumentCharges +
      this.previewForm.value.previewvehicleTransferCharges +
      this.previewForm.value.previewnocClearanceExpenseCost +
      this.previewForm.value.previewchallanAmountCost +
      this.previewForm.value.previewccClearanceExpenseCost +
      this.previewForm.value.previewpollutionCertificateCost;
  }//close openLarge



  get otherDocfieldArray(): FormArray {
    return this.previewForm.get('otherfieldsDoc') as FormArray;
  }
  ngOnInit() {
    this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
    this.crmUniversalId = this.EvalObj.crmUniversalId;

    this.evalutorId = this.loginEmployee.empId;

    this.profileForm = this.fb.group({
      getcardetails: [''],
    })

    this.mangerForm = this.fb.group({
      managerpriceGap: [''],
      previewcustExpectedPrice: [''],
      previewevaluatorOfferPrice: [''],
      managercustOfferedPrice: [''],

      managerrejectremarks: ['']

    });

    this.previewForm = this.fb.group({

      previewregistrationNumber: ['', Validators.required , Validators.maxLength(10)],
      previewnameonRC: [''],
      previewmodel: [''],
      previewvariant: [''],
      previewregDate: [''],
      previewmake: [''],
      previewfuelType: [''],
      previewtransmission: [''],
      previewtotalRefurbishmentCost: [],
      role: [''],
      previewVehicleServiceCost: [''],
      previewvehicleServiceCost: [''],
      previewengineNumber: [''],
      previewpincode: [''],
      previewchallanPending: [''],
      previewminorAccidentRemarks: [''],
      previewminorAccident: [''],
      previewmajorAccidentRemarks: [''],
      previewmajorAccident: [''],
      previewcolour: [''],
      previewevalutorId: [''],
      previewcustExpectedPrice: [''],
      previewemission: [''],
      previewevaluatorOfferPrice: [''],
      previewoilChanges: [''],
      previewoilChangesCost: [],
      previewpowerbrakefluidchange: [''],
      previewpowerBrakeFluidChangeCost: [],
      previewcoolantFilterChange: [''],
      previewcoolantFilterChangeCost: [],
      previewremovalStainMarksStickers: [''],
      previewremovalStainMarksStickersCost: [],
      previewcarpetCleaning: [''],
      previewcarpetCleaningCost: [],
      previewengineRoom: [''],
      previewengineRoomCost: [],
      previewvehicleTransfer: [''],
      previewvehicleTransferCharges: [],
      previewnocClearanceExpense: [''],
      previewnocClearanceExpenseCost: [],
      previewchallanAmount: [''],
      previewchallanAmountCost: [],
      previewccClearanceExpense: [''],
      previewccClearanceExpenseCost: [],
      previewfrontWheelLeft: [''],
      previewfrontWheelRight: [''],
      previewhypothecatedBranch: [''],
      previewhypothecatedCompletedDate: [''],
      previewhypothecation: [''],
      previewimageDocuments: [''],
      previewinsFromDate: [''],
      previewinsToDate: [''],
      previewinsurance: [''],
      previewinsuranceCompanyName: [''],
      previewinsuranceCost: [],
      previewinsuranceType: [''],
      previewkmDriven: [''],
      previewloanAmountDue: [''],
      previewnoOfOwners: [''],
      previewpolicyNumber: [''],
      previewpollutionCertificate: [''],
      previewpollutionCertificateCost: [],
      previewmobileNum: [''],
      previewname: [''],
      previewcost: [''],
      previewrearWheelLeft: [''],
      previewrearWheelRight: [''],
      previewregCity: [''],
      previewregDistrict: [''],
      regDocument: [''],
      regDocumentCharges: [],
      previewregState: [''],
      previewregValidity: [''],
      previewrubbingPolishing: [''],
      previewrubbingPolishingCost: [],
      previewspareAlliWheel: [''],
      previewspareDiskWheel: [''],
      previewspareKey: [''],
      previewspareKeyCost: [],
      previewtypeOfBody: [''],
      previewvehicleType: [''],
      previewyearMonthOfManufacturing: [''],
      previewchassisNum: [''],
      previewperiodicServiceCost: [],
      otherImagesDoc: [''],
      previewperiodicService: [''],
      otherfieldsDoc: this.fb.array([]),
      name: [''],
      cost: [''],
      remarks: [''],
    });

    //get Evaluation by id
    this.http.getevalutionoldcarbyid(this.EvalObj.entityModuleId).subscribe(res => {
      this.evalautionSubmitForm = res;
      this.openLarge(res);

    }, error => {
      this.openSnackBar('Sever is down', 'Get Evaluation failed');
    });

  }//End ngOnInit

  /**
	   * Checking control validation
	   *
	   * @param controlName: string => Equals to formControlName
	   * @param validationType: string => Equals to valitors name
	   */
 isControlHasError(controlName: string, validationType: string): boolean {
  const control = this.previewForm.controls[controlName];
  if (!control) {
    return false;
  }
  const result = control.hasError(validationType) && (control.dirty || control.touched);
  return result;
}


  evalution() {

    this.approveOrReject = false;
    this.http.geteva(this.role.empId, this.page, this.pageSize).subscribe(res => {
      res.content = res.content;
      this.scope = res;
      this.evluation = res.content;
      this.$filterEvluation = this.evluation;
      this.changeDetectorRef.detectChanges();
    });
  }

  evalutionApprove() {
    this.approveOrReject = true;
    this.http.getapprove(this.role.empId, this.page, this.pageSize).subscribe(res => {
      res.content = res.content;
      this.scope = res;
      this.evluation = res.content;
      this.$filterEvluation = this.evluation;
      this.changeDetectorRef.detectChanges();
    });
  }

  paginatorEvents(event) {
    this.page = event.pageIndex;
    this.pageSize = event.pageSize;
    this.evalution();
  }

  approvePaginatorEvents(event) {
    this.page = event.pageIndex;
    this.pageSize = event.pageSize;
    this.evalutionApprove();
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
    });
  }

}