import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TdappointmentComponent } from '../../test-drive/tdappointment/tdappointment.component';

//import { TdappointmentComponent } from './tdappointment.component';

describe('TdappointmentComponent', () => {
  let component: TdappointmentComponent;
  let fixture: ComponentFixture<TdappointmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TdappointmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TdappointmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
