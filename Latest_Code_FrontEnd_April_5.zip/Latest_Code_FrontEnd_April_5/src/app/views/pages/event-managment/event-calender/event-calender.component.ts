import {
	Component,
	OnInit,
	Injectable,
	ChangeDetectorRef,
} from "@angular/core";
import dayGridMonthPlugin from "@fullcalendar/daygrid";
import bootstrap from "@fullcalendar/daygrid";
import { SelectionModel } from "@angular/cdk/collections";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { DatePipe } from "@angular/common";
import {
	EventManagementService,
	SharedService,
} from "../../../../core/e-commerce/_services";
import { NotificationService } from "../../../../core/e-commerce/_services/notification.service";
import { Router } from "@angular/router";
import {
	MessageType,
	LayoutUtilsService,
	QueryParamsModel,
} from "../../../../core/_base/crud";
import { FormBuilder, NgModel } from "@angular/forms";

@Injectable()
@Component({
	selector: "kt-event-calender",
	templateUrl: "./event-calender.component.html",
	styleUrls: ["./event-calender.component.scss"],
	providers: [DatePipe],
})
export class EventCalenderComponent implements OnInit {
	calenderEvents: any[];
	count1 = 0;
	count = 0;
	lastDate: Date;
	firstDate: Date;
	pendingEvents: any = [];
	scope: any = {};
	flag = true;
	eventAll: any[];
	holidayAll: any;
	holidayList: any;
	listEvents: any;
	numRows: any = [];
	empId: number;
	approveOrReject = false;
	noData: Boolean;
	eventStartDate: String;
	currentDate: { getFullYear: () => any; getMonth: () => any };
	loginEmployee: { empId: number; orgId: any; branchId: any; hrmsRole: any };
	page = 0;
	pageSize = 10;
	page1 = 0;
	pageSize1 = 10;
	initialSelection = [];
	selection = new SelectionModel(true, this.initialSelection);
	calendarPlugins = [dayGridMonthPlugin];
	theme = [bootstrap];
	header = {
		left: "prev Month next",
		center: "title",
		right: "today prevYear Year nextYear",
	};
	views = {
		dayGridMonth: {
			allDay: false,
			displayEventTime: false,
		},
	};
	footer = {
		left: "",
		center: "addEventButton",
		right: "",
	};
	selectable: any;

	constructor(
		private fb: FormBuilder,
		private router: Router,
		public notificationService: NotificationService,
		private event: EventManagementService,
		private date: DatePipe,
		private changeDetectorRef: ChangeDetectorRef,
		private sharedService: SharedService,
		private modalService: NgbModal
	) {}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.empId = this.loginEmployee.empId;
		this.getAllEventShedules();
		this.getPaginationEvents();
	}

	getEventHolidaysList() {
		this.flag = false;
		this.event.getEventHolidaysList().subscribe((res) => {
			this.holidayList = res;
			this.holidayAll = [];
			this.holidayList.forEach(
				(element: {
					holidyName: any;
					holidyDate: string;
					type: any;
				}) => {
					this.holidayAll.push({
						title: element.holidyName,
						timeZone: "UTC",
						start: element.holidyDate.substr(0, 10),
						end: element.holidyDate.substr(0, 10),
						textColor: "white",
						type: element.type,
						color: "#d5d8fd",
					});
				}
			);
			for (let i = 0; i < this.holidayAll.length; i++) {
				if (this.holidayAll[i].type === "Public") {
					this.holidayAll[i].color =
						"lighten($color: #ff0e0e, $amount: 6)";
				}

				if (this.holidayAll[i].type === "Special") {
					this.holidayAll[i].color = "#633232";
				}
			}
		});
	}

	getAllEventShedules() {
		this.getEventHolidaysList();
		this.flag = false;
		this.currentDate =
			this.lastDate === undefined ? new Date() : this.lastDate;
		const year = this.currentDate.getFullYear();
		const month = this.currentDate.getMonth();
		const firstDate = this.date.transform(
			new Date(year, month, 1),
			"yyyy-MM-dd"
		);
		const lastDate = this.date.transform(
			new Date(year, month + 1, 0),
			"yyyy-MM-dd"
		);
		this.event
			.getAllEventsByFilter(
				firstDate,
				lastDate,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId,
				this.empId,
				this.loginEmployee.hrmsRole
			)
			.subscribe((res: any) => {
				if (res.status) {
					this.pendingEvents = res;
					this.eventAll = [];
					(this.pendingEvents || []).forEach(
						(element: {
							startDatetime: string;
							endDatetime: string;
							name: any;
							id: any;
							status: any;
						}) => {
							const startDate = element.startDatetime.substr(
								0,
								19
							);
							const endDate = element.endDatetime.substr(0, 19);
							this.eventAll.push({
								title: element.name,
								id: element.id,
								timeZone: "UTC",
								start: startDate,
								end: endDate,
								textColor: "black",
								status: element.status,
								color: "#d5d8fd",
							});
						}
					);
					for (let i = 0; i < this.eventAll.length; i++) {
						switch (this.eventAll[i].status) {
							case "Planning_Pending":
								this.eventAll[i].color = "#ffdbca";
								break;
							case "Approval_Pending":
								this.eventAll[i].color = "#fff1b3";
								break;
							case "Event has been approved..!":
								this.eventAll[i].color = "#c1ffc1";
								break;
							case "Approved":
								this.eventAll[i].color = "#c1ffc1";
								break;
							default:
								this.eventAll[i].color = "#ffbfbf";
								break;
						}
					}
					this.calenderEvents =
						this.holidayAll != undefined
							? [...this.eventAll, ...this.holidayAll]
							: [...this.eventAll];
					this.flag = true;
					this.changeDetectorRef.detectChanges();
				}
			});
	}

	getPaginationEvents() {
		this.flag = false;
		this.event.approveOrReject = this.approveOrReject;
		this.currentDate =
			this.lastDate === undefined ? new Date() : this.lastDate;
		const year = this.currentDate.getFullYear();
		const month = this.currentDate.getMonth();
		const firstDate = this.date.transform(
			new Date(year, month, 1),
			"yyyy-MM-dd"
		);
		const lastDate = this.date.transform(
			new Date(year, month + 1, 0),
			"yyyy-MM-dd"
		);
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize
		);
		this.event
			.getAllEventsByFilterWithPagination(
				firstDate,
				lastDate,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId,
				this.empId,
				queryParams
			)
			.subscribe((res: any) => {
				if (res && res.status) {
					this.scope = res;
					this.listEvents = res.content;
					if (this.listEvents && this.listEvents.length > 0) {
						this.numRows = this.listEvents.filter(
							(ele: { status: string }) => {
								return ele.status === "Approval_Pending";
							}
						);
						this.noData = false;
					} else {
						this.noData = true;
					}
					this.flag = true;
					this.changeDetectorRef.detectChanges();
				}
			});
		this.page1 = 0;
		this.pageSize1 = 10;
	}

	paginatorEvents(event: { pageIndex: number; pageSize: number }) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.getPaginationEvents();
	}

	approveOrRejectPaginatorEvents(event: {
		pageIndex: number;
		pageSize: number;
	}) {
		this.page1 = event.pageIndex;
		this.pageSize1 = event.pageSize;
		this.eventsForApporRej();
	}

	isAllSelected(): boolean {
		const numSelected = this.selection.selected.length;
		const numRows = this.numRows.length;
		return numSelected === numRows;
	}

	masterToggle() {
		if (this.selection.selected.length === this.numRows.length) {
			this.selection.clear();
		} else {
			this.numRows.forEach((row: any) => {
				this.selection.select(row);
			});
		}
	}

	checkboxLabel(row?: any): string {
		if (!row) {
			return `${this.isAllSelected() ? "select" : "deselect"} all`;
		}
		return `${this.selection.isSelected(row) ? "deselect" : "select"} row ${
			row.position + 1
		}`;
	}

	handleDateClick(arg: {
		target: {
			dataset: { date: String };
			children: { textContent: any }[];
			textContent: any;
		};
		path: Array<{
			localName: string;
			ariaLabel: string;
			textContent: string;
		}>;
	}) {
		// handler method
		this.eventStartDate = arg.target.dataset.date;
		this.event.eventStartDate = this.eventStartDate;

		// --Filtering the EVENTS acc to Month--
		if (arg.path[1].ariaLabel === "next") {
			this.currentDate =
				this.lastDate === undefined ? new Date() : this.lastDate;
			const year = this.currentDate.getFullYear();
			const month = this.currentDate.getMonth();
			this.count = 1;
			this.firstDate = new Date(year, month + this.count, 1);
			const firstDate = this.date.transform(this.firstDate, "yyyy-MM-dd");
			this.lastDate = new Date(year, month + this.count + 1, 0);
			const lastDate = this.date.transform(this.lastDate, "yyyy-MM-dd");
			this.changeDetectorRef.detectChanges();
			this.page = 0;
			this.pageSize = 10;
			this.page1 = 0;
			this.pageSize1 = 10;
			this.getAllEventShedules();
			if (this.event.approveOrReject) {
				this.eventsForApporRej();
			} else {
				this.getPaginationEvents();
			}
		} else if (arg.path[1].ariaLabel === "prev") {
			this.currentDate =
				this.lastDate === undefined ? new Date() : this.lastDate;
			const year = this.currentDate.getFullYear();
			const month = this.currentDate.getMonth();
			this.count1 = 1;
			this.firstDate = new Date(year, month - this.count1, 1);
			const firstDate = this.date.transform(this.firstDate, "yyyy-MM-dd");
			this.lastDate = new Date(year, month - this.count1 + 1, 0);
			const lastDate = this.date.transform(this.lastDate, "yyyy-MM-dd");
			this.changeDetectorRef.detectChanges();
			this.page = 0;
			this.pageSize = 10;
			this.page1 = 0;
			this.pageSize1 = 10;
			this.getAllEventShedules();
			if (this.event.approveOrReject) {
				this.eventsForApporRej();
			} else {
				this.getPaginationEvents();
			}
		}
		// --End--
		// -- Navigating to CREATE FORM by Clicking on White Space of Date Cell--
		if (
			this.eventStartDate >= this.date.transform(new Date(), "yyyy-MM-dd")
		) {
			if (arg.path[0].localName === "td") {
				this.router.navigate([
					"/eventManagement/evenManagement/createEvent",
				]);
				this.event.formResetCheck = false;
			}
		}
		// --END--
		// --Navigating to PREVIEW FORM by Clicking on EVENT Either on Space of Div Element Or on Title of the Event--
		if (this.calenderEvents && this.calenderEvents.length) {
			for (const element of this.calenderEvents) {
				if (arg.path[0].localName === "div") {
					if (arg.target.children[0].textContent === element.title) {
						this.event.eventId = element.id;
						this.router.navigate([
							"/eventManagement/evenManagement",
							this.event.eventId,
						]);
					}
				}

				if (arg.path[0].textContent === element.title) {
					this.event.eventId = element.id;
					this.router.navigate([
						"/eventManagement/evenManagement",
						this.event.eventId,
					]);
				}
				if (arg.path[0].textContent === element.title) {
					this.event.eventId = element.id;
					this.router.navigate([
						"/eventManagement/evenManagement",
						this.event.eventId,
					]);
				}
				if (arg.path[3].localName === "td") {
					for (const element of this.calenderEvents) {
						if (arg.target.textContent === element.title) {
							this.event.eventId = element.id;
							this.router.navigate([
								"/eventManagement/evenManagement",
								this.event.eventId,
							]);
						}
					}
				}
				// END
			}
		}
		//END
	}

	editEvent(event: { id: any }) {
		this.event.eventId = event.id;

		this.router.navigate([
			"/eventManagement/evenManagement",
			this.event.eventId,
		]);
	}

	approve(event: { statusRemarks: string; id: any }) {
		event.statusRemarks = "Event has been approved..!";
		this.event
			.approveEventShedule(
				event.id,
				event,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res) => {
				this.eventsForApporRej();
				this.sendSMS(event, "Approved");
				this.sendEmail(event, "Approved");
			});
	}

	reject(event: { statusRemarks: string; id: any }) {
		event.statusRemarks = "Event has been rejected please try again..";
		this.event
			.rejectEventShedule(
				event.id,
				event,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res) => {
				this.eventsForApporRej();
				this.sendSMS(event, "Rejected");
				this.sendEmail(event, "Rejected");
			});
	}

	bulkapprove() {
		this.selection.selected.forEach((event) => {
			event.statusRemarks = "Event has been approved..!";
			this.event
				.approveEventShedule(
					event.id,
					event,
					this.loginEmployee.orgId,
					this.loginEmployee.branchId
				)
				.subscribe((res) => {
					this.eventsForApporRej();
					this.sendSMS(event, "Approved");
					this.sendEmail(event, "Approved");
				});
		});
	}

	bulkreject() {
		this.selection.selected.forEach((event) => {
			event.statusRemarks = "Event has been rejected please try again..";
			this.event
				.rejectEventShedule(
					event.id,
					event,
					this.loginEmployee.orgId,
					this.loginEmployee.branchId
				)
				.subscribe((res) => {
					this.eventsForApporRej();
					this.sendSMS(event, "Rejected");
					this.sendEmail(event, "Rejected");
				});
		});
	}

	saveRemarks() {
		this.modalService.dismissAll();
	}

	eventsForApporRej() {
		this.event.approveOrReject = !this.approveOrReject;
		this.flag = false;
		this.listEvents = [];
		this.currentDate =
			this.lastDate === undefined ? new Date() : this.lastDate;
		const year = this.currentDate.getFullYear();
		const month = this.currentDate.getMonth();
		const firstDate = this.date.transform(
			new Date(year, month, 1),
			"yyyy-MM-dd"
		);
		const lastDate = this.date.transform(
			new Date(year, month + 1, 0),
			"yyyy-MM-dd"
		);
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page1,
			this.pageSize1
		);
		this.event
			.getAllEventsByFilterWithPaginationApproveorReject(
				firstDate,
				lastDate,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId,
				this.empId,
				queryParams
			)
			.subscribe((res: any) => {
				if (res && !res.status) {
					this.scope = res;
					this.listEvents = res.content;
					if (this.listEvents && this.listEvents.length > 0) {
						this.numRows = this.listEvents.filter(
							(ele: { status: string }) => {
								return ele.status === "Approval_Pending";
							}
						);
						this.noData = false;
					} else {
						this.noData = true;
					}
					this.flag = true;
					this.changeDetectorRef.detectChanges();
				}
				this.flag = true;
				this.changeDetectorRef.detectChanges();
			});
		this.page = 0;
		this.pageSize = 10;
	}

	sendEmail(obj, type: string) {
		let emails = [];
		obj.eventEmpDetails.forEach((a: { empEmailId: any }) => {
			if (a.empEmailId) {
				emails.push(a.empEmailId);
			}
		});
		if (obj.approverEmailId) {
			emails.push(obj.approverEmailId);
		}
		if (obj.organiserEmailId) {
			emails.push(obj.organiserEmailId);
		}
		let data = {
			content: "Event " + obj.name + " has been " + type,
			contentType: "text",
			from: "automate.customerapp@gmail.com",
			fromName: "Automate",
			subject: "Event Management Notification",
			to: emails,
		};
		this.notificationService.sendEmail(data).subscribe((responce) => {});
	}

	sendSMS(obj, type: string) {
		let phoneNos = "";
		obj.eventEmpDetails.forEach((a: { empPhone: string }) => {
			if (phoneNos === "" && a.empPhone !== "0") {
				phoneNos = a.empPhone;
			} else {
				if (a.empPhone !== "0") {
					phoneNos = phoneNos + "," + a.empPhone;
				}
			}
		});
		if (phoneNos === "" && obj.approverPhone !== "0") {
			phoneNos = obj.approverPhone;
		} else {
			if (obj.approverPhone !== "0") {
				phoneNos = phoneNos + "," + obj.approverPhone;
			}
		}
		if (phoneNos === "" && obj.organiserPhone !== "0") {
			phoneNos = obj.organiserPhone;
		} else {
			if (obj.organiserPhone !== "0") {
				phoneNos = phoneNos + "," + obj.organiserPhone;
			}
		}
		let data = {
			message: "Event " + obj.name + " has been " + type,
			messageType: "",
			phoneNumber: phoneNos,
			senderId: "",
		};
		this.notificationService.sendSMS(data).subscribe((responce) => {});
	}
}
