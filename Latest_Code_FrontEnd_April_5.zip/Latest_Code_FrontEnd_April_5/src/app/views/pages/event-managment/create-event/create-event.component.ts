import {
	Component,
	OnInit,
	ChangeDetectorRef,
	Injectable,
} from "@angular/core";
import {
	FormGroup,
	FormControl,
	FormArray,
	FormBuilder,
	ValidationErrors,
	Validators,
} from "@angular/forms";
import { EventManagementService } from "../../../../core/e-commerce/_services/event-management.service";
import { NotificationService } from "../../../../core/e-commerce/_services/notification.service";
import { QueryParamsModel } from "../../../../core/_base/crud";
import { Router } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { DatePipe } from "@angular/common";
import { SharedService } from "../../../../core/e-commerce/_services";

@Injectable()
@Component({
	selector: "kt-create-event",
	templateUrl: "./create-event.component.html",
	styleUrls: ["./create-event.component.scss"],
	providers: [DatePipe],
})
export class CreateEventComponent implements OnInit {
	pastTime1: any;

	constructor(
		public event: EventManagementService,
		public notificationService: NotificationService,
		private changeDetectorRef: ChangeDetectorRef,
		private modalService: NgbModal,
		private fb: FormBuilder,
		private router: Router,
		private date: DatePipe,
		private sharedService: SharedService
	) {
		this.startDate1 = this.event.eventStartDate;
		this.smForm = new FormGroup({
			// -- EVENT SHEDULE --
			eventName: new FormControl(""),
			eventNumber: new FormControl(),
			organizer: new FormControl(),
			pincode: new FormControl(""),
			type: new FormControl(""),
			approverEmailId: new FormControl(""),
			approverPhone: new FormControl(""),
			organiserEmailId: new FormControl(""),
			organiserPhone: new FormControl(""),
			// otherType: new FormControl(this.otherTypeValues),
			category: new FormControl(""),
			otherCategory: new FormControl(this.otherCategoryValue),
			assessmentPotential: new FormArray([]),
			area: new FormControl(""),
			location: new FormControl(""),
			district: new FormControl(""),
			state: new FormControl(""),

			startDate: new FormControl("", Validators.required),
			startTime: new FormControl(""),
			endDate: new FormControl("", Validators.required),
			endTime: new FormControl(""),

			// -- DEMO VEHICLES --
			rcNo: new FormControl(this.rcNo),
			vehicleId: new FormControl(this.vehicleId),
			model: new FormControl(this.models),
			varient: new FormControl(this.variant),
			colour: new FormControl(this.color),
			fuel: new FormControl(this.fuel),
			// -- EMPLOYEE DETAILS --
			empId: new FormControl(this.empId),
			tl: new FormControl(""),
			dse: new FormControl(),
			driver: new FormControl(),
			otherEmployee: new FormArray([]),
			financeExecutive: new FormControl(""),
			evaluator: new FormControl(""),
			// -- ITEM LIST --
			itemList: this.fb.array([
				// this.itemListGroup()
			]),
			otherItem: new FormControl(this.otherItem),
			"req.leaflets": new FormControl(""),
			budget: new FormControl("", { validators: this.invalid }),
			remarks: new FormControl(),
		});
	}
	tempHolders: number;
	eventCategory: Object;
	eventType: Object;
	getEventShedule: Object;
	getEventSheduleAssessment = [];
	getEventSheduleEndtime;
	finalBudget: any = 0;
	roleId: Number = 117;
	startDate1: any;
	selectedId: any;
	employeesList1: any = [];
	eventEmpList: any = [];
	minDate = this.date.transform(new Date(), "yyyy-MM-dd");
	minTime = new Date();

	newTempdropdownEmp: any = [];
	tlList: any = [];
	selected: any;
	finalEmpList: any = [];
	flag1 = false;
	queryParams: QueryParamsModel;
	submittedOrganiserId: any;
	pastTime: any;
	selectedOtherItem: any;
	tlList1: any = [];
	dseList: any = [];
	driverList: any = [];
	feList: any = [];
	evalutorList: any;
	evaluatorList: any = [];
	dseList1: any = [];
	driverList1: any = [];
	feList1: any = [];
	evalutorList1: any = [];
	selected1: any;
	selected2: any;
	selected3: any;
	selected4: any;
	events = [];
	empId: any[] = [];
	editAssessmentArr: any[];
	page = 0;
	pageSize = 10;
	scope: any;
	eventStartDate: any = this.event.eventStartDate;
	assessmentvalue: any;

	addVehicle: any = [];
	vehicleList = [];
	addVehicles: any = [];
	models = [];
	color = [];
	variant = [];
	fuel = [];
	rcNo = [];
	vehicleId = [];
	flag = false;
	category: any = [];
	itemNames: any = [];
	eventTypes: any = [];
	budgetvalue: [];

	otherCategoryValue: any;
	otherTypeValues: any;
	otherItem: any[] = [];
	employeesList: any = [];
	invalid;
	isLoading = false;

	smForm: FormGroup;

	tempHolder = 0;
	endDatetime;
	time;

	startDatetime;
	roleId1;
	managerRole;
	loginEmployee;
	totalBudget;

	hidden = false;
	ngOnInit(): void {
		window.onload = (event) => {
			this.router.navigate(["eventManagement/evenManagement"]);
		};
		this.newTempdropdownEmp = this.sharedService.employeeDetailsArray;
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));

		if (this.event.approveOrReject) {
			this.managerRole = true;
		} else {
			this.managerRole = false;
		}
		this.event.getEventCategories().subscribe((res) => {
			this.category = res;
		});
		this.event.getBudgetItems().subscribe((res) => {
			this.itemNames = res;
		});
		this.event.getEventTypes().subscribe((res) => {
			this.eventTypes = res;
		});
		this.event.getTlList().subscribe((res: any) => {
			this.tlList1 = res.dmsEntity.employees;
		});
		this.event.getDseList().subscribe((res: any) => {
			this.dseList = res.dmsEntity.employees;
		});
		this.event.getDriverList().subscribe((res: any) => {
			this.driverList = res.dmsEntity.employees;
		});
		this.event.getFinanceExecutiveList().subscribe((res: any) => {
			this.feList = res.dmsEntity.employees;
		});
		this.event.getEvaluatorList().subscribe((res: any) => {
			this.evaluatorList = res.dmsEntity.employees;
		});
		this.queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize
		);
		if (this.event.formResetCheck === true) {
			this.event.getTlList().subscribe((res: any) => {
				this.tlList1 = res.dmsEntity.employees;
			});
			this.event.getDseList().subscribe((res: any) => {
				this.dseList = res.dmsEntity.employees;
			});
			this.event.getDriverList().subscribe((res: any) => {
				this.driverList = res.dmsEntity.employees;
			});
			this.event.getFinanceExecutiveList().subscribe((res: any) => {
				this.feList = res.dmsEntity.employees;
			});
			this.event.getEvaluatorList().subscribe((res: any) => {
				this.evaluatorList = res.dmsEntity.employees;
			});
			this.event
				.getEventShedule(
					this.event.eventId,
					this.queryParams,
					this.loginEmployee.orgId,
					this.loginEmployee.branchId
				)
				.subscribe((res) => {
					this.submittedOrganiserId = res[0].organiserId; // sending in Update method Call
					const control = this.smForm.controls.itemList as FormArray;
					if (res[0].budget) {
						res[0].budget.forEach(() => {
							// iterate the array
							control.push(this.itemListGroup()); // push values
						});
					}
					const vehiclesList1 = [];
					if (res[0].eventVehicleDetails) {
						res[0].eventVehicleDetails.forEach((x) => {
							// iterate the array
							vehiclesList1.push({
								rcNo: x.rcNo,
								vehicleInfo: {
									model: x.model,
									varientName: x.variant,
									color: x.color,
									fuelType: x.fuel,
								},
							}); // push values
						});
					}
					this.addVehicles = vehiclesList1;
					this.vehicleId = res[0].eventVehicleDetails;

					const otherEmployee = this.smForm.controls
						.otherEmployee as FormArray;
					if (res[0].others) {
						res[0].others.forEach(() => {
							otherEmployee.push(this.otherEmployeeGroup());
						});
					}
					const assessment = this.smForm.controls
						.assessmentPotential as FormArray;
					if (res[0].assessments) {
						res[0].assessments.forEach((x) => {
							assessment.push(
								this.fb.group({
									question: x.question,
									value: x.value,
								})
							);
						});
					}
					this.tlList1.forEach((element) => {
						res[0].eventEmpDetails.forEach((sub) => {
							if (element.empId.toString() === sub.empId) {
								this.tlList.push(sub.empName);
								this.finalEmpList.push(element);
								this.selected = this.tlList;
							}
						});
					});
					this.dseList.forEach((element) => {
						res[0].eventEmpDetails.forEach((sub) => {
							if (element.empId.toString() === sub.empId) {
								this.dseList1.push(sub.empName);
								this.finalEmpList.push(element);
								this.selected1 = this.dseList1;
							}
						});
					});
					this.driverList.forEach((element) => {
						res[0].eventEmpDetails.forEach((sub) => {
							if (element.empId.toString() === sub.empId) {
								this.driverList1.push(sub.empName);
								this.finalEmpList.push(element);
								this.selected2 = this.driverList1;
							}
						});
					});
					this.feList.forEach((element) => {
						res[0].eventEmpDetails.forEach((sub) => {
							if (element.empId.toString() === sub.empId) {
								this.feList1.push(sub.empName);
								this.finalEmpList.push(element);
								this.selected3 = this.feList1;
							}
						});
					});
					this.evaluatorList.forEach((element) => {
						res[0].eventEmpDetails.forEach((sub) => {
							if (element.empId.toString() === sub.empId) {
								this.evalutorList1.push(sub.empName);
								this.finalEmpList.push(element);
								this.selected4 = this.evalutorList1;
							}
						});
					});

					// -- END --
					this.flag = true;
					setTimeout(() => {
						this.smForm.patchValue({
							eventName: res[0].name,
							pincode: res[0].pincode,
							type: res[0].eventType.name,
							approverEmailId: res[0].approverEmailId,
							approverPhone: res[0].approverPhone,
							organiserEmailId: res[0].organiserEmailId,
							organiserPhone: res[0].organiserPhone,
							category: res[0].eventCategory.name,
							area: res[0].area,
							location: res[0].location,
							district: res[0].district,
							state: res[0].state,
							startDate: res[0].startDatetime.substr(0, 10),
							startTime: {
								hour: parseInt(
									res[0].startDatetime.substr(11, 2)
								),
								minute: parseInt(
									res[0].startDatetime.substr(14, 2)
								),
							},
							endDate: res[0].endDatetime.substr(0, 10),
							endTime: {
								hour: parseInt(
									res[0].endDatetime.substr(11, 2)
								),
								minute: parseInt(
									res[0].endDatetime.substr(14, 2)
								),
							},
							eventStart: res[0].startDatetime,
							eventEnd: res[0].endDatetime,
							tl: res[0].others,
							budget: res[0].totalBudgetAmount,
							itemList: res[0].budget,
							otherEmployee: res[0].others,
							assessments: res[0].assessmentPotential,
							organizer: res[0].organiserName,
							areatype: res[0].areatype,
							availableCars: res[0].availableCars,
							populationStrngth: res[0].populationStrngth,
						});
					}, 2000);
				});
			// debugger;
		} else {
			this.smForm.reset();
			this.eventStartDate = this.event.eventStartDate;
			this.smForm.patchValue({
				startDate: this.eventStartDate,
				organizer: this.loginEmployee.empName,
				otherEmployee: [
					{
						designation: "",
						employeeName: "",
					},
				],
				itemList: [this.itemListGroup()],
			});
		}

		this.employeesList = [];
		this.isLoading = true;
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize
		);
		this.event
			.getRedsignedRoles(
				this.queryParams,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((response) => {
				if (response) {
					this.scope = response.dmsEntity.employeesPage;
					this.employeesList = response.dmsEntity.employeesPage
						? response.dmsEntity.employeesPage.content
						: [];
					this.isLoading = false;
					this.changeDetectorRef.detectChanges();
				}
			});
	}
	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
	}
	// -- EVENT LIST --

	itemListGroup() {
		return this.fb.group({
			name: [],
			officeAllotte: [],
			quantity: [],
			cost: [],
			price: [],
			remarks: [],
		});
	}
	otherEmployeeGroup() {
		return this.fb.group({
			designation: "",
			employeeName: "",
		});
	}
	optionSelect1(event, tl) {}
	otherItems(content, names, index) {
		if (
			names.name === "Police permission" ||
			names.name === "Land rent" ||
			names.name === "Local body Permission"
		) {
			const quantity: any = this.smForm.controls.itemList;
			quantity.at(index).patchValue({ quantity: 1 });
		}
		if (names.name === "Other") {
			this.modalService.open(content, {
				backdrop: "static",
				keyboard: false,
				size: "lg",
			});
		}
	}

	saveOtherItem(otheritem) {
		this.selectedOtherItem = otheritem;
		this.otherItem.push(otheritem);
		this.modalService.dismissAll();
	}
	cal(event, i) {
		this.smForm.value.itemList[i].price = 0;
		this.smForm.value.itemList[i].price =
			this.smForm.value.itemList[i].quantity *
			this.smForm.value.itemList[i].cost;
		// -- Budget Caluculation--
		this.smForm.value.itemList.forEach((element) => {
			this.finalBudget = this.finalBudget + Number(element.price);
		});
		this.smForm.patchValue({
			budget: this.finalBudget,
		});
		this.totalBudget = this.finalBudget;
		this.finalBudget = 0;
		// -- END --
	}

	addItem() {
		(this.smForm.get("itemList") as FormArray).push(this.itemListGroup());
	}
	removeItem(i) {
		(this.smForm.get("itemList") as FormArray).removeAt(i);
		// --Checking the Budget Caluculation--
		this.finalBudget = 0;
		this.smForm.value.itemList.forEach((element) => {
			this.finalBudget = this.finalBudget + Number(element.price);
		});
		this.smForm.patchValue({
			budget: this.finalBudget,
		});
		this.totalBudget = this.finalBudget;
		this.finalBudget = 0;
		// -- END --
	}
	officeAllotted(event, i) {
		if (event.target.checked === true) {
			// --Checking the Budget Caluculation--
			this.finalBudget = 0;
			this.smForm.value.itemList.forEach((element) => {
				this.finalBudget = this.finalBudget + Number(element.price);
			});
			this.smForm.patchValue({
				budget: this.finalBudget,
			});
			this.totalBudget = this.finalBudget;
			this.finalBudget = 0;
			// -- END --
			event.path[2].nextElementSibling.nextElementSibling.firstElementChild.firstChild.hidden = true;
			event.path[2].nextElementSibling.nextElementSibling.nextElementSibling.firstElementChild.firstChild.hidden = true;
			event.path[2].nextElementSibling.nextElementSibling.nextElementSibling.nextElementSibling.firstElementChild.firstChild.hidden = true;
		} else {
			// --Checking the Budget Caluculation--
			this.finalBudget = 0;
			this.smForm.value.itemList.forEach((element) => {
				this.finalBudget = this.finalBudget + Number(element.price);
			});
			this.smForm.patchValue({
				budget: this.finalBudget,
			});
			this.totalBudget = this.finalBudget;
			this.finalBudget = 0;
			// -- END --
			event.path[2].nextElementSibling.nextElementSibling.firstElementChild.firstChild.hidden = false;
			event.path[2].nextElementSibling.nextElementSibling.nextElementSibling.firstElementChild.firstChild.hidden = false;
			event.path[2].nextElementSibling.nextElementSibling.nextElementSibling.nextElementSibling.firstElementChild.firstChild.hidden = false;
		}
	}

	// -- EVENT CATEGORY --

	assessment(value, i, content3) {
		this.eventCategory = {
			id: value.id,
			name: value.name,
		};
		(this.smForm.get("assessmentPotential") as FormArray).clear();
		this.event.getAssessment(value.id).subscribe((res) => {
			res.forEach((element) => {
				if (value.name === element.eventCategory.name) {
					(this.smForm.get("assessmentPotential") as FormArray).push(
						this.fb.group({
							question: element.question,
							value: [],
						})
					);
				}
			});
		});
		this.modalService.open(content3, {
			backdrop: "static",
			keyboard: false,
			size: "lg",
		});
	}

	saveAssessment(content) {
		this.flag = true;
		this.modalService.dismissAll();
		this.checkUpcomingEvents(content);
	}

	editAssessment(content) {
		this.modalService.open(content, {
			backdrop: "static",
			keyboard: false,
			size: "lg",
		});
	}

	saveEditedAssessment(assessment) {
		this.modalService.dismissAll();
	}

	otherCategory(content) {
		// this.flag=!this.flag;
		// event.target.checked= false
		this.modalService.open(content, {
			keyboard: false,
			backdrop: "static",
			size: "lg",
		});
	}

	// -- PINCODE --

	pincodeSearch(event, form) {
		this.event.getLocationUsingPincode(event).subscribe((res) => {
			form.patchValue({
				state: res[0].PostOffice[0].State,
				district: res[0].PostOffice[0].District,
				location: res[0].PostOffice[0].Name,
			});
		});
	}

	// -- EVENT TYPE --

	_type(value) {
		this.eventType = {
			id: value.id,
			name: value.name,
		};
	}

	otherType(content) {
		// this.flag=!this.flag;
		// event.target.checked= false
		this.modalService.open(content, {
			size: "lg",
		});
	}

	saveOtherType(other) {
		this.eventTypes.push(other);
		this.otherTypeValues = other;
		this.modalService.dismissAll();
	}

	// -- DEMO VEHICLES --
	openLarge(content, event) {
		this.modalService.open(content, {
			backdrop: "static",
			keyboard: false,
			size: "lg",
		});
		this.event
			.getVehicles(this.loginEmployee.branchId,  this.loginEmployee.orgId)
			.subscribe((vehicle) => {
				this.vehicleList = vehicle.vehicles;

				// Checking response of this array elements with the one already Pushed Array
				this.vehicleList.forEach((element) => {
					this.addVehicles.forEach((subelement) => {
						if (element.rcNo === subelement.rcNo) {
							element.check = true;
						}
					});
				});
			});
	}
	closeLarge() {
		this.modalService.dismissAll();
	}
	checkVehicle(vehicle, event, content7, content8) {
		if (event.target.checked === true) {
			let statusOfResponse;
			this.vehicleList.forEach((element1) => {
				if (element1.id === vehicle.id) {
					this.event
						.getvehicleAllotments(this.startDate1, element1.id)
						.subscribe((response: any) => {
							statusOfResponse = response.statusDescription;
							if (statusOfResponse) {
								this.modalService.open(content7, {
									keyboard: false,
									backdrop: "static",
									size: "lg",
								});
								this.selectedId = element1.id;
							} else {
								this.modalService.open(content8, {
									keyboard: false,
									backdrop: "static",
									size: "lg",
								});
								this.selectedId = element1.id;
							}
						});
				}
			});
		}
	}

	vehicle() {
		this.vehicleId = [];
		this.addVehicle = [];
		this.vehicleList.forEach((element, index) => {
			const checkedItem = document.getElementById(
				"checkbox" + index
			) as HTMLInputElement;
			if (checkedItem.checked === true) {
				this.addVehicle.push(element);
			}
		});
		this.addVehicles = [...this.addVehicle];

		for (let i = 0; i < this.addVehicle.length; i++) {
			this.vehicleId.push({
				vehicleId: this.addVehicles[i].vehicleId,
				rcNo: this.addVehicles[i].rcNo,
				model: this.addVehicles[i].vehicleInfo.model,
				variant: this.addVehicles[i].vehicleInfo.varientName,
				color: this.addVehicles[i].vehicleInfo.color,
				fuel: this.addVehicles[i].vehicleInfo.fuelType,
			});
			this.models.push(this.addVehicles[i].vehicleInfo.model);
			this.fuel.push(this.addVehicles[i].vehicleInfo.fuelType);
			this.color.push(this.addVehicles[i].vehicleInfo.color);
			this.variant.push(this.addVehicles[i].vehicleInfo.varientName);
			this.rcNo.push(this.addVehicles[i].rcNo);
		}
		this.modalService.dismissAll();
	}
	remove(i) {
		this.models.splice(i, 1);
		this.fuel.splice(i, 1);
		this.color.splice(i, 1);
		this.variant.splice(i, 1);
		this.rcNo.splice(i, 1);
		this.addVehicle.splice(i, 1);
		this.addVehicles.splice(i, 1);
		this.vehicleId.splice(i, 1);
	}

	// -- EMPLOYEE DETAILS --

	addotherEmployee() {
		(this.smForm.get("otherEmployee") as FormArray).push(
			new FormGroup({
				designation: new FormControl(),
				employeeName: new FormControl(),
			})
		);
	}
	removeotherEmployee(i) {
		(this.smForm.get("otherEmployee") as FormArray).removeAt(i);
	}
	optionSelect(event, val) {
		this.finalEmpList.forEach((element, index) => {
			if (event === false) {
				if (element.empId === val.empId) {
					this.finalEmpList.splice(index, 1);
				}
			}
		});
		if (event === true) {
			this.eventEmpList.push(val);
		} else {
			this.eventEmpList.forEach((element, index) => {
				if (element.empId === val.empId) {
					this.eventEmpList.splice(index, 1);
				}
			});
		}
	}
	back() {
		this.event.formResetCheck === true
			? this.router.navigate([
					"/eventManagement/evenManagement",
					this.event.eventId,
			  ])
			: this.router.navigate(["/eventManagement/evenManagement"]);
	}
	isBudgetValid() {
		if (this.smForm.value.budget < this.totalBudget) {
			this.invalid = true;
		} else {
			this.invalid = false;
		}
	}
	backtoCalendar() {
		this.router.navigate(["/eventManagement/evenManagement"]);
	}
	checkUpcomingEvents(content) {
		if (this.smForm.value.category && this.smForm.value.area) {
			const categoryId = this.category.filter(
				(a) => a.name === this.smForm.value.category
			)[0].id;
			this.event
				.upcomingEvents(
					this.smForm.value.startDate,
					categoryId,
					this.smForm.value.area,
					this.loginEmployee.orgId,
					this.loginEmployee.branchId
				)
				.subscribe((data) => {
					this.events = data;
					if (this.events.length > 0) {
						this.modalService.open(content, {
							backdrop: "static",
							keyboard: false,
							size: "lg",
						});
					}
				});
		}
	}

	isStartTimeValid() {
		if (this.smForm.controls.startTime.value) {
			const currentTime = this.date.transform(
				new Date(),
				"yyyy-MM-dd H:mm"
			);
			const startTimeHour =
				this.smForm.controls.startTime.value.hour < 10
					? "0" + this.smForm.controls.startTime.value.hour
					: this.smForm.controls.startTime.value.hour;
			const startTimeMin =
				this.smForm.controls.startTime.value.minute < 10
					? "0" + this.smForm.controls.startTime.value.minute
					: this.smForm.controls.startTime.value.minute;
			const startTime = `${this.date.transform(
				this.smForm.controls.startDate.value,
				"yyyy-MM-dd"
			)} ${startTimeHour}:${startTimeMin}`;

			if (startTime < currentTime) {
				this.pastTime = true;
			} else {
				this.pastTime = false;
			}
		}
	}
	isEndTimeValid() {
		if (this.smForm.controls.endTime.value) {
			const startTimeHour =
				this.smForm.controls.startTime.value.hour < 10
					? "0" + this.smForm.controls.startTime.value.hour
					: this.smForm.controls.startTime.value.hour;
			const startTimeMin =
				this.smForm.controls.startTime.value.minute < 10
					? "0" + this.smForm.controls.startTime.value.minute
					: this.smForm.controls.startTime.value.minute;
			const endTimeHour =
				this.smForm.controls.endTime.value.hour < 10
					? "0" + this.smForm.controls.endTime.value.hour
					: this.smForm.controls.endTime.value.hour;
			const endTimeMin =
				this.smForm.controls.endTime.value.minute < 10
					? "0" + this.smForm.controls.endTime.value.minute
					: this.smForm.controls.endTime.value.minute;
			const startTime = `${this.date.transform(
				this.smForm.controls.startDate.value,
				"yyyy-MM-dd"
			)} ${startTimeHour}:${startTimeMin}`;
			const endTime = `${this.date.transform(
				this.smForm.controls.endDate.value,
				"yyyy-MM-dd"
			)} ${endTimeHour}:${endTimeMin}`;
			if (endTime < startTime) {
				this.pastTime1 = true;
			} else {
				this.pastTime1 = false;
			}
		}
	}
	// -- FORM SUBMITING --
	submit() {
		this.endDatetime = (
			Date.parse(
				this.date.transform(this.smForm.value.endDate, "yyyy-MM-dd")
			) +
			(this.smForm.value.endTime.hour * 60 * 60 * 1000 +
				this.smForm.value.endTime.minute * 60 * 1000)
		).toString();
		this.startDatetime = (
			Date.parse(
				this.date.transform(this.smForm.value.startDate, "yyyy-MM-dd")
			) +
			(this.smForm.value.startTime.hour * 60 * 60 * 1000 +
				this.smForm.value.startTime.minute * 60 * 1000)
		).toString();
		this.smForm.controls.endDate.patchValue(
			this.date.transform(this.smForm.value.endDate, "yyyy-MM-dd")
		);
		this.smForm.controls.startDate.patchValue(
			this.date.transform(this.smForm.value.startDate, "yyyy-MM-dd")
		);
		const obj = {
			// "id": "",
			name: this.smForm.value.eventName,
			district: this.smForm.value.district,
			area: this.smForm.value.area,
			eventId: "001",
			branchId: this.loginEmployee.branchId,
			organizationId: this.loginEmployee.orgId,
			budget: this.smForm.value.itemList,
			totalBudgetAmount: this.smForm.value.budget,
			eventCategory: this.eventCategory,
			eventEmpDetails: this.eventEmpList,
			enddate: this.smForm.value.endDate,
			startdate: this.smForm.value.startDate,
			endDatetime: this.endDatetime,
			location: this.smForm.value.location,
			startDatetime: this.startDatetime,
			assessments: this.smForm.value.assessmentPotential,
			pincode: this.smForm.value.pincode,
			eventVehicleDetails: this.vehicleId,
			others: this.smForm.value.otherEmployee,
			eventType: this.eventType,
			state: this.smForm.value.state,
			leafLetsQuntiry: "1",
			longitude: "Chan",
			latitude: "demo",
			status: "Approval_Pending",
			organiserId: this.loginEmployee.empId,
			organiserName: this.loginEmployee.empName,
			managerId: this.loginEmployee.approverId,
		};
		if (this.smForm.valid) {
			this.event
				.postEventShedule(
					obj,
					this.loginEmployee.orgId,
					this.loginEmployee.branchId
				)
				.subscribe((res) => {
					if (!res.status) {
						window.alert("Event has been successfully created");
						this.router.navigate([
							"eventManagement/evenManagement",
						]);
					} else {
						window.alert(res.message);
					}
				});
		} else {
			alert("Please Fill all the details before Submit");
		}
	}

	omit_special_char(event) {
		let k;
		k = event.charCode; //
		return (
			(k > 64 && k < 91) ||
			(k > 96 && k < 123) ||
			k === 8 ||
			k === 32 ||
			(k >= 48 && k <= 57)
		);
	}

	update() {
		this.endDatetime = (
			Date.parse(
				this.date.transform(this.smForm.value.endDate, "yyyy-MM-dd")
			) +
			(this.smForm.value.endTime.hour * 60 * 60 * 1000 +
				this.smForm.value.endTime.minute * 60 * 1000)
		).toString();
		this.startDatetime = (
			Date.parse(
				this.date.transform(this.smForm.value.startDate, "yyyy-MM-dd")
			) +
			(this.smForm.value.startTime.hour * 60 * 60 * 1000 +
				this.smForm.value.startTime.minute * 60 * 1000)
		).toString();
		this.smForm.controls.endDate.patchValue(
			this.date.transform(this.smForm.value.endDate, "yyyy-MM-dd")
		);
		this.smForm.controls.startDate.patchValue(
			this.date.transform(this.smForm.value.startDate, "yyyy-MM-dd")
		);
		this.eventTypes.forEach((element) => {
			if (this.smForm.value.type === element.name) {
				this.eventType = element;
			}
		});

		this.category.forEach((element) => {
			if (this.smForm.value.category === element.name) {
				this.eventCategory = element;
			}
		});

		const obj = {
			id: this.event.eventId,
			name: this.smForm.value.eventName,
			district: this.smForm.value.district,
			area: this.smForm.value.area,
			eventId: "001",
			branchId: this.loginEmployee.branchId,
			organizationId: this.loginEmployee.orgId,
			budget: this.smForm.value.itemList,
			totalBudgetAmount: this.smForm.value.budget,
			eventCategory: this.eventCategory,
			eventEmpDetails: this.eventEmpList.concat(this.finalEmpList),
			endDatetime: this.endDatetime,
			enddate: this.smForm.value.endDate,
			startdate: this.smForm.value.startDate,
			location: this.smForm.value.location,
			startDatetime: this.startDatetime,
			assessments: this.smForm.value.assessmentPotential,
			pincode: this.smForm.value.pincode,
			eventVehicleDetails: this.vehicleId,
			others: this.smForm.value.otherEmployee,
			eventType: this.eventType,
			state: this.smForm.value.state,
			leafLetsQuntiry: "1",
			longitude: "Chan",
			latitude: "demo",
			status: "Approval_Pending",
			organiserId: this.loginEmployee.empId,
			organiserName: this.smForm.value.organizer,
			managerId: this.loginEmployee.approverId,
		};
		this.event
			.updateEventSchedule(
				obj,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res: any) => {
				if (!res.status) {
					window.alert("Event has been successfully Updated");
					this.router.navigate(["eventManagement/evenManagement"]);
				} else {
					window.alert(res.message);
				}
			});
	}
	reset() {
		this.smForm.reset();
	}
	openremarks(content) {
		this.modalService.open(content, {
			keyboard: false,
			backdrop: "static",
			size: "lg",
		});
	}
	reject() {
		this.endDatetime = (
			Date.parse(
				this.date.transform(this.smForm.value.endDate, "yyyy-MM-dd")
			) +
			(this.smForm.value.endTime.hour * 60 * 60 * 1000 +
				this.smForm.value.endTime.minute * 60 * 1000)
		).toString();
		this.startDatetime = (
			Date.parse(
				this.date.transform(this.smForm.value.startDate, "yyyy-MM-dd")
			) +
			(this.smForm.value.startTime.hour * 60 * 60 * 1000 +
				this.smForm.value.startTime.minute * 60 * 1000)
		).toString();
		this.smForm.controls.endDate.patchValue(
			this.date.transform(this.smForm.value.endDate, "yyyy-MM-dd")
		);
		this.smForm.controls.startDate.patchValue(
			this.date.transform(this.smForm.value.startDate, "yyyy-MM-dd")
		);
		this.eventTypes.forEach((element) => {
			if (this.smForm.value.type == element.name) {
				this.eventType = element;
			}
		});

		this.category.forEach((element) => {
			if (this.smForm.value.category == element.name) {
				this.eventCategory = element;
			}
		});
		const obj = {
			id: this.event.eventId,
			name: this.smForm.value.eventName,
			district: this.smForm.value.district,
			area: this.smForm.value.area,
			approverEmailId: this.smForm.value.approverEmailId,
			approverPhone: this.smForm.value.approverPhone,
			organiserEmailId: this.smForm.value.organiserEmailId,
			organiserPhone: this.smForm.value.organiserPhone,
			eventId: "001",
			branchId: this.loginEmployee.branchId,
			organizationId: this.loginEmployee.orgId,
			budget: this.smForm.value.itemList,
			totalBudgetAmount: this.smForm.value.budget,
			eventCategory: this.eventCategory,
			eventEmpDetails: this.eventEmpList.concat(this.finalEmpList),
			endDatetime: this.endDatetime,
			enddate: this.smForm.value.endDate,
			startdate: this.smForm.value.startDate,
			location: this.smForm.value.location,
			startDatetime: this.startDatetime,
			assessments: this.smForm.value.assessmentPotential,
			pincode: this.smForm.value.pincode,
			eventVehicleDetails: this.vehicleId,
			others: this.smForm.value.otherEmployee,
			eventType: this.eventType,
			state: this.smForm.value.state,
			leafLetsQuntiry: "1",
			longitude: "Chan",
			latitude: "demo",
			status: "Approval_Pending",
			organiserId: this.submittedOrganiserId,
			organiserName: this.smForm.value.organizer,
			managerId: this.loginEmployee.empId,
			statusRemarks: this.smForm.value.remarks,
		};
		this.event
			.rejectEventShedule(
				this.event.eventId,
				obj,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res: any) => {
				this.sendEmail(obj, "Rejected");
				this.sendSMS(obj, "Rejected");
				window.alert("Event has been Rejected successfully");
				this.router.navigate(["eventManagement/evenManagement"]);
			});
	}
	approve() {
		this.endDatetime = (
			Date.parse(
				this.date.transform(this.smForm.value.endDate, "yyyy-MM-dd")
			) +
			(this.smForm.value.endTime.hour * 60 * 60 * 1000 +
				this.smForm.value.endTime.minute * 60 * 1000)
		).toString();
		this.startDatetime = (
			Date.parse(
				this.date.transform(this.smForm.value.startDate, "yyyy-MM-dd")
			) +
			(this.smForm.value.startTime.hour * 60 * 60 * 1000 +
				this.smForm.value.startTime.minute * 60 * 1000)
		).toString();
		this.smForm.controls.endDate.patchValue(
			this.date.transform(this.smForm.value.endDate, "yyyy-MM-dd")
		);
		this.smForm.controls.startDate.patchValue(
			this.date.transform(this.smForm.value.startDate, "yyyy-MM-dd")
		);
		this.eventTypes.forEach((element) => {
			if (this.smForm.value.type == element.name) {
				this.eventType = element;
			}
		});

		this.category.forEach((element) => {
			if (this.smForm.value.category == element.name) {
				this.eventCategory = element;
			}
		});
		const obj = {
			id: this.event.eventId,
			name: this.smForm.value.eventName,
			approverEmailId: this.smForm.value.approverEmailId,
			approverPhone: this.smForm.value.approverPhone,
			organiserEmailId: this.smForm.value.organiserEmailId,
			organiserPhone: this.smForm.value.organiserPhone,
			district: this.smForm.value.district,
			area: this.smForm.value.area,
			eventId: "001",
			branchId: this.loginEmployee.branchId,
			organizationId: this.loginEmployee.orgId,
			budget: this.smForm.value.itemList,
			totalBudgetAmount: this.smForm.value.budget,
			eventCategory: this.eventCategory,
			eventEmpDetails: this.eventEmpList.concat(this.finalEmpList),
			endDatetime: this.endDatetime,
			enddate: this.smForm.value.endDate,
			startdate: this.smForm.value.startDate,
			location: this.smForm.value.location,
			startDatetime: this.startDatetime,
			assessments: this.smForm.value.assessmentPotential,
			pincode: this.smForm.value.pincode,
			eventVehicleDetails: this.vehicleId,
			others: this.smForm.value.otherEmployee,
			eventType: this.eventType,
			state: this.smForm.value.state,
			leafLetsQuntiry: "1",
			longitude: "Chan",
			latitude: "demo",
			status: "Approval_Pending",
			organiserId: this.smForm.value.organizer.id
				? this.smForm.value.organizer.id
				: this.submittedOrganiserId,
			organiserName: this.smForm.value.organizer.name
				? this.smForm.value.organizer.name
				: this.smForm.value.organizer,
			statusRemarks: this.smForm.value.remarks,
			managerId: this.loginEmployee.empId,
		};
		this.event
			.approveEventShedule(
				this.event.eventId,
				obj,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res: any) => {
				this.sendEmail(obj, "Approved");
				this.sendSMS(obj, "Approved");
				window.alert("Event has been Approved successfully");
				this.router.navigate(["eventManagement/evenManagement"]);
			});
	}

	sendEmail(obj, type) {
		let emails = [];
		obj.eventEmpDetails.forEach((a) => {
			if (a.email) {
				emails.push(a.email);
			}
		});
		if (obj.approverEmailId) {
			emails.push(obj.approverEmailId);
		}
		if (obj.organiserEmailId) {
			emails.push(obj.organiserEmailId);
		}
		let data = {
			content: "Event " + obj.name + " has been " + type,
			contentType: "text",
			from: "automate.customerapp@gmail.com",
			fromName: "Automate",
			subject: "Event Management Notification",
			to: emails,
		};
		this.notificationService.sendEmail(data).subscribe((responce) => {});
	}

	sendSMS(obj, type) {
		let phoneNos = "";
		obj.eventEmpDetails.forEach((a) => {
			if (phoneNos === "" && a.mobile !== "0") {
				phoneNos = a.mobile;
			} else {
				if (a.mobile !== "0") {
					phoneNos = phoneNos + "," + a.mobile;
				}
			}
		});
		if (phoneNos === "" && obj.approverPhone !== "0") {
			phoneNos = obj.approverPhone;
		} else {
			if (obj.approverPhone !== "0") {
				phoneNos = phoneNos + "," + obj.approverPhone;
			}
		}
		if (phoneNos === "" && obj.organiserPhone !== "0") {
			phoneNos = obj.organiserPhone;
		} else {
			if (obj.organiserPhone !== "0") {
				phoneNos = phoneNos + "," + obj.organiserPhone;
			}
		}
		let data = {
			message: "Event " + obj.name + " has been " + type,
			messageType: "",
			phoneNumber: phoneNos,
			senderId: "",
		};
		this.notificationService.sendSMS(data).subscribe((responce) => {});
	}
}
