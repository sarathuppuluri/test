import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { CCEService } from "../../../core/e-commerce/_services/cce.service";

@Component({
	selector: "kt-cce",
	templateUrl: "./cce.component.html",
	styleUrls: ["./cce.component.scss"],
})
export class CCEComponent implements OnInit {
	constructor(private router: Router, private cceService: CCEService) {}
	data: any = { todayData: {}, monthData: {}, overAllData: {} };
	dashBoardData: any;
	ngOnInit() {
		this.getDashBoardDetails();
	}

	getDashBoardDetails() {
		this.cceService.getStats().subscribe((data) => {
			this.dashBoardData = data.body;
		});
	}
	routetoList(type) {
		this.router.navigateByUrl("services/cceDashboard/call-list/" + type);
	}
}
