// Angular
import {
	Component,
	OnInit,
	Input,
	EventEmitter,
	ElementRef,
	ViewChild,
	ChangeDetectionStrategy,
	OnDestroy,
	ChangeDetectorRef,
} from "@angular/core";
// Material
import { SelectionModel } from "@angular/cdk/collections";
import {
	MatPaginator,
	MatSort,
	MatSnackBar,
	MatDialog,
} from "@angular/material";
// RXJS
import {
	debounceTime,
	distinctUntilChanged,
	tap,
	skip,
	delay,
	take,
} from "rxjs/operators";
import { fromEvent, merge, Subscription, of } from "rxjs";
// Translate Module
import { TranslateService } from "@ngx-translate/core";
// NGRX
import { Store, ActionsSubject } from "@ngrx/store";
import { AppState } from "../../../../../../../core/reducers";
// CRUD
import {
	LayoutUtilsService,
	MessageType,
	QueryParamsModel,
} from "../../../../../../../core/_base/crud";
// Services and Models
import { VehicleModel } from "../../../../../../../core/e-commerce";

// Components
import { VehiclesService } from "../../../../../../../core/e-commerce/_services/vehicles.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { DomSanitizer } from "@angular/platform-browser";
import { Router } from "@angular/router";
import { FormGroup, FormBuilder, FormArray } from "@angular/forms";
declare let require: any;
const FileSaver = require("file-saver");

import * as _ from "lodash";

@Component({
	selector: "kt-accessories-view",
	templateUrl: "./view-accessories.component.html",
	styleUrls: ["./view-accessories.component.scss"],
})
export class AccessoriesViewComponent implements OnInit, OnDestroy {
	// Table fields
	message = "";
	displayedColumns = ["vehicle", "model", "brand", "actions"];
	@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
	@ViewChild("sort1", { static: true }) sort: MatSort;
	// Filter fields
	@ViewChild("searchInput", { static: true }) searchInput: ElementRef;
	filterStatus = "";
	filterType = "";
	// Selection
	selection = new SelectionModel<VehicleModel>(true, []);
	vehiclesResult: VehicleModel[] = [];
	// Subscriptions
	private subscriptions: Subscription[] = [];

	VechiclesListData = [];
	isLoaded = false;
	vehicleId: any;
	public imagesUrl;
	vehiclesForm: FormGroup;
	externalFileName: any;
	internalFileName: any;
	exterior360FileName: any;
	interior360FileName: any;
	edocsName: any;
	vehicleDetails: {};
	deleteIndex: any;
	editIndex: any;
	editModelName: any;
	editedModelObj: any;
	exteriorUrl: any;
	interiorUrl: any;
	interiorOrExterior: any;
	interiorOrExteriorUrl: any;
	vehId: any;
	vehicId: any;
	/**
	 * Component constructor
	 *
	 * @param dialog: MatDialog
	 * @param snackBar: MatSnackBar
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 * @param store: Store<AppState>
	 */
	constructor(
		public dialog: MatDialog,
		//private vehSer: VehicleListService,
		public snackBar: MatSnackBar,
		private layoutUtilsService: LayoutUtilsService,
		private translate: TranslateService,
		private store: Store<AppState>,
		private vechileService: VehiclesService,
		private changeDetectorRef: ChangeDetectorRef,
		private modalService: NgbModal,
		private sanitizer: DomSanitizer,
		private router: Router,
		private fb: FormBuilder
	) {}

	ngOnInit() {
		this.vehiclesForm = this.fb.group({
			model: [],
			interior360FileName: [{ value: "", disabled: true }],
			interior360File: [],
			exterior360FileName: [{ value: "", disabled: true }],
			exterior360File: [],
			internalFileName: [{ value: "", disabled: true }],
			internalFile: [],
			externalFileName: [{ value: "", disabled: true }],
			externalFile: [],
			edocsName: [],
			edocument: [],
		});
		this.imagesUrl = [
			"https://vehicles-inventory.s3.ap-south-1.amazonaws.com/Aura/Hyundai_AURA_sedan_gallery_Big_PC_1120x600_6.jpg",
			"https://vehicles-inventory.s3.ap-south-1.amazonaws.com/Aura/Hyundai_AURA_sedan_gallery_Big_PC_1120x600_1.jpg",
		];

		const data = "some text";
		const blob = new Blob([data], { type: "application/octet-stream" });
		this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
			window.URL.createObjectURL(blob)
		);
	}
	openLarge(content) {
		this.modalService.open(content, {
			size: "lg",
		});
	}

	Variants(vehId) {
		this.vehicleId = vehId;
		localStorage.setItem("vehIdData", this.vehicleId);
		this.router.navigate(["/vehicleManagement/vehicles/variantsList"]);
	}
	

	ngAfterViewInit() {
		this.vehicId = localStorage.getItem("vehIdData");
	}

	tempData = [];
	AllDataBranch: any = [];
	vehicleList: any = [];
	eBroucher: any = [];
	fuelType: any = [];
	fuelNames: any = [];
	FuelData: any = [];
	eBroucherFile: any = [];
	transmissionType: any = [];
	FiltertransmissionType: any = [];
	transmissionTypeData: any = [];
	docfiles: any = [];
	docNameType: any = [];
	docs: any = [];
	docUrl: any = [];
	docData: any = [];
	ebroucher = [];
	ebroucherDataUrl = [];
	ebroucherDataUrlTwo = [];
	ebroucherName = [];
	ebroucherDataNameTwo = [];
	eBroucherDownload: any = [];
	interiorImages: any = [];
	intLeng: any = [];

	downloadFiles: any = [];
	docObj: any = [];
	fileUrl;
	files = [];
	downloadFile(dataDoc) {
		dataDoc.forEach((ele) => {
			FileSaver.saveAs(ele.url, ele.document_name);
		});
	}
	brouchureDocOpen(val) {
		val.forEach((ele) => {
			if (ele.document_name === "Vehicle_Sepcifications")
				window.open(ele.url);
		});
	}
	compareDocOpen(val) {
		val.forEach((ele) => {
			if (ele.document_name === "Comparison") window.open(ele.url);
		});
	}

	ngOnDestroy() {
		this.subscriptions.forEach((el) => el.unsubscribe());
	}

	openLarge360(content, val) {
		this.modalService.open(content, {
			size: "lg",
		});
		this.interiorOrExterior = val;
	}
	click360(val1) {
		if (val1 === "true") {
			this.interiorOrExterior.forEach((element) => {
				if (element.document_name === "360_exterior") {
					this.exteriorUrl = element.url;
				}
			});
			if (this.exteriorUrl != "") {
				window.open(this.exteriorUrl);
				this.modalService.dismissAll();
			} else this.modalService.dismissAll();
		} else {
			this.interiorOrExterior.forEach((element) => {
				if (element.document_name == "360_interior") {
					this.interiorUrl = element.url;
				}
			});
			if (this.interiorUrl != "") {
				window.open(this.interiorUrl);
				this.modalService.dismissAll();
			} else this.modalService.dismissAll();
		}
	}

	/** ACTIONS */
	/**
	 * Delete vehicle
	 *
	 * @param _item: VehicleModel
	 */
	deleteVehicle(_item: VehicleModel) {
		const _title: string = this.translate.instant(
			"ECOMMERCE.POLICIES.DELETE_POLICY_SIMPLE.TITLE"
		);
		const _description: string = this.translate.instant(
			"ECOMMERCE.POLICIES.DELETE_POLICY_SIMPLE.DESCRIPTION"
		);
		const _waitDesciption: string = this.translate.instant(
			"ECOMMERCE.POLICIES.DELETE_POLICY_SIMPLE.WAIT_DESCRIPTION"
		);
		const _deleteMessage = this.translate.instant(
			"ECOMMERCE.POLICIES.DELETE_POLICY_SIMPLE.MESSAGE"
		);

		const dialogRef = this.layoutUtilsService.deleteElement(
			_title,
			_description,
			_waitDesciption
		);
		dialogRef.afterClosed().subscribe((res) => {
			if (!res) {
				return;
			}
			this.layoutUtilsService.showActionNotification(
				_deleteMessage,
				MessageType.Delete
			);
		});
	}

	/**
	 * Show add vehicle dialog
	 */
	addVehicle() {
		const newVehicle = new VehicleModel();
		newVehicle.clear(); // Set all defaults fields
		this.editVehicle(newVehicle);
	}

	/**
	 * Show Edit vehicle dialog and save after success close result
	 * @param vehicle: VehicleModel
	 */
	editVehicle(content) {
		this.modalService.open(content, {
			size: "lg",
		});
	}
	deleteModel(i, content) {
		this.modalService.open(content, {
			size: "lg",
		});
		this.deleteIndex = i;
	}
	deleteModelYes() {
		this.vechileService.delete(this.deleteIndex);
		this.modalService.dismissAll();
	}
	editModel(i, content) {
		this.modalService.open(content, {
			size: "lg",
		});
		this.vehicleList.forEach((element) => {
			if (element.vehicleId === i) {
				this.vehiclesForm = this.fb.group({
					model: [element.model],
					interior360FileName: [{ value: "", disabled: true }],
					interior360File: [],
					exterior360FileName: [{ value: "", disabled: true }],
					exterior360File: [],
					internalFileName: [{ value: "", disabled: true }],
					internalFile: [],
					externalFileName: [{ value: "", disabled: true }],
					externalFile: [],
					edocsName: [],
					edocument: [],
				});
				this.editedModelObj = element;
			}
		});
		this.editIndex = i;
	}
	modelName(event) {
		this.vehiclesForm.patchValue({ model: event.target.value });
	}
	dismissModal() {
		this.modalService.dismissAll();
	}

	externalFileSelect(event) {
		if (event.target.files.length > 0) {
			this.externalFileName = event.target.files[0].name;
			this.vehiclesForm
				.get("externalFileName")
				.patchValue(this.externalFileName);
			this.vehiclesForm
				.get("externalFile")
				.patchValue(event.target.files[0]);
		}
	}
	internalFileSelect(event) {
		if (event.target.files.length > 0) {
			this.internalFileName = event.target.files[0].name;
			this.vehiclesForm
				.get("internalFileName")
				.patchValue(this.internalFileName);
			this.vehiclesForm
				.get("internalFile")
				.patchValue(event.target.files[0]);
		}
	}
	exterior360FileSelect(event) {
		if (event.target.files.length > 0) {
			this.exterior360FileName = event.target.files[0].name;
			this.vehiclesForm
				.get("exterior360FileName")
				.patchValue(this.exterior360FileName);
			this.vehiclesForm
				.get("exterior360File")
				.patchValue(event.target.files[0]);
		}
	}
	interior360FileSelect(event) {
		if (event.target.files.length > 0) {
			this.interior360FileName = event.target.files[0].name;
			this.vehiclesForm
				.get("interior360FileName")
				.patchValue(this.interior360FileName);
			this.vehiclesForm
				.get("interior360File")
				.patchValue(event.target.files[0]);
		}
	}
	edocsFileSelect(event) {
		if (event.target.files.length > 0) {
			this.edocsName = event.target.files[0].name;
			this.vehiclesForm.get("edocsName").patchValue(this.edocsName);
			this.vehiclesForm
				.get("edocument")
				.patchValue(event.target.files[0]);
		}
	}
	requestObj = new FormData();
	saveModal() {
		this.requestObj.append(
			"interior_image",
			this.vehiclesForm.value.internalFile
		);
		this.requestObj.append(
			"exterior_image",
			this.vehiclesForm.value.externalFile
		);
		this.requestObj.append(
			"360_exterior",
			this.vehiclesForm.value.exterior360File
		);
		this.requestObj.append(
			"360_interior",
			this.vehiclesForm.value.interior360File
		);
		this.requestObj.append("edocuments", this.vehiclesForm.value.edocument);
		this.vehicleDetails = {
			model: this.vehiclesForm.value.model,
			organizationId: 1,
		};
		this.requestObj.append(
			"vehicleDetails",
			JSON.stringify(this.vehicleDetails)
		);
		this.vechileService.saveVehicleDetails(this.requestObj);
		this.modalService.dismissAll();
	}
	updateRequestObj;
	updateModal() {
		this.editedModelObj.model = this.vehiclesForm.value.model;
		this.vechileService.updateVehicleDetails(this.editedModelObj);
		this.modalService.dismissAll();
	}

	/**
	 * Show Edit vehicle dialog and save after success close result
	 * @param vehicle: VehicleModel
	 */
	viewAccessories(vehList) {}
}
