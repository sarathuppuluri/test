import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-vehicles',
  templateUrl: './vehicles.component.html',
  styleUrls: ['./vehicles.component.scss']
})
export class VehiclesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
