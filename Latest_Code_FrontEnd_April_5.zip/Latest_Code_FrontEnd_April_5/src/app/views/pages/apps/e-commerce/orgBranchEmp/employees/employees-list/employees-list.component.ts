// Angular
import { Component, OnInit, ElementRef, ViewChild, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy, ChangeDetectorRef } from '@angular/core';
// Material
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort, MatSnackBar, MatDialog } from '@angular/material';
// RXJS
import { Subscription } from 'rxjs';
// Translate Module
import { TranslateService } from '@ngx-translate/core';
// NGRX
import { Store } from '@ngrx/store';
import { AppState } from '../../../../../../../core/reducers';
// CRUD
import { LayoutUtilsService, MessageType, QueryParamsModel } from '../../../../../../../core/_base/crud';
// Services and Models
import { EmployeesModel } from '../../../../../../../core/e-commerce/_models/employees.model';
// Components
import { EmployeesEditDialogComponent } from '../../employees/employees-edit/employees-edit.dialog.component';
import { BranchService } from '../../../../../../../core/e-commerce/_services/branch.service';
import { ActivatedRoute } from '@angular/router';
@Component({
	// tslint:disable-next-line:component-selector
	selector: 'kt-employees-list',
	templateUrl: './employees-list.component.html',
	encapsulation: ViewEncapsulation.None
})
export class EmployeesComponent implements OnInit, OnDestroy {
	loginEmployee: any;

	page = 0;
	pageSize = 10;
	isLoading = false;
	scope: any = {};

	// Subscriptions
	private subscriptions: Subscription[] = [];

	tempData = [];
	orgId: any;
	branchId: string;

	/**
	 * Component constructor
	 *
	 * @param dialog: MatDialog
	 * @param snackBar: MatSnackBar
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 */
	constructor(
		public dialog: MatDialog,
		private branchService: BranchService,
		private translate: TranslateService,
		public snackBar: MatSnackBar,
		private changeDetectorRef: ChangeDetectorRef,
		private layoutUtilsService: LayoutUtilsService,
		private routeData: ActivatedRoute
	) {
		this.orgId = this.routeData.snapshot.paramMap.get('orgId');
		this.branchId = this.routeData.snapshot.paramMap.get('branchId');
	}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.loadEmployeeById();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(el => el.unsubscribe());
	}

	/**
	 * Load Employee List from service
	 */
	loadEmployeeById() {
		this.isLoading = true;
		const queryParams = new QueryParamsModel({}, '', '', this.page, this.pageSize);
		this.branchService.getEmployeeById(this.orgId, this.branchId, queryParams).subscribe(res => {
			this.isLoading = false;
			this.scope = res.employeeInquiryInfo;
			this.tempData = res.employeeInquiryInfo.content;
			this.changeDetectorRef.detectChanges();
		}, error => {
			console.log('All Data of Employee error::' + error);
			this.changeDetectorRef.detectChanges();
		}, () => {
			
		});
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.loadEmployeeById();
	}


	deleteEmployee(element) {
		const _title = 'Employee Delete';
		const _description = 'Are you sure to permanently delete this Employee?';
		const _waitDesciption = 'Employee is deleting...';
		const _deleteMessage = 'Employee has been deleted';

		const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.branchService.deleteEmployee(element.empId).subscribe(empRes => {
				this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
				this.loadEmployeeById();
				this.changeDetectorRef.detectChanges();
			});
		});
	}


	/**
	 * Show add vehicle dialog
	 */
	addEmployee() {
		const editEmployee = new EmployeesModel();
		editEmployee.clear(); // Set all defaults fields
		editEmployee.orgId = this.orgId;
		editEmployee.branchId = this.branchId;
		this.editEmployee(editEmployee);
	}

	/**
	 * Show Edit vehicle dialog and save after success close result
	 * @param editEmployee: EmployeeModel
	 */
	editEmployee(editEmployee: EmployeesModel) {
		let saveMessageTranslateParam = 'ECOMMERCE.EMPLOYEES.EDIT.';
		saveMessageTranslateParam += Number(editEmployee.empId) > 0 ? 'UPDATE_MESSAGE' : 'ADD_MESSAGE';
		const _saveMessage = this.translate.instant(saveMessageTranslateParam);
		const _messageType = Number(editEmployee.empId) > 0 ? MessageType.Update : MessageType.Create;

		const dialogRef = this.dialog.open(EmployeesEditDialogComponent, { data: { editEmployee } });
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}

			this.layoutUtilsService.showActionNotification(_saveMessage, _messageType).afterOpened().subscribe(empRes => {
				this.loadEmployeeById();
			});
		});
	}
}
