// Angular
import { Component, OnInit, ElementRef, ViewChild, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy, ChangeDetectorRef } from '@angular/core';
// Material
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort, MatSnackBar, MatDialog } from '@angular/material';
// RXJS
import { Subscription } from 'rxjs';
// Translate Module
import { TranslateService } from '@ngx-translate/core';
// NGRX
import { Store } from '@ngrx/store';
import { AppState } from '../../../../../../../core/reducers';
// CRUD
import { LayoutUtilsService, MessageType, QueryParamsModel } from '../../../../../../../core/_base/crud';
// Services and Models
import { BranchModel, AddressInfo, PhoneDirectory } from '../../../../../../../core/e-commerce/_models/branch.model';
// Components
import { BranchEditDialogComponent } from '../../branch/branch-edit/branch-edit.dialog.component';
import { PhoneDirectoryEditDialogComponent } from '../../branch/phonedirectory-edit/phonedirectory-edit.dialog.component';
import { BranchService } from '../../../../../../../core/e-commerce/_services/branch.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
	// tslint:disable-next-line:component-selector
	selector: 'kt-branch-list',
	templateUrl: './branch-list.component.html',
	styleUrls: ['./branch-list.component.scss']
})
export class BranchComponent implements OnInit, OnDestroy {
	loginEmployee: any;

	page = 0;
	pageSize = 10;
	isLoading = false;
	scope: any = {};

	// Subscriptions
	private subscriptions: Subscription[] = [];

	tempData = [];
	orgId: any;

	/**
	 * Component constructor
	 *
	 * @param dialog: MatDialog
	 * @param snackBar: MatSnackBar
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 */
	constructor(
		public dialog: MatDialog,
		private branchService: BranchService,
		private translate: TranslateService,
		public snackBar: MatSnackBar,
		private router: Router,
		private changeDetectorRef: ChangeDetectorRef,
		private layoutUtilsService: LayoutUtilsService,
		private routeData: ActivatedRoute
	) {
		this.orgId = this.routeData.snapshot.paramMap.get('orgId');
	}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.loadBranchById();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(el => el.unsubscribe());
	}

	loadBranchById() {
		this.isLoading = true;
		const queryParams = new QueryParamsModel({}, '', '', this.page, this.pageSize);
		this.branchService.getBranchById(this.orgId, queryParams).subscribe(res => {
			this.isLoading = false;
			this.scope = res.branchInquiryInfos;
			this.tempData = res.branchInquiryInfos.content;
			this.changeDetectorRef.detectChanges();
		}, error => {
			console.log('All Data of Branch error::' + error);
			this.changeDetectorRef.detectChanges();
		}, () => {
			
		});
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.loadBranchById();
	}


	deleteBranch(element) {
		const _title = 'Branch Delete';
		const _description = 'Are you sure to permanently delete this Branch?';
		const _waitDesciption = 'Branch is deleting...';
		const _deleteMessage = 'Branch has been deleted';

		const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.branchService.deleteBranch(element.branchId).subscribe(branchRes => {
				this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
				this.loadBranchById();
				this.changeDetectorRef.detectChanges();
			});
		});
	}


	/**
	 * Show add vehicle dialog
	 */
	addBranch() {
		const editBranch = new BranchModel();
		const editAddressInfo = new AddressInfo();
		editBranch.clear(); // Set all defaults fields
		editAddressInfo.clear(); // Set all defaults fields
		editBranch.addressInfo = editAddressInfo;
		editBranch.orgId = this.orgId;
		this.editBranch(editBranch);
	}

	/**
	 * Show Edit vehicle dialog and save after success close result
	 * @param editBranch: BranchModel
	 */
	editBranch(editBranch: BranchModel) {
		let saveMessageTranslateParam = 'ECOMMERCE.BRANCH.EDIT.';
		saveMessageTranslateParam += Number(editBranch.branchId) > 0 ? 'UPDATE_MESSAGE' : 'ADD_MESSAGE';
		const _saveMessage = this.translate.instant(saveMessageTranslateParam);
		const _messageType = Number(editBranch.branchId) > 0 ? MessageType.Update : MessageType.Create;

		const dialogRef = this.dialog.open(BranchEditDialogComponent, { data: { editBranch } });
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}

			this.layoutUtilsService.showActionNotification(_saveMessage, _messageType).afterOpened().subscribe(orgRes => {
				this.loadBranchById();
			});
		});
	}

	getRowData(branchId) {
		this.router.navigate(['/organizationManagement/employees', this.orgId, branchId]);
	}


	/**
	 * Phone Directory Code.
	 */
	loadPhoneDirectory() {
		this.branchService.getPhoneDirectory(this.orgId).subscribe(res => {
			this.tempData = res.result;
			this.changeDetectorRef.detectChanges();
		});
	}

	deletePhoneDirectory(element) {
		const _title = 'Phone Directory Delete';
		const _description = 'Are you sure to permanently delete this Phone Directory?';
		const _waitDesciption = 'Phone Directory is deleting...';
		const _deleteMessage = 'Phone Directory has been deleted';

		const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.branchService.deletePhoneDirectory(element.id).subscribe(phoneDirectoryRes => {
				this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
				this.loadPhoneDirectory();
				this.changeDetectorRef.detectChanges();
			});
		});
	}

	/**
	 * Show add PhoneDirectory dialog
	 */
	addPhoneDirectory() {
		const editPhoneDirectory = new PhoneDirectory();
		editPhoneDirectory.clear(); // Set all defaults fields
		editPhoneDirectory.organization_id = this.orgId;
		this.editPhoneDirectory(editPhoneDirectory);
	}

	/**
	 * Show Edit PhoneDirectory dialog and save after success close result
	 * @param editPhoneDirectory: PhoneDirectory
	 */
	editPhoneDirectory(editPhoneDirectory: PhoneDirectory) {
		let saveMessageTranslateParam = 'ECOMMERCE.PHONEDIRECTORY.EDIT.';
		saveMessageTranslateParam += editPhoneDirectory.id > 0 ? 'UPDATE_MESSAGE' : 'ADD_MESSAGE';
		const _saveMessage = this.translate.instant(saveMessageTranslateParam);
		const _messageType = editPhoneDirectory.id > 0 ? MessageType.Update : MessageType.Create;

		const dialogRef = this.dialog.open(PhoneDirectoryEditDialogComponent, { data: { editPhoneDirectory } });
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}

			this.layoutUtilsService.showActionNotification(_saveMessage, _messageType).afterOpened().subscribe(orgRes => {
				this.loadPhoneDirectory();
			});
		});
	}
}
