// Angular
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";

// Translate Module
import { TranslateModule } from "@ngx-translate/core";
// UI
import { PartialsModule } from "../../../partials/partials.module";
import { SliderModule } from "angular-image-slider";
// Auth
import { ModuleGuard } from "../../../../core/auth";
import { PreenquiryService } from "../../../../core/e-commerce/_services/pre-enquiry.service";
// Core => Services
import { EventManagementService } from "../../../../core/e-commerce/_services/event-management.service";
import {
	MyRolesService,
	EnquiryService,
	MenuService,
	VehiclesService,
	VehicleListService,
	BranchService,
	OrganisationService,
	EMIService,
	B2CTransactionsService,
	EvaluatorService,
	IncentivesService,
	CustomerComplaintsService,
} from "../../../../core/e-commerce";
// Core => Utils
import {
	HttpUtilsService,
	TypesUtilsService,
	InterceptService,
	LayoutUtilsService,
} from "../../../../core/_base/crud";
// Shared
import {
	ActionNotificationComponent,
	DeleteEntityDialogComponent,
	UpdateEntityDialogComponent,
	TaskEntityDialogComponent,
	FetchEntityDialogComponent,
	UpdateStatusDialogComponent,
} from "../../../partials/content/crud";
// Components
import { ECommerceComponent } from "./e-commerce.component";
// MyRoles
import { MyRolesListComponent } from "./myroles/myroles-list/myroles-list.component";
import { MyRolesSubViewComponent } from "./myroles/myroles-subview/myroles-subview.component";
import { MyRolesSubViewEmpComponent } from "./myroles/myroles-subview-emp/myroles-subview-emp.component";
import { MyRoleEditDialogComponent } from "./myroles/myrole-edit/myrole-edit.dialog.component";
// Emp Role Maps
import { EmpRoleMapsListComponent } from "./emprolemaps/emprolemaps-list/emprolemaps-list.component";
// Vehicles
import { VehiclesListComponent } from "./vehicles/vehicles-list/vehicles-list.component";
import {
	AccessoriesModelsComponent,
	CreateAccessoriesDialog,
	CreateKitDialog,
} from "./vehicles/accessories/accessories-models.component";
// Organization
import { OrganisationListComponent } from "./orgBranchEmp/organisation/organisation-list/organisation-list.component";
import { OrganisationEditDialogComponent } from "./orgBranchEmp/organisation/organisation-edit/organisation-edit.dialog.component";
// Branch and Phone Directory
import { BranchComponent } from "./orgBranchEmp/branch/branch-list/branch-list.component";
import { BranchEditDialogComponent } from "./orgBranchEmp/branch/branch-edit/branch-edit.dialog.component";
import { PhoneDirectoryEditDialogComponent } from "./orgBranchEmp/branch/phonedirectory-edit/phonedirectory-edit.dialog.component";
// Employees
import { EmployeesComponent } from "./orgBranchEmp/employees/employees-list/employees-list.component";
import { EmployeesEditDialogComponent } from "./orgBranchEmp/employees/employees-edit/employees-edit.dialog.component";

// Sms and Email
import { SMSEMAILDialogComponent } from "./sms-email-dialog/sms-email-dialog.component";

// Material
import {
	MatInputModule,
	MatPaginatorModule,
	MatProgressSpinnerModule,
	MatSortModule,
	MatTableModule,
	MatSelectModule,
	MatMenuModule,
	MatProgressBarModule,
	MatButtonModule,
	MatCheckboxModule,
	MatDialogModule,
	MatTabsModule,
	MatNativeDateModule,
	MatCardModule,
	MatRadioModule,
	MatIconModule,
	MatDatepickerModule,
	MatAutocompleteModule,
	MAT_DIALOG_DEFAULT_OPTIONS,
	MatSnackBarModule,
	MatTooltipModule,
} from "@angular/material";
import { environment } from "../../../../../environments/environment";
import { NgbProgressbarModule } from "@ng-bootstrap/ng-bootstrap";
import { NgxPermissionsModule } from "ngx-permissions";
import { NgbAlertConfig, NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { VehiclesVariantListComponent } from "./vehicles/vehicles-variant-list/vehicles-variant-list.component";
import { MatExpansionModule } from "@angular/material/expansion";
import { AccessoriesViewComponent } from "./vehicles/accessories/view-accessories/view-accessories.component";
import {
	DemoVehiclesComponent,
	CreateDemoVehicleDialog,
} from "./vehicles/demo-vehicles/demo-vehicles.component";
import { EmployeeUnmappingComponent } from "./emprolemaps/emprolemaps-list/employee-unmapping/employee-unmapping.component";
import { VehiclesComponent } from "./vehicles/vehicles.component";

const routes: Routes = [
	{
		path: "",
		component: ECommerceComponent,
		children: [
			{
				path: "",
				redirectTo: "roles",
				pathMatch: "full",
			},
			{
				path: "roles",
				component: MyRolesListComponent,
			},
			{
				path: "roles/subview/:roleId",
				component: MyRolesSubViewComponent,
			},
			{
				path: "roles/subview/emp/:roleId",
				component: MyRolesSubViewEmpComponent,
			},
			{
				path: "employees",
				component: EmpRoleMapsListComponent,
			},
			{
				path: "employees/unMapping/:id",
				component: EmployeeUnmappingComponent,
			},
			{
				path: "newVehicles",
				component: VehiclesListComponent,
			},
			{
				path: "newVehicles/variantsList",
				component: VehiclesVariantListComponent,
			},
			{
				path: "accessories",
				component: AccessoriesModelsComponent,
			},
			{
				path: "DemoVehicles",
				component: DemoVehiclesComponent,
			},
			{
				path: "organizations",
				component: OrganisationListComponent,
			},
			{
				path: "branch/:orgId",
				component: BranchComponent,
			},
			{
				path: "employees/:orgId/:branchId",
				component: EmployeesComponent,
			},
			{
				path: "vehicles",
				component: VehiclesComponent,
			},
		],
	},
];

@NgModule({
	imports: [
		SliderModule,
		MatDialogModule,
		CommonModule,
		HttpClientModule,
		PartialsModule,
		NgxPermissionsModule.forChild(),
		RouterModule.forChild(routes),
		FormsModule,
		ReactiveFormsModule,
		TranslateModule.forChild(),
		MatButtonModule,
		MatMenuModule,
		MatSelectModule,
		MatInputModule,
		MatTableModule,
		MatAutocompleteModule,
		MatRadioModule,
		MatIconModule,
		MatNativeDateModule,
		MatProgressBarModule,
		MatDatepickerModule,
		MatCardModule,
		MatPaginatorModule,
		MatSortModule,
		MatCheckboxModule,
		MatProgressSpinnerModule,
		MatSnackBarModule,
		MatTabsModule,
		MatTooltipModule,
		NgbProgressbarModule,
		NgbModule,
		MatExpansionModule,
	],
	providers: [
		ModuleGuard,
		InterceptService,
		{
			provide: HTTP_INTERCEPTORS,
			useClass: InterceptService,
			multi: true,
		},
		{
			provide: MAT_DIALOG_DEFAULT_OPTIONS,
			useValue: {
				hasBackdrop: true,
				panelClass: "kt-mat-dialog-container__wrapper",
				height: "auto",
				width: "900px",
			},
		},
		TypesUtilsService,
		LayoutUtilsService,
		HttpUtilsService,
		MyRolesService,
		EnquiryService,
		PreenquiryService,
		EMIService,
		B2CTransactionsService,
		IncentivesService,
		CustomerComplaintsService,
		EvaluatorService,
		MenuService,
		VehiclesService,
		VehicleListService,
		TypesUtilsService,
		LayoutUtilsService,
		BranchService,
		OrganisationService,
		EventManagementService,
		NgbAlertConfig,
	],
	entryComponents: [
		ActionNotificationComponent,
		MyRoleEditDialogComponent,
		DeleteEntityDialogComponent,
		UpdateEntityDialogComponent,
		TaskEntityDialogComponent,
		FetchEntityDialogComponent,
		UpdateStatusDialogComponent,
		OrganisationEditDialogComponent,
		CreateAccessoriesDialog,
		CreateKitDialog,
		BranchEditDialogComponent,
		PhoneDirectoryEditDialogComponent,
		EmployeesEditDialogComponent,
		SMSEMAILDialogComponent,
		CreateDemoVehicleDialog,
	],
	declarations: [
		ECommerceComponent,
		// MyRoles
		MyRolesListComponent,
		MyRolesSubViewComponent,
		MyRolesSubViewEmpComponent,
		MyRoleEditDialogComponent,
		// Emp Role Maps
		EmpRoleMapsListComponent,
		// Vehicles
		VehiclesListComponent,
		VehiclesVariantListComponent,
		AccessoriesModelsComponent,
		AccessoriesViewComponent,
		CreateAccessoriesDialog,
		CreateKitDialog,
		DemoVehiclesComponent,
		CreateDemoVehicleDialog,
		// Organization
		OrganisationListComponent,
		OrganisationEditDialogComponent,
		// Branch and Phone Directory
		BranchComponent,
		BranchEditDialogComponent,
		PhoneDirectoryEditDialogComponent,
		// Employees
		EmployeesComponent,
		EmployeesEditDialogComponent,

		// SMS and Email
		SMSEMAILDialogComponent,

		EmployeeUnmappingComponent,
		VehiclesComponent,
	],
})
export class ECommerceModule {}
