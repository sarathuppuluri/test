// Angular
import { Component, OnInit, ChangeDetectorRef, Inject, ChangeDetectionStrategy, ViewEncapsulation, ViewChild, ElementRef, OnDestroy } from '@angular/core';
// Material
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
// RxJS
import { Subscription, of } from 'rxjs';
import { delay } from 'rxjs/operators';
// NGRX
import { Update } from '@ngrx/entity';
import { Store, select } from '@ngrx/store';
// State
import { AppState } from '../../../../../../../core/reducers';
// CRUD
import { LayoutUtilsService, MessageType, TypesUtilsService, QueryParamsModel } from '../../../../../../../core/_base/crud';
// Services and Models
import { CustomerModel } from '../../../../../../../core/e-commerce';
import { BranchModel } from '../../../../../../../core/e-commerce/_models/branch.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BranchService } from '../../../../../../../core/e-commerce/_services/branch.service';

declare let ol: any;

@Component({
	selector: 'kt-branch-edit-dialog',
	templateUrl: './branch-edit.dialog.component.html',
	styleUrls: ['./branch-edit.dialog.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush,
	encapsulation: ViewEncapsulation.None
})
export class BranchEditDialogComponent implements OnInit, OnDestroy {

	/**
	 * Component constructor
	 *
	 * @param dialogRef: MatDialogRef<CustomerEditDialogComponent>
	 * @param data: any
	 * @param fb: FormBuilder
	 * @param store: Store<AppState>
	 * @param typesUtilsService: TypesUtilsService
	 */
	constructor(public dialogRef: MatDialogRef<BranchEditDialogComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any,
		private fb: FormBuilder,
		private changeDetectorRef: ChangeDetectorRef,
		private layoutUtilsService: LayoutUtilsService,
		private branchService: BranchService,
		private store: Store<AppState>) {
	}
	// Public properties
	branch: BranchModel;
	customerForm: FormGroup;
	hasFormErrors = false;
	viewLoading = false;
	branchEdit: any;
	state: any;
	id: number;
	selectstate: string;
	district: any;
	selectedValue: string;
	// Private properties
	private componentSubscriptions: Subscription;
	latitude = 17.2452844;
	longitude = 80.185539;
	lat: number;
	lon: number;
	map: any;
	secmap: any;
	editCond: boolean;
	showroom = true;
	servicecenter = false;

	branchForm: FormGroup;

	hasSubmitted = false;
	message = '';


	tempData = [];
	AllDataBranch: any = [];
	dataSource: any = [];


	ngOnInit() {
		this.branchEdit = this.data.editBranch;
		this.createForm();
	}

	createForm() {
		this.branchForm = this.fb.group({
			city: [this.branchEdit.addressInfo.city],
			country: [this.branchEdit.addressInfo.country],
			district: [this.branchEdit.addressInfo.district],
			houseNo: [this.branchEdit.addressInfo.houseNo],
			isRural: [this.branchEdit.addressInfo.isRural],
			isUrban: [this.branchEdit.addressInfo.isUrban],
			pincode: [this.branchEdit.addressInfo.pincode],
			state: [this.branchEdit.addressInfo.state],
			street: [this.branchEdit.addressInfo.street],
			village: [this.branchEdit.addressInfo.village],
			branchType: [this.branchEdit.branchType],
			cinNumber: [this.branchEdit.cinNumber],
			email: [this.branchEdit.email],
			imageUrl: [this.branchEdit.imageUrl],
			mobile: [this.branchEdit.mobile],
			name: [this.branchEdit.name],
			storeId: [this.branchEdit.storeId],
			phone: [this.branchEdit.phone],
			status: [this.branchEdit.status],
			website: [this.branchEdit.website]
		});
	}

	ngOnDestroy() {
		if (this.componentSubscriptions) {
			this.componentSubscriptions.unsubscribe();
		}
	}


	/**
	 * Check control is invalid
	 * @param controlName: string
	 */
	isControlInvalid(controlName: string): boolean {
		const control = this.customerForm.controls[controlName];
		const result = control.invalid && control.touched;
		return result;
	}

	onSubmit() {
		this.hasSubmitted = true;
		this.hasFormErrors = false;
		const controls = this.branchForm.controls;
		if (this.branchForm.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		}

		this.branchEdit.addressInfo.city = controls.city.value;
		this.branchEdit.addressInfo.country = controls.country.value;
		this.branchEdit.addressInfo.district = controls.district.value;
		this.branchEdit.addressInfo.houseNo = controls.houseNo.value;
		this.branchEdit.addressInfo.isRural = controls.isRural.value;
		this.branchEdit.addressInfo.isUrban = controls.isUrban.value;
		this.branchEdit.addressInfo.latitude = localStorage.getItem('latit');
		this.branchEdit.addressInfo.longitude = localStorage.getItem('longit');
		this.branchEdit.addressInfo.pincode = controls.pincode.value;
		this.branchEdit.addressInfo.state = controls.state.value;
		this.branchEdit.addressInfo.street = controls.street.value;
		this.branchEdit.addressInfo.village = controls.village.value;
		this.branchEdit.branchType = controls.branchType.value;
		this.branchEdit.cinNumber = controls.cinNumber.value;
		this.branchEdit.email = controls.email.value;
		this.branchEdit.imageUrl = controls.imageUrl.value;
		this.branchEdit.name = controls.name.value;
		this.branchEdit.phone = controls.phone.value;
		this.branchEdit.mobile = controls.mobile.value;
		this.branchEdit.storeId = controls.storeId.value;
		this.branchEdit.status = controls.status.value;
		this.branchEdit.website = controls.website.value;

		const branchDataObj = { branchInfo: this.branchEdit };

		if (Number(this.branchEdit.branchId) > 0) {
			this.updateBranch(branchDataObj);
		} else {
			this.createBranch(branchDataObj);
		}
	}

	createBranch(branchData) {
		this.branchService.createBranch(branchData).subscribe(response => {
			this.hasSubmitted = false;
			if (!response) {
				return;
			}

			this.dialogRef.close({ branchData, isEdit: false });
		});
	}


	loadLeadsShowroomById() {
		const queryParams = new QueryParamsModel({}, '', '', 0, 10);
		this.branchService.getBranchById(4, queryParams).subscribe((res: any) => {
			this.tempData = res.branchInquiryInfos.content;
			this.changeDetectorRef.detectChanges();
		}, error => {
			console.log('All Data of organisation error::' + error);
			this.changeDetectorRef.detectChanges();
		}, () => {
			
		});
	}

	updateBranch(editBranch) {
		this.branchService.updateBranch(editBranch).subscribe(response => {
			this.hasSubmitted = false;
			if (!response) {
				return;
			}
			this.dialogRef.close({ editBranch, isEdit: true });
		});
	}

	/** Alect Close event */
	onAlertClose() {
		this.hasFormErrors = false;
	}
}
