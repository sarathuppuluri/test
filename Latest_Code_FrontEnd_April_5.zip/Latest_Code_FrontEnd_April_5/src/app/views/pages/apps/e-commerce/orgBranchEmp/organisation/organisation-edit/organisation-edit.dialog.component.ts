// Angular
import { Component, OnInit, ChangeDetectorRef, Inject, ChangeDetectionStrategy, ViewEncapsulation, ViewChild, ElementRef, OnDestroy } from '@angular/core';
// Material
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
// RxJS
import { Subscription, of } from 'rxjs';
import { delay } from 'rxjs/operators';
// NGRX
import { Update } from '@ngrx/entity';
import { Store, select } from '@ngrx/store';
// State
import { AppState } from '../../../../../../../core/reducers';
// CRUD
import { LayoutUtilsService, MessageType, TypesUtilsService, QueryParamsModel } from '../../../../../../../core/_base/crud';
// Services and Models
import { CustomerModel } from '../../../../../../../core/e-commerce';
import { OrganizationModel } from '../../../../../../../core/e-commerce/_models/organization.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { OrganisationService } from '../../../../../../../core/e-commerce/_services/organisation.service';

declare let ol: any;

@Component({
	styleUrls: ['./organisation-edit.dialog.component.scss'],
	selector: 'kt-organisation-edit-dialog',
	templateUrl: './organisation-edit.dialog.component.html',
	changeDetection: ChangeDetectionStrategy.OnPush,
	encapsulation: ViewEncapsulation.None
})
export class OrganisationEditDialogComponent implements OnInit, OnDestroy {

	/**
	 * Component constructor
	 *
	 * @param dialogRef: MatDialogRef<CustomerEditDialogComponent>
	 * @param data: any
	 * @param fb: FormBuilder
	 * @param store: Store<AppState>
	 * @param typesUtilsService: TypesUtilsService
	 */
	constructor(public dialogRef: MatDialogRef<OrganisationEditDialogComponent>,
		           @Inject(MAT_DIALOG_DATA) public data: any,
		           private fb: FormBuilder,
		           private changeDetectorRef: ChangeDetectorRef,
		           private layoutUtilsService: LayoutUtilsService,
		           private orgService: OrganisationService,
		           private store: Store<AppState>) {
	}
	// Public properties
	branch: OrganizationModel;
	customerForm: FormGroup;
	hasFormErrors = false;
	viewLoading = false;
	orgEdit: any;
	state: any;
	id: number;
	selectstate: string;
	district: any;
	selectedValue: string;
	// Private properties
	private componentSubscriptions: Subscription;
	latitude = 20.5937;
	longitude = 78.9629;
	lat: number;
	lon: number;
	map: any;
	secmap: any;
	editCond: boolean;
	showroom = true;
	servicecenter = false;
	@ViewChild('mapContainer', { static: false }) gmap: ElementRef;

	markers = [
		{ latitude: 20.5937, longitude: 78.9629 }
	];

	orgForm: FormGroup;

	hasSubmitted = false;
	message = '';


	tempData = [];
	AllDataBranch: any = [];
	dataSource: any = [];

	ngOnInit() {
		const markerSource = new ol.source.Vector();
		const markerSourceTwo = new ol.source.Vector();
		const markerStyle = new ol.style.Style({
			image: new ol.style.Icon(/** @type {olx.style.IconOptions} */({
				anchor: [0.5, 46],
				anchorXUnits: 'fraction',
				anchorYUnits: 'pixels',
				opacity: 0.75,
				src: '//raw.githubusercontent.com/jonataswalker/map-utils/master/images/marker.png'
			}))
		});
		this.map = new ol.Map({
			target: 'map',
			layers: [
				new ol.layer.Tile({
					source: new ol.source.OSM()
				}),
				new ol.layer.Vector({
					source: markerSource,
					style: markerStyle,
				}),
			],
			view: new ol.View({
				center: ol.proj.fromLonLat([73.8567, 18.5204]),
				zoom: 8
			})
		});
		this.secmap = new ol.Map({
			target: 'secmap',
			layers: [
				new ol.layer.Tile({
					source: new ol.source.OSM()
				}),
				new ol.layer.Vector({
					source: markerSourceTwo,
					style: markerStyle,
				}),
			],
			view: new ol.View({
				center: ol.proj.fromLonLat([73.8567, 18.5204]),
				zoom: 8
			})
		});



		this.map.on('click', function(args) {
			const lonlat = ol.proj.transform(args.coordinate, 'EPSG:3857', 'EPSG:4326');
			const lon = lonlat[0];
			const lat = lonlat[1];
			addMarker(lon, lat);
		});

		this.secmap.on('click', function(args) {

			const lonlat = ol.proj.transform(args.coordinate, 'EPSG:3857', 'EPSG:4326');
			const lon = lonlat[0];
			const lat = lonlat[1];
			secoundaddMarker(lon, lat);
		});

		function addMarker(lon, lat) {
			localStorage.setItem('latit', lat);
			localStorage.setItem('longit', lon);
			markerSource.clear();

			const iconFeature = new ol.Feature({
				geometry: new ol.geom.Point(ol.proj.transform([lon, lat], 'EPSG:4326',
					'EPSG:3857')),
				name: 'Null Island',
				population: 4000,
				rainfall: 500
			});

			markerSource.addFeature(iconFeature);
		}



		function secoundaddMarker(lon, lat) {
			localStorage.setItem('latit', lat);
			localStorage.setItem('longit', lon);
			markerSourceTwo.clear();

			const iconFeature = new ol.Feature({
				geometry: new ol.geom.Point(ol.proj.transform([lon, lat], 'EPSG:4326',
					'EPSG:3857')),
				name: 'Null Island',
				population: 4000,
				rainfall: 500
			});

			markerSourceTwo.addFeature(iconFeature);
		}

		this.orgEdit = this.data.editOrg;
		this.createForm();
	}

	placeMarker(position: any) {
		const lat = position.coords.lat;
		const lng = position.coords.lng;

		this.markers.push({ latitude: lat, longitude: lng });
	}

	createForm() {
		this.orgForm = this.fb.group({
			city: [this.orgEdit.addressInfo.city],
			country: [this.orgEdit.addressInfo.country],
			district: [this.orgEdit.addressInfo.district],
			houseNo: [this.orgEdit.addressInfo.houseNo],
			isRural: [this.orgEdit.addressInfo.isRural],
			isUrban: [this.orgEdit.addressInfo.isUrban],
			pincode: [this.orgEdit.addressInfo.pincode],
			state: [this.orgEdit.addressInfo.state],
			street: [this.orgEdit.addressInfo.street],
			village: [this.orgEdit.addressInfo.village],
			brand: [this.orgEdit.brand],
			cin: [this.orgEdit.cin],
			domainName: [this.orgEdit.domainName],
			email: [this.orgEdit.email],
			logoBigUrl: [this.orgEdit.logoBigUrl],
			logoSmallUrl: [this.orgEdit.logoSmallUrl],
			name: [this.orgEdit.name],
			phone: [this.orgEdit.phone],
			mobile: [this.orgEdit.mobile],
			status: [this.orgEdit.status],
			url: [this.orgEdit.url],
			website: [this.orgEdit.website],
		});
	}



	/**
	 * On destroy
	 */
	ngOnDestroy() {
		if (this.componentSubscriptions) {
			this.componentSubscriptions.unsubscribe();
		}
	}

	/**
	 * Check control is invalid
	 * @param controlName: string
	 */
	isControlInvalid(controlName: string): boolean {
		const control = this.customerForm.controls[controlName];
		const result = control.invalid && control.touched;
		return result;
	}

	onSubmit() {
		this.hasSubmitted = true;
		this.hasFormErrors = false;
		const controls = this.orgForm.controls;
		if (this.orgForm.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		}

		if (Number(this.orgEdit.orgId) > 0) {
			this.updateOrg(controls);
		} else {
		}
	}

	loadLeadsShowroomById() {
		const queryParams = new QueryParamsModel({}, '', '', 0, 10);
		this.orgService.getOrgById(4, queryParams).subscribe((res: any) => {
			this.tempData = res.organizationInquiryInfos.content;
			this.changeDetectorRef.detectChanges();
		}, error => {
			console.log('All Data of organisation error::' + error);
			this.changeDetectorRef.detectChanges();
		}, () => {
			
		});
	}

	updateOrg(controls) {
		this.orgEdit.addressInfo.city = controls.city.value;
		this.orgEdit.addressInfo.country = controls.country.value;
		this.orgEdit.addressInfo.district = controls.district.value;
		this.orgEdit.addressInfo.houseNo = controls.houseNo.value;
		this.orgEdit.addressInfo.isRural = controls.isRural.value;
		this.orgEdit.addressInfo.isUrban = controls.isUrban.value;
		this.orgEdit.addressInfo.latitude = localStorage.getItem('latit');
		this.orgEdit.addressInfo.longitude = localStorage.getItem('longit');
		this.orgEdit.addressInfo.pincode = controls.pincode.value;
		this.orgEdit.addressInfo.state = controls.state.value;
		this.orgEdit.addressInfo.street = controls.street.value;
		this.orgEdit.addressInfo.village = controls.village.value;
		this.orgEdit.brand = controls.brand.value;
		this.orgEdit.cin = controls.cin.value;
		this.orgEdit.domainName = controls.domainName.value;
		this.orgEdit.email = controls.email.value;
		this.orgEdit.logoBigUrl = controls.logoBigUrl.value;
		this.orgEdit.logoSmallUrl = controls.logoSmallUrl.value;
		this.orgEdit.name = controls.name.value;
		this.orgEdit.phone = controls.phone.value;
		this.orgEdit.mobile = controls.mobile.value;
		this.orgEdit.status = controls.status.value;
		this.orgEdit.url = controls.url.value;
		this.orgEdit.website = controls.website.value;

		const orgDataObj = { organizationInfo: this.orgEdit };

		this.orgService.updateOrg(orgDataObj).subscribe(response => {
			this.hasSubmitted = false;
			if (!response) {
				return;
			}
			this.dialogRef.close({ orgDataObj, isEdit: true });
		});
	}

	/** Alect Close event */
	onAlertClose() {
		this.hasFormErrors = false;
	}
}
