import { Component, ViewChild, OnInit, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MatSnackBar } from '@angular/material';
import { VehicleListService } from '../../../../../../core/e-commerce/_services/VehiclesList.service';
import { VehiclesListComponent } from "../vehicles-list/vehicles-list.component";
import { FormBuilder, FormGroup } from '@angular/forms';
@Component({
	selector: "kt-vehicles-variant-list",
	templateUrl: "./vehicles-variant-list.component.html",
	styleUrls: ["./vehicles-variant-list.component.scss"],
})
export class VehiclesVariantListComponent implements OnInit, AfterViewInit {
	panelOpenState = false;
	IDVeh: any;
	variantsForm: FormGroup;
	@ViewChild(VehiclesListComponent, { static: false })
	vehComponent: VehiclesListComponent;
	colorForm: FormGroup;
	onRoadForm: FormGroup;
	colorClose: boolean = false;
	editForm: FormGroup;
	varientId: any;
	onRoadDetail: any;
	varient_id: any;
	retreivedId: any = 0;
	loginEmployee: any;
	varientDetails: any;
	url: any;
	constructor(
		private modalService: NgbModal,
		private vehSer: VehicleListService,
		private changeDetectorRef: ChangeDetectorRef,
		private _fb: FormBuilder,
		public snackBar: MatSnackBar
	) {}

	message: string;
	vehicId: any;
	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.variantsForm = this._fb.group({
			bhp: [],
			enginecc: [],
			fuelType: [],
			mileage: [],
			name: [],
			status: [],
			vehicleId: [],
			transmission_type: [],
			imageUrl: [],
		});
		this.colorForm = this._fb.group({
			color: [],
			color_body_code: [],
			color_top_code: [],
			is_dual_color: [null],
			vehicleId: [],
			priority: [],
			url: [],
			varient_id: [],
			vehicleImageId: [],
		});
		this.onRoadForm = this._fb.group({
			ex_showroom_price: [],
			vehicle_road_tax: [],
			registration_charges: [],
			handling_charges: [],
			fast_tag: [],
			tcs_percentage: [],
			tcs_amount: [],
			essential_kit: [],
		});
		this.vehicId = localStorage.getItem("vehIdData");
		this.loadLeadsShowroomById(this.vehicId);
	}
	ngAfterViewInit() {
		let message;
		this.message = this.vehComponent.vehicId;
	}
	receiveMessage($event) {
		this.message = $event;
	}
	deleteUrl() {
		this.url = "";
	}

	saveVariant(val) {
		let formObj = {
			bhp: this.variantsForm.controls.bhp.value,
			enginecc: this.variantsForm.controls.enginecc.value,
			fuelType: this.variantsForm.controls.fuelType.value,
			id: 0,
			mileage: this.variantsForm.controls.mileage.value,
			name: this.variantsForm.controls.name.value,
			status: this.variantsForm.controls.status.value,
			transmission_type: this.variantsForm.controls.transmission_type
				.value,
			vehicleId: localStorage.getItem("vehIdData"),
			vehicleImages: [
				{
					color: this.colorForm.controls.color.value,
					color_body_code: this.colorForm.controls.color_body_code
						.value
						? this.colorForm.controls.color_body_code.value
						: "#000000",
					color_top_code: this.colorForm.controls.color_top_code.value
						? this.colorForm.controls.color_top_code.value
						: "#000000",
					is_dual_color: this.colorForm.controls.is_dual_color.value
						? this.colorForm.controls.is_dual_color.value
						: false,
					priority: 0,
					//url: this.colorForm.controls.url.value ? this.colorForm.controls.url.value : '',
					url: this.url != "" ? this.url : "",
					varient_id: 0,
					vehicleId: localStorage.getItem("vehIdData"),
					vehicleImageId: 0,
				},
			],
		};

		this.vehSer.saveVehicleVarients(formObj).subscribe((res) => {
			if (res.status === "fail") {
				this.openSnackBar(res.showMessage, res.status, "fail");
			} else {
				this.openSnackBar(
					"Variant has been saved successfully",
					res.status,
					"success"
				);
				this.modalService.dismissAll();
			}
			this.loadLeadsShowroomById(this.vehicId);
			this.changeDetectorRef.detectChanges();
		});
	}
	openColor(content) {
		this.modalService.open(content, {
			size: "lg",
		});
		this.colorForm.controls.url.setValue(this.url);
		this.colorForm
			.get("vehicleId")
			.setValue(localStorage.getItem("vehIdData"));
	}
	topColorChange(event) {
		this.colorForm.get("color_top_code").setValue(event.target.value);
	}
	bodyColorChange(event) {
		this.colorForm.get("color_body_code").setValue(event.target.value);
		if (this.colorForm.get("is_dual_color").value) {
			this.colorForm
				.get("color_top_code")
				.setValue(this.colorForm.get("color_body_code").value);
		}
	}
	dualColorChange(event) {
		this.colorForm.get("is_dual_color").setValue(event.checked);
		if (event.checked === true) {
			if (this.colorForm.get("color_body_code").value)
				this.colorForm
					.get("color_top_code")
					.setValue(this.colorForm.get("color_body_code").value);
		} else {
			this.colorForm.get("color_top_code").setValue("");
		}
	}
	dualColorChangeEdit(event) {
		this.editForm.get("is_dual_color").setValue(event.checked);
		if (event.checked === true) {
			if (this.editForm.get("color_body_code").value)
				this.editForm
					.get("color_top_code")
					.setValue(this.editForm.get("color_body_code").value);
		} else {
			this.editForm.get("color_top_code").setValue("");
		}
	}
	saveColor(val) {}

	openLarge(content) {
		this.modalService.open(content, {
			size: "lg",
		});
	}

	editVehicle(content, val) {
		this.modalService.open(content, {
			size: "lg",
		});
		this.editForm = this._fb.group({
			bhp: val.bhp,
			enginecc: val.enginecc,
			fuelType: val.fuelType,
			mileage: val.mileage,
			name: val.name,
			status: val.status,
			vehicleId: val.vehicleId,
			transmission_type: val.transmission_type,
			color:
				val.vehicleImages.length > 0 ? val.vehicleImages[0].color : "",
			color_body_code:
				val.vehicleImages.length > 0
					? val.vehicleImages[0].color_body_code
					: "",
			color_top_code:
				val.vehicleImages.length > 0
					? val.vehicleImages[0].color_top_code
					: "",
			is_dual_color:
				val.vehicleImages.length > 0
					? val.vehicleImages[0].is_dual_color
					: "",
			priority:
				val.vehicleImages.length > 0
					? val.vehicleImages[0].priority
					: "",
			url: val.vehicleImages.length > 0 ? val.vehicleImages[0].url : "",
			varient_id: val.id,
			vehicleImageId:
				val.vehicleImages.length > 0
					? val.vehicleImages[0].vehicleImageId
					: "",
		});
	}
	saveEditedVarient(val) {
		this.modalService.dismissAll();
		let formObj = {
			id: this.editForm.controls.varient_id.value,
			bhp: this.editForm.controls.bhp.value,
			enginecc: this.editForm.controls.enginecc.value,
			fuelType: this.editForm.controls.fuelType.value,
			mileage: this.editForm.controls.mileage.value,
			name: this.editForm.controls.name.value,
			status: this.editForm.controls.status.value,
			transmission_type: this.editForm.controls.transmission_type.value,
			vehicleId: localStorage.getItem("vehIdData"),
			vehicleImages: [
				{
					color: this.editForm.controls.color.value,
					color_body_code: this.editForm.controls.color_body_code
						.value,
					color_top_code: this.editForm.controls.color_top_code.value,
					is_dual_color: this.editForm.controls.is_dual_color.value
						? this.editForm.controls.is_dual_color.value
						: false,
					priority: 0,
					url: this.editForm.controls.url.value,
					varient_id: this.editForm.controls.varient_id.value,
					vehicleId: localStorage.getItem("vehIdData"),
					vehicleImageId: this.editForm.controls.vehicleImageId.value,
				},
			],
		};
		this.vehSer.updateVarients(formObj).subscribe((res) => {
			if (res.status === "success") {
				this.openSnackBar(
					"Variant has been updated successfully",
					res.status,
					"success"
				);
				this.modalService.dismissAll();
			} else {
				this.openSnackBar(
					"Oops! Variant has NOT been updated",
					res.status,
					"fail"
				);
			}
			this.loadLeadsShowroomById(this.vehicId);
			this.changeDetectorRef.detectChanges();
		});
	}
	deleteVarient(val, type) {
		let id;
		if (type === "editForm") {
			id = val.controls.varient_id.value;
		} else if (type === "del") {
			id = val.id;
		}
		if (id === undefined) {
			this.openSnackBar("Oops! No variant Id ", "", "fail");
			return false;
		}
		this.vehSer.deleteVarient(id).subscribe((res) => {
			if (res.status === "success") {
				this.openSnackBar(
					"Variant has been deleted successfully",
					res.status,
					"success"
				);
			} else {
				this.openSnackBar(res.showMessage, res.status, "fail");
			}
			this.loadLeadsShowroomById(this.vehicId);
			this.changeDetectorRef.detectChanges();
			this.modalService.dismissAll();
		});
	}

	tempData = [];
	AllDataBranch: any = [];
	vehicleList: any = [];
	eBroucher: any = [];
	fuelType: any = [];
	fuelNames: any = [];
	FuelData: any = [];
	eBroucherFile: any = [];
	transmissionType: any = [];
	FiltertransmissionType: any = [];
	transmissionTypeData: any = [];
	varientsData: any = [];
	varientstransType: any = [];
	countPetrol: any;
	petrolImages: any = [];
	countPetrolImg: any = [];
	autoImages: any = [];
	countAutoImg: any = [];
	countAuto: any;
	vID: any;
	loadLeadsShowroomById(vehicId) {
		this.vehicleList = [];
		this.varientsData = [];
		this.varientstransType = [];

		this.vehSer
			.getVehiclesData(vehicId, this.loginEmployee.orgId)
			.subscribe(
				(res) => {
					this.vehicleList = res.varients;
					let filterFuelType;
					let FiltertransmissionType;

					this.vehicleList.forEach((varData, i) => {
						if (varData.fuelType === "Petrol") {
							this.countPetrolImg.push(
								varData.vehicleImages.length
							);
							varData.vehicleImages.forEach((data, i) => {
								data = data;
								this.petrolImages.push(data.url);
							});
							this.varientsData.push(varData);
							this.countPetrol = this.varientsData.length;
						}

						if (varData.transmission_type === "Automatic") {
							this.countAutoImg.push(
								varData.vehicleImages.length
							);
							varData.vehicleImages.forEach((data, i) => {
								data = data;
								this.autoImages.push(data.url);
							});
							this.varientstransType.push(varData);
							this.countAuto = this.varientstransType.length;
						}
					});
					this.changeDetectorRef.detectChanges();
				},
				(error) => {
					console.log("All Data of organisation error::" + error);
					this.changeDetectorRef.detectChanges();
				},
				() => {}
			);
	}
	openOnRoad(val, content) {
		this.modalService.open(content, {
			size: "lg",
		});
		this.varient_id = val.id;
		this.vehSer
			.getOnRoadPrice(this.varient_id, this.loginEmployee.orgId)
			.subscribe((res) => {
				if (res) {
					this.retreivedId = res.id;
					this.onRoadForm = this._fb.group({
						ex_showroom_price: res.ex_showroom_price
							? res.ex_showroom_price
							: [],
						vehicle_road_tax: res.vehicle_road_tax
							? res.vehicle_road_tax
							: [],
						registration_charges: res.registration_charges
							? res.registration_charges
							: [],
						handling_charges: res.handling_charges
							? res.handling_charges
							: [],
						fast_tag: res.fast_tag ? res.fast_tag : [],
						tcs_percentage: res.tcs_percentage
							? res.tcs_percentage
							: [],
						tcs_amount: res.tcs_amount ? res.tcs_amount : [],
						essential_kit: res.essential_kit
							? res.essential_kit
							: [],
					});
				} else {
					this.retreivedId = 0;
					this.onRoadForm = this._fb.group({
						ex_showroom_price: [],
						vehicle_road_tax: [],
						registration_charges: [],
						handling_charges: [],
						fast_tag: [],
						tcs_percentage: [],
						tcs_amount: [],
						essential_kit: [],
					});
				}
				this.changeDetectorRef.detectChanges();
			});
	}
	changeShowroomPrice(event) {
		if (
			this.onRoadForm.controls.tcs_percentage.value != "" ||
			this.onRoadForm.controls.tcs_percentage.value != null
		) {
			this.onRoadForm
				.get("tcs_amount")
				.setValue(
					this.onRoadForm.controls.tcs_percentage.value *
						event.target.value
				);
		}
	}
	changePercent(event) {
		if (
			this.onRoadForm.controls.ex_showroom_price.value != "" ||
			this.onRoadForm.controls.ex_showroom_price.value != null
		) {
			this.onRoadForm
				.get("tcs_amount")
				.setValue(
					this.onRoadForm.controls.ex_showroom_price.value *
						event.target.value *
						0.01
				);
		}
	}
	saveOnRoadPrice(val) {
		if (this.retreivedId === 0) {
			let formObj = {
				id: 0,
				organization_id: 1,
				vehicle_id: parseInt(localStorage.getItem("vehIdData")),
				varient_id: this.varient_id,
				ex_showroom_price: parseInt(
					val.controls.ex_showroom_price.value
				),
				vehicle_road_tax: parseInt(val.controls.vehicle_road_tax.value),
				registration_charges: parseInt(
					val.controls.registration_charges.value
				),
				handling_charges: parseInt(val.controls.handling_charges.value),
				fast_tag: parseInt(val.controls.fast_tag.value),
				tcs_percentage: parseInt(val.controls.tcs_percentage.value),
				tcs_amount: parseInt(val.controls.tcs_amount.value),
				essential_kit: parseInt(val.controls.essential_kit.value),
			};
			this.vehSer.saveOnRoadPrice(formObj).subscribe((res) => {
				this.changeDetectorRef.detectChanges();
			});
		} else {
			let formObj = {
				id: this.retreivedId,
				organization_id: 1,
				vehicle_id: parseInt(localStorage.getItem("vehIdData")),
				varient_id: this.varient_id,
				ex_showroom_price: val.controls.ex_showroom_price.value,
				vehicle_road_tax: val.controls.vehicle_road_tax.value,
				registration_charges: val.controls.registration_charges.value,
				handling_charges: val.controls.handling_charges.value,
				fast_tag: val.controls.fast_tag.value,
				tcs_percentage: val.controls.tcs_percentage.value,
				tcs_amount: val.controls.tcs_amount.value,
				essential_kit: parseInt(val.controls.essential_kit.value),
			};
			this.vehSer.updateOnRoadPrice(formObj).subscribe((res) => {
				this.changeDetectorRef.detectChanges();
			});
		}
		this.onRoadForm.reset();
		this.modalService.dismissAll();
	}
	openVarients(content, val) {
		this.varientDetails = {};
		this.modalService.open(content, {
			size: "lg",
		});
		this.varientDetails = {
			bhp: val.bhp,
			enginecc: val.enginecc,
			fuelType: val.fuelType,
			mileage: val.mileage,
			name: val.name,
			transmission_type: val.transmission_type,
			color:
				val.vehicleImages.length > 0 ? val.vehicleImages[0].color : "",
			color_body_code:
				val.vehicleImages.length > 0
					? val.vehicleImages[0].color_body_code
					: "",
			color_top_code:
				val.vehicleImages.length > 0
					? val.vehicleImages[0].color_top_code
					: "",
			is_dual_color:
				val.vehicleImages.length > 0
					? val.vehicleImages[0].is_dual_color.value
					: "",
			url: val.vehicleImages.length > 0 ? val.vehicleImages[0].url : "",
		};
	}
	fileChoose(event, docType) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			let formData = new FormData();
			formData.append("uploadFile", file);
			formData.append("uploadType", "vhehicle");
			this.vehSer.imageUpload("vhehicle", formData).subscribe((res) => {
				this.url = res.confirmationId;
				this.changeDetectorRef.detectChanges();
			});
		}
	}

	ngOnDestroy() {
		localStorage.removeItem("vehIdData");
	}
	openSnackBar(message: string, action: string, myclass: string) {
		this.snackBar.open(message, action, {
			duration: 2000,
			panelClass: myclass,
		});
	}
}
