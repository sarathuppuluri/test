// Angular
import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
// Material
import { MatSnackBar, MatDialog } from '@angular/material';
// RXJS
import { Subscription } from 'rxjs';
// CRUD
import { LayoutUtilsService, MessageType, QueryParamsModel } from '../../../../../../../core/_base/crud';
// Translate Module
import { TranslateService } from '@ngx-translate/core';
// Services and Models
import { OrganizationModel } from '../../../../../../../core/e-commerce/_models/organization.model';
// Components
import { OrganisationEditDialogComponent } from '../organisation-edit/organisation-edit.dialog.component';
import { OrganisationService } from '../../../../../../../core/e-commerce/_services/organisation.service';
import { Router } from '@angular/router';
import { AddressInfo } from '../../../../../../../core/e-commerce/_models/branch.model';
@Component({
	// tslint:disable-next-line:component-selector
	selector: 'kt-organisation',
	templateUrl: './organisation-list.component.html',
	styleUrls: ['./organisation-list.component.scss']
})
export class OrganisationListComponent implements OnInit, OnDestroy {
	loginEmployee: any;

	page = 0;
	pageSize = 10;
	isLoading = false;
	scope: any = {};

	// Subscriptions
	private subscriptions: Subscription[] = [];

	tempData = [];

	/**
	 * Component constructor
	 *
	 * @param dialog: MatDialog
	 * @param snackBar: MatSnackBar
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 */
	constructor(
		public dialog: MatDialog,
		private orgService: OrganisationService,
		private translate: TranslateService,
		private router: Router,
		public snackBar: MatSnackBar,
		private changeDetectorRef: ChangeDetectorRef,
		private layoutUtilsService: LayoutUtilsService
	) { }

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.loadOrgById();
	}

	ngOnDestroy() {
		this.subscriptions.forEach(el => el.unsubscribe());
	}

	/**
	 * Load Organizations List from service
	 */
	loadOrgById() {
		this.isLoading = true;
		const queryParams = new QueryParamsModel({}, '', '', this.page, this.pageSize);
		this.orgService.getOrgById(this.loginEmployee.orgId, queryParams).subscribe(res => {
			this.isLoading = false;
			this.scope = res.organizationInquiryInfos;
			this.tempData = res.organizationInquiryInfos.content;
			this.changeDetectorRef.detectChanges();
		}, error => {
			console.log('All Data of organisation error::' + error);
			this.changeDetectorRef.detectChanges();
		});
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.loadOrgById();
	}

	deleteOrg(element) {
		const _title = 'Organisation Delete';
		const _description = 'Are you sure to permanently delete this Organisation?';
		const _waitDesciption = 'Organisation is deleting...';
		const _deleteMessage = 'Organisation has been deleted';

		const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.orgService.deleteOrg(element.id).subscribe(orgRes => {
				this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
				this.loadOrgById();
				this.changeDetectorRef.detectChanges();
			});
		});
	}


	/**
	 * Show add vehicle dialog
	 */
	addOrg() {
		const editOrg = new OrganizationModel();
		const editAddressInfo = new AddressInfo();
		editOrg.clear(); // Set all defaults fields
		editAddressInfo.clear(); // Set all defaults fields
		editOrg.addressInfo = editAddressInfo;
		this.editOrg(editOrg);
	}

	/**
	 * Show Edit Org dialog and save after success close result
	 * @param editOrg: OrganizationModel
	 */
	editOrg(editOrg: OrganizationModel) {
		let saveMessageTranslateParam = 'ECOMMERCE.ORG.EDIT.';
		saveMessageTranslateParam += Number(editOrg.orgId) > 0 ? 'UPDATE_MESSAGE' : 'ADD_MESSAGE';
		const _saveMessage = this.translate.instant(saveMessageTranslateParam);
		const _messageType = Number(editOrg.orgId) > 0 ? MessageType.Update : MessageType.Create;

		const dialogRef = this.dialog.open(OrganisationEditDialogComponent, { data: { editOrg } });
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.layoutUtilsService.showActionNotification(_saveMessage, _messageType).afterOpened().subscribe(orgRes => {
				this.loadOrgById();
			});
		});
	}

	getRowData(orgId) {
		this.router.navigate(['/organizationManagement/branch', orgId]);
	}
}
