// Angular
import {
	Component,
	OnInit,
	ChangeDetectorRef,
	Inject,
	ChangeDetectionStrategy,
	ViewEncapsulation,
	ViewChild,
	ElementRef,
	OnDestroy,
} from "@angular/core";
// Material
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
// RxJS
import { Subscription, of } from "rxjs";
import { delay } from "rxjs/operators";
// NGRX
import { Update } from "@ngrx/entity";
import { Store, select } from "@ngrx/store";
// State
import { AppState } from "../../../../../../../core/reducers";
// CRUD
import {
	LayoutUtilsService,
	MessageType,
	TypesUtilsService,
	QueryParamsModel,
} from "../../../../../../../core/_base/crud";
// Services and Models
import {
	CustomerModel,
	EnquiryService,
	MyRolesService,
} from "../../../../../../../core/e-commerce";
import { EmployeesModel } from "../../../../../../../core/e-commerce/_models/employees.model";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { BranchService } from "../../../../../../../core/e-commerce/_services/branch.service";

declare let ol: any;

@Component({
	selector: "kt-employees-edit-dialog",
	templateUrl: "./employees-edit.dialog.component.html",
	styleUrls: ["./employees-edit.dialog.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush,
	encapsulation: ViewEncapsulation.None,
})
export class EmployeesEditDialogComponent implements OnInit, OnDestroy {
	myrolesResult: any = [];
	departmentDesignation: any;

	/**
	 * Component constructor
	 *
	 * @param dialogRef: MatDialogRef<CustomerEditDialogComponent>
	 * @param data: any
	 * @param fb: FormBuilder
	 * @param store: Store<AppState>
	 * @param typesUtilsService: TypesUtilsService
	 */
	constructor(
		public dialogRef: MatDialogRef<EmployeesEditDialogComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any,
		private fb: FormBuilder,
		private changeDetectorRef: ChangeDetectorRef,
		private layoutUtilsService: LayoutUtilsService,
		private branchService: BranchService,
		private myroleservice: MyRolesService,
		private enquiryservice: EnquiryService,
		private store: Store<AppState>
	) {}
	// Public properties
	customerForm: FormGroup;
	hasFormErrors = false;
	viewLoading = false;
	empEdit: any;
	state: any;
	id: number;
	selectstate: string;
	district: any;
	selectedValue: string;
	// Private properties
	private componentSubscriptions: Subscription;
	lat: number;
	lon: number;
	map: any;
	secmap: any;
	editCond: boolean;
	showroom = true;
	servicecenter = false;
	@ViewChild("mapContainer", { static: false }) gmap: ElementRef;

	empForm: FormGroup;
	AddressForm1: FormGroup;
	AddressForm2: FormGroup;

	hasSubmitted = false;
	message = "";

	tempData = [];
	AllDataBranch: any = [];
	dataSource: any = [];

	loginEmployee: any;

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.empEdit = this.data.editEmployee;
		this.createForm();
		this.loadDepartAndDesig();
	}

	createForm() {
		this.empForm = this.fb.group({
			departmentId: [this.empEdit.departmentId],
			designationId: [this.empEdit.designationId],
			repotingTo: [this.empEdit.repotingTo],
			approverId: [this.empEdit.approverId],
			empName: [this.empEdit.empName],
			mobile: [this.empEdit.mobile],
			email: [this.empEdit.email],
		});

		this.AddressForm1 = this.fb.group({
			pincode: [""],
			houseNo: [""],
			street: [""],
			address: [""],
			village: [""],
			city: [""],
			district: [""],
			state: [""],
			isUrban: [""],
			sameAsCommunicationAddress: [""],
		});

		this.AddressForm2 = this.fb.group({
			pincode: [""],
			houseNo: [""],
			street: [""],
			address: [""],
			village: [""],
			city: [""],
			district: [""],
			state: [""],
			isUrban: [""],
		});

		if (Number(this.empEdit.empId) > 0 && this.empEdit.address !== null) {
			this.AddressForm1.patchValue(this.empEdit.address.presentAddress);
			this.AddressForm2.patchValue(this.empEdit.address.permanentAddress);
		}
	}

	assignAddress(event) {
		if (
			this.AddressForm1.controls.sameAsCommunicationAddress.value === true
		) {
			this.AddressForm2.patchValue(this.AddressForm1.value);
		}
	}

	// pincode search Method for Address
	pincodeSearch(event, form) {
		if (event.length === 6) {
			if (
				this.AddressForm1.controls.sameAsCommunicationAddress.value !==
				true
			) {
				const locationPincode = this.enquiryservice
					.getLocationUsingPincode(event)
					.subscribe((res) => {
						form.patchValue({
							state: res[0].PostOffice[0].State,
							district: res[0].PostOffice[0].District,
						});
					});
			}
		}
	}

	mobileNumberKeyPress(event: any) {
		const pattern = /[0-9]/;
		const inputChar = String.fromCharCode(event.charCode);
		if (event.keyCode != 8 && !pattern.test(inputChar)) {
			event.preventDefault();
		}
	}

	/**
	 * On destroy
	 */
	ngOnDestroy() {
		if (this.componentSubscriptions) {
			this.componentSubscriptions.unsubscribe();
		}
	}

	/**
	 * Check control is invalid
	 * @param controlName: string
	 */
	isControlInvalid(controlName: string): boolean {
		const control = this.customerForm.controls[controlName];
		const result = control.invalid && control.touched;
		return result;
	}

	onSubmit() {
		this.hasSubmitted = true;
		this.hasFormErrors = false;
		const controls = this.empForm.controls;
		if (this.empForm.invalid) {
			Object.keys(controls).forEach((controlName) =>
				controls[controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		}

		this.empEdit.departmentId = controls.departmentId.value;
		this.empEdit.designationId = controls.designationId.value;
		this.empEdit.repotingTo = controls.repotingTo.value;
		this.empEdit.approverId = controls.approverId.value;
		this.empEdit.cognitoName =
			Number(this.empEdit.empId) > 0
				? this.empEdit.cognitoName
				: controls.empName.value.replace(/\s/g, "");
		this.empEdit.createdBy = this.loginEmployee.empName;
		this.empEdit.empName = controls.empName.value;
		this.empEdit.mobile = controls.mobile.value;
		this.empEdit.email = controls.email.value;
		this.empEdit.address = {
			presentAddress: this.AddressForm1.value,
			permanentAddress: this.AddressForm2.value,
		};
		this.empEdit.updatedBy = this.loginEmployee.empName;

		const empDataObj = this.empEdit;

		if (Number(this.empEdit.empId) > 0) {
			this.updateEmployee(empDataObj);
		} else {
			this.createEmployee(empDataObj);
		}
	}

	createEmployee(empData) {
		const cognitoEMP = {
			name: this.empEdit.empName.replace(/\s/g, ""),
			email: this.empEdit.email,
			lastname: this.empEdit.email,
			birthdate: this.empEdit.dateOfBirth,
			phoneNumber: this.empEdit.mobile,
			password: "Bharat@123",
		};
		this.branchService
			.createCognitoEMP(cognitoEMP)
			.subscribe((cognitoRes) => {
				if (cognitoRes.status === "200") {
					const confirmEMP = {
						empname: cognitoRes.userName,
						password: "Bharat@123",
						newPassword: "Bharat@123",
					};
					this.branchService
						.createEmployee(empData)
						.subscribe((response) => {
							this.hasSubmitted = false;
							if (!response) {
								return;
							}
							this.branchService
								.confirmCognitoEMP(confirmEMP)
								.subscribe((confirmRes) => {
									if (confirmRes.status === "200") {
										this.dialogRef.close({
											empData,
											isEdit: false,
										});
									} else {
										this.layoutUtilsService.showActionNotification(
											confirmRes.reason,
											MessageType.Create
										);
									}
								});
						});
				} else {
					this.layoutUtilsService.showActionNotification(
						cognitoRes.reason,
						MessageType.Create
					);
				}
			});
	}

	updateEmployee(editEmployee) {
		this.branchService
			.updateEmployee(editEmployee)
			.subscribe((response) => {
				this.hasSubmitted = false;
				if (!response) {
					return;
				}
				this.dialogRef.close({ editEmployee, isEdit: true });
			});
	}

	/**
	 * Load Department and Designation
	 */
	loadDepartAndDesig() {
		this.branchService
			.getDepartmentDesignation(this.empEdit.orgId, this.empEdit.branchId)
			.subscribe(
				(res) => {
					this.departmentDesignation = res.dmsEntity;
					if (Number(this.empEdit.empId) > 0) {
						this.loadEmpReportingTo();
					}
					this.changeDetectorRef.detectChanges();
				},
				(error) => {
					console.log(error);
				}
			);
	}

	/**
	 * Load Employee Reporting To List
	 */
	loadEmpReportingTo() {
		if (
			this.empForm.controls.designationId.value === 0 ||
			this.empForm.controls.departmentId.value === 0 ||
			this.empForm.controls.designationId.value === "null" ||
			this.empForm.controls.departmentId.value === "null" ||
			this.empForm.controls.designationId.value === undefined ||
			this.empForm.controls.departmentId.value === undefined
		) {
			return;
		}
		const design = this.departmentDesignation.designations.filter(
			(record) =>
				record.dmsDesignationId ===
				+this.empForm.controls.designationId.value
		);
		this.branchService
			.getEmpReportingTo(
				this.empEdit.orgId,
				this.empEdit.branchId,
				design[0].designationLevel,
				this.empForm.controls.departmentId.value
			)
			.subscribe(
				(res) => {
					this.tempData = res.dmsEntity.employees;
					this.changeDetectorRef.detectChanges();
				},
				(error) => {
					console.log(error);
				}
			);
	}

	/**
	 * Load Employee List from service
	 */
	loadEmployeeById() {
		const queryParams = new QueryParamsModel({}, "", "", 0, 100);
		this.branchService
			.getEmployeeById(
				this.empEdit.orgId,
				this.empEdit.branchId,
				queryParams
			)
			.subscribe(
				(res) => {
					this.tempData = res.employeeInquiryInfo.content;
					this.changeDetectorRef.detectChanges();
				},
				(error) => {
					console.log("All Data of Employee error::" + error);
					this.changeDetectorRef.detectChanges();
				},
				() => {}
			);
	}

	/**
	 * Load Roles List from service
	 */
	loadMyRolesListView() {
		const queryParams = new QueryParamsModel({}, "", "", 0, 1000);
		this.myroleservice
			.getRedsignedRolesNewChange(
				queryParams,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res) => {
				this.myrolesResult = res.dmsEntity.rolePage.content;
				this.changeDetectorRef.detectChanges();
			});
	}

	/** Alect Close event */
	onAlertClose() {
		this.hasFormErrors = false;
	}
}
