// Angular
import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// Material
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
// RxJS
import { Subscription, of } from 'rxjs';
import { delay } from 'rxjs/operators';
// NGRX
import { Update } from '@ngrx/entity';
import { Store, select } from '@ngrx/store';
// State
import { AppState } from '../../../../../../core/reducers';
// CRUD
import { TypesUtilsService } from '../../../../../../core/_base/crud';
// Services and Models
import { MyRoleModel, MyRolesService } from '../../../../../../core/e-commerce';

@Component({
	// tslint:disable-next-line:component-selector
	selector: 'kt-myroles-edit-dialog',
	templateUrl: './myrole-edit.dialog.component.html',
	changeDetection: ChangeDetectionStrategy.OnPush,
	encapsulation: ViewEncapsulation.None
})
export class MyRoleEditDialogComponent implements OnInit, OnDestroy {

	userName;
	loginEmployee;

	// Public properties
	myrole: any;
	myroleForm: FormGroup;
	hasFormErrors = false;
	viewLoading = false;
	// Private properties
	private componentSubscriptions: Subscription;
	message: any;

	/**
	 * Component constructor
	 *
	 * @param dialogRef: MatDialogRef<MyRoleEditDialogComponent>
	 * @param data: any
	 * @param fb: FormBuilder
	 * @param store: Store<AppState>
	 * @param typesUtilsService: TypesUtilsService
	 */
	constructor(public dialogRef: MatDialogRef<MyRoleEditDialogComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any,
		private fb: FormBuilder,
		private store: Store<AppState>,
		private typesUtilsService: TypesUtilsService,
		private changeDetectorRef: ChangeDetectorRef,
		private myroleservice: MyRolesService) {
	}

	ngOnInit() {
		this.userName = JSON.parse(localStorage.getItem('loginEmployee')).empName;
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.myrole = this.data.myrole;
		this.createForm();
	}

	/**
	 * On destroy
	 */
	ngOnDestroy() {
		if (this.componentSubscriptions) {
			this.componentSubscriptions.unsubscribe();
		}
	}

	createForm() {
		this.myroleForm = this.fb.group({
			roleName: [this.myrole.roleName, Validators.required],
			description: [this.myrole.description, Validators.required]
		});
	}

	/**
	 * Returns page title
	 */
	getTitle(): string {
		if (this.myrole.roleId > 0) {
			return `Edit Role '${this.myrole.roleName}'`;
		}

		return 'New Role';
	}

	/**
	 * Check control is invalid
	 * @param controlName: string
	 */
	isControlInvalid(controlName: string): boolean {
		const control = this.myroleForm.controls[controlName];
		const result = control.invalid && control.touched;
		return result;
	}

	/** ACTIONS */

	/**
	 * Returns prepared myrole
	 */
	/*prepareMyRole(): MyRoleModel {
		const controls = this.myroleForm.controls;
		const _myrole = new MyRoleModel();
		_myrole.roleId = this.myrole.roleId;
		_myrole.createdBy = this.myrole.createdBy;
		_myrole.roleName = controls.roleName.value;
		_myrole.description = controls.description.value;
		return _myrole;
	}*/

	/*
	 * On Submit
	 */
	onSubmit() {
		this.hasFormErrors = false;
		const controls = this.myroleForm.controls;
		/** check form */
		if (this.myroleForm.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			return;
		}
		if (this.myrole.roleId > 0) {
			this.updateRedesignedData();
		} else {
			this.createRedesignedData();
		}
	}

	updateRedesignedData() {
		this.myrole.roleName = this.myroleForm.controls.roleName.value;
		this.myrole.description = this.myroleForm.controls.description.value;
		const roleData = this.myrole;
		this.myroleservice.updateRedsignedRole(roleData).subscribe(res => {
			if (res.status === 500) {
				this.message = res.message;
				this.hasFormErrors = true;
				this.changeDetectorRef.detectChanges();
				return;
			}
			this.dialogRef.close({ roleData, isEdit: true });
		}, err => {
			this.dialogRef.close({ roleData, isEdit: true });
		});
	}

	createRedesignedData() {
		this.message = '';
		const roleDataDev = {
			createdBy: this.userName,
			description: this.myroleForm.controls.description.value,
			roleName: this.myroleForm.controls.roleName.value,
			orgId: this.loginEmployee.orgId,
			branchId: this.loginEmployee.branchId
		};
		this.myroleservice.createRedsignedRole(roleDataDev).subscribe(res => {
			if (res.status === 500) {
				this.message = res.message;
				this.hasFormErrors = true;
				this.changeDetectorRef.detectChanges();
				return;
			}
			this.dialogRef.close({ roleDataDev, isEdit: false });
		}, err => {
			this.dialogRef.close({ roleDataDev, isEdit: false });
		});
	}

	/** Alect Close event */
	onAlertClose($event) {
		this.hasFormErrors = false;
	}
}
