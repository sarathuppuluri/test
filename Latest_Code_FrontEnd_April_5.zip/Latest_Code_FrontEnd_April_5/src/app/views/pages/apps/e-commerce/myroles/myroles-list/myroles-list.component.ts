// Angular
import {
	Component,
	OnInit,
	ViewChild,
	OnDestroy,
	ChangeDetectorRef,
} from "@angular/core";
// Material
import { SelectionModel } from "@angular/cdk/collections";
import { MatSort, MatDialog } from "@angular/material";
// RXJS
import { Subscription } from "rxjs";
// Translate Module
import { TranslateService } from "@ngx-translate/core";
// CRUD
import {
	LayoutUtilsService,
	MessageType,
	QueryParamsModel,
} from "../../../../../../core/_base/crud";
// Services and Models
import { MyRoleModel } from "../../../../../../core/e-commerce";
// Components
import { MyRoleEditDialogComponent } from "../myrole-edit/myrole-edit.dialog.component";

import { MyRolesService } from "../../../../../../core/e-commerce/_services";
import { Router } from "@angular/router";
import { MenuAsideService } from "../../../../../../core/_base/layout/services/menu-aside.service";
import { FormBuilder, FormGroup } from "@angular/forms";

@Component({
	selector: "kt-myroles-list",
	templateUrl: "./myroles-list.component.html",
})
export class MyRolesListComponent implements OnInit, OnDestroy {
	loginEmployee: any;

	searchFormGroup: FormGroup;
	searchProgress = false;
	message = "";

	/**
	 * Component constructor
	 *
	 * @param dialog: MatDialog
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 */
	constructor(
		public dialog: MatDialog,
		private layoutUtilsService: LayoutUtilsService,
		private translate: TranslateService,
		private myroleservice: MyRolesService,
		private router: Router,
		private changeDetectorRef: ChangeDetectorRef,
		private menuAsideService: MenuAsideService,
		private formBuilder: FormBuilder
	) {}
	// Table fields
	dataSource: any;
	displayedColumns = ["roleName", "description", "actions"];
	// @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
	@ViewChild("sort1", { static: true }) sort: MatSort;
	// Filter fields
	/*@ViewChild('searchInput', {static: true}) searchInput: ElementRef;
	filterStatus = '';
	filterType = '';*/
	// Selection
	selection = new SelectionModel<MyRoleModel>(true, []);
	myrolesResult: MyRoleModel[] = [];
	// Subscriptions
	private subscriptions: Subscription[] = [];
	isLoading = false;
	page = 0;
	pageSize = 10;
	tempActions = [];

	scope: any = {};

	ngOnInit() {
		this.menuAsideService.tempList.forEach((element) => {
			if (element.menuName === "employeeManagement") {
				element.submenu.forEach((subelement) => {
					if (subelement.menuName === "roles") {
						this.myroleservice.readUrl = subelement.apiUrl;
						this.tempActions = subelement.actions;
						this.tempActions.forEach((element) => {
							if (element.actionName === "viewRole") {
								// this.myroleservice.readUrl = element.apiUrl;
							} else if (element.actionName === "createRole") {
								this.myroleservice.createUrl = element.apiUrl;
							} else if (element.actionName === "editRole") {
								this.myroleservice.updateUrl = element.apiUrl;
							} else if (element.actionName === "deleteRole") {
								this.myroleservice.deleteUrl = element.apiUrl;
							}
						});
					}
				});
			}
		});
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.searchForm();
		this.loadMyRolesListView();
	}

	/**
	 * On Destroy
	 */
	ngOnDestroy() {
		this.subscriptions.forEach((el) => el.unsubscribe());
	}

	loadMyRolesListView() {
		this.myrolesResult = [];
		this.isLoading = true;
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize
		);
		this.myroleservice
			.getRedsignedRolesNewChange(
				queryParams,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res) => {
				this.isLoading = false;
				this.scope = res.dmsEntity.rolePage;
				this.myrolesResult = res.dmsEntity.rolePage.content;
				this.changeDetectorRef.detectChanges();
			});
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.loadMyRolesListView();
	}

	// search role
	searchForm() {
		this.searchFormGroup = this.formBuilder.group({
			name: [""],
		});
	}

	// submit search role name
	onSubmit() {
		this.searchProgress = true;
		const controls = this.searchFormGroup.controls;
		this.message = "";
		this.myrolesResult = [];
		this.myroleservice
			.getRolesBasedOnName(controls.name.value)
			.subscribe((res) => {
				this.searchProgress = false;
				if (res.statusCode !== 400 && res.status !== 500) {
					if (Array.isArray(res.dmsEntity.rolesList) === false) {
						if (res.status !== 500) {
							this.myrolesResult.push(res.dmsEntity.role);
						} else {
							this.message = "No Roles Found";
						}
					} else {
						this.myrolesResult = res.dmsEntity.rolesList;
					}
				} else {
					this.message = res.message;
					this.myrolesResult = [];
				}
				this.changeDetectorRef.detectChanges();
			});
	}

	// reset serach role name
	onReset() {
		this.searchFormGroup.reset();
		this.message = "";
		this.loadMyRolesListView();
	}

	/** ACTIONS */
	/**
	 * Delete myrole
	 */
	deleteMyRole(role) {
		const _title: string = this.translate.instant("Role Delete");
		const _description: string = this.translate.instant(
			"Are you sure to permanently delete this Role?"
		);
		const _waitDesciption: string = this.translate.instant(
			"Role is deleting..."
		);
		const _deleteMessage = this.translate.instant("SuccessFully deleted.");

		const dialogRef = this.layoutUtilsService.deleteElement(
			_title,
			_description,
			_waitDesciption
		);
		dialogRef.afterClosed().subscribe((res) => {
			if (!res) {
				return;
			}
			this.myroleservice
				.deleteRedsignedRole(role.roleId)
				.subscribe((res) => {
					this.layoutUtilsService
						.showActionNotification(
							_deleteMessage,
							MessageType.Delete
						)
						.afterOpened()
						.subscribe((res) => {
							this.page =
								this.myrolesResult.length === 1
									? this.page - 1
									: this.page;
							this.loadMyRolesListView();
						});
				});
		});
	}

	/**
	 * Show add myrole dialog
	 */
	addMyRole() {
		const newMyRole = new MyRoleModel();
		newMyRole.clear(); // Set all defaults fields
		this.editMyRole(newMyRole);
	}

	/**
	 * Show Edit myrole dialog and save after success close result
	 * @param myrole: MyRoleModel
	 */
	editMyRole(myrole: MyRoleModel) {
		let saveMessageTranslateParam = "ECOMMERCE.ROLES.EDIT.";
		saveMessageTranslateParam +=
			myrole.roleId > 0 ? "UPDATE_MESSAGE" : "ADD_MESSAGE";
		const _saveMessage = this.translate.instant(saveMessageTranslateParam);
		const _messageType =
			myrole.roleId > 0 ? MessageType.Update : MessageType.Create;
		const dialogRef = this.dialog.open(MyRoleEditDialogComponent, {
			data: { myrole },
		});
		dialogRef.afterClosed().subscribe((res) => {
			if (!res) {
				return;
			}
			this.layoutUtilsService
				.showActionNotification(_saveMessage, _messageType)
				.afterOpened()
				.subscribe((res) => {
					this.loadMyRolesListView();
				});
		});
	}

	getRowData(data) {
		this.router.navigate([
			"/employeeManagement/roles/subview",
			data.roleId,
		]);
	}
}
