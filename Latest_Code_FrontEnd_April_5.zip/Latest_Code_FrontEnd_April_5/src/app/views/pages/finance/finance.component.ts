import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-finance',
  templateUrl: './finance.component.html',
  styleUrls: ['./finance.component.scss']
})
export class FinanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
