// Angular
import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
// Core Module
import { CoreModule } from "../../../core/core.module";
import { PartialsModule } from "../../partials/partials.module";
import { MatIconModule } from "@angular/material/icon";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import {
	MatTabsModule,
	MatCardModule,
	MatInputModule,
	MatFormFieldModule,
	MatExpansionModule,
	MatStepperModule,
	MatCheckboxModule,
	MatButtonModule,
	MatAutocompleteModule,
} from "@angular/material";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { FlexLayoutModule } from "@angular/flex-layout";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { InsuranceCalculatorComponent } from "./insurance-calculator.component";
import { InsuranceCalculatorService } from "../../../core/e-commerce/_services/insurance-calculator.service";

@NgModule({
	imports: [
		CommonModule,
		PartialsModule,
		CoreModule,
		MatIconModule,
		NgbModule,
		MatTabsModule,
		MatCardModule,
		FormsModule,
		ReactiveFormsModule,
		MatFormFieldModule,
		MatStepperModule,
		MatInputModule,
		MatButtonModule,
		MatCheckboxModule,
		MatAutocompleteModule,
		MatInputModule,
		MatExpansionModule,
		ReactiveFormsModule,
		FlexLayoutModule,
		MatDatepickerModule,
		RouterModule.forChild([
			{
				path: "",
				component: InsuranceCalculatorComponent,
			},
		]),
	],
	providers: [InsuranceCalculatorService],
	declarations: [InsuranceCalculatorComponent],
})
export class InsuranceCalculatorModule {}
