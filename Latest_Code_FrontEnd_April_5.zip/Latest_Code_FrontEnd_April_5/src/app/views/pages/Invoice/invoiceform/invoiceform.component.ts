import { Component, ElementRef, OnInit, OnDestroy, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgControlStatus, FormArray } from '@angular/forms';
import { EnquiryService, SharedService, MyRolesService, Lead360Service } from '../../../../core/e-commerce/_services';
import { ActivatedRoute, Router } from '@angular/router';
import { LayoutUtilsService } from '../../../../core/_base/crud/utils/layout-utils.service';
import { QueryParamsModel } from '../../../../../app/core/_base/crud';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { findIndex } from 'rxjs/operators';
import { Subscription } from 'rxjs';

@Component({
	selector: 'kt-invoiceform',
	templateUrl: './invoiceform.component.html',
	styleUrls: ['./invoiceform.component.scss']
})
export class InvoiceformComponent implements OnInit, OnDestroy {
	// Used in the MatPicker
	startDate;
	message: any;
	loginEmployee: any;
	dropClicked = false;
	dropLeadDetails: any = { dmsLeadDropInfo: {} };
	warranty: any;
	insuranceType = 0;
	addOnCovers = 0;
	warrantyElement = 0;
	onRoadPriceCalculator = 0;
	onRoadPriceDiscountCalculator: any;
	accessoryCost = 0;
	addSelectedAccessoryCost = 0;
	accessoriesArray = [];
	slectedCorporateOfferCost: any;
	corporateOfferPrice = 0;
	pendingAmount: number;
	// changeVechileModelStore: NodeJS.Timeout;
	// changeVariantStore: NodeJS.Timeout;
	onRoadPrice: any;
	offers: any = {
		offerDetails: [
			// {}, {}, {}
		]
	};

	netExShowroomPrice = 0;
	basicPrice = 0;
	gstAmount = 0;
	cessAmount = 0;
	corporateCheckValue: boolean;
	offerDetailsCheckValue: boolean;

	// Subscriptions
	private subscriptions: Subscription[] = [];

	constructor(private fb: FormBuilder, private enquiryservice: EnquiryService, private routeData: ActivatedRoute,
		private layoutUtilsService: LayoutUtilsService,
		private sharedService: SharedService,
		private myroleService: MyRolesService,
		private lead360Service: Lead360Service,
		private router: Router,
		private changedetectorref: ChangeDetectorRef,
		private modalService: NgbModal) {
		this.leadId = this.routeData.snapshot.paramMap.get('id');
		this.startDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
	}

	_subscription;

	EnquiryEditForm: FormGroup;
	EnquiryEditForm2: FormGroup;
	EnquiryEditForm4: FormGroup;

	PreBookingForm: FormGroup;
	InvoiceForm: FormGroup;
	DropEnquiryForm: FormGroup;

	hasFormErrors = false;

	submitted = false;
	leadId = '';

	vechilesData = [];
	vechileModelsList = [];
	variantsList = [];
	colorsList = [];
	fuelTypeList = [];
	variantRecord = [];

	showImageCheck = true;
	hasSubmitted = false;
	endAutoSave = false;
	statusShow = false;

	second = 1000;
	minute = this.second * 60;
	hour = this.minute * 60;
	day = this.hour * 24;
	month = this.day * 30;
	year = this.day * 365;

	leadObject: any = {};
	vehicleAllotementBody: any = {};
	postOnRoadPriceTable: any = {};
	invoiceDetails: any = {};
	totalSelected = 0;
	offerData: any = [];

	page = 0;
	pageSize = 10;
	scope: any = {};

	popCheck = false;
	testDrive = '';
	homeVisit = '';
	evaluation = '';
	isTestDrive = false;
	isHomeVisit = false;
	isEvaluation = false;

	ngOnInit() {
		this.endAutoSave = false;
		this.statusShow = false;
		this.enquiryForm();
		this.getVechilesDetails();
		this.getLeadDetailsUniversalId();
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		// this.onRoadPriceDetails();
		// this.offerDetails();
	}

	ngOnDestroy(): void {
		// Called once, before the instance is destroyed.
		// Add 'implements OnDestroy' to the class.
		this.endAutoSave = true;
		this.statusShow = false;
		// clearTimeout(this.changeVechileModelStore);
		// clearTimeout(this.changeVariantStore);
		this.subscriptions.forEach(el => el.unsubscribe());
	}

	assignBillingAddress(i) {
		this.EnquiryEditForm2.patchValue(this.leadObject.dmsLeadDto.dmsAddresses[i]);
	}

	enquiryForm() {
		this.EnquiryEditForm = this.fb.group({
			referencenumber: [''],
			firstName: [''],
			lastName: [''],
			relation: [''],
			relationName: [''],
			dseName: [''],
			aadharNumber: [''],
			panNumber: [''],
			gstNumber: [''],
			vehicleRegNumber: [''],
			nameOnRcCard: ['']
		});

		this.EnquiryEditForm2 = this.fb.group({
			pincode: [''],
			houseNo: [''],
			street: [''],
			address: [''],
			village: [''],
			city: [''],
			district: [''],
			state: [''],
			preferredBillingAddress: ['']
		});

		this.InvoiceForm = this.fb.group({
			stateType: ['', Validators.required],
			gst: [''],
			gst_rate: [''],
			cessPercentage: [''],
			totalTax: [''],

			invoiceType: [''],
			invoiceDate: [(new Date(Date.now())).toISOString()],
			financerName: [''],
			branch: [''],
			corporateCode: [''],
			corporateName: [''],
		});

		this.EnquiryEditForm4 = this.fb.group({
			model: [''],
			variant: [''],
			variantCode: [''],
			color: [''],
			colorCode: [''],
			chassisNumber: [''],
			keyNumber: [''],
			fuel: [''],
			engineCC: ['', Validators.required],
			transimmisionType: ['']
		});

		this.PreBookingForm = this.fb.group({
			specialSchemeOffer: [''],
			promotionalOffers: [''],
			cashDiscount: [''],
			focAccessories: [''],
			additionalOffer1: [''],
			additionalOffer2: ['']
		});

		this.DropEnquiryForm = this.fb.group({
			dropReason: [''],
			dealerName: [''],
			brandName: [''],
			otherReason: [''],
			additionalRemarks: [''],
			location: [''],
			model: ['']
		});
	}

	/**
	* Checking control validation
	*
	* @param controlName: string => Equals to formControlName
	* @param validationType: string => Equals to valitors name
	*/
	isControlHasError(controlName: string, validationType: string, formName): boolean {
		const control = this[formName].controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}

	mobileNumberKeyPress(event: any) {
		const pattern = /[0-9]/;
		// const pattern = /[0-9\+\-\ ]/;
		// const pattern = "^((\\+91-?)|0)?[0-9]{10}$";

		const inputChar = String.fromCharCode(event.charCode);
		if (event.keyCode !== 8 && !pattern.test(inputChar)) {
			event.preventDefault();
		}
	}

	onSubmit() {
		this.hasSubmitted = true;
		this.hasFormErrors = false;
		this.endAutoSave = true;
		this.statusShow = true;
		this.updateLeadDetails(this.EnquiryEditForm.value);
	}

	// Get Lead Details By UniversalID
	getLeadDetailsUniversalId() {
		this.enquiryservice.getLeadByUniversalID(this.leadId).subscribe(res => {
			if (!res) {
				return;
			}
			this.leadObject = res.dmsEntity;
			this.EnquiryEditForm.patchValue(this.leadObject.dmsContactDto ? this.leadObject.dmsContactDto : this.leadObject.dmsAccountDto);
			this.EnquiryEditForm.patchValue(this.leadObject.dmsLeadDto);
			this.EnquiryEditForm.patchValue({ dseName: this.leadObject.dmsEmployeeAllocationDtos[0].employeeName });
			this.InvoiceForm.patchValue({
				corporateName: this.postOnRoadPriceTable.corporateName
			});
			this.EnquiryEditForm4.patchValue({
				model: this.leadObject.dmsLeadDto.model
			});
			if (this.leadObject.dmsLeadDto.dmsAddresses.length > 0) {
				if (this.leadObject.dmsLeadDto.dmsAddresses[0].preferredBillingAddress === 'Communication') {
					this.EnquiryEditForm2.patchValue(this.leadObject.dmsLeadDto.dmsAddresses[0]);
				} else {
					this.EnquiryEditForm2.patchValue(this.leadObject.dmsLeadDto.dmsAddresses[1]);
				}
			}

			if (this.leadObject.dmsLeadDto.dmsLeadProducts.length > 0) {
				this.EnquiryEditForm4.patchValue({
					model: (this.leadObject.dmsLeadDto.dmsLeadProducts[0].model !== null) ? this.leadObject.dmsLeadDto.dmsLeadProducts[0].model : this.leadObject.dmsLeadDto.model,
					variant: this.leadObject.dmsLeadDto.dmsLeadProducts[0].variant,
					color: this.leadObject.dmsLeadDto.dmsLeadProducts[0].color,
					fuel: this.leadObject.dmsLeadDto.dmsLeadProducts[0].fuel,
					transimmisionType: this.leadObject.dmsLeadDto.dmsLeadProducts[0].transimmisionType
				});
			}

			// get OnRoadPrice Table Posted Data
			this.enquiryservice.getOnRoadPricePosted(this.leadObject.dmsLeadDto.id).subscribe(response => {
				if (response.dmsEntity.dmsOnRoadPriceDtoList.length > 0) {
					this.postOnRoadPriceTable = response.dmsEntity.dmsOnRoadPriceDtoList[0];
				}
			});

			// get Vehicle Allotment Details
			this.enquiryservice.getVehicleAllocation(this.leadObject.dmsLeadDto.id).subscribe(response => {
				if (response.dmsEntity.dmsAllotmentDtoList.length > 0) {
					this.vehicleAllotementBody = response.dmsEntity.dmsAllotmentDtoList[0];
					this.EnquiryEditForm4.patchValue({
						chassisNumber: this.vehicleAllotementBody.chassisNo,
						keyNumber: this.vehicleAllotementBody.keyNo
					});
				}
			});

			// get Invoice Details
			this.enquiryservice.getInvoiceDetails(this.leadObject.dmsLeadDto.id).subscribe(response => {
				if (response.dmsEntity.dmsInvoiceDtoList.length > 0) {
					this.invoiceDetails = response.dmsEntity.dmsInvoiceDtoList[0];
					this.InvoiceForm.patchValue(this.invoiceDetails);
					this.InvoiceForm.patchValue({
						invoiceDate: (new Date(this.invoiceDetails.invoiceDate ? this.invoiceDetails.invoiceDate : Date.now())).toISOString()
					});
					this.EnquiryEditForm4.patchValue({ engineCC: `${this.invoiceDetails.engineCc} CC` });
					this.gstRate();
					this.cessRate();
				}
			});

			this.EnquiryEditForm.get('referencenumber').disable({ onlySelf: true });
			// this.EnquiryEditForm.disable();
			this.EnquiryEditForm2.disable();
			this.EnquiryEditForm4.disable();
			this.InvoiceForm.get('gst').disable({ onlySelf: true });
			this.InvoiceForm.get('gst_rate').disable({ onlySelf: true });
			this.InvoiceForm.get('cessPercentage').disable({ onlySelf: true });
			this.InvoiceForm.get('totalTax').disable({ onlySelf: true });
			this.EnquiryEditForm4.get('engineCC').enable({ onlySelf: true });


			if (this.leadObject.dmsLeadDto.leadStatus === 'INVOICECOMPLETED') {
				// Lead360 Tasks
				this.myroleService.getAllTasksUniversalID(this.leadId, 'Invoice').subscribe(taskRes => {
					taskRes.dmsEntity.tasks.forEach((element) => {
						if (element.taskName === 'Test Drive' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')) {
							this.testDrive = 'Test Drive : Pending';
							this.isTestDrive = true;
						}
						if (element.taskName === 'Home Visit' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')) {
							this.homeVisit = 'Home Visit : Pending';
							this.isHomeVisit = true;
						}
						if (element.taskName === 'Evaluation' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')
							&& this.leadObject.dmsLeadDto.buyerType === 'Replacement Buyer') {
							this.evaluation = 'Evaluation : Pending';
							this.isEvaluation = true;
						}

						if (element.universalId === this.leadId && element.taskName === 'Proceed to Predelivery'
							&& element.assignee.empId === this.loginEmployee.empId) {
							this.lead360Service.selectedTaskObj = element;
							// this.router.navigate(['/lead360']);
							this.popCheck = true;
							return;
						}
					});
				});
			}
		});
	}

	// Post Lead Details
	updateLeadDetails(controls) {
		if (this.EnquiryEditForm4.invalid) {
			this.EnquiryEditForm4.controls.engineCC.markAsTouched();
			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		} else if (this.InvoiceForm.invalid) {
			this.InvoiceForm.controls.stateType.markAsTouched();
			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		}

		if (this.leadObject.dmsContactDto) {
			this.leadObject.dmsContactDto.firstName = controls.firstName;
			this.leadObject.dmsContactDto.lastName = controls.lastName;
		} else {
			this.leadObject.dmsAccountDto.firstName = controls.firstName;
			this.leadObject.dmsAccountDto.lastName = controls.lastName;
		}
		this.leadObject.dmsLeadDto.firstName = controls.firstName;
		this.leadObject.dmsLeadDto.lastName = controls.lastName;

		// Invoice Object
		this.invoiceDetails.id = this.invoiceDetails.id ? this.invoiceDetails.id : 0;
		this.invoiceDetails.invoiceType = this.InvoiceForm.value.invoiceType;
		this.invoiceDetails.invoiceDate = Date.parse(this.InvoiceForm.value.invoiceDate);
		this.invoiceDetails.financerName = this.InvoiceForm.value.financerName;
		this.invoiceDetails.branch = this.InvoiceForm.value.branch;
		this.invoiceDetails.corporateCode = this.InvoiceForm.value.corporateCode;
		this.invoiceDetails.stateType = this.InvoiceForm.value.stateType;
		this.invoiceDetails.gst = this.InvoiceForm.controls.gst.value;
		this.invoiceDetails.gst_rate = this.InvoiceForm.controls.gst_rate.value;
		this.invoiceDetails.cessPercentage = this.InvoiceForm.controls.cessPercentage.value;
		this.invoiceDetails.totalTax = this.InvoiceForm.controls.totalTax.value;
		this.invoiceDetails.engineCc = (this.EnquiryEditForm4.controls.engineCC.value).split(' ').shift();
		this.invoiceDetails.basicPrice = this.basicPrice.toFixed(2);
		this.invoiceDetails.cessAmount = this.cessAmount.toFixed(2);
		this.invoiceDetails.totalAmount = this.netExShowroomPrice;
		this.invoiceDetails.leadId = this.leadObject.dmsLeadDto.id;
		this.invoiceDetails.bookingId = this.leadObject.dmsLeadDto.dmsBooking.id;

		this.enquiryservice.sendInvoiceDetails(this.invoiceDetails).subscribe(response => {
			if (!response) {
				return;
			}
			if (response.success === false) {
				this.message = response.message;
				return;
			}
			this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
				if (res.statusCode !== 500) {
					this.message = '';
					this.leadObject = res.dmsEntity;
					this.hasSubmitted = false;
					if (this.endAutoSave) {
						this.leadObject.dmsLeadDto.leadStatus = 'INVOICECOMPLETED';
						this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(stageRes => {
						});
						if (this.statusShow) {
							this.updateStatusMessage('Invoice Updated Successfully');
						}
					}
					this.changedetectorref.detectChanges();
				} else {
					this.hasSubmitted = false;
					this.message = res.message;
					this.gotoTop();
					this.changedetectorref.detectChanges();
				}
			});
		});
	}

	// Lead Address Object
	sendCommunicationDetails(controls1) {
		const comData = [
			{
				addressType: 'Communication',
				houseNo: controls1.houseNo,
				street: controls1.street,
				city: controls1.city,
				district: controls1.district,
				pincode: controls1.pincode,
				state: controls1.state,
				village: controls1.village,
				county: 'India',
				id: this.leadObject.dmsLeadDto.dmsAddresses[0] ? this.leadObject.dmsLeadDto.dmsAddresses[0].id : 0
			},
		];

		return comData;
	}

	// Lead Products Object
	sendModelSelection(controls) {
		const objData = [
			{
				color: controls.color,
				model: controls.model,
				fuel: controls.fuel,
				transimmisionType: controls.transimmisionType,
				variant: controls.variant,
				id: this.leadObject.dmsLeadDto.dmsLeadProducts[0] ? this.leadObject.dmsLeadDto.dmsLeadProducts[0].id : 0
			}
		];

		return objData;
	}

	// Pop-Up To Show Pending Tasks
	pendingTasksStatus() {
		let _title = '';
		_title = 'Pending Tasks';
		const _description = [this.testDrive, this.homeVisit, this.evaluation];
		const dialogRef = this.layoutUtilsService.taskRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.isTestDrive = false;
			this.isHomeVisit = false;
			this.isEvaluation = false;
			this.testDrive = '';
			this.homeVisit = '';
			this.evaluation = '';
			if (!this.popCheck) {
				this.updateStatusMessagePermission();
			} else {
				this.router.navigate(['/lead360']);
				this.popCheck = false;
			}
		});
	}

	// Pop-Up after Submission -- Permission Denied
	updateStatusMessagePermission() {
		let _title = '';
		_title = '';
		const _description = `Permission Denied`;
		const dialogRef = this.layoutUtilsService.updateRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.goBack();
			this.popCheck = false;
		});
	}

	// Pop-Up after Enquiry Submission
	updateStatusMessage(msg) {
		let _title = /*'Invoice Updated Successfully'*/ msg;
		const _description = `Invoice Number: ${this.leadObject.dmsLeadDto.referencenumber}`;
		const dialogRef = this.layoutUtilsService.updateRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.router.navigate(['/invoice/invoice']);
		});
	}

	// pincode search Method for Address
	pincodeSearch(event, form) {
		if (event.length === 6) {
			if (this.EnquiryEditForm2.controls.sameAsCommunicationAddress.value !== true) {
				this.enquiryservice.getLocationUsingPincode(event).subscribe(res => {
					form.patchValue({
						state: res[0].PostOffice[0].State,
						district: res[0].PostOffice[0].District
					});
				});
			}
		}
	}

	// Change Vechile Model
	changeVechileModel() {
		const selectedModel = this.EnquiryEditForm4.controls.model.value;
		const promise = new Promise((resolve) => {
			if ((selectedModel !== null) && (selectedModel !== 'Select') && (selectedModel !== '')) {
				resolve();
			}
		});

		promise.then(() => {
			let tempData = this.vechilesData.filter(record => record.model === selectedModel)
				.map(obj => {
					return {
						variantsList: obj.varients,
					};
				})[0];
			tempData = tempData;
			this.variantsList = tempData.variantsList || [];
			this.changeVariant();
			this.showImageCheck = true;
		});
	}

	// Image display based on Model
	swapImage() {
		this.showImageCheck = false
	}

	// Change Variant
	changeVariant() {
		this.variantRecord = [];
		const selectedVariant = this.EnquiryEditForm4.controls.variant.value;
		const promise = new Promise((resolve) => {
			if ((selectedVariant !== null) && (selectedVariant !== 'Select') && (selectedVariant !== '')) {
				this.variantRecord = this.variantsList.filter(record => record.name === selectedVariant);
				this.EnquiryEditForm4.patchValue({ engineCC: this.variantRecord[0].enginecc });
				this.cessRate();
				resolve();
			}
		});

		promise.then(() => {
			this.showImageCheck = false;
			this.colorsList = this.variantRecord[0].vehicleImages.filter(record => record.color === this.EnquiryEditForm4.controls.color.value);
			this.onRoadPriceDetails();
		});
	}

	// Get vechiles Details
	getVechilesDetails() {
		this._subscription = this.sharedService.vechileDetailsChange.subscribe((value) => {
			this.vechilesData = value;
			this.changeVechileModel();
		});
	}

	// Get OnRoad Price Details
	onRoadPriceDetails() {
		this.enquiryservice.getOnRoadPriceDetails(this.variantRecord[0].id, this.loginEmployee.orgId).subscribe(res => {
			this.onRoadPrice = res;
			this.enquiryservice.getAllOffers(this.variantRecord[0].vehicleId, this.variantRecord[0].id, this.loginEmployee.orgId).subscribe(res => {
				this.offers = res;
				if ((Array.isArray(this.offers.offerCorporate) === true) && this.offers.offerCorporate.length > 0) {
					this.corporateCheckValue = true;
				} else {
					this.corporateCheckValue = false;
				}
				if ((Array.isArray(this.offers.offerDetails) === true) && this.offers.offerDetails.length > 0) {
					this.offerDetailsCheckValue = true;
					if ((Array.isArray(this.postOnRoadPriceTable.offerData) === true) && this.postOnRoadPriceTable.offerData.length > 0) {
						this.offerData = this.postOnRoadPriceTable.offerData;
						this.offers.offerDetails.forEach(element => {
							this.postOnRoadPriceTable.offerData.forEach(subElement => {
								if (element.offerName === subElement.offerName && element.amount === subElement.offerAmount) {
									element.isSelected = true;
								}
							});
						});
						this.totalSelected = this.offerData.reduce((acc, cur) => acc + (cur.offerAmount || 0), 0);
					}
				} else {
					this.offerDetailsCheckValue = false;
				}
				if (this.postOnRoadPriceTable.corporateCheck) {
					this.offers.offerCorporate[0].offerCorporates.forEach(element => {
						if (element.company === this.postOnRoadPriceTable.corporateName) {
							this.corporateOfferPrice = element.discount_amount;
							this.totalAmountCal();
						}
					});
				} else {
					this.totalAmountCal();
				}
				this.changedetectorref.detectChanges();
			});
		});
	}

	// Get Offers
	offerDetails() {
		this.enquiryservice.getAllOffers(this.variantRecord[0].vehicleId, this.variantRecord[0].id, this.loginEmployee.orgId).subscribe(res => {
			this.offers = res;
			this.changedetectorref.detectChanges();
		});
	}

	gstRate() {
		if (this.InvoiceForm.controls.stateType.value === 'Same_State') {
			this.InvoiceForm.patchValue({
				gst: 'CGST + SGST',
				gst_rate: 28,
				totalTax: (28 + (this.InvoiceForm.controls.cessPercentage.value ? this.InvoiceForm.controls.cessPercentage.value : 0))
			});
		} else if (this.InvoiceForm.controls.stateType.value === 'Other_State') {
			this.InvoiceForm.patchValue({
				gst: 'IGST',
				gst_rate: 28,
				totalTax: (28 + (this.InvoiceForm.controls.cessPercentage.value ? this.InvoiceForm.controls.cessPercentage.value : 0))
			});
		} else if (this.InvoiceForm.controls.stateType.value === 'Union_Territory') {
			this.InvoiceForm.patchValue({
				gst: 'UTGST',
				gst_rate: 28,
				totalTax: (28 + (this.InvoiceForm.controls.cessPercentage.value ? this.InvoiceForm.controls.cessPercentage.value : 0))
			});
		}
		setTimeout(() => {
			this.totalAmountCal();
		}, 100);
	}

	cessRate() {
		let engineCCValue = (this.EnquiryEditForm4.controls.engineCC.value).split(' ').shift();
		if (this.EnquiryEditForm4.controls.fuel.value !== 'Diesel') {
			if (engineCCValue < 1200) {
				this.InvoiceForm.patchValue({
					cessPercentage: 1,
					totalTax: ((this.InvoiceForm.controls.gst_rate.value ? this.InvoiceForm.controls.gst_rate.value : 0) + 1)
				});
			} else if ((engineCCValue >= 1200) && (engineCCValue <= 1500)) {
				this.InvoiceForm.patchValue({
					cessPercentage: 17,
					totalTax: ((this.InvoiceForm.controls.gst_rate.value ? this.InvoiceForm.controls.gst_rate.value : 0) + 17)
				});
			} else if (engineCCValue > 1500) {
				this.InvoiceForm.patchValue({
					cessPercentage: 20,
					totalTax: ((this.InvoiceForm.controls.gst_rate.value ? this.InvoiceForm.controls.gst_rate.value : 0) + 20)
				});
			}
		} else {
			if (engineCCValue < 1500) {
				this.InvoiceForm.patchValue({
					cessPercentage: 3,
					totalTax: ((this.InvoiceForm.controls.gst_rate.value ? this.InvoiceForm.controls.gst_rate.value : 0) + 3)
				});
			} else if (engineCCValue >= 1500) {
				this.InvoiceForm.patchValue({
					cessPercentage: 20,
					totalTax: ((this.InvoiceForm.controls.gst_rate.value ? this.InvoiceForm.controls.gst_rate.value : 0) + 20)
				});
			}
		}
		setTimeout(() => {
			this.totalAmountCal();
		}, 100);
	}

	totalAmountCal() {
		this.netExShowroomPrice =
			this.onRoadPrice.ex_showroom_price -
			(this.totalSelected +
				(((this.postOnRoadPriceTable.corporateName !== null) || (this.postOnRoadPriceTable.corporateName !== '')) ? Number(this.corporateOfferPrice) : 0) +
				this.postOnRoadPriceTable.specialScheme +
				this.postOnRoadPriceTable.promotionalOffers +
				this.postOnRoadPriceTable.cashDiscount +
				this.postOnRoadPriceTable.focAccessories +
				this.postOnRoadPriceTable.additionalOffer1 +
				this.postOnRoadPriceTable.additionalOffer2);

		this.basicPrice = (this.netExShowroomPrice) / (1 + (this.InvoiceForm.controls.totalTax.value) / 100);
		this.gstAmount = (this.basicPrice * (this.InvoiceForm.controls.gst_rate.value / 100)) / 2;
		this.cessAmount = (this.basicPrice * (this.InvoiceForm.controls.cessPercentage.value / 100));
	}

	goToPredelivery() {
		if (this.testDrive || this.homeVisit || this.evaluation) {
			this.pendingTasksStatus();
		} else {
			if (!this.popCheck) {
				// this.updateStatusMessage();
				this.updateStatusMessagePermission();
			} else {
				this.router.navigate(['/lead360']);
				this.popCheck = false;
			}
		}
	}

	dropEnquiry() {
		this.dropClicked = true;
	}

	// Proceed to Drop
	proceedToCancel() {
		this.dropLeadDetails.dmsLeadDropInfo.additionalRemarks = this.DropEnquiryForm.value.additionalRemarks;
		this.dropLeadDetails.dmsLeadDropInfo.branchId = this.loginEmployee.branchId;
		this.dropLeadDetails.dmsLeadDropInfo.brandName = this.DropEnquiryForm.value.brandName;
		this.dropLeadDetails.dmsLeadDropInfo.dealerName = this.DropEnquiryForm.value.dealerName;
		this.dropLeadDetails.dmsLeadDropInfo.enquiryCategory = this.DropEnquiryForm.value.enquiryCategory;
		this.dropLeadDetails.dmsLeadDropInfo.leadId = this.leadObject.dmsLeadDto.id;
		this.dropLeadDetails.dmsLeadDropInfo.crmUniversalId = this.leadId;
		this.dropLeadDetails.dmsLeadDropInfo.lostReason = this.DropEnquiryForm.value.dropReason;
		this.dropLeadDetails.dmsLeadDropInfo.organizationId = this.loginEmployee.orgId;
		this.dropLeadDetails.dmsLeadDropInfo.otherReason = '';
		this.dropLeadDetails.dmsLeadDropInfo.droppedBy = this.loginEmployee.empId;
		this.dropLeadDetails.dmsLeadDropInfo.location = this.DropEnquiryForm.value.location;
		this.dropLeadDetails.dmsLeadDropInfo.model = this.DropEnquiryForm.value.model;
		this.dropLeadDetails.dmsLeadDropInfo.stage = 'INVOICE';
		this.dropLeadDetails.dmsLeadDropInfo.status = 'INVOICE';
		const sendDropDet = this.enquiryservice.sendDropDetails(this.dropLeadDetails).subscribe(res => {
			if (res.statusCode === '200') {
				this.leadObject.dmsLeadDto.leadStage = 'DROPPED';
				const sendLeadEnq = this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
				});
				this.subscriptions.push(sendLeadEnq);
			}
			if (res.approver === this.loginEmployee.empName) {
				this.lead360Service.getAllTasksByUniversalId(this.leadId);
				this.updateStatusMessage('Successfully Dropped Lead');
			} else {
				this.lead360Service.getAllApprovalTasksByUniversalId(this.leadId);
				this.updateStatusMessage('Sent For Approval');
			}
		});
		this.subscriptions.push(sendDropDet);
	}

	goBack() {
		this.router.navigate(['/invoice/invoice']);
	}

	gotoTop() {
		window.scroll({
			top: 0,
			left: 0,
			behavior: 'smooth'
		});
	}
}
