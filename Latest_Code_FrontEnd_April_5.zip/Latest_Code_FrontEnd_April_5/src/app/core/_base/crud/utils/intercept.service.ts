// Angular
import { Injectable } from "@angular/core";
import {
	HttpEvent,
	HttpInterceptor,
	HttpHandler,
	HttpRequest,
	HttpResponse,
} from "@angular/common/http";
// RxJS
import { Observable } from "rxjs";
import { tap } from "rxjs/operators";

@Injectable()
export class InterceptService implements HttpInterceptor {
	// intercept request and add token
	intercept(
		request: HttpRequest<any>,
		next: HttpHandler
	): Observable<HttpEvent<any>> {
		const idToken = localStorage.getItem("idToken");

		if (
			idToken &&
			!request.url.match(/api.postalpincode.in\//) &&
			!request.url.match("http://hrms") &&
			!request.url.match("http://role-management") &&
			!request.url.match("http://sales/task") &&
			!request.url.match("http://sales") &&
			!request.url.match("http://admin") &&
			!request.url.match("http://inventory") &&
			!request.url.match("http://ops") &&
			!request.url.match("http://vehicle-information-service") &&
			!request.url.match("http://customer-service") &&
			!request.url.match("http://vehicle-services") ) {
			request = request.clone({
				headers: request.headers.set("auth-token", idToken),
			});
			request = request.clone({
				headers: request.headers
					.set("Accept", "application/json")
					.set("Content-Type", "application/json"),
			});
		}

		return next.handle(request).pipe(
			tap(
				(event) => {
					if (event instanceof HttpResponse) {
					}
				},
				(error) => {
					console.error(error.status);
					console.error(error.message);
				}
			)
		);
	}
}
