// Angular
import { Injectable } from "@angular/core";
import { NavigationEnd, Router } from "@angular/router";
// RxJS
import { filter, mergeMap, tap, withLatestFrom } from "rxjs/operators";
import { defer, Observable, of } from "rxjs";
// NGRX
import { Actions, Effect, ofType } from "@ngrx/effects";
import { Action, select, Store } from "@ngrx/store";
// Auth actions
import {
	AuthActionTypes,
	Login,
	Logout,
	Register,
	UserLoaded,
	UserRequested,
} from "../_actions/auth.actions";
import { AuthService } from "../_services/index";
import { AppState } from "../../reducers";
import { isUserLoaded } from "../_selectors/auth.selectors";

import * as moment from "moment";

@Injectable()
export class AuthEffects {
	@Effect({ dispatch: false })
	login$ = this.actions$.pipe(
		ofType<Login>(AuthActionTypes.Login),
		tap((action) => {
			let expire: any;
			localStorage.setItem(
				"authTokenKey",
				action.payload.user.accessToken
			);
			localStorage.setItem("idToken", action.payload.user.idToken);
			localStorage.setItem(
				"refreshToken",
				action.payload.user.refreshToken
			);
			localStorage.setItem("userName", action.payload.user.userName);
			const isNew = localStorage.getItem("isNew");
			if (isNew === "true") {
				expire = moment()
					.add(action.payload.user.tokenExpiresin, "seconds")
					.valueOf();
				localStorage.setItem("isNew", "false");
			} else {
				expire = action.payload.user.tokenExpiresin;
			}
			localStorage.setItem("tokenExpiresin", expire);
			this.store.dispatch(new UserRequested());
		})
	);

	@Effect({ dispatch: false })
	logout$ = this.actions$.pipe(
		ofType<Logout>(AuthActionTypes.Logout),
		tap(() => {
			localStorage.clear();
			this.router.navigate(["/auth/login"]);
		})
	);

	@Effect({ dispatch: false })
	register$ = this.actions$.pipe(
		ofType<Register>(AuthActionTypes.Register),
		tap((action) => {
			localStorage.setItem(
				"authTokenKey",
				action.payload.user.accessToken
			);
			localStorage.setItem("idToken", action.payload.user.idToken);
			localStorage.setItem(
				"tokenExpiresin",
				action.payload.user.tokenExpiresin
			);
			localStorage.setItem(
				"refreshToken",
				action.payload.user.refreshToken
			);
			localStorage.setItem("userName", action.payload.user.userName);
		})
	);

	@Effect()
	init$: Observable<Action> = defer(() => {
		const userToken = localStorage.getItem("authTokenKey");
		const idToken = localStorage.getItem("idToken");
		const expiresIn = localStorage.getItem("tokenExpiresin");
		const refreshToken = localStorage.getItem("refreshToken");
		const userName = localStorage.getItem("userName");
		let observableResult = of({ type: "NO_ACTION" });
		if (userToken) {
			let user = {
				accessToken: userToken,
				idToken: idToken,
				tokenExpiresin: expiresIn,
				refreshToken: refreshToken,
				userName: userName,
			};
			observableResult = of(new Login({ user: user }));
		}
		return observableResult;
	});

	private returnUrl: string;

	constructor(
		private actions$: Actions,
		private router: Router,
		private auth: AuthService,
		private store: Store<AppState>
	) {
		this.router.events.subscribe((event) => {
			if (event instanceof NavigationEnd) {
				this.returnUrl = event.url;
			}
		});
	}
}
