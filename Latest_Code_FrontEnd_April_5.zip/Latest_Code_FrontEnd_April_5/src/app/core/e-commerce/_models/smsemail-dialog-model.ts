export interface SMSEMAILDialogModel {
    disableClose?: boolean;
    titleString?: string;
    messageString?: string;
    responseData?: string;
    placeholderString?: string;
    okButtonString?: string;
    cancelButtonString?: string;
    dialogType?: number;
    maxLength?: number;
    email?: emailDialogModel;
}

export interface emailDialogModel {
    emailTemplate?: string;
    emailId?: string;
    templateTypes?: emailData[]
}

export interface emailData {
    templateName: string;
    subjectName: string;
    emailText: string;
}