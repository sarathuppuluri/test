enum EnumDialogTypes {
    ALERT, PROMPT, CONFIRM, DROP_DOWN, EMAIL, SMS
}

export class SMSEMAILEnums {
    static pcDialogType = EnumDialogTypes;
}
