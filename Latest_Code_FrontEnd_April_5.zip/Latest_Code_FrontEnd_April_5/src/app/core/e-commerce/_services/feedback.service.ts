import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { HttpUtilsService } from "../../_base/crud";
import { environment } from "../../../../environments/environment.base";

@Injectable()
export class FeedbackService {
	loginEmployee: any;
	constructor(private http: HttpClient, private httpUtils: HttpUtilsService) {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
	}

	getFeedbacks(limit, offset): Observable<any> {
		return this.http.get(
			environment.notificationServices +
				"/feedback/api/feedback_b2c/all?branchId=" +
				this.loginEmployee.branchId +
				"&limit=" +
				limit +
				"&offset=" +
				offset +
				"&orgId=" +
				this.loginEmployee.orgId
		);
	}
}
