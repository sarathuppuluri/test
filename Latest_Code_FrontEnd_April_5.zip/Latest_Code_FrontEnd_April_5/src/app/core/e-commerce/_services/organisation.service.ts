// Angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../_base/crud';
// Models
import { OrganizationModel } from './../_models/organization.model';
import { environment } from '../../../../environments/environment.base';
import { HttpHeaders } from '@angular/common/http';


@Injectable()
export class OrganisationService {
	constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

	// Get Org By ID
	getOrgById(orgId, queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(`${environment.roleManagement}/organization/details?id=${orgId}&offset=${httpParams.get('startindex')}&limit=${httpParams.get('endindex')}`);
	}

	// Get All Orgs
	getAllOrgs(queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(`${environment.roleManagement}/organization/details?offset=${httpParams.get('startindex')}&limit=${httpParams.get('endindex')}`);
	}

	// Update Org
	updateOrg(data): Observable<any> {
		return this.http.post<OrganizationModel>(`${environment.roleManagement}/organization/update`, data);
	}


	// CREATE =>  POST: add a new customer to the server
	createOrg(data): Observable<any> {
		return this.http.post<OrganizationModel>(`${environment.roleManagement}/organization/create`, data);
	}


	deleteOrg(id): Observable<any> {
		return this.http.delete<any>(`${environment.roleManagement}/organization/delete/${id}`);
	}
}
