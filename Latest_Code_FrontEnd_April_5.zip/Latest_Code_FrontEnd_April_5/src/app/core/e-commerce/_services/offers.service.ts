import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";
import { environment } from "../../../../environments/environment.base";

@Injectable()
export class OffersService {
	offer: any;
	loginEmployee: any;
	constructor(private http: HttpClient) {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
	}

	getAllOffers(page, size): Observable<any> {
		return this.http.get(
			environment.ops +
				"/api/getalloffers?orgId=" +
				this.loginEmployee.orgId + "pageNo=" +
				page +
				"&pageSize=" +
				size,
			{ headers: this.getHeaders() }
		);
	}

	getAllOfferMappings(): Observable<any> {
		return this.http.get(environment.ops + "/api/alloffermapping", {
			headers: this.getHeaders(),
		});
	}

	createOffer(data) {
		return this.http.post(
			environment.ops + "/api/createofferdetail",
			data,
			{ headers: this.getHeaders() }
		);
	}

	createCropOffer(data) {
		return this.http.post(
			environment.ops + "/api/createcorporateoffer",
			data,
			{ headers: this.getHeaders() }
		);
	}

	createOfferMapping(data) {
		return this.http.post(
			environment.ops + "/api/createoffermapping1",
			data,
			{ headers: this.getHeaders() }
		);
	}

	getOfferMappingsByOfferId(id): Observable<any> {
		return this.http.get(
			environment.ops + "/api/offermappingbyofferid?id=" + id,
			{ headers: this.getHeaders() }
		);
	}

	getOfferById(type, id): Observable<any> {
		return this.http.get(
			environment.ops +
				"/api/getofferbyid?offerType=" +
				type +
				"&offerId=" +
				id,
			{ headers: this.getHeaders() }
		);
	}

	getOfferMappingById(id): Observable<any> {
		return this.http.get(
			environment.ops + "/api/offermappingbyid?id=" + id,
			{ headers: this.getHeaders() }
		);
	}

	deleteOffer(offerDetails) {
		const options = {
			headers: this.getHeaders(),
			body: offerDetails,
		};
		return this.http.delete(
			environment.ops + "api//deleteofferdetail",
			options
		);
	}

	deleteCropOffer(offerMapping) {
		const options = {
			headers: this.getHeaders(),
			body: offerMapping,
		};
		return this.http.delete(
			environment.ops + "/api/deletecorporateoffer",
			options
		);
	}

	deleteOfferMapping(offerMapping) {
		const options = {
			headers: this.getHeaders(),
			body: offerMapping,
		};
		return this.http.delete(
			environment.ops + "/api/deleteoffermapping",
			options
		);
	}

	updateOffer(data) {
		return this.http.put(
			environment.ops + "/api/updateofferdetail",
			data,
			{ headers: this.getHeaders() }
		);
	}

	updateCropOffer(data) {
		return this.http.put(
			environment.ops + "/api/updatecorporateoffer",
			data,
			{ headers: this.getHeaders() }
		);
	}

	updateOfferMapping(data) {
		return this.http.put(
			environment.ops + "/api/updateoffermapping",
			data,
			{ headers: this.getHeaders() }
		);
	}

	getHeaders() {
		let headers = new HttpHeaders();
		headers = headers.append("orgid", this.loginEmployee.orgId);
		return headers;
	}

	getVehicles(): Observable<any> {
		return this.http.get(
			environment.vehicleInfoService +
				"/api/vehicle_details?organizationId=" +
				this.loginEmployee.orgId
		);
	}
}
