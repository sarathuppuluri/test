// Angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel } from '../../_base/crud';
// Environment
import { environment } from '../../../../environments/environment.base';


@Injectable()
export class CustomerComplaintsService {
	constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

	// Get all Customer Compliants
	getCustComplList(queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(`${environment.sales}/customer-complaints?limit=${httpParams.get('endindex')}&offset=${httpParams.get('startindex')}`);
	}

	// Delete Customer Compliant
	deleteCustCompl(complId): Observable<any> {
		return this.http.delete<any>(`${environment.sales}/customer-complaints/id/${complId}`);
	}

	// Create Customer Compliant
	createCustCompl(data): Observable<any> {
		return this.http.post<any>(`${environment.sales}/customer-complaints`, data);
	}

	// Update Customer Compliant
	updateCustCompl(data): Observable<any> {
		return this.http.put<any>(`${environment.sales}/customer-complaints`, data);
	}

	// Search Customer Compliant
	searchCustCompl(compliantType, customerName, employee): Observable<any> {
		if (compliantType !== '' && (customerName === '' || customerName === null) && (employee === '' || employee === null)) {
			return this.http.get<any>(`${environment.sales}/customer-complaints/filter?complaint_Type=${compliantType}`);
		} else if (customerName !== '' && (compliantType === '' || compliantType === null) && (employee === '' || employee === null)) {
			return this.http.get<any>(`${environment.sales}/customer-complaints/filter?customer_Name=${customerName}`);
		} else if (employee !== '' && (compliantType === '' || compliantType === null) && (customerName === '' || customerName === null)) {
			return this.http.get<any>(`${environment.sales}/customer-complaints/filter?employee=${employee}`);
		} else if ((compliantType !== '' && customerName !== '') && (employee === '' || employee === null)) {
			return this.http.get<any>(`${environment.sales}/customer-complaints/filter?complaint_Type=${compliantType}&customer_Name=${customerName}`);
		} else if ((compliantType !== '' && employee !== '') && (customerName === '' || customerName === null)) {
			return this.http.get<any>(`${environment.sales}/customer-complaints/filter?complaint_Type=${compliantType}&employee=${employee}`);
		} else if ((customerName !== '' && employee !== '') && (compliantType === '' || compliantType === null)) {
			return this.http.get<any>(`${environment.sales}/customer-complaints/filter?customer_Name=${customerName}&employee=${employee}`);
		} else {
			return this.http.get<any>(`${environment.sales}/customer-complaints/filter?complaint_Type=${compliantType}&customer_Name=${customerName}&employee=${employee}`);
		}
	}

	// Search PreEnquiry API
	getSearchResultsPreEnquiry(phone, name): Observable<any> {
		if (name !== '' && (phone === '' || phone === null)) {
			return this.http.get<any>(`${environment.sales}/lead?lastName=${name}`);
		} else if (phone !== '' && (name === '' || name === null)) {
			return this.http.get<any>(`${environment.sales}/lead?phone=${phone}`);
		} else {
			return this.http.get<any>(`${environment.sales}/lead?lastName=${name}&phone=${phone}`);
		}
	}
}
