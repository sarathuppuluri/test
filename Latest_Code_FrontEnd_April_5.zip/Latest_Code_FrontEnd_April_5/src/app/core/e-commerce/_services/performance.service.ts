import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Subject, Observable, of } from "rxjs";
import { environment } from "../../../../environments/environment.base";

const API_URL = `${environment.hrms}`;

@Injectable()
export class PerformanceService {
	isUserLogin = false;
	userDetails: any;

	constructor(private http: HttpClient) {
		if (sessionStorage.getItem("userData") !== null) {
			this.isUserLogin = true;
			this.userDetails = JSON.parse(sessionStorage.getItem("userData"));
		} else {
			this.isUserLogin = false;
		}
	}

	getAllPerformance(orgid, branchid, limit, offset) {
		return this.http.get<any>(
			`${API_URL}/api/performance/getAllPerformance?orgid=${orgid}&branchid=${branchid}&offset=${offset}&limit=${limit}`
		);
	}

	savePerformance(data) {
		const headerObject = {
			headers: new HttpHeaders().set("Content-Type", "application/json"),
		};
		return this.http.post(
			`${API_URL}/api/performance/savePerformance`,
			JSON.stringify(data),
			headerObject
		);
	}

	updatePerformance(data) {
		const headerObject = {
			headers: new HttpHeaders().set("Content-Type", "application/json"),
		};
		return this.http.put(
			`${API_URL}/api/performance/updatePerformance`,
			JSON.stringify(data),
			headerObject
		);
	}

	deletePerformance(id): Observable<any> {
		return this.http.delete<any>(`${API_URL}/api/performance/id/${id}`);
	}
	getMappingsByid(id): Observable<any> {
		return this.http.get<any>(`${API_URL}/api/performance/id/${id}`);
	}

	deleteMappings(id): Observable<any> {
		return this.http.delete<any>(`${API_URL}/api/performance/mappingid/${id}`);
	}

	updateMapping(data) {
		const headerObject = {
			headers: new HttpHeaders().set("Content-Type", "application/json"),
		};
		return this.http.put(
			`${API_URL}/updatePerformance`,
			JSON.stringify(data),
			headerObject
		);
	}

	saveMapping(data) {
		const headerObject = {
			headers: new HttpHeaders().set("Content-Type", "application/json"),
		};
		return this.http.post(
			`${API_URL}/api/performance/savePerformanceMapping`,
			JSON.stringify(data),
			headerObject
		);
	}
}
