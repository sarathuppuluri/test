import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { HttpUtilsService } from "../../_base/crud";
import { environment } from "../../../../environments/environment.base";

@Injectable({
	providedIn: "root",
})
export class NotificationService {
	constructor(
		private http: HttpClient,
		private httpUtils: HttpUtilsService
	) {}

	sendEmail(data) {
		return this.http.post(
			environment.notificationServices +
				"/dms-core-api/dmscore/api/sendEmail",
			data
		);
	}

	sendSMS(data) {
		return this.http.post(
			environment.notificationServices +
				"/dms-core-api/dmscore/api/sendSms",
			data
		);
	}
}
