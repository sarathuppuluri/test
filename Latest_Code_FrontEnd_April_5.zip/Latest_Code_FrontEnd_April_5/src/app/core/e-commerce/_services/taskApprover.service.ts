import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { HttpUtilsService } from "../../_base/crud";
import { environment } from "../../../../environments/environment.base";

@Injectable()
export class TaskApproverService {
	loginEmployee: any;
	empName: any;
	rowObject: any;
	constructor(private http: HttpClient, private httpUtils: HttpUtilsService) {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
	}
	getTasksApproverList(): Observable<any> {
		return this.http.get(
			environment.sales +
				"/task-approver/list-entries?branchId=" +
				this.loginEmployee.branchId +
				"&orgId=" +
				this.loginEmployee.orgId
		);
	}

	getTasksApproverById(taskId, empId): Observable<any> {
		return this.http.get(
			environment.sales +
				"/task-approver/list-entry?branchId=" +
				this.loginEmployee.branchId +
				"&empId=" +
				empId +
				"&orgId=" +
				this.loginEmployee.orgId +
				"&taskId=" +
				taskId
		);
	}

	deleteTaskApprover(id) {
		return this.http.delete(
			environment.roleManagement + "/task-approver/delete?id=" + id
		);
	}

	updateTaskApprover(data): Observable<any> {
		return this.http.put(
			`${environment.roleManagement}/task-approver/update`,
			data
		);
	}
	createTaskApprover(data): Observable<any> {
		return this.http.post(
			`${environment.roleManagement}/task-approver/create`,
			data
		);
	}

	getTaskDefinitions(): Observable<any> {
		return this.http.get<any>(`${environment.roleManagement}/taskDefinition`);
	}

	getDepartments(): Observable<any> {
		return this.http.get<any>(
			`${environment.roleManagement}/employee/master-data/orgId/${this.loginEmployee.orgId}/branchId/${this.loginEmployee.branchId}`
		);
	}

	getEmployeeByDept(deptId, desigId) {
		return this.http.get<any>(
			`${environment.roleManagement}/employee/dept-employees?orgId=${this.loginEmployee.orgId}&branchId=${this.loginEmployee.branchId}&deptId=${deptId}&desigId=${desigId}`
		);
	}

	getReporties(gradeId, deptId) {
		return this.http.get<any>(
			`${environment.roleManagement}/employee/reports-to?orgId=${this.loginEmployee.orgId}&branchId=${this.loginEmployee.branchId}&grade=${gradeId}&deptId=${deptId}`
		);
	}
}
