import { Injectable } from '@angular/core';
import { HttpUtilsService } from '../../_base/crud';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable()
export class MenuService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  updateMenu(url, menuData): Observable<any> {
      return this.http.put<any>(url, menuData);
  }
}
