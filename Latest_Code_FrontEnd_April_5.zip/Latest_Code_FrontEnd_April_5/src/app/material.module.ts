import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatExpansionModule } from "@angular/material/expansion";
import { MatButtonModule } from "@angular/material/button";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatSidenavModule } from "@angular/material/sidenav";
import { MatDatepickerModule,MatStepperModule, MatNativeDateModule, MatIconModule, MatBadgeModule, MatListModule, MatRadioModule, MatChipsModule, MatTooltipModule, MatPaginatorModule, MatCardModule, MatTableModule, MatAutocompleteModule, MatInputModule, MatSelectModule, MatCheckboxModule, MatToolbarModule, MatDialogModule, MatTabsModule, MatGridListModule, MatSortModule } from '@angular/material';




@NgModule({
  imports: [
    CommonModule,
    MatFormFieldModule,
    MatExpansionModule,
    MatGridListModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSortModule,
    MatIconModule,
    MatSidenavModule,
    MatBadgeModule,
    MatListModule,
    MatRadioModule,
    MatChipsModule,
    MatTooltipModule,
    MatPaginatorModule,
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatAutocompleteModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatToolbarModule,
    MatDialogModule,
    MatProgressSpinnerModule,
    MatStepperModule
  ],

  exports: [
    CommonModule,
    MatFormFieldModule,
    MatExpansionModule,
    MatGridListModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatSidenavModule,
    MatSortModule,
    MatBadgeModule,
    MatListModule,
    MatRadioModule,
    MatChipsModule,
    MatTooltipModule,
    MatPaginatorModule,
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatAutocompleteModule,
    MatInputModule,
    MatTabsModule,
    MatSelectModule,
    MatCheckboxModule,
    MatDialogModule,
    MatToolbarModule,
    MatStepperModule,
    MatProgressSpinnerModule
  ]
})
export class CustomMaterialModule {}
