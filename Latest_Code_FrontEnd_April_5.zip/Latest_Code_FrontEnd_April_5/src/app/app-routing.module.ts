// Angular
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
// Components
import { BaseComponent } from "./views/theme/base/base.component";
import { ErrorPageComponent } from "./views/theme/content/error-page/error-page.component";
// Auth
import { AuthGuard } from "./core/auth";
import { MenuComponent } from "./views/pages/menu/menu.component";
import { EvaluatorComponent } from "./views/pages/evaluator/evaluator.component";
import { ManagerscreenComponent } from "./views/pages/managerscreen/managerscreen.component";
import { CreateEventComponent } from "./views/pages/event-managment/create-event/create-event.component";
import { EventCalenderComponent } from "./views/pages/event-managment/event-calender/event-calender.component";
import { MyTaskComponent } from "./views/pages/my-task/my-task.component";
import { PreviewEventFormComponent } from "./views/pages/event-managment/preview-event-form/preview-event-form.component";
import { EmployeeAllocationComponent } from "./views/pages/employee-allocation/employee-allocation.component";
import { AddVehicleComponent } from "./views/pages/admin/add-vehicle/add-vehicle.component";
import { MyTasksComponent } from "./views/pages/admin/my-tasks/my-task.component";
import { AddAlertComponent } from "./views/pages/admin/add-alert/add-alert.component";
import { EmicalculatorComponent } from "./views/pages/emicalculator/emicalculator.component";
import { PropertyDocsComponent } from "./views/pages/admin/property-docs/property-docs.component";
import { DataBankComponent } from "./views/pages/data-bank/data-bank.component";
import { TerritoryAllocationComponent } from "./views/pages/territory-allocation/territory-allocation.component";
import { UrbanTerritoryAllocationComponent } from "./views/pages/territory-allocation/urban/urban-territory-allocation.component";
import { RuralTerritoryAllocationComponent } from "./views/pages/territory-allocation/rural/rural-territory-allocation.component";
import { PerformanceRepotingComponent } from "./views/pages/performance-repoting/performanceRepoting.component";
import { BookingReportsrtsComponent } from "./views/pages/Reports/booking-reportsrts/booking-reportsrts.component";
import { EnquiryReportsComponent } from "./views/pages/Reports/enquiry-reports/enquiry-reports.component";
import { PrebookingReportsComponent } from "./views/pages/Reports/prebooking-reports/prebooking-reports.component";
import { PendingBookingTrackerComponent } from "./views/pages/pending-booking-tracker/pending-booking-tracker.component";
import { DropAnalysisComponent } from "./views/pages/drop-analysis/drop-analysis.component";
import { B2cTransactionsComponent } from "./views/pages/b2c-transactions/b2c-transactions.component";
import { IncentivesComponent } from "./views/pages/Reports/incentives/incentives.component";
import { UsedVehiclesComponent } from "./views/pages/used-vehicles/used-vehicles.component";
import { VehicleCreateComponent } from "./views/pages/used-vehicles/vehicle-create/vehicle-create.component";
import { AddWarrantyComponent } from "./views/pages/apps/e-commerce/vehicles/add-warranty/add-warranty";
import { VehiclesListComponent } from "./views/pages/apps/e-commerce/vehicles/vehicles-list/vehicles-list.component";
import { AddInsuranceAddonComponent } from "./views/pages/apps/e-commerce/vehicles/add-insurance-addon/add-insurance-addon";
import { IncentivesListComponent } from "./views/pages/incentives/incentives-list/incentives-list.component";
import { CustomerComplaintsListComponent } from "./views/pages/customer-complaints/customer-complaints-list/customer-complaints-list.component";
import { EMICalculatorComponent } from "./views/pages/admin/emi-calculator/emi-calculator.component";
import { LatestNewsComponent } from "./views/pages/admin/latest-news/latest-news.component";
import { TaskDelegationComponent } from "./views/pages/task-delegation/task-delegation.component";
import { EventsCampaignsComponent } from "./views/pages/admin/events-campaigns/events-campaigns.component";
import { PerformanceMappingComponent } from "./views/pages/performance-repoting/performance-mapping/performance-mapping.component";
import { AllotmentComponent } from "./views/pages/allotment/allotment.component";
import { VehicleExchangeComponent } from "./views/pages/vehicle-exchange/vehicle-exchange.component";
import { FinanceComponent } from "./views/pages/finance/finance.component";
import { TrainingComponent } from "./views/pages/training/training.component";

const routes: Routes = [
	{
		path: "auth",
		loadChildren: () =>
			import("../app/views/pages/auth/auth.module").then(
				(m) => m.AuthModule
			),
	},

	{
		path: "emi/:principle/:tenure/:interestRate/:processFee",
		component: EmicalculatorComponent,
	},

	{
		path: "",
		component: BaseComponent,
		canActivate: [AuthGuard],
		children: [
			{
				path: "dashboard",
				loadChildren: () =>
					import(
						"../app/views/pages/dashboard/dashboard.module"
					).then((m) => m.DashboardModule),
			},
			{
				path: "lead360",
				loadChildren: () =>
					import("../app/views/pages/lead-360/lead360.module").then(
						(m) => m.Lead360Module
					),
			},
			{
				path: "services",
				loadChildren: () =>
					import("../app/views/pages/services/services.module").then(
						(m) => m.ServicesModule
					),
			},
			{
				path: "adminPanel",
				loadChildren: () =>
					import(
						"../app/views/pages/services-admin/services-admin.module"
					).then((m) => m.ServicesAdminModule),
			},
			{
				path: "inventory",
				loadChildren: () =>
					import(
						"../app/views/pages/inventory/inventory.module"
					).then((m) => m.InventoryModule),
			},
			{
				path: "policyManagement",
				loadChildren: () =>
					import(
						"../app/views/pages/apps/e-commerce/e-commerce.module"
					).then((m) => m.ECommerceModule),
			},
			{
				path: "employeeManagement",
				loadChildren: () =>
					import(
						"../app/views/pages/apps/e-commerce/e-commerce.module"
					).then((m) => m.ECommerceModule),
			},
			{
				path: "vehicleManagement",
				loadChildren: () =>
					import(
						"../app/views/pages/apps/e-commerce/e-commerce.module"
					).then((m) => m.ECommerceModule),
			},
			{
				path: "adminPanel",
				loadChildren: () =>
					import(
						"../app/views/pages/apps/e-commerce/e-commerce.module"
					).then((m) => m.ECommerceModule),
			},
			{
				path: "user-management",
				loadChildren: () =>
					import(
						"../app/views/pages/user-management/user-management.module"
					).then((m) => m.UserManagementModule),
			},
			{
				path: "organizationManagement",
				loadChildren: () =>
					import(
						"../app/views/pages/apps/e-commerce/e-commerce.module"
					).then((m) => m.ECommerceModule),
			},
			{
				path: "ems",
				loadChildren: () =>
					import("./views/pages/enquiry/wizard.module").then(
						(m) => m.WizardModule
					),
			},
			{
				path: "insuranceCalculator",
				loadChildren: () =>
					import(
						"../app/views/pages/insurance-calculator/insurance-calculator.module"
					).then((m) => m.InsuranceCalculatorModule),
			},
			{
				path: "employeeManagement/employeeAllocation",
				component: EmployeeAllocationComponent,
			},
			{
				path: "employeeManagement/taskDelegation",
				component: TaskDelegationComponent,
			},
			{
				path: "myTasks/myTasksMenu",
				component: MyTaskComponent,
			},
			{
				path: "Performance/Performance",
				component: PerformanceRepotingComponent,
			},
			{
				path: "Performance/Performance/:id",
				component: PerformanceMappingComponent,
			},
			{
				path: "ems",
				loadChildren: () =>
					import("./views/pages/pre-enquiry/preenquiry.module").then(
						(m) => m.PreenquiryModule
					),
			},
			{
				path: "ems",
				loadChildren: () =>
					import("./views/pages/enquiry/wizard.module").then(
						(m) => m.WizardModule
					),
			},
			{
				path: "services/cceDashboard",
				loadChildren: () =>
					import("./views/pages/cce/cce.module").then(
						(m) => m.CCEModule
					),
			},
			{
				path: "eventManagement/evenManagement",
				component: EventCalenderComponent,
			},
			{
				path: "eventManagement/evenManagement/createEvent",
				component: CreateEventComponent,
			},
			{
				path: "eventManagement/evenManagement/:id",
				component: PreviewEventFormComponent,
			},
			{
				path: "menuManagement/menu",
				component: MenuComponent,
			},
			{
				path: "evaluator/evaluatorMenu",
				component: ManagerscreenComponent,
			},
			{
				path: "evaluator/evaluatorMenu/managerscreen",
				component: EvaluatorComponent,
			},
			{
				path: "admin/addVehicle",
				component: AddVehicleComponent,
			},
			{
				path: "admin/addAlert",
				component: AddAlertComponent,
			},
			{
				path: "administration/administration",
				component: PropertyDocsComponent,
			},
			{
				path: "administration/myTask",
				component: MyTasksComponent,
			},
			{
				path: "preBooking",
				loadChildren: () =>
					import(
						"../app/views/pages/prebookingscreens/prebooking.module"
					).then((m) => m.PrebookingModule),
			},
			{
				path: "booking",
				loadChildren: () =>
					import(
						"../app/views/pages/bookingscreens/booking.module"
					).then((m) => m.BookingModule),
			},
			{
				path: "invoice",
				loadChildren: () =>
					import("../app/views/pages/Invoice/invoice.module").then(
						(m) => m.InvoiceModule
					),
			},
			{
				path: "preDelivery",
				loadChildren: () =>
					import(
						"../app/views/pages/predelivery/predelivery.module"
					).then((m) => m.PredeliveryModule),
			},
			{
				path: "adminPanel/offers",
				loadChildren: () =>
					import("../app/views/pages/admin/offer/offer.module").then(
						(m) => m.OfferModule
					),
			},
			{
				path: "adminPanel/taskApprover",
				loadChildren: () =>
					import(
						"../app/views/pages/admin/tasks-approve/task-approve.module"
					).then((m) => m.TaxApproveModule),
			},
			{
				path: "adminPanel/Feedback",
				loadChildren: () =>
					import(
						"../app/views/pages/admin/feedback/feedback.module"
					).then((m) => m.FeedbackModule),
			},
			{
				path: "adminPanel/Taxrate",
				loadChildren: () =>
					import(
						"../app/views/pages/admin/tax-calculations/tax-calculations.module"
					).then((m) => m.TaxCalculationsModule),
			},
			{
				path: "delivery",
				loadChildren: () =>
					import("../app/views/pages/delivery/delivery.module").then(
						(m) => m.DeliveryModule
					),
			},
			{
				path: "insurance",
				loadChildren: () =>
					import(
						"../app/views/pages/insurance/insurance.module"
					).then((m) => m.InsuranceModule),
			},

			{
				path: "pending booking tracker/Booking Tracker Sales",
				component: PendingBookingTrackerComponent,
			},
			{
				path: "dropAnalysis/droppedLeads",
				component: DropAnalysisComponent,
			},
			{
				path: "adminPanel/B2CTransactions",
				component: B2cTransactionsComponent,
			},
			{
				path: "adminPanel/usedVehicles",
				component: UsedVehiclesComponent,
			},
			{
				path: "adminPanel/EMICalculator",
				component: EMICalculatorComponent,
			},
			{
				path: "adminPanel/LatestNews",
				component: LatestNewsComponent,
			},
			{
				path: "adminPanel/eventsCampaigns",
				component: EventsCampaignsComponent,
			},
			{
				path: "adminPanel/create-usedVehicle/:id",
				component: VehicleCreateComponent,
			},
			{
				path: "adminPanel/newVehicles",
				component: VehiclesListComponent,
			},
			{
				path: "adminPanel/warranty",
				component: AddWarrantyComponent,
			},
			{
				path: "adminPanel/insurance",
				component: AddInsuranceAddonComponent,
			},
			{
				path: "databank",
				component: DataBankComponent,
			},
			{
				path: "Incentives/Incentives",
				component: IncentivesListComponent,
			},
			{
				path: "customerCompliants/customerCompliants",
				component: CustomerComplaintsListComponent,
			},
			{
				path: "builder",
				loadChildren: () =>
					import(
						"../app/views/theme/content/builder/builder.module"
					).then((m) => m.BuilderModule),
			},
			{
				path: "testDriveMenu",
				loadChildren: () =>
					import(
						"../app/views/pages/test-drive/test-drive.module"
					).then((m) => m.TestDriveModule),
			},
			{
				path: "reports/booking",
				component: BookingReportsrtsComponent,
			},
			{
				path: "reports/enquiry",
				component: EnquiryReportsComponent,
			},
			{
				path: "reports/performance",
				component: PrebookingReportsComponent,
			},
			{
				path: "reports/incentive",
				component: IncentivesComponent,
			},
			{
				path: "territoryAllocation",
				component: TerritoryAllocationComponent,
			},
			{
				path: "territoryAllocation/urban",
				component: UrbanTerritoryAllocationComponent,
			},
			{
				path: "territoryAllocation/rural",
				component: RuralTerritoryAllocationComponent,
			},
			{
				path: "allotment/allotment",
				component: AllotmentComponent,
			},
			{
				path: "vehicleExchange/vehicleExchange",
				component: VehicleExchangeComponent,
			},
			{
				path: "financeMenu/finance",
				component: FinanceComponent,
			},
			{
				path: "training/training",
				component: TrainingComponent,
			},
			{
				path: "error/403",
				component: ErrorPageComponent,
				data: {
					type: "error-v6",
					code: 403,
					title: "403... Access forbidden",
					desc:
						"Looks like you don't have permission to access for requested page.<br> Please, contact administrator",
				},
			},
			{ path: "error/:type", component: ErrorPageComponent },
			{ path: "", redirectTo: "dashboard", pathMatch: "full" },
			{ path: "**", redirectTo: "dashboard", pathMatch: "full" },
		],
	},

	{ path: "**", redirectTo: "error/403", pathMatch: "full" },
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule],
})
export class AppRoutingModule {}
