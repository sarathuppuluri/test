export class CustomerCompliantsModel {

	id: number;
	complaintType: string;
	createdBy: string;
	customerId: number;
	customerName: string;
	customerRemarks: string;
	department: string;
	employee: string;
	employeeRemarks: string;
	role: string;
	statuscd: string;
	updatedBy: string;


	clear() {
		this.id = 0;
		this.complaintType = '';
		this.createdBy = '';
		this.customerId = 0;
		this.customerName = '';
		this.customerRemarks = '';
		this.department = '';
		this.employee = '';
		this.employeeRemarks = '';
		this.role = '';
		this.statuscd = '';
		this.updatedBy = '';
	}
}
