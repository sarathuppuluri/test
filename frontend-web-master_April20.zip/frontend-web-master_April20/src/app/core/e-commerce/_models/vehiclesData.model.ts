export const Brands = [
    {
        brand: 'Hyundai',
        Variant: [
            { model: 'Accent' },
            { model: 'Creta' },
            { model: 'Elantra' },
            { model: 'Elite i20' },
            { model: 'Eon' },
            { model: 'Grand i10' },
            { model: 'i10' },
            { model: 'i20' },
            { model: 'i20 Active' },
            { model: 'Neo Fluidic Elantra' },
            { model: 'New Santro 1.1' },
            { model: 'Santa Fe' },
            { model: 'Santro Xing' },
            { model: 'Sonata' },
            { model: 'Sonata Transform' },
            { model: 'Verna' },
            { model: 'Verna Transform' },
            { model: 'Xcent' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Maruti Suzuki',
        Variant: [
            { model: 'POPULAR' },
            { model: 'Baleno' },
            { model: 'Ciaz' },
            { model: 'Swift' },
            { model: 'Alto K10' },
            { model: 'Alto 800' },
            { model: 'Celerio' },
            { model: '800' },
            { model: 'A-Star' },
            { model: 'Alto' },
            { model: 'Celerio X' },
            { model: 'Eeco' },
            { model: 'Estilo' },
            { model: 'Grand Vitara' },
            { model: 'Gypsy' },
            { model: 'Ignis' },
            { model: 'Kizashi' },
            { model: 'New Swift DZire' },
            { model: 'Omni' },
            { model: 'Ritz' },
            { model: 'S-Cross' },
            { model: 'Swift Dzire' },
            { model: 'SX4' },
            { model: 'Versa' },
            { model: 'Vitara Brezza' },
            { model: 'Wagon R' },
            { model: 'Wagon R 1.0' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Tata',
        Variant: [
            { model: 'Tiago' },
            { model: 'Hexa' },
            { model: 'Tigor' },
            { model: 'Nano' },
            { model: 'Zest' },
            { model: 'Sumo Gold' },
            { model: 'Aria' },
            { model: 'Bolt' },
            { model: 'Harrier' },
            { model: 'Indica eV2' },
            { model: 'Indica V2' },
            { model: 'Indigo eCS' },
            { model: 'Nano GenX' },
            { model: 'Nexon' },
            { model: 'Safari' },
            { model: 'Safari Storme' },
            { model: 'Vista Tech' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Honda',
        Variant: [
            { model: 'Amaze' },
            { model: 'City' },
            { model: 'Brio' },
            { model: 'Jazz' },
            { model: 'Civic' },
            { model: 'Mobilio' },
            { model: 'Accord' },
            { model: 'BR-V' },
            { model: 'CR-V' },
            { model: 'WR-V' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Ford',
        Variant: [
            { model: 'EcoSport' },
            { model: 'Endeavour' },
            { model: 'Fiesta' },
            { model: 'Fiesta Classic' },
            { model: 'Figo' },
            { model: 'Figo Aspire' },
            { model: 'Freestyle' },
            { model: 'Ikon' },
            { model: 'Mondeo' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Renault',
        Variant: [
            { model: 'Captur' },
            { model: 'Duster' },
            { model: 'Fluence' },
            { model: 'Koleos' },
            { model: 'Kwid' },
            { model: 'Lodgy' },
            { model: 'Scala' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Mahindra',
        Variant: [
            { model: 'XUV500' },
            { model: 'KUV100' },
            { model: 'TUV300' },
            { model: 'Scorpio' },
            { model: 'Bolero' },
            { model: 'Xylo' },
            { model: 'e2o' },
            { model: 'Marazzo' },
            { model: 'Marshal' },
            { model: 'NuvoSport' },
            { model: 'REVAi' },
            { model: 'Scorpio Getaway' },
            { model: 'Thar' },
            { model: 'Verito' },
            { model: 'Verito Vibe CS' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Toyota',
        Variant: [
            { model: 'Etios Liva' },
            { model: 'Corolla Altis' },
            { model: 'Etios' },
            { model: 'Yaris' },
            { model: 'Camry' },
            { model: 'Corolla' },
            { model: 'Fortuner' },
            { model: 'Innova' },
            { model: 'Innova Crysta' },
            { model: 'Land Cruiser' },
            { model: 'Land Cruiser Prado' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Chevrolet',
        Variant: [
            { model: 'Sail' },
            { model: 'Spark' },
            { model: 'Tavera' },
            { model: 'Sail Hatchback' },
            { model: 'Trailblazer' },
            { model: 'Aveo' },
            { model: 'ALL' },
            { model: 'Beat' },
            { model: 'Captiva' },
            { model: 'Cruze' },
            { model: 'Enjoy' },
            { model: 'Optra Magnum' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Datsun',
        Variant: [
            { model: 'GO' },
            { model: 'Go Plus' },
            { model: 'Redi-GO' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Fiat',
        Variant: [
            { model: 'Abarth 595' },
            { model: 'Abarth Punto' },
            { model: 'Avventura' },
            { model: 'Linea' },
            { model: 'Linea Classic' },
            { model: 'Punto Evo' },
            { model: 'Punto Pure' },
            { model: 'Siena' },
            { model: 'Uno' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Skoda',
        Variant: [
            { model: 'Fabia' },
            { model: 'Octavia' },
            { model: 'Rapid' },
            { model: 'Rapid new' },
            { model: 'Superb' },
            { model: 'Yeti' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Jeep',
        Variant: [
            { model: 'Compass' },
            { model: 'Jeep' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Kia',
        Variant: [
            { model: 'Kia Seltos' },
            { model: 'Kia Carnival' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Nissan',
        Variant: [
            { model: 'Micra' },
            { model: 'Micra Active' },
            { model: 'Sunny' },
            { model: 'Terrano' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Volkswagen',
        Variant: [
            { model: '1600' },
            { model: 'Ameo' },
            { model: 'Beetle' },
            { model: 'Cross Polo' },
            { model: 'Jetta' },
            { model: 'Passat' },
            { model: 'Polo' },
            { model: 'Vento' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'MG Motors',
        Variant: [
            { model: 'Hector' },
            { model: 'Other' }
        ]
    },
    {
        brand: 'Other',
        Variant: [
            { model: 'Other' }
        ]
    }
];
