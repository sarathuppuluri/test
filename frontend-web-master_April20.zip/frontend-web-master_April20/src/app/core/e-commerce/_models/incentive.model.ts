export class IncentivesModel {

	branch_id: number;
	id: number;
	incentive_amt: number;
	incentive_type: string;
	incentive_unit: string;
	org_id: number;
	rule_maxval: number;
	rule_minval: number;
	segment: string;
	team: string;


	clear() {
		this.branch_id = 0;
		this.id = 0;
		this.incentive_amt = 0;
		this.incentive_type = '';
		this.incentive_unit = '';
		this.org_id = 0;
		this.rule_maxval = 0;
		this.rule_minval = 0;
		this.segment = '';
		this.team = '';

	}
}
