export interface Task {
	taskName?;
	taskCreatedTime?;
	assigneeId?;
	leadId?;
	taskId?;
	activityId?;
	leadDto;
	universalId;
}
