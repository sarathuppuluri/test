export class BranchModel {

	adress: 0;
	branchId: string;
	orgId: string;
	branchType: string;
	cinNumber: string;
	email: string;
	imageUrl: string;
	mobile: string;
	name: string;
	phone: string;
	status: string;
	storeId: string;
	website: string;
	addressInfo: AddressInfo;


	clear() {
		this.adress = 0;
		this.branchId = '0';
		this.branchType = 'Sales';
		this.cinNumber = '';
		this.email = '';
		this.imageUrl = '';
		this.mobile = '';
		this.name = '';
		this.storeId = '';
		this.phone = '';
		this.status = 'Active';
		this.website = '';
	}
}

export class AddressInfo {
	addressType: string;
	city: string;
	country: string;
	district: string;
	houseNo: string;
	isRural: number;
	isUrban: number;
	latitude: string;
	longitude: string;
	pincode: string;
	preferredBillingAddress: string;
	state: string;
	street: string;
	village: string;

	clear() {
		this.addressType = '';
		this.city = '';
		this.country = '';
		this.district = '';
		this.houseNo = '';
		this.isRural = 0;
		this.isUrban = 1;
		this.latitude = '';
		this.longitude = '';
		this.pincode = '';
		this.preferredBillingAddress = '';
		this.state = '';
		this.street = '';
		this.village = '';
	}
}

export class PhoneDirectory {
	branch_id: number;
	contact_details: [];
	id: number;
	organization_id: number;

	clear() {
		this.branch_id = 0;
		this.contact_details = [];
		this.id = 0;
		this.organization_id = 0;
	}
}
