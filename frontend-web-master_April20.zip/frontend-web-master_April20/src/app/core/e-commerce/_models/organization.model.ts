import { AddressInfo } from './branch.model';

export class OrganizationModel {

	brand: string;
	cin: string;
	domainName: string;
	email: string;
	logoBigUrl: string;
	logoSmallUrl: string;
	mobile: string;
	name: string;
	orgId: string;
	phone: string;
	status: string;
	url: string;
	website: string;
	addressInfo: AddressInfo;


	clear() {
		this.brand = '';
		this.cin = '';
		this.domainName = '';
		this.email = '';
		this.logoBigUrl = '';
		this.logoSmallUrl = '';
		this.mobile = '';
		this.name = '';
		this.orgId = '0';
		this.phone = '';
		this.status = '';
		this.url = '';
		this.website = '';
	}
}
