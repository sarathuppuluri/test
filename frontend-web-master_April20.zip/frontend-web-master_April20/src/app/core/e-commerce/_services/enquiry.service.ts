import { Injectable } from "@angular/core";
import { HttpUtilsService, QueryParamsModel } from "../../_base/crud";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable, of } from "rxjs";
import { environment } from "../../../../environments/environment.base";

const API_ENQUIRY_URL = `${environment.preEnquiryDomain}/dev/enquiry`;
const API_PINCODE_URL = `${environment.API_PINCODE_URL}`;
const API_SCORECARD = `${environment.preEnquiryDomain}/dev/enquiry/scorecard`;
// PreBooking APIs
const API_ONROADPRICE_URL = `${environment.vehicleInfoService}/api/vehicle_on_road_prices`;
const API_ALLOFFERS_URL = `${environment.ops}/api/allofferdetail`;
const API_ALLACCESSORIES_URL = `${environment.inventory}/inventory/accessories`;

@Injectable()
export class EnquiryService {
	constructor(
		private http: HttpClient,
		private httpUtils: HttpUtilsService
	) {}

	getCustomer(id): Observable<any> {
		let headers = new HttpHeaders();
		headers = headers.append("showroomid", "12");
		headers = headers.append("orgid", "1");
		return this.http.get<any>(
			API_ENQUIRY_URL + `/personalinfo/customer/id/${id}`,
			{ headers }
		);
	}

	updateCustomer(id, data): Observable<any> {
		let headers = new HttpHeaders();
		headers = headers.append("showroomid", "12");
		headers = headers.append("orgid", "1");
		data.customerId = `${id}`;
		return this.http.put<any>(
			API_ENQUIRY_URL + `/personalinfo/customer/id/${id}`,
			data,
			{ headers }
		);
	}

	// Upload Documents
	createCustomerDoc(data): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/documents`,
			data
		);
	}

	// Delete Documents
	deleteDocument(keyName): Observable<any> {
		return this.http.delete<any>(
			`${environment.sales}/documents?key=${keyName}`
		);
	}

	// location using pincode
	getLocationUsingPincode(pincode): Observable<any> {
		return this.http.get<any>(API_PINCODE_URL + `/${pincode}`);
	}

	sendScoreCardDetails(data): Observable<any> {
		return this.http.post<any>(API_SCORECARD, data);
	}

	updateScoreCardDetails(data): Observable<any> {
		return this.http.put<any>(API_SCORECARD, data);
	}

	// Documents Upload response Upload
	documentsUpload(data): Observable<any> {
		return this.http.post<any>(environment.sales, data);
	}

	// For Getting LeadBy UniversalID
	getLeadByUniversalID(universalId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/enquiry/lead/id/${universalId}`
		);
	}

	// For Updating Lead data
	updateLeadEnquiry(body): Observable<any> {
		return this.http.put<any>(`${environment.sales}/enquiry/lead`, body);
	}

	// For Posting Lead Details
	sendLeadEnquiryDetails(body): Observable<any> {
		return this.http.post<any>(`${environment.sales}/enquiry/lead`, body);
	}

	/**
	 * PreBooking APIs
	 */
	// Get OnRoad Price Details by VarientId and OrgId
	getOnRoadPriceDetails(varientId, orgId): Observable<any> {
		return this.http.get<any>(
			`${API_ONROADPRICE_URL}/${varientId}/${orgId}`
		);
	}

	// Get Offers By vehicleId, VarientId and OrgId
	getAllOffers(vehicleId, varientId, orgId): Observable<any> {
		let headers = new HttpHeaders();
		headers = headers.append("orgId", orgId);
		return this.http.get<any>(
			`${API_ALLOFFERS_URL}?varientId=${varientId}&vehicleId=${vehicleId}`,
			{ headers }
		);
	}

	// Get All Accessories By OrgId and vehicleId
	getAllAccessories(
		vehicleId,
		orgId,
		queryParams: QueryParamsModel
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		let headers = new HttpHeaders();
		headers = headers.append("orgId", orgId);
		return this.http.get<any>(
			`${API_ALLACCESSORIES_URL}/${vehicleId}?pageNo=${httpParams.get(
				"startindex"
			)}&pageSize=${httpParams.get("endindex")}`,
			{ headers }
		);
	}

	// PreBooking Payment API
	sendPaymentDetails(body): Observable<any> {
		return this.http.post<any>(`${environment.sales}/payment`, body);
	}

	// Get PreBooking Payment API
	getPaymentDetails(leadId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/payment?leadId=${leadId}`
		);
	}

	// Vehicle Allotment API
	sendVehicleAllocation(body): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/allotment`,
			body
		);
	}

	// Get Vehicle Allocation API
	getVehicleAllocation(vehicleAllocateId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/allotment/lead/${vehicleAllocateId}`
		);
	}

	// Invoice Details API
	sendInvoiceDetails(body): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/invoice`,
			body
		);
	}

	// Get Invoice Details API
	getInvoiceDetails(invoiceId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/invoice/lead/${invoiceId}`
		);
	}

	// Delivery Details API
	sendDeliveryDetails(body): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/delivery`,
			body
		);
	}

	// Get Delivery Details API
	getDeliveryDetails(deliveryId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/delivery/lead/${deliveryId}`
		);
	}

	// Delivery Details Check List API
	sendDeliveryDetailsCheckList(body): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/delivery-checklist`,
			body
		);
	}

	// Get Delivery Details Check List API
	getDeliveryDetailsCheckList(deliveryId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/delivery-checklist/lead/${deliveryId}`
		);
	}

	// On Road Price Details API
	sendOnRoadPriceDetails(body): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/on-road-price`,
			body
		);
	}

	// Get On Road Price Details API
	getOnRoadPricePosted(onRoadPriceId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/on-road-price/lead/${onRoadPriceId}`
		);
	}

	// Get Booking Amount Received(Booking Screen)
	getBookingAmount(bookingAmountId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/booking-amount/lead/${bookingAmountId}`
		);
	}

	// Post Booking Amount Received(Booking Screen)
	sendBookingAmount(body): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/booking-amount`,
			body
		);
	}

	// Check if the user Created a Lead before Proceeding with Evalaution
	checkLeadAvailability(rcNo): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/rc-lead/on-road-price-lead/${rcNo}`
		);
	}

	// Inventory Vehicle Check Allocation
	getInventoryDetails(leadId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/allotment/allotmentflowthroughleadid?leadId=${leadId}`
		);
	}

	// Get Pending Booking Tracker List
	getBookingTracker(empId, queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.sales
			}/booking/tracker?empId=${empId}&limit=${httpParams.get(
				"endindex"
			)}&offset=${httpParams.get("startindex")}`
		);
	}

	// Post Drop Details of Leads
	sendDropDetails(body): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/lead-drop`,
			body
		);
	}

	// Get All Drop Details List
	getLeadDropDetails(queryParams: any): Observable<any> {
		const httpParams = new HttpParams()
			.set("approver", queryParams.approver)
			.set("branch", queryParams.branch)
			.set("droppedBy", "")
			.set("id", queryParams.id)
			.set("orgId", queryParams.orgId);
		return this.http.get<any>(`${environment.sales}/lead-drop/details`, {
			params: httpParams,
		});
	}

	// Get All Drop Details By BranchID and OrgID
	getLeadDropDetailsBranchOrg(
		branchId,
		orgId,
		empName,
		queryParams: QueryParamsModel
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.sales
			}/lead-drop/details?branch=${branchId}&limit=${httpParams.get(
				"endindex"
			)}&loginUser=${empName}&offset=${httpParams.get(
				"startindex"
			)}&orgId=${orgId}`
		);
	}

	/**
	 * Unique ID Number Generator at each stage
	 */
	sendOrgBranchStageRef(body): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/lead-customer-reference`, // TODO : No mapping found at backend.
			body
		);
	}

	/**
	 * Send Data from Sales to Services.
	 */
	sendDatafromSalestoServices(body): Observable<any> {
		return this.http.post<any>(
			`${environment.salesToServices}/testing/pushdatatoservice`,
			body
		);
	}
}
