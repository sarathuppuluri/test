import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { HttpUtilsService } from "../../../core/_base/crud";
import { environment } from "../../../../environments/environment.base";

const API_DELETE_FILE = environment.sales;

@Injectable({
	providedIn: "root",
})
export class BookingTestDriveService {
	loginEmployee: any = JSON.parse(localStorage.getItem("loginEmployee"));
	role = this.loginEmployee.hrmsRole;
	branchId = this.loginEmployee.branchId;
	orgId = this.loginEmployee.orgId;
	vehicleApiGatewayUrl = environment.sales;

	constructor(public http: HttpClient, private httpUtils: HttpUtilsService) {}

	getLookups() {
		const type = "TESTDRIVE";
		const url = `${environment.inventory}/demoVehicle/vehicles?branchId=${this.branchId}&orgId=${this.orgId}&type=${type}`;
		return this.http.get<any>(url);
	}

	uploadFiles(requestBody) {
		const url = `${environment.sales}/documents`;
		return this.http.post<any>(url, requestBody);
	}

	submitAppointmentRequest(requestBody) {
		const url = `${environment.ops}/testdrive/appointment`;
		return this.http.post(url, requestBody);
	}

	checkAllotment(date, vehicleId): Observable<any> {
		const url = `${environment.inventory}/allotment/vehicle/allotments?allotmentDate=${date}&id=${vehicleId}`;
		return this.http.get(url);
	}

	appointmentsHistory(limit, offset): Observable<any> {
		const url = `${environment.ops}/testdrive/history?branch=${this.branchId}&limit=${limit}&offset=${offset}&orgId=${this.orgId}`;
		return this.http.get(url);
	}

	getAppointmentRequest(apointmentId: string): Observable<any> {
		const url = `${environment.ops}/testdrive/history?branch=${this.branchId}&filterType=TESTDRIVE&filterVal=${apointmentId}&orgId=${this.orgId}`;
		return this.http.get(url);
	}

	searchCustomerId(customerId): Observable<any> {
		const url = `${environment.ops}/testdrive/history?branch=${this.branchId}&filterType=CUST&filterVal=${customerId}&orgId=${this.orgId}`;
		return this.http.get(url);
	}

	searchDSE(dseId): Observable<any> {
		const url = `${environment.ops}/testdrive/history?branch=${this.branchId}&filterType=DSE&filterVal=${dseId}&orgId=${this.orgId}`;
		return this.http.get(url);
	}

	getEmployees(roleName) {
		const url = `${environment.roleManagement}/user/role/name/`;
		return this.http.get<any>(`${url}${roleName}`);
	}

	updateAppointmentRequest(requestBody) {
		const url = `${environment.ops}/testdrive/appointment`;
		return this.http.put(url, requestBody);
	}

	getAppointmentHistoryWithFilters(requestParams) {
		let url = `${environment.ops}/testdrive/history?branch=${requestParams.branchId}&orgId=${requestParams.orgId}&limit=${requestParams.limit}&offset=${requestParams.offset}`;
		url =
			requestParams.filterType && requestParams.filterTypeValue
				? `${url}&filterType=${requestParams.filterType}&filterVal=${requestParams.filterTypeValue}`
				: url;
		url = requestParams.status
			? `${url}&status=${requestParams.status}`
			: url;
		url = requestParams.source
			? `${url}&source=${requestParams.source}`
			: url;
		return this.http.get<any>(url);
	}

	updateTask(requestBody) {
		const url = `${environment.sales}/dms/updateTestDriveTask`;
		return this.http.post(url, requestBody);
	}

	// Delete Documents
	deleteDocument(keyName): Observable<any> {
		return this.http.delete<any>(`${API_DELETE_FILE}?key=${keyName}`);
	}
}
