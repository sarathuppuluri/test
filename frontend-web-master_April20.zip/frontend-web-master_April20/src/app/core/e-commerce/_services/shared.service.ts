import { Injectable } from '@angular/core';
import { HttpUtilsService, QueryParamsModel } from '../../_base/crud';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../../../environments/environment.base';


const API_VECHILE_DETAILIS_URL = `${environment.vehicleInfoService}/api/vehicle_details`;
const API_CUSTOMER_TYPE_DROPDOWN = `${environment.sales}/master-data/customertype`;

@Injectable()
export class SharedService {
  pending2;
  pending1;
  employeeDetailsArray: any = [];

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) {
  }

  vechileDetailsInfo = [];
  vechileDetailsChange: Subject<any> = new Subject<any>();

  customerTypeInfo = [];
  // categorizing based on type
  customerTypeDropDownOne = [];
  customerTypeDropDownTwo = [];
  customerTypeDropDownThree = [];

  eventAll = [];
  holidayList: any;
  tempStore: any = [];
  holidayAll: any = [];

  tempEvents: Subject<any> = new Subject<any>();
  color;
  pending;

  // Get all Vehicle details
  getVechilesData() {
    return this.vechileDetailsInfo;
  }

  fetchVechileDetails() {
    this.http.get<any>(API_VECHILE_DETAILIS_URL + `?organizationId=${1}`).subscribe(res => {
      this.vechileDetailsInfo = res;
      this.vechileDetailsChange.next(this.vechileDetailsInfo);
    });
  }


  fetchCustomerTypeDropDown() {
    this.http.get<any>(API_CUSTOMER_TYPE_DROPDOWN).subscribe(res => {
      this.customerTypeInfo = res;
      this.customerTypeDropDownOne = this.customerTypeInfo;
      this.customerTypeDropDownThree = this.customerTypeDropDownOne.splice(3, 1);
      this.customerTypeDropDownTwo = this.customerTypeDropDownOne.splice(4, 1);
    });
  }
}
