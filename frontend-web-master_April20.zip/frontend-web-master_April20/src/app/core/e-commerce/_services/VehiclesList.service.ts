// Angular
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../_base/crud';
// Models
import { BranchModel } from '../_models/branch.model';
import { environment } from '../../../../environments/environment.base';
const API_VEHICLES_URL = '/api/vehicle_details/';

@Injectable()
export class VehicleListService {
	constructor(
		private http: HttpClient,
		private httpUtils: HttpUtilsService
	) {}

	// CREATE =>  POST: ad a new customer to the server
	createVehicle(data): Observable<any> {
		// Note: Add headers if needed (tokens/bearer)
		const url =
			environment.vehicleInfoService + API_VEHICLES_URL + "/create";
		return this.http.post<BranchModel>(url, data);
	}

	updateBranch(data): Observable<any> {
		// Note: Add headers if needed (tokens/bearer)
		const url =
			environment.vehicleInfoService + API_VEHICLES_URL + "/update";
		return this.http.post<BranchModel>(url, data);
	}

	deleteBranch(id): Observable<any> {
		return this.http.delete<any>(
			environment.vehicleInfoService +
				API_VEHICLES_URL +
				"/delete" +
				`/${id}`
		);
	}

	// READ
	getAllVehicles(): Observable<BranchModel[]> {
		const url = API_VEHICLES_URL + "/update";
		return this.http.get<BranchModel[]>(API_VEHICLES_URL);
	}

	getVehicleById(vehicleId: number): Observable<BranchModel> {
		return this.http.get<BranchModel>(API_VEHICLES_URL + `/${vehicleId}`);
	}

	getAllVehiclesData(orgId): Observable<any> {
		const url = environment.vehicleInfoService + API_VEHICLES_URL;
		return this.http.get<any>(url + "?organizationId=" + orgId);
	}

	getVehiclesData(id, orgId): Observable<any> {
		const url =
			environment.vehicleInfoService +
			"/api/vehicle_details/" +
			id +
			"/" +
			orgId;
		return this.http.get<any>(url);
	}

	// Method from server should return QueryResultsModel(items: any[], totalsCount: number)
	// items => filtered/sorted result
	// Server should return filtered/sorted result
	findVehicles(queryParams: QueryParamsModel): Observable<QueryResultsModel> {
		// Note: Add headers if needed (tokens/bearer)
		const httpHeaders = this.httpUtils.getHTTPHeaders();
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);

		const url = API_VEHICLES_URL + "/find";
		return this.http.get<QueryResultsModel>(url, {
			headers: httpHeaders,
			params: httpParams,
		});
	}

	// UPDATE => PUT: update the customer on the server
	updateVehicle(branch: BranchModel): Observable<any> {
		const httpHeader = this.httpUtils.getHTTPHeaders();
		return this.http.put(API_VEHICLES_URL, branch, { headers: httpHeader });
	}

	// UPDATE Status
	updateStatusForVehicle(
		branchs: BranchModel[],
		status: number
	): Observable<any> {
		const httpHeaders = this.httpUtils.getHTTPHeaders();
		const body = {
			vehiclesForUpdate: branchs,
			newStatus: status,
		};
		const url = API_VEHICLES_URL + "/updateStatus";
		return this.http.put(url, body, { headers: httpHeaders });
	}

	// DELETE => delete the customer from the server
	deleteVehicle(branchId: number): Observable<BranchModel> {
		const url = `${API_VEHICLES_URL}/${branchId}`;
		return this.http.delete<BranchModel>(url);
	}

	deleteVehicles(ids: number[] = []): Observable<any> {
		const url = API_VEHICLES_URL + "/deleteVehicles";
		const httpHeaders = this.httpUtils.getHTTPHeaders();
		const body = { vehicleIdsForDelete: ids };
		return this.http.put<QueryResultsModel>(url, body, {
			headers: httpHeaders,
		});
	}

	/**
	 * Accessories APIs   --- Starts Here ---
	 */
	// GETALLACCESSORIES =>  GET: To get all Accessories by modelId
	getAllAccessoriesByVehicle(id, pageNo, pageSize, orgId): Observable<any> {
		let headers = new HttpHeaders();
		headers = headers.append("orgId", orgId);
		const url = `${environment.inventory}/inventory/accessories/${id}?pageNo=${pageNo}&pageSize=${pageSize}`;
		return this.http.get<any>(url, { headers });
	}

	// CREATE =>  POST: add a new Accessory
	addAccessories(requestBody, type) {
		if (type === "created") {
			const url = `${environment.inventory}/inventory/accessories`;
			return this.http.post(url, requestBody);
		} else if (type === "updated") {
			// UPDATE =>  PUT: update the Accessory
			const url = `${environment.inventory}/inventory/accessories/update`;
			const httpHeaders = this.httpUtils.getHTTPHeaders();
			return this.http.put<QueryResultsModel>(url, requestBody, {
				headers: httpHeaders,
			});
		}
	}

	// DELETE =>  DELETE: delete the Accessory
	deleteAccessory(id): Observable<any> {
		return this.http.delete<any>(
			`${environment.inventory}/inventory/accessories/delete/${id}`
		);
	}

	// UPLOAD =>  POST: ad a new Accessory
	uploadAccessory(data): Observable<any> {
		return this.http.post<any>(
			`${environment.inventory}/uploaddocument`,
			data
		);
	}

	// CREATE KIT=>  POST: add a new Kit
	saveKit(requestBody, type) {
		if (type === "created") {
			const url = `${environment.inventory}/inventory/accessoriesMapping/create`;
			return this.http.post(url, requestBody);
		} else if (type === "updated") {
			// UPDATE =>  PUT: update the kit
			const url = `${environment.inventory}/inventory/accessoriesMapping/update`;

			const httpHeaders = this.httpUtils.getHTTPHeaders();
			return this.http.put<QueryResultsModel>(url, requestBody, {
				headers: httpHeaders,
			});
		}
	}

	// DELETE =>  DELETE: delete the kit
	deleteKit(id): Observable<any> {
		return this.http.delete<any>(
			`${environment.inventory}/inventory/accessoriesMapping/delete?accessoryMappingID=${id}`
		);
	}

	saveVehicleVarients(obj): Observable<any> {
		return this.http.post<any>(
			`${environment.vehicleInfoService}/api/variants/saveVehicleVariant`,
			obj
		);
	}

	updateVarients(obj): Observable<any> {
		return this.http.post<any>(
			`${environment.vehicleInfoService}/api/variants/updateVehicleVariant`,
			obj
		);
	}

	deleteVarient(id: number): Observable<any> {
		return this.http.delete<any>(
			`${environment.vehicleInfoService}/api/variants/delete/` + id
		);
	}

	imageUpload(type, formData): Observable<any> {
		return this.http.post<any>(
			`${environment.vehicleInfoService}/api/vehicle_details/upload?uploadType=` +
				type,
			formData
		);
	}

	getOnRoadPrice(varId, orgId) {
		const url =
			`${environment.vehicleInfoService}/api/vehicle_on_road_prices/` +
			varId +
			"/" +
			orgId;
		return this.http.get<any>(url);
	}

	saveOnRoadPrice(obj): Observable<any> {
		return this.http.post<any>(
			`${environment.vehicleInfoService}/api/vehicle_on_road_prices/onRoadPrice`,
			obj
		);
	}

	updateOnRoadPrice(obj): Observable<any> {
		return this.http.put(
			`${environment.vehicleInfoService}/api/vehicle_on_road_prices/onRoadPrice`,
			obj
		);
	}

	saveWarranty(obj): Observable<any> {
		return this.http.post<any>(
			`${environment.vehicleInfoService}/vehecle/extendedWarranty`,
			obj
		);
	}

	getAllWarranty(orgId, queryParams: QueryParamsModel): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.vehicleInfoService
			}/vehecle/extendedWarranty?orgId=${orgId}&offset=${httpParams.get(
				"startindex"
			)}&limit=${httpParams.get("endindex")}`
		);
	}

	warrantyDelete(id: number): Observable<any> {
		return this.http.delete<any>(
			`${environment.vehicleInfoService}/vehecle/extendedWarranty/` + id
		);
	}

	updateWarrant(obj): Observable<any> {
		return this.http.put<any>(
			`${environment.vehicleInfoService}/vehecle/extendedWarranty`,
			obj
		);
	}

	getAllInsuranceAddOns(
		orgId,
		queryParams: QueryParamsModel
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.vehicleInfoService
			}/vehicle/insuranceAddOn?orgId=${orgId}&offset=${httpParams.get(
				"startindex"
			)}&limit=${httpParams.get("endindex")}`
		);
	}

	saveInsurance(obj): Observable<any> {
		return this.http.post<any>(
			`${environment.vehicleInfoService}/vehicle/insuranceAddOn`,
			obj
		);
	}

	insuranceDelete(id: number): Observable<any> {
		return this.http.delete<any>(
			`${environment.vehicleInfoService}/vehicle/insuranceAddOn/` + id
		);
	}

	updateInsurance(obj): Observable<any> {
		return this.http.post<any>(
			`${environment.vehicleInfoService}/vehicle/insuranceAddOn`,
			obj
		);
	}

	getAllInsuranceDetails(
		orgId,
		queryParams: QueryParamsModel
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${
				environment.vehicleInfoService
			}/vehicle/insuranceDetails?orgId=${orgId}&offset=${httpParams.get(
				"startindex"
			)}&limit=${httpParams.get("endindex")}`
		);
	}

	saveInsuranceDetail(obj): Observable<any> {
		return this.http.post<any>(
			`${environment.vehicleInfoService}/vehicle/insuranceDetails`,
			obj
		);
	}

	updateInsuranceDetail(obj): Observable<any> {
		return this.http.post<any>(
			`${environment.vehicleInfoService}/vehicle/insuranceDetails`,
			obj
		);
	}

	insuranceDetailDelete(id: number): Observable<any> {
		return this.http.delete<any>(
			`${environment.vehicleInfoService}/vehicle/insuranceDetails/` + id
		);
	}

	getInsuranceMapping(id: number): Observable<any> {
		return this.http.get<any>(
			`${environment.vehicleInfoService}/vehicle/insuranceMapping?insurence_id=` +
				id
		);
	}

	saveInsuranceMappings(obj): Observable<any> {
		return this.http.post<any>(
			`${environment.vehicleInfoService}/vehicle/insuranceMapping`,
			obj
		);
	}

	updateInsuranceMappings(obj): Observable<any> {
		return this.http.put<any>(
			`${environment.vehicleInfoService}/vehicle/insuranceMapping`,
			obj
		);
	}

	deleteInsuranceMapping(id: number): Observable<any> {
		return this.http.delete<any>(
			`${environment.vehicleInfoService}/vehicle/insuranceMapping/` + id
		);
	}

	/**
	 * Demo Vehicles APIs --- Start Here ---
	 */
	// DEMOVEHICLES- get all
	getAllDemoVehicles(branchId, orgId, limit, offset): Observable<any> {
		let headers = new HttpHeaders();
		headers = headers.append("orgId", orgId);
		const url = `${environment.inventory}/demoVehicle/vehicles?branchId=${branchId}&orgId=${orgId}&limit=${limit}&offSet=${offset}`;
		return this.http.get<any>(url);
	}

	// CREATE/UPDATE DEMOVEHICLES =>  POST/PUT:
	addDemoVehicle(requestBody, type) {
		if (type === "created") {
			const url = `${environment.inventory}/demoVehicle/create`;
			return this.http.post(url, requestBody);
		} else if (type === "updated") {
			const url = `${environment.inventory}/demoVehicle/update`;
			const httpHeaders = this.httpUtils.getHTTPHeaders();
			return this.http.put<QueryResultsModel>(url, requestBody, {
				headers: httpHeaders,
			});
		}
	}

	// UPLOAD DEMOVEHICLES DOCs
	uploadDemoVehicleDocs(data, docType): Observable<any> {
		return this.http.post<any>(
			`${environment.vehicleInfoService}/api/vehicle_details/upload?uploadType=${docType}`,
			data
		);
	}

	// DELETE =>  DEMOVEHICLES
	deleteDemoVehicle(id): Observable<any> {
		return this.http.delete<any>(
			`${environment.inventory}/demoVehicle/delete/${id}`
		);
	}
}
