import { Injectable } from '@angular/core';
import { HttpUtilsService, QueryParamsModel } from '../../_base/crud';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment.base';

@Injectable()
export class InsuranceCalculatorService {
	constructor(private http: HttpClient) { }

	getVehicles(orgId): Observable<any> {
		return this.http.get(
			`${environment.vehicleInfoService}/api/vehicle_details?organizationId=` +
			orgId
		);
	}

	getInsuranceDetails(data) {
		return this.http.post(
			`${environment.inventory}/dms/insurance/details`,
			data
		);
	}

	getonRoadPrice(varientId, orgId): Observable<any> {
		return this.http.get(
			`${environment.vehicleInfoService}/api/vehicle_on_road_prices/` +
			varientId +
			'/' +
			orgId
		);
	}
}
