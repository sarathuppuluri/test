import { Injectable } from '@angular/core';
import { HttpUtilsService, QueryParamsModel } from '../../_base/crud';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment.base';

@Injectable()
export class InventoryService {
	constructor(private http: HttpClient) { }

	get(): Observable<any> {
		return this.http.get(`${environment.inventory}/dms/inventory/listall`);
	}

	getById(id): Observable<any> {
		return this.http.get(
			`${environment.inventory}/dms/inventory/list?vehicleId=` + id
		);
	}
	save(data) {
		return this.http.post(
			`${environment.inventory}/dms/inventory/create`,
			data
		);
	}

	update(data) {
		return this.http.put(
			`${environment.inventory}/dms/inventory/update`,
			data
		);
	}

	delete(id) {
		return this.http.delete(
			`${environment.inventory}/dms/inventory/delete?vehicleId=` + id
		);
	}

	getVehicles(orgId): Observable<any> {
		return this.http.get(
			`${environment.vehicleInfoService}/api/vehicle_details?organizationId=` +
			orgId
		);
	}
	search(searchFormat): Observable<any> {
		return this.http.get(
			`${environment.inventory}/dms/inventory/search?` + searchFormat
		);
	}
}
