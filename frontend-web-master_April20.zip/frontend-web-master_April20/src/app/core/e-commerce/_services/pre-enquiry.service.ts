import { Injectable } from '@angular/core';
import { HttpUtilsService, QueryParamsModel } from '../../_base/crud';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment.base';


const API_SEARCH_URL = '/dev/preenquiry/customer';
const API_LEADS_URL = '/dev/preenquiry/leads';
const API_DSE_URL = '/dev/preenquiry/allocatedse';
const API_DELETE_URL = '/dev/preenquiry/customer';


// New API GateWay URL for Visitors
const API_NEW_ALLOCATE_URL = 'dms/createEnquiry';

const API_BULK_UPLOAD_URL = 'uploadFile';
const API_BULK_ENQUIRY_URL = 'enquiry-bulk-upload/uploadFile';


@Injectable()
export class PreenquiryService {
	constructor(
		private http: HttpClient,
		private httpUtils: HttpUtilsService
	) {}
	getSearchLeads(number, name, stage, orgid, showroomid): Observable<any> {
		let headers = new HttpHeaders();
		headers = headers.append("showroomid", showroomid);
		headers = headers.append("orgid", orgid);
		if (name !== "" && number === null) {
			return this.http.get<any>(
				environment.preEnquiryDomain +
					API_SEARCH_URL +
					"?name=" +
					name +
					"&leadstage=" +
					stage,
				{ headers }
			);
		} else if (number !== "" && name === "") {
			return this.http.get<any>(
				environment.preEnquiryDomain +
					API_SEARCH_URL +
					"?number=" +
					number +
					"&leadstage=" +
					stage,
				{ headers }
			);
		} else {
			return this.http.get<any>(
				environment.preEnquiryDomain +
					API_SEARCH_URL +
					"?number=" +
					number +
					"&name=" +
					name +
					"&leadstage=" +
					stage,
				{ headers }
			);
		}
	}

	leadsShowroomByID(
		orgId,
		showRoomId,
		status,
		queryParams: QueryParamsModel
	): Observable<any> {
		const headers = this.httpUtils.getHTTPHeaders();
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			environment.preEnquiryDomain +
				API_LEADS_URL +
				`/org/${orgId}/showroom/${showRoomId}?index=${httpParams.get(
					"startindex"
				)}&elements=${httpParams.get("endindex")}&status=${status}`,
			{ headers }
		);
	}

	leadProfileByID(id, orgid, showroomid): Observable<any> {
		let headers = new HttpHeaders();
		headers = headers.append("showroomid", showroomid);
		headers = headers.append("orgid", orgid);
		return this.http.get<any>(
			environment.preEnquiryDomain + API_SEARCH_URL + `/${id}`,
			{ headers }
		);
	}

	createLeads(data, orgid, showroomid): Observable<any> {
		let headers = new HttpHeaders();
		headers = headers.append("showroomid", showroomid);
		headers = headers.append("orgid", orgid);
		return this.http.post<any>(
			environment.preEnquiryDomain + API_SEARCH_URL,
			data,
			{ headers }
		);
	}

	dseAllocation(dseid, customerid, orgid, showroomid): Observable<any> {
		let data;
		let headers = new HttpHeaders();
		headers = headers.append("showroomid", showroomid);
		headers = headers.append("orgid", orgid);
		// return this.http.post<any>(environment.preEnquiryDomain + API_DSE_URL + `?dseid=${dseid}&customerid=${customerid}`, data, { headers });
		if (dseid === "") {
			return this.http.post<any>(
				environment.preEnquiryDomain +
					API_DSE_URL +
					`?customerid=${customerid}`,
				data,
				{ headers }
			);
		} else {
			return this.http.post<any>(
				environment.preEnquiryDomain +
					API_DSE_URL +
					`?dseid=${dseid}&customerid=${customerid}`,
				data,
				{ headers }
			);
		}
	}

	editLead(id, data, orgid, showroomid): Observable<any> {
		let headers = new HttpHeaders();
		headers = headers.append("showroomid", showroomid);
		headers = headers.append("orgid", orgid);
		return this.http.put<any>(
			environment.preEnquiryDomain + API_SEARCH_URL + `/${id}`,
			data,
			{ headers }
		);
	}

	deleteLead(id): Observable<any> {
		return this.http.delete<any>(
			environment.preEnquiryDomain + API_DELETE_URL + `/${id}`
		);
	}

	// For Creating Contact
	sendContactDTO(dseValue: boolean, contactDTO): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/contact?allocateDse=${dseValue}`,
			contactDTO
		);
	}

	// For Creating Account
	sendAccountDTO(dseValue: boolean, accountDTO): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/account?allocateDse=${dseValue}`,
			accountDTO
		);
	}

	// For Creating LeadDto
	sendLeadDTO(dseValue: boolean, leadDTO): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/lead?allocateDse=${dseValue}`,
			leadDTO
		);
	}

	// Get All Leads By Status
	getAllLeadsByStatus(
		status,
		queryParams: QueryParamsModel,
		empId
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${environment.sales}/lead/all?limit=${httpParams.get(
				"endindex"
			)}&offset=${httpParams.get(
				"startindex"
			)}&status=${status}&empId=${empId}`
		);
	}

	// Get lead By Universal Id
	getLeadByUniversalID(universalId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/lead/id/${universalId}`
		);
	}

	// Search PreEnquiry API
	getSearchResultsPreEnquiry(
		phone,
		name,
		stage,
		queryParams: QueryParamsModel,
		empId
	): Observable<any> {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		if (name !== "" && (phone === "" || phone === null)) {
			return this.http.get<any>(
				`${
					environment.sales
				}/lead?lastName=${name}&leadStage=${stage}&limit=${httpParams.get(
					"endindex"
				)}&offset=${httpParams.get("startindex")}&empId=${empId}`
			);
		} else if (phone !== "" && (name === "" || name === null)) {
			return this.http.get<any>(
				`${
					environment.sales
				}/lead?leadStage=${stage}&phone=${phone}&limit=${httpParams.get(
					"endindex"
				)}&offset=${httpParams.get("startindex")}&empId=${empId}`
			);
		} else {
			return this.http.get<any>(
				`${
					environment.sales
				}/lead?lastName=${name}&leadStage=${stage}&phone=${phone}&limit=${httpParams.get(
					"endindex"
				)}&offset=${httpParams.get("startindex")}&empId=${empId}`
			);
		}
	}

	// No Thanks Click Task Assign to Customer Care Department -- showroom case
	noThanksClick(leadId) {
		return this.http.post<any>(
			`${environment.roleManagement}/nothanks?leadId=${leadId}`,
			{}
		);
	}

	// Allocate DSE API
	allocateDSEPreEnquiry(universalId): Observable<any> {
		let data;
		return this.http.post<any>(
			`${environment.sales}/${API_NEW_ALLOCATE_URL}/${universalId}`,
			data
		);
	}

	// Edit Contact API
	updateContactPreEnquiry(dseValue: boolean, contactDTO): Observable<any> {
		return this.http.put<any>(
			`${environment.sales}/contact?allocateDse=${dseValue}`,
			contactDTO
		);
	}

	// Edit Account API
	updateAccountPreEnquiry(dseValue: boolean, accountDTO): Observable<any> {
		return this.http.put<any>(
			`${environment.sales}/account?allocateDse=${dseValue}`,
			accountDTO
		);
	}

	// Bulk upload
	bulkUpload(data): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/${API_BULK_UPLOAD_URL}`,
			data
		);
	}

	// Bulk upload Enquiry
	bulkEnquiryUpload(data): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/${API_BULK_ENQUIRY_URL}`,
			data
		);
	}

	// Get Strategy for Source of Enquiry
	getStrategySource(sourceId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/source-of-enquiry/source-enquiry-id/${sourceId}`
		);
	}

	// Post Strategy for Source of Enquiry
	sendStrategySoure(data): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/source-of-enquiry/strategy`,
			data
		);
	}

	// Get Employees based on Source
	getEmployeesSource(sourceId): Observable<any> {
		return this.http.get<any>(
			`${environment.sales}/employees/source-of-enquiry/${sourceId}`
		);
	}

	// Post Employee to Source
	sendEmployeesSource(data): Observable<any> {
		return this.http.post<any>(
			`${environment.sales}/lead/sales-consultant/manual`,
			data
		);
	}

	// Get All Events Based on StartDate and EndDate
	getAllEvents(startDate, endDate, empId, branchId, orgId) {
		let headers = new HttpHeaders();
		headers = headers.append("branchid", branchId);
		headers = headers.append("orgid", orgId);
		return this.http.get<any>(
			`${environment.ops}/dms/getAllEventsByFilterWithoutPagination?startdate=${startDate}&enddate=${endDate}&organiserid=${empId}`,
			{ headers }
		);
	}
}
