import { Injectable } from '@angular/core';
import { HttpUtilsService, QueryParamsModel } from '../../_base/crud';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { environment } from '../../../../environments/environment.base';


@Injectable()
export class EventsCampaignsService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  getAllNotificationTemplates(branchId,orgId,status): Observable<any> {
    return this.http.get<any>(environment.notificationServices+ `/dms-core-api/notificationMaster/template?branch=${branchId}&orgId=${orgId}&status=${status}`);
  }

  getAllEventsCampaignsData(pageSize,page,orgId,branchId): Observable<any> {
      return this.http.get<any>(environment.notificationServices+ `/notification/banner?limit=${pageSize}&offset=${page}&orgId=${orgId}&branch=${branchId}`);
  }

  saveEventsCampaigns(data): Observable<any> {
    return this.http.post<any>(environment.notificationServices+ '/notification/banner', data);
  }
  
  updateEventsCampaigns(data): Observable<any> {    
    return this.http.put<any>(environment.notificationServices+ `/notification/banner`, data);
  }

  deleteEventsCampaigns(id): Observable<any> {
    return this.http.delete<any>(`${environment.notificationServices}/notification/banner/${id}`);
  }
 
}
