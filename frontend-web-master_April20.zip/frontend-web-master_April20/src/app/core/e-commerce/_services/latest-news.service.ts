import { Injectable } from '@angular/core';
import { HttpUtilsService, QueryParamsModel } from '../../_base/crud';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { environment } from '../../../../environments/environment.base';


@Injectable()
export class LatestNewsService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  
  getLatestNewsData(pageSize,page,orgId): Observable<any> {
      return this.http.get<any>(environment.vehicleInfoService + `/vehicle/news?limit=${pageSize}&offset=${page}&orgId=${orgId}`);
  }

  saveLatestNews(data): Observable<any> {
    return this.http.post<any>(environment.vehicleInfoService + '/vehicle/news', data);
  }
  
  updateLatestNews(data): Observable<any> {    
    return this.http.put<any>(environment.vehicleInfoService + `/vehicle/news`, data);
  }
  deleteLatestNews(id): Observable<any> {
    return this.http.delete<any>(`${environment.vehicleInfoService}/vehicle/news/${id}`);
  }
 
}
