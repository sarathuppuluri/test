import { Injectable } from '@angular/core';
import { HttpUtilsService, QueryParamsModel } from '../../_base/crud';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { environment } from '../../../../environments/environment.base';


@Injectable()
export class EMIService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  getEmiData(pageSize,pageLimit,orgId): Observable<any> {
      return this.http.get<any>(environment.notificationServices + `/emiData/emiCalculatorData?limit=${pageSize}&offset=${pageLimit}&orgId=${orgId}`);
  }

  saveEMICalc(data): Observable<any> {
    return this.http.post<any>(environment.notificationServices + '/emiData/emiCalculatorData', data);
  }
  
  updateEMICalc(data): Observable<any> {    
    return this.http.put<any>(environment.notificationServices + `/emiData/emiCalculatorData`, data);
  }
 
}
