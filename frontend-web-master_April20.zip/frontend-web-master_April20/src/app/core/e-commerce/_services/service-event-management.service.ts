import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {
	HttpUtilsService,
	QueryParamsModel,
	QueryResultsModel,
} from '../../_base/crud';
import { Observable } from 'rxjs';
import { map, filter } from 'rxjs/operators';
import { environment } from '../../../../environments/environment.base';

@Injectable()
export class ServiceEventManagementService {
	constructor(
		private http: HttpClient,
		private httpUtils: HttpUtilsService
	) {}
	eventStartDate;
	eventId;
	formResetCheck = false;
	approveOrReject;

	getVehicles(branch_id, org_id) {
		return this.http.get<any>(
			`${environment.inventory}/demoVehicle/vehicles?branchId=${branch_id}&orgId=${org_id}&type=EVENT`
		);
	}

	getRedsignedRoles(queryParams: QueryParamsModel) {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get<any>(
			`${environment.roleManagement}/employee?limit=${httpParams.get(
				"endindex"
			)}&offset=${httpParams.get("startindex")}`
		);
	}

	getPincode() {
		return this.http.get(environment.API_PINCODE_URL);
	}

	getLocationUsingPincode(pincode): Observable<any> {
		return this.http.get<any>(environment.API_PINCODE_URL + `/${pincode}`);
	}

	getEventCategories() {
		return this.http.get(`${environment.ops}/dms/events/categories`);
	}

	getAssessment(id): Observable<any> {
		return this.http.get(
			`${environment.ops}/dms/events/assessments/id/${id}`
		);
	}

	getBudgetItems(): Observable<any> {
		return this.http.get(`${environment.ops}/dms/events/budget-items`);
	}

	getEventTypes(): Observable<any> {
		return this.http.get(`${environment.ops}/dms/events/types`);
	}

	postEventShedule(post, orgId, branchId): Observable<any> {
		return this.http.post(`${environment.ops}/dms/events/schedule`, post, {
			headers: this.getHeaders(orgId, branchId),
		});
	}

	getAllEventShedules(orgId, branchId, queryParams) {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get(
			`${environment.ops}/dms/events/schedule/all
			?pageNo=${httpParams.get("startindex")}&pageSize=${httpParams.get("endindex")}`,
			{ headers: this.getHeaders(orgId, branchId) }
		);
	}

	getEventShedule(id, queryParams, orgId, branchId) {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get(
			`${
				environment.ops
			}/dms/events/schedule/id/${id}?pageNo=${httpParams.get(
				"startindex"
			)}&pageSize=${httpParams.get("endindex")}`,
			{ headers: this.getHeaders(orgId, branchId) }
		);
	}

	deleteEventShedules(id, orgId, branchId) {
		return this.http.delete(
			`${environment.ops}/dms/events/schedule/id/${id}`,
			{
				headers: this.getHeaders(orgId, branchId),
			}
		);
	}

	getEventHolidaysList() {
		return this.http.get(`${environment.ops}/dms/events/holidays`);
	}

	getAllEventsByFilter(start, end, orgId, branchId, empId, hrmsRole) {
		return this.http.get(
			`${environment.ops}/dms/events/all?startdate=${start}&enddate=${end}&organiserid=${empId}`,
			{ headers: this.getHeaders(orgId, branchId) }
		);
	}

	getAllEventsByFilterWithPagination(
		start,
		end,
		orgId,
		branchId,
		empId,
		queryParams
	) {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get(
			`${
				environment.ops
			}/dms/events/all?startdate=${start}&enddate=${end}&organiserid=${empId}&pageNo=${httpParams.get(
				"startindex"
			)}&pageSize=${httpParams.get("endindex")}`,
			{ headers: this.getHeaders(orgId, branchId) }
		);
	}

	getAllEventsByFilterWithPaginationApproveorReject(
		start,
		end,
		orgId,
		branchId,
		empId,
		queryParams
	) {
		const httpParams = this.httpUtils.getFindHTTPParams(queryParams);
		return this.http.get(
			`${
				environment.ops
			}/dms/events/all?startdate=${start}&enddate=${end}&managerId=${empId}&pageNo=${httpParams.get(
				"startindex"
			)}&pageSize=${httpParams.get("endindex")}`,
			{ headers: this.getHeaders(orgId, branchId) }
		);
	}

	getvehicleAllotments(date, id) {
		return this.http.get(
			environment.admin +
				"/dms-inventory/allotment/vehicle/allotments" +
				`?allotmentDate=${date}` +
				`&id=${id}`
		);
	}

	getDseList() {
		return this.http.get(
			environment.roleManagement + `/user/role/name/Field DSE`
		);
	}

	getTlList() {
		return this.http.get(environment.roleManagement + `/user/role/name/TL`);
	}

	getDriverList() {
		return this.http.get(
			environment.roleManagement + `/user/role/name/Driver`
		);
	}

	getFinanceExecutiveList() {
		return this.http.get(
			environment.roleManagement + `/user/role/name/Finance Executive`
		);
	}

	getEvaluatorList() {
		return this.http.get(
			environment.roleManagement + `/user/role/name/Evaluator`
		);
	}

	updateEventSchedule(data, orgId, branchId) {
		return this.http.put(environment.ops, data, {
			headers: this.getHeaders(orgId, branchId),
		});
	}

	approveEventShedule(id, data, orgId, branchId) {
		return this.http.put(
			`${environment.ops}/dms/events/schedule/id/${id}/op/approve`,
			data,
			{ headers: this.getHeaders(orgId, branchId) }
		);
	}

	rejectEventShedule(id, data, orgId, branchId) {
		return this.http.put(
			`${environment.ops}/dms/events/schedule/id/${id}/reject`,
			data,
			{ headers: this.getHeaders(orgId, branchId) }
		);
	}

	uploadDocument(data) {
		return this.http.post<any>(`${environment.ops}/dms/document`, data);
	}

	getDocuments(eventId) {
		return this.http.get<any>(
			`${environment.ops}/dms/document?eventId=${eventId}`
		);
	}

	deleteDocument(eventId, billNo, fileName) {
		return this.http.delete<any>(
			`${environment.ops}/dms/document?eventId=${eventId}&billNo=${billNo}&fileName=${fileName}`
		);
	}

	uploadEventDocument(data) {
		return this.http.post<any>(
			`${environment.ops}/dms/event-document`,
			data
		);
	}

	getEventDocuments(eventId, branchId, orgid) {
		http: return this.http.get<any>(
			`${environment.ops}/dms/event-document?eventId=` +
				eventId +
				"&branchId=" +
				branchId +
				"&orgid=" +
				orgid
		);
	}

	deleteEventDocument(eventId, orgid, fileName, branchId) {
		return this.http.delete<any>(
			`${environment.ops}/dms/event-document?eventId=` +
				eventId +
				"&branchId=" +
				orgid +
				"&orgid=" +
				branchId +
				"&fileName=" +
				fileName
		);
	}

	// Changed to service event domian url -- check once
	upcomingEvents(startdate, categoryId, area, orgId, branchId) {
		http: return this.http.get<any>(
			`${environment.ops}/dms/events/upcoming` +
				"?startdate=" +
				startdate +
				"&categoryId=" +
				categoryId +
				"&area=" +
				area,
			{ headers: this.getHeaders(orgId, branchId) }
		);
	}

	getHeaders(orgId, branchId) {
		let headers = new HttpHeaders();
		headers = headers.append("orgid", orgId);
		headers = headers.append("branchid", branchId);
		return headers;
	}
}
