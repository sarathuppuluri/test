import { Injectable } from '@angular/core';
import { HttpUtilsService, QueryParamsModel } from '../../_base/crud';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment.base';

const API_VEHICLE_GET = `${environment.admin}/b2cvehicleinfo/api/dashboardImages/`;
const API_VEHICLE_ADD = `${environment.admin}/b2cvehicleinfo/api/dashboardImages/add`;
const API_VEHICLE_UPDATE = `${environment.admin}/b2cvehicleinfo/api/dashboardImages/update`;

const API_VEHICLE_ALERT = `${environment.inventory}/dms/notification/all`;

const API_BILLS_GET = `${environment.admin}/dmsBills/generalBills`;
const API_BILLS_PUT = `${environment.admin}/dmsBills/generalBill`;
const API_SOFTWAREINFO_GET = `${environment.admin}/administration/softwareDetails`;
const API_PROPERTY_GET = `${environment.admin}/administration/dmsPropertyDocument`;
const API_ASSET_GET = `${environment.admin}/administration/assetDetails`;
const API_COMPANY_VEHICLE_GET = `${environment.admin}/administration/dmsCompanyVehicle`;
const API_STATUARY_GET = `${environment.admin}/administration/dmsStatutory`;
const API_TASKS_GET = `${environment.sales}/general_task`;
const API_RANDOM_DOCUMENT_UPLOAD = 'random-document';
@Injectable()
export class AdminService {


  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }
  getAllImages(): Observable<any> {
    return this.http.get<any>(API_VEHICLE_GET);
  }

  addDashboardImage(data): Observable<any> {
    return this.http.post<any>(API_VEHICLE_ADD, data);
  }

  updateDashboardImage(data) {
    return this.http.post<any>(API_VEHICLE_UPDATE, data);
  }

  getAllNotification(custId): Observable<any> {
    let headers = new HttpHeaders();
    headers = headers.set('orgId', '0');
    return this.http.get<any>(API_VEHICLE_ALERT + `?customerId=${custId}`, { headers });
  }


  // Bills API'S
  getGeneralBills() {
    return this.http.get<any>(API_BILLS_GET);
  }

  generalBillSave(obj) {
    return this.http.put(API_BILLS_PUT, obj);
  }

  generalBillUpdate(obj) {
    return this.http.put(API_BILLS_PUT, obj);
  }

  getGeneralBillsById(id) {
    return this.http.get(API_BILLS_PUT + '/' + id);
  }

  generalBillDelete(id) {
    return this.http.delete(API_BILLS_PUT + '/' + id);
  }

  createBillDoc(requestBody) {
    const url = `${environment.sales}/documents`;
    return this.http.post<any>(url, requestBody);
  }


  // Software Details API'S
  getSoftwareDetails() {
    return this.http.get<any>(API_SOFTWAREINFO_GET);
  }

  softwareDetailsSave(obj) {
    return this.http.post<any>(API_SOFTWAREINFO_GET, obj);
  }

  softwareDetailsUpdate(obj) {
    return this.http.put<any>(API_SOFTWAREINFO_GET, obj);
  }

  softwareDetailsDelete(id) {
    return this.http.delete<any>(API_SOFTWAREINFO_GET + '/' + id);
  }

  getSoftwareDetailsById(id) {
    return this.http.get<any>(API_SOFTWAREINFO_GET + '/' + id);
  }


  // Property Docs API'S
  dmsPropertyDocumentSave(obj) {
    return this.http.post(API_PROPERTY_GET, obj);
  }

  getdmsPropertyDocument() {
    return this.http.get<any>(API_PROPERTY_GET);
  }

  dmsPropertyDocumentUpdate(obj) {
    return this.http.put(API_PROPERTY_GET, obj);
  }

  dmsPropertyDocumentDelete(id) {
    return this.http.delete(API_PROPERTY_GET + '/' + id);
  }

  getdmsPropertyDocumentById(id) {
    return this.http.get(API_PROPERTY_GET + '/' + id);
  }


  // Assets API
  assetDetailsSave(obj) {
    return this.http.post<any>(API_ASSET_GET, obj);
  }

  getdmsAssetDetails() {
    return this.http.get<any>(API_ASSET_GET);
  }

  getdmsAssetDetailById(id) {
    return this.http.get<any>(API_ASSET_GET + '/' + id);
  }

  dmsAssetDetailUpdate(obj) {
    return this.http.put(API_ASSET_GET, obj);
  }

  dmsAssetDetailDelete(id) {
    return this.http.delete(API_ASSET_GET + '/' + id);
  }


  // Company vehicle API
  getdmsCompanyVehicle() {
    return this.http.get<any>(API_COMPANY_VEHICLE_GET);
  }

  dmsCompanyVehicleSave(obj) {
    return this.http.post<any>(API_COMPANY_VEHICLE_GET, obj);
  }

  dmsCompanyVehicleUpdate(obj) {
    return this.http.put(API_COMPANY_VEHICLE_GET, obj);
  }

  getdmsCompanyVehicleById(id) {
    return this.http.get(API_COMPANY_VEHICLE_GET + '/' + id);
  }

  dmsCompanyVehicleDelete(id) {
    return this.http.delete(API_COMPANY_VEHICLE_GET + '/' + id);
  }


  // StatuaryPermission Docs API'S
  dmsStatutorySave(obj) {
    return this.http.post(API_STATUARY_GET, obj);
  }

  getdmsStatutory() {
    return this.http.get<any>(API_STATUARY_GET);
  }

  dmsStatutoryUpdate(obj) {
    return this.http.put(API_STATUARY_GET, obj);
  }

  dmsStatutoryDelete(id) {
    return this.http.delete(API_STATUARY_GET + '/' + id);
  }

  getdmsStatutoryById(id) {
    return this.http.get(API_STATUARY_GET + '/' + id);
  }


  // Tasks API's
  saveAlltasks(obj) {
    return this.http.post(`${API_TASKS_GET}/general-task`, obj);
  }

  createDoc(data) {
    return this.http.post<any>(`${environment.sales}/${API_RANDOM_DOCUMENT_UPLOAD}`, data);
  }

  cancelTask(id) {
    return this.http.delete(`${API_TASKS_GET}/delete/${id}`);
  }

  getEmplayeeByNameOrId(empName, empId) {
    let url = '';

    if (empId !== '' && empName === '') {
      url = 'id=' + empId;
    }
    if (empName !== '' && empId === '') {
      url = 'name=' + empName;
    }
    if (empName !== '' && empId !== '') {
      url = 'id=' + empId + '&name=' + empName;
    }
    return this.http.get<any>(`${environment.sales}/employees?${url}`);
  }

  getAlltasksByName(name, orgId, branchId) {
    return this.http.get(`${environment.sales}/general-task/all`
      + `?orgid=` + orgId + `&branchid=` + branchId + `&empName=` + name);
  }

  // Upload Documents
  createCustomerDoc(data): Observable<any> {
    return this.http.post<any>(`${environment.sales}/${API_RANDOM_DOCUMENT_UPLOAD}`, data);
  }
}

