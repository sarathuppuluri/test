import { environment } from './../../../../environments/environment.base';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const API_BASE_URL = `${environment.inventory}/demoVehicle/search?orgId=ORG01&showroomId=HYD122`;

@Injectable({
  providedIn: 'root'
})
export class VehiclelistService {

  constructor(public http: HttpClient) { }

  getAllVehicles() {
    return this.http.get<any>(API_BASE_URL);
  }
}

