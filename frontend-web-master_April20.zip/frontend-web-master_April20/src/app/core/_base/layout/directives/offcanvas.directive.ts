// Angular
import { AfterViewInit, Directive, ElementRef, Input } from '@angular/core';

export interface OffcanvasOptions {
	baseClass: string;
	overlay?: boolean;
	closeBy: string;
	toggleBy?: any;
}

/**
 * Setup off Convas
 */
@Directive({
	selector: '[ktOffcanvas]',
	exportAs: 'ktOffcanvas',
})
export class OffcanvasDirective implements AfterViewInit {
	@Input() options: OffcanvasOptions;
	private offcanvas: any;

	constructor(private el: ElementRef) { }

	ngAfterViewInit(): void {
		setTimeout(() => {
			this.offcanvas = new KTOffcanvas(this.el.nativeElement, this.options);
		});
	}

	/**
	 * Returns the offCanvas
	 */
	getOffcanvas() {
		return this.offcanvas;
	}
}
