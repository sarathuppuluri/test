export class BaseModel {
	// Edit
	_isEditMode = false;
	// Log
	_userId = 0; // Admin
	_createdDate: string;
	_updatedDate: string;
}
