import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'kt-delivery',
    templateUrl: './deliverymain.component.html'
})
export class DeliveryMainComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
