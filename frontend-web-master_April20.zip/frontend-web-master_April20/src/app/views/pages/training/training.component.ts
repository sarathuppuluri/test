import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-training',
  templateUrl: './training.component.html',
  styleUrls: ['./training.component.scss']
})
export class TrainingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
