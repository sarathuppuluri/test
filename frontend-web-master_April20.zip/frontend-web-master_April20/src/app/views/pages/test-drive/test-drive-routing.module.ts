import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TdappointmentComponent } from './tdappointment/tdappointment.component';
import { TdschedulesComponent } from './tdschedules/tdschedules.component';
import { TdvehiclesComponent } from './tdvehicles/tdvehicles.component';
import { TdvehiclemanagementComponent } from './tdvehiclemanagement/tdvehiclemanagement.component';

const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forChild(
    [{
      'path': 'testDrive',
      'component': TdschedulesComponent
    },
    {
      'path': 'vehicles',
      'component': TdvehiclesComponent
    },
    {
      'path': 'request/:testDriveId',
      'component': TdappointmentComponent
    },
    {
      'path': 'vehmang',
      'component': TdvehiclemanagementComponent
    }]
  )],
  exports: [RouterModule]
})
export class TestDriveRoutingModule { }
