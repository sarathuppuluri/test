import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { TestDriveRoutingModule } from './test-drive-routing.module';
import { TdappointmentComponent } from './tdappointment/tdappointment.component';
import { TdschedulesComponent } from './tdschedules/tdschedules.component';
import { TdvehiclesComponent } from './tdvehicles/tdvehicles.component';
import { TdvehiclemanagementComponent } from './tdvehiclemanagement/tdvehiclemanagement.component';
import {
  MatFormFieldModule,
  MatInputModule,
  MatPaginatorModule,
  MatProgressSpinnerModule,
  MatSortModule,
  MatTableModule,
  MatSelectModule,
  MatMenuModule,
  MatProgressBarModule,
  MatButtonModule,
  MatCheckboxModule,
  MatDialogModule,
  MatTabsModule,
  MatNativeDateModule,
  MatCardModule,
  MatRadioModule,
  MatIconModule,
  MatDatepickerModule,
  MatAutocompleteModule,
  MAT_DIALOG_DEFAULT_OPTIONS,
  MatSnackBarModule,
  MatTooltipModule,
} from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { PortletModule } from '../../partials/content/general/portlet/portlet.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TestDriveService } from './test-drive.service';
import { FormsModule } from '@angular/forms';
import { PagesModule } from '../pages.module';

@NgModule({
  declarations: [TdappointmentComponent,
    TdschedulesComponent,
    TdvehiclesComponent,
    TdvehiclemanagementComponent],
  imports: [
    MatFormFieldModule,
    MatInputModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSortModule,
    MatTableModule,
    MatSelectModule,
    MatMenuModule,
    MatProgressBarModule,
    MatButtonModule,
    MatCheckboxModule,
    MatDialogModule,
    MatTabsModule,
    MatNativeDateModule,
    MatCardModule,
    MatRadioModule,
    MatIconModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MatSnackBarModule,
    MatTooltipModule,
    CommonModule,
    TestDriveRoutingModule,
    ReactiveFormsModule,
    PortletModule,
    NgbModule,
    FormsModule,
    PagesModule
  ],
  providers: [TestDriveService]
})
export class TestDriveModule { }
