import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerComponent } from './customer/customer.component';
import { ServicesEventCalenderComponent } from './event-management/services-event-calender/services-event-calender.component';
import { CreateServiceEventComponent } from './event-management/create-service-event/create-service-event.component';
import { ServicesPreviewEventFormComponent } from './event-management/services-preview-event-form/services-preview-event-form.component';
import { JobCardComponent } from './job-card/job-card.component';

const routes: Routes = [
	{
		path: 'customer',
		component: CustomerComponent,
	},
	{
		path: 'eventManagement',
		component: ServicesEventCalenderComponent,
	},
	{
		path: 'eventManagement/createServiceEvent',
		component: CreateServiceEventComponent,
	},
	{
		path: 'eventManagement/:id',
		component: ServicesPreviewEventFormComponent,
	},
	{
		path: 'job-card',
		component: JobCardComponent,
	},
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
})
export class ServicesRoutingModule {}
