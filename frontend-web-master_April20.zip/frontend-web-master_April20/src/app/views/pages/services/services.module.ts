// Angular
import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
// Core Module
import { CoreModule } from "../../../core/core.module";
import { PartialsModule } from "../../partials/partials.module";
import { MatIconModule } from "@angular/material/icon";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import {
	MatTabsModule,
	MatCardModule,
	MatLabel,
	MatInputModule,
	MatFormFieldModule,
	MatExpansionModule,
	MatStepperModule,
	MatButtonModule,
	MatAutocompleteModule,
	MatSelectModule,
	MatMenuModule,
	MatCheckboxModule,
	MatPaginatorModule,
	MAT_DATE_LOCALE,
	MatDialogModule,
	MAT_DIALOG_DATA,
	MatDialogRef,
} from "@angular/material";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { FlexLayoutModule } from "@angular/flex-layout";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { CustomerComponent } from "./customer/customer.component";
import {
	CreateServiceEventComponent,
	DialogComponent,
} from "./event-management/create-service-event/create-service-event.component";
import { ServicesEventCalenderComponent } from "./event-management/services-event-calender/services-event-calender.component";
import { ServicesPreviewEventFormComponent } from "./event-management/services-preview-event-form/services-preview-event-form.component";
import { selectAll } from "../../../core/auth/_reducers/role.reducers";
import { FullCalendarModule } from "@fullcalendar/angular";
import { ServiceEventManagementService } from "../../../core/e-commerce/_services/service-event-management.service";
import { CreateCustomerComponent } from "./customer/create-customer/create-customer.component";
import { MatRadioModule } from "@angular/material";
import { JobCardComponent } from "./job-card/job-card.component";
import { ServicesRoutingModule } from "./services.routing.module";
import { CustomerInfoComponent } from "./customer/customer-info/customer-info.component";
import { BookingsComponent } from "./customer/bookings/bookings.component";
import { ServiceBookingComponent } from "./customer/bookings/service-booking/service-booking.component";
import { CustomerService } from "./customer/customer.service";
import { FollowUpComponent } from "./customer/follow-up/follow-up.component";
import { QueryComponent } from "./customer/query/query.component";
import { CreateQueryComponent } from "./customer/query/create-query/create-query.component";
import { RsaComponent } from "./customer/rsa/rsa.component";
import { CreateRsaComponent } from "./customer/rsa/create-rsa/create-rsa.component";
import { VehicleServiceHistoryComponent } from "./customer/vehicle-service-history/vehicle-service-history.component";
import { AddInsuranceComponent } from "./customer/add-insurance/add-insurance.component";
import { AddWarrantyComponent } from "./customer/add-warranty/add-warranty.component";
import { AddVehicleComponent } from "./customer/add-vehicle/add-vehicle.component";

@NgModule({
	imports: [
		CommonModule,
		PartialsModule,
		CoreModule,
		MatIconModule,
		NgbModule,
		MatTabsModule,
		MatCardModule,
		FormsModule,
		ReactiveFormsModule,
		MatFormFieldModule,
		MatStepperModule,
		MatDialogModule,
		MatMenuModule,
		MatCheckboxModule,
		MatPaginatorModule,
		FullCalendarModule,
		MatSelectModule,
		MatButtonModule,
		MatAutocompleteModule,
		MatInputModule,
		MatExpansionModule,
		ReactiveFormsModule,
		FlexLayoutModule,
		MatDatepickerModule,
		MatRadioModule,

		RouterModule.forChild([
			{
				path: "",
				component: CustomerComponent,
			},
			{
				path: "create",
				component: CreateCustomerComponent,
			},
			{
				path: "evenManagement",
				component: ServicesEventCalenderComponent,
			},
			{
				path: "evenManagement/createServiceEvent",
				component: CreateServiceEventComponent,
			},
			{
				path: "evenManagement/:id",
				component: ServicesPreviewEventFormComponent,
			},
			{
				path: "customer-info/:customerId",
				component: CustomerInfoComponent,
			},
			{
				path: "bookings/:customerId/:regNumber",
				component: BookingsComponent,
			},
			{
				path:
					"service-booking/:customerId/:regNumber/:bookingId/:fromCCE",
				component: ServiceBookingComponent,
			},
			{
				path: "follow-up/:customerId/:regNumber",
				component: FollowUpComponent,
			},
			{
				path: "query-search/:customerId/:regNumber",
				component: QueryComponent,
			},
			{
				path: "query-create/:customerId/:regNumber/:queryId",
				component: CreateQueryComponent,
			},
			{
				path: "rsa/:customerId/:regNumber",
				component: RsaComponent,
			},
			{
				path: "rsa-create/:customerId/:regNumber/:rsaId",
				component: CreateRsaComponent,
			},
		]),
		ServicesRoutingModule,
	],
	providers: [
		ServiceEventManagementService,
		CustomerService,
		{ provide: MAT_DATE_LOCALE, useValue: "en-GB" },
		{ provide: MAT_DIALOG_DATA, useValue: {} },
		{ provide: MatDialogRef, useValue: {} },
	],
	declarations: [
		CustomerComponent,
		CreateServiceEventComponent,
		ServicesPreviewEventFormComponent,
		ServicesEventCalenderComponent,
		CreateCustomerComponent,
		CustomerInfoComponent,
		BookingsComponent,
		ServiceBookingComponent,
		FollowUpComponent,
		QueryComponent,
		CreateQueryComponent,
		JobCardComponent,
		RsaComponent,
		VehicleServiceHistoryComponent,
		CreateRsaComponent,
		AddInsuranceComponent,
		AddWarrantyComponent,
		AddVehicleComponent,
		DialogComponent,
	],
	entryComponents: [
		VehicleServiceHistoryComponent,
		AddInsuranceComponent,
		AddWarrantyComponent,
		AddVehicleComponent,
		DialogComponent,
	],
})
export class ServicesModule {}
