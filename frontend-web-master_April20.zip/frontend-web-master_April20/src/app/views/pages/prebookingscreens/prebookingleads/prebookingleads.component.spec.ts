import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrebookingleadsComponent } from './prebookingleads.component';

describe('PrebookingleadsComponent', () => {
  let component: PrebookingleadsComponent;
  let fixture: ComponentFixture<PrebookingleadsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrebookingleadsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrebookingleadsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
