import { Component, ElementRef, OnInit, OnDestroy, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgControlStatus, FormControl } from '@angular/forms';
import { EnquiryService, SharedService, MyRolesService, Lead360Service } from '../../../../core/e-commerce/_services';
import { ActivatedRoute, Router } from '@angular/router';
import { LayoutUtilsService } from '../../../../core/_base/crud/utils/layout-utils.service';
import { QueryParamsModel } from '../../../../../app/core/_base/crud';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { findIndex } from 'rxjs/operators';

@Component({
	selector: 'kt-pre-booking',
	templateUrl: './pre-booking.component.html',
	styleUrls: ['./pre-booking.component.scss']
})

export class PreBookingComponent implements OnInit, OnDestroy {
	// Used in the MatPicker
	startDate;
	message: any;
	loginEmployee: any;
	warranty: any;
	insuranceType = 0;
	addOnCovers = 0;
	warrantyElement = 0;
	onRoadPriceCalculator = 0;
	onRoadPriceDiscountCalculator: any;
	accessoryCost = 0;
	addSelectedAccessoryCost = 0;
	accessoriesArray = [];
	slectedCorporateOfferCost: any;
	corporateOfferPrice: any;
	// changeVechileModelStore: NodeJS.Timeout;
	// changeVariantStore: NodeJS.Timeout;

	paymentBody: any = {};
	corporateCheckValue = false;
	offerDetailsCheckValue = false;

	dropClicked = false;
	dropLeadDetails: any = { dmsLeadDropInfo: {} };
	hasApprover = false;
	displayRemarks: boolean;
	slectedCorporateElem: any;

	constructor(private fb: FormBuilder, private enquiryservice: EnquiryService, private routeData: ActivatedRoute,
		private layoutUtilsService: LayoutUtilsService,
		private sharedService: SharedService,
		private myroleService: MyRolesService,
		private lead360Service: Lead360Service,
		private router: Router,
		private changedetectorref: ChangeDetectorRef,
		private modalService: NgbModal) {
		this.leadId = this.routeData.snapshot.paramMap.get('id');
		this.startDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
	}

	_subscription;

	EnquiryEditForm: FormGroup;
	EnquiryEditForm2: FormGroup;
	EnquiryEditForm21: FormGroup;
	EnquiryEditForm3: FormGroup;
	EnquiryEditForm4: FormGroup;
	EnquiryEditForm6: FormGroup;

	PreBookingForm: FormGroup;
	PreBookingPaymentForm: FormGroup;
	DropEnquiryForm: FormGroup;
	hasFormErrors = false;

	submitted = false;
	leadId = '';

	vechilesData = [];
	vechileModelsList = [];
	variantsList = [];
	colorsList = [];
	fuelTypeList = [];
	variantRecord = [];

	customerTypeDropDown = [];
	showImageCheck = true;
	hasSubmitted = false;
	endAutoSave = false;
	statusShow = false;

	second = 1000;
	minute = this.second * 60;
	hour = this.minute * 60;
	day = this.hour * 24;
	month = this.day * 30;
	year = this.day * 365;

	leadObject: any = {};
	postOnRoadPriceTable: any = {};
	bookingAmountReceived: any = {};

	documentsObject = [];
	// Lead Attachments Object
	tempObjDoc = {
		branchId: '',
		contentSize: 0,
		createdBy: Date.now(),
		description: '',
		documentNumber: '',
		documentPath: '',
		documentType: '',
		documentVersion: 0,
		fileName: '',
		gstNumber: '',
		id: 0,
		isActive: 0,
		isPrivate: 0,
		keyName: '',
		modifiedBy: 'Admin',
		orgId: '',
		ownerId: '',
		ownerName: 'Admin',
		parentId: '',
		tinNumber: ''
	};

	previewURL = [];
	docKeyNames = [];

	docsPath: any = {};

	page = 0;
	pageSize = 1000;
	scope: any = {};

	onRoadPrice: any = {
		// roadtax: [{}]
	};
	offers: any = {
		offerDetails: [
			// {}, {}, {}
		]
	};
	accessoriesList: any = [];
	bookingAmountReceivedArray = [];

	editEnable = false;
	managerEdit = false;

	popCheck = false;
	testDrive = '';
	homeVisit = '';
	evaluation = '';
	isTestDrive = false;
	isHomeVisit = false;
	isEvaluation = false;

	showExchangeOffer = false;

	insuranceAddonData = new FormControl();

	ngOnInit() {
		this.endAutoSave = false;
		this.statusShow = false;
		this.enquiryForm();
		this.getVechilesDetails();
		this.getLeadDetailsUniversalId();
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		if (this.loginEmployee.roles.includes('PreBooking Approver')) {
			this.managerEdit = true;
			this.editEnable = true;
		}
	}

	ngOnDestroy(): void {
		// Called once, before the instance is destroyed.
		// Add 'implements OnDestroy' to the class.
		this.endAutoSave = true;
		this.statusShow = false;
		// clearTimeout(this.changeVechileModelStore);
		// clearTimeout(this.changeVariantStore);
	}

	changeInitialValues() {
		if (this.leadObject.dmsLeadDto.enquirySegment === 'Personal') {
			this.customerTypeDropDown = this.sharedService.customerTypeDropDownOne;
		} else if (this.leadObject.dmsLeadDto.enquirySegment === 'Commercial') {
			this.customerTypeDropDown = this.sharedService.customerTypeDropDownTwo;
		} else if (this.leadObject.dmsLeadDto.enquirySegment === 'Company') {
			this.customerTypeDropDown = this.sharedService.customerTypeDropDownThree;
		}
		this.changedetectorref.detectChanges();
	}

	changeCustomerTypeValues() {
		if (this.EnquiryEditForm.controls.enquirySegment.value === 'Personal') {
			this.customerTypeDropDown = this.sharedService.customerTypeDropDownOne;
		} else if (this.EnquiryEditForm.controls.enquirySegment.value === 'Commercial') {
			this.customerTypeDropDown = this.sharedService.customerTypeDropDownTwo;
		} else if (this.EnquiryEditForm.controls.enquirySegment.value === 'Company') {
			this.customerTypeDropDown = this.sharedService.customerTypeDropDownThree;
		}
	}

	assignAddress(event) {
		if (this.EnquiryEditForm2.controls.sameAsCommunicationAddress.value === true) {
			this.EnquiryEditForm21.patchValue(this.EnquiryEditForm2.value);
		}
	}

	enquiryForm() {
		this.EnquiryEditForm = this.fb.group({
			salutation: [''],
			firstName: [''],
			lastName: [''],
			gender: [''],
			dateOfBirth: [''],
			age: [''],
			maritalStatus: [''],
			phone: [''],
			email: [''],

			enquirySegment: [''],
			customerType: [''],

			documentType: [''],
			gstNumber: [''],
			customerCategoryType: [''],

			otherVehicleType: [''],
			otherVehicleRcNo: [''],

			commitmentDeliveryPreferredDate: [''],
			commitmentDeliveryTentativeDate: [''],
			occasion: [''],
			occasionTime: [''],
			remarks: ['']
		});

		this.EnquiryEditForm2 = this.fb.group({
			pincode: ['', Validators.required],
			houseNo: ['', Validators.required],
			street: ['', Validators.required],
			address: [''],
			village: ['', Validators.required],
			city: ['', Validators.required],
			district: ['', Validators.required],
			state: ['', Validators.required],
			urban: [''],
			sameAsCommunicationAddress: ['']
		});

		this.EnquiryEditForm21 = this.fb.group({
			pincode: ['', Validators.required],
			houseNo: ['', Validators.required],
			street: ['', Validators.required],
			address: [''],
			village: ['', Validators.required],
			city: ['', Validators.required],
			district: ['', Validators.required],
			state: ['', Validators.required],
			urban: ['']
		});

		this.EnquiryEditForm3 = this.fb.group({
			pan: [''],
			panFileName: [''],
			form60: [''],
			form60FileName: [''],
			aadhar: [''],
			aadharFileName: [''],
			employeeId: [''],
			employeeIdFileName: [''],
			payslips: [''],
			payslipsFileName: [''],
			relationshipProof: [''],
			relationshipProofFileName: [''],

			receipt: [''],
			receiptFileName: [''],
		});

		this.EnquiryEditForm4 = this.fb.group({
			model: ['', Validators.required],
			variant: ['', Validators.required],
			color: ['', Validators.required],
			fuel: ['', Validators.required],
			transimmisionType: ['', Validators.required]
		});

		this.EnquiryEditForm6 = this.fb.group({
			financeType: [''],
			financeCategory: [''],
			downPayment: [''],
			loanAmount: [''],
			financeCompany: [''],
			expectedTenureYears: [''],
			annualIncome: [''],
			location: [''],
			rateOfInterest: [''],
			emi: ['']
		});

		this.PreBookingForm = this.fb.group({
			deliveryLocation: [''],

			otherVehicle: [''],
			insuranceType: [''],
			insuranceAddonName: [''],
			warrantyName: [''],

			npsScheme: [''],
			exchangeCheck: [''],
			corporateCheck: [''],
			corporateName: [''],
			ruralCheck: [''],

			specialScheme: [''],
			promotionalOffers: [''],
			cashDiscount: [''],
			focAccessories: [''],
			additionalOffer1: [''],
			additionalOffer2: [''],

			bookingAmount: ['', Validators.required],
			// reasonVehicleAllocation: [''],
			paymentAt: ['', Validators.required],
			modeOfPayment: ['', Validators.required]
		});

		this.PreBookingPaymentForm = this.fb.group({
			typeOfUPI: [''],
			fromMobile: [''],
			toMobile: [''],
			utrNo: [''],
			date: [''],
			bankName: [''],
			chequeNumber: [''],
			ddNumber: ['']
		});

		this.DropEnquiryForm = this.fb.group({
			dropReason: [''],
			dealerName: [''],
			brandName: [''],
			otherReason: [''],
			additionalRemarks: [''],
			location: [''],
			model: ['']
		});
	}

	ageCal() {
		const millisecondsDiff = (Date.now() - Date.parse(this.EnquiryEditForm.controls.dateOfBirth.value));
		const age = Math.round(millisecondsDiff / this.year);
		this.EnquiryEditForm.patchValue({ age });
	}

	enquiryCategoryCal() {
		const millisecondsDiff = (Date.parse(this.EnquiryEditForm.controls.expected_delivery_date.value) - Date.now());
		const days = Math.round(millisecondsDiff / this.day);
		if (days <= 5 && days >= 0) {
			this.EnquiryEditForm.patchValue({ enquiryCategory: 'Hot' });
		} else if (days <= 10 && days > 5) {
			this.EnquiryEditForm.patchValue({ enquiryCategory: 'Warm' });
		} else if (days > 10) {
			this.EnquiryEditForm.patchValue({ enquiryCategory: 'Cold' });
		}
	}

	/**
	* Checking control validation
	*
	* @param controlName: string => Equals to formControlName
	* @param validationType: string => Equals to valitors name
	*/
	isControlHasError(controlName: string, validationType: string, formName): boolean {
		const control = this[formName].controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}

	mobileNumberKeyPress(event: any) {
		const pattern = /[0-9]/;
		// const pattern = /[0-9\+\-\ ]/;
		// const pattern = "^((\\+91-?)|0)?[0-9]{10}$";

		const inputChar = String.fromCharCode(event.charCode);
		if (event.keyCode != 8 && !pattern.test(inputChar)) {
			event.preventDefault();
		}
	}

	onSubmit() {
		this.hasSubmitted = true;
		this.endAutoSave = true;
		this.statusShow = true;
		this.updateLeadDetails(this.EnquiryEditForm.value);
	}

	// Booking Amount Received Array
	addBookingAmountReceived(controls) {
		const tempAdvance = [
			{
				id: (this.bookingAmountReceivedArray.length > 0) ? this.bookingAmountReceivedArray[0].id : 0,
				paymentName: 'Booking Advance Amount',
				amount: controls.bookingAmount,
				leadId: this.leadObject.dmsLeadDto.id,
			}
		];

		return tempAdvance;
	}

	onPaymentSubmit() {
		this.hasSubmitted = true;
		let controls = this.PreBookingPaymentForm.value;

		// Advance Booking Amount -- in Booking received table
		this.bookingAmountReceivedArray = this.addBookingAmountReceived(this.PreBookingForm.value);

		this.paymentBody.bankName = controls.bankName;
		this.paymentBody.bookingId = this.leadObject.dmsLeadDto.dmsBooking.id;
		this.paymentBody.chequeNo = controls.chequeNumber;
		this.paymentBody.date = Date.parse(controls.date);
		this.paymentBody.ddNo = controls.ddNumber;
		this.paymentBody.id = this.paymentBody.id ? this.paymentBody.id : 0;
		this.paymentBody.leadId = this.leadObject.dmsLeadDto.id;
		this.paymentBody.paymentMode = this.leadObject.dmsLeadDto.dmsBooking.modeOfPayment;
		this.paymentBody.transferFromMobile = controls.fromMobile;
		this.paymentBody.transferToMobile = controls.toMobile;
		this.paymentBody.typeUpi = controls.typeOfUPI;
		this.paymentBody.utrNo = controls.utrNo;
		this.updateLeadDetails(this.EnquiryEditForm.value);
		this.enquiryservice.sendPaymentDetails(this.paymentBody).subscribe(response => {
			this.enquiryservice.sendBookingAmount(this.bookingAmountReceivedArray).subscribe(bookingRes => {
				if (!bookingRes) {
					return;
				}
				if (bookingRes.success === false) {
					this.message = bookingRes.message;
					return;
				}

				// if Booking Amount is Success then Proceed
				if (this.testDrive || this.homeVisit || this.evaluation) {
					this.pendingTasksStatus();
				} else {
					if (!this.popCheck) {
						// this.updateStatusMessage();
						this.updateStatusMessagePermission();
					} else {
						this.router.navigate(['/lead360']);
						this.popCheck = false;
					}
				}

				this.enquiryservice.getInventoryDetails(this.leadObject.dmsLeadDto.id).subscribe(inventoryRes => {
				});
			});
		});
	}

	editForm(editVal) {
		if (!editVal) {
			this.editEnable = true;
			this.EnquiryEditForm.disable();
			this.EnquiryEditForm2.disable();
			this.EnquiryEditForm21.disable();
			this.EnquiryEditForm3.disable();
			this.EnquiryEditForm4.disable();
			this.EnquiryEditForm6.disable();
			this.PreBookingForm.disable();
			this.insuranceAddonData.disable();
			if (this.leadObject.dmsLeadDto.leadStatus !== 'SENTFORAPPROVAL') {
				this.EnquiryEditForm3.get('receipt').enable({ onlySelf: true });
				this.EnquiryEditForm3.get('receiptFileName').enable({ onlySelf: true });
			}
		} else {
			this.editEnable = false;
			this.EnquiryEditForm.enable();
			this.EnquiryEditForm2.enable();
			this.EnquiryEditForm21.enable();
			this.EnquiryEditForm3.enable();
			this.EnquiryEditForm4.enable();
			this.EnquiryEditForm6.enable();
			this.PreBookingForm.enable();
			this.insuranceAddonData.enable();
			this.EnquiryEditForm.get('enquirySegment').disable({ onlySelf: true });
			this.EnquiryEditForm.get('customerType').disable({ onlySelf: true });
			this.EnquiryEditForm.get('remarks').disable({ onlySelf: true });
		}
	}

	// Get Lead Details By UniversalID
	getLeadDetailsUniversalId() {
		this.enquiryservice.getLeadByUniversalID(this.leadId).subscribe(res => {
			if (!res) {
				return;
			}
			delete res.dmsEntity.dmsEmployeeAllocationDtos;
			this.leadObject = res.dmsEntity;
			this.changeInitialValues();
			this.EnquiryEditForm.patchValue(this.leadObject.dmsContactDto ? this.leadObject.dmsContactDto : this.leadObject.dmsAccountDto);
			this.EnquiryEditForm.patchValue({
				dateOfBirth: (new Date(this.leadObject.dmsContactDto ? this.leadObject.dmsContactDto.dateOfBirth : this.leadObject.dmsAccountDto.dateOfBirth)).toISOString()
			});
			this.EnquiryEditForm.patchValue(this.leadObject.dmsLeadDto);
			this.EnquiryEditForm.patchValue({
				commitmentDeliveryPreferredDate: (new Date(this.leadObject.dmsLeadDto.commitmentDeliveryPreferredDate ? this.leadObject.dmsLeadDto.commitmentDeliveryPreferredDate : Date.now())).toISOString(),
				commitmentDeliveryTentativeDate: (new Date(this.leadObject.dmsLeadDto.commitmentDeliveryTentativeDate ? this.leadObject.dmsLeadDto.commitmentDeliveryTentativeDate : Date.now())).toISOString()
			});
			this.EnquiryEditForm4.patchValue({
				model: this.leadObject.dmsLeadDto.model
			});

			if (this.leadObject.dmsLeadDto.dmsAddresses.length > 0) {
				this.EnquiryEditForm2.patchValue(this.leadObject.dmsLeadDto.dmsAddresses[0]);
			}
			if (this.leadObject.dmsLeadDto.dmsAddresses.length > 1) {
				this.EnquiryEditForm21.patchValue(this.leadObject.dmsLeadDto.dmsAddresses[1]);
			}

			if (this.leadObject.dmsLeadDto.dmsAttachments.length > 0) {
				this.documentsObject = this.leadObject.dmsLeadDto.dmsAttachments;
				const customerDocs = this.leadObject.dmsLeadDto.dmsAttachments.reduce((acc, record) => {
					acc[record.documentType] = (record.documentNumber === '' ? record.fileName : record.documentNumber);
					acc[record.documentType + 'doc'] = record.documentPath;
					acc[record.documentType + 'key'] = record.keyName;
					return acc;
				}, {});
				const test = {
					panFileName: customerDocs.pan,
					aadharFileName: customerDocs.aadhar,
					employeeIdFileName: customerDocs.employeeId,
					payslipsFileName: customerDocs.payslips,
					relationshipProofFileName: customerDocs.relationshipProof,
					form60FileName: customerDocs.form60,
					receiptFileName: customerDocs.receipt
				};
				this.docsPath = {
					panDocPath: customerDocs.pandoc,
					panKey: customerDocs.pankey,
					aadharDocPath: customerDocs.aadhardoc,
					aadharKey: customerDocs.aadharkey,
					employeeIdDocPath: customerDocs.employeeIddoc,
					employeeIdKey: customerDocs.employeeIdkey,
					payslipsDocPath: customerDocs.payslipsdoc,
					payslipsKey: customerDocs.payslipskey,
					relationshipProofDocPath: customerDocs.relationshipProofdoc,
					relationshipProofKey: customerDocs.relationshipProofkey,
					form60DocPath: customerDocs.form60doc,
					form60Key: customerDocs.form60key,
					receiptDocPath: customerDocs.receiptdoc,
					receiptKey: customerDocs.receiptkey
				}
				this.previewURL[1] = this.docsPath.panDocPath;
				this.previewURL[2] = this.docsPath.aadharDocPath;
				this.previewURL[4] = this.docsPath.employeeIdDocPath;
				this.previewURL[5] = this.docsPath.payslipsDocPath;
				this.previewURL[10] = this.docsPath.form60DocPath;
				this.previewURL[11] = this.docsPath.receiptDocPath;
				this.previewURL[12] = this.docsPath.relationshipProofDocPath;
				this.EnquiryEditForm3.patchValue(test);
			}

			if (this.leadObject.dmsLeadDto.dmsLeadProducts.length > 0) {
				this.EnquiryEditForm4.patchValue({
					model: (this.leadObject.dmsLeadDto.dmsLeadProducts[0].model !== null) ? this.leadObject.dmsLeadDto.dmsLeadProducts[0].model : this.leadObject.dmsLeadDto.model,
					variant: this.leadObject.dmsLeadDto.dmsLeadProducts[0].variant,
					color: this.leadObject.dmsLeadDto.dmsLeadProducts[0].color,
					fuel: this.leadObject.dmsLeadDto.dmsLeadProducts[0].fuel,
					transimmisionType: this.leadObject.dmsLeadDto.dmsLeadProducts[0].transimmisionType
				});
			}
			if (this.leadObject.dmsLeadDto.dmsfinancedetails.length > 0) {
				this.EnquiryEditForm6.patchValue(this.leadObject.dmsLeadDto.dmsfinancedetails[0]);
			}

			if (this.leadObject.dmsLeadDto.dmsBooking) {
				this.PreBookingForm.patchValue(this.leadObject.dmsLeadDto.dmsBooking);
			}

			if (this.leadObject.dmsLeadDto.dmsAccessories) {
				this.accessoriesArray = this.leadObject.dmsLeadDto.dmsAccessories;
				this.accessoriesArray.forEach((element) => {
					this.accessoryCost = this.accessoryCost + element.amount;
				});
				this.addSelectedAccessory();
			}

			// get PreBooking Payment Details
			this.enquiryservice.getPaymentDetails(this.leadObject.dmsLeadDto.id).subscribe(response => {
				this.paymentBody = response;
				this.PreBookingPaymentForm.patchValue(this.paymentBody);
				this.PreBookingPaymentForm.patchValue({ date: (new Date(this.paymentBody.date ? this.paymentBody.date : Date.now())).toISOString() });
			});

			// get OnRoadPrice Table Posted Data
			this.enquiryservice.getOnRoadPricePosted(this.leadObject.dmsLeadDto.id).subscribe(response => {
				if (response.dmsEntity.dmsOnRoadPriceDtoList.length > 0) {
					this.postOnRoadPriceTable = response.dmsEntity.dmsOnRoadPriceDtoList[0];
					this.PreBookingForm.patchValue(this.postOnRoadPriceTable);
					this.insuranceAddonData.setValue(this.postOnRoadPriceTable.insuranceAddonData);
				}
			});

			// get Booking Amount Received Details
			this.enquiryservice.getBookingAmount(this.leadObject.dmsLeadDto.id).subscribe(response => {
				if (response.dmsEntity.dmsBookingAmountReceivedDtoList.length > 0) {
					response.dmsEntity.dmsBookingAmountReceivedDtoList.forEach(element => {
						if (element.paymentName === 'Booking Advance Amount') {
							this.bookingAmountReceivedArray = [element];
						}
						if (element.paymentName === 'Vehicle Exchange Amount') {
							this.showExchangeOffer = true;
						}
					});
				}
			});

			this.EnquiryEditForm.get('enquirySegment').disable({ onlySelf: true });
			this.EnquiryEditForm.get('customerType').disable({ onlySelf: true });

			if ((this.leadObject.dmsLeadDto.leadStatus === 'PREBOOKINGCOMPLETED') || (this.leadObject.dmsLeadDto.leadStatus === 'SENTFORAPPROVAL') || (this.leadObject.dmsLeadDto.leadStatus === 'REJECTED' && this.managerEdit)) {
				this.editForm(false);
			} else if (this.leadObject.dmsLeadDto.leadStatus === 'REJECTED' && !this.managerEdit) {
				this.editForm(true);
				this.displayRemarks = true;
			}

			if (this.leadObject.dmsLeadDto.leadStatus === 'PREBOOKINGCOMPLETED') {
				// Lead360 Tasks
				this.myroleService.getAllTasksUniversalID(this.leadId, 'Pre Booking').subscribe(taskRes => {
					taskRes.dmsEntity.tasks.forEach((element) => {
						if (element.taskName === 'Test Drive' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')) {
							this.testDrive = 'Test Drive : Pending';
							this.isTestDrive = true;
						}
						if (element.taskName === 'Home Visit' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')) {
							this.homeVisit = 'Home Visit : Pending';
							this.isHomeVisit = true;
						}
						if (element.taskName === 'Evaluation' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')
							&& this.leadObject.dmsLeadDto.buyerType === 'Replacement Buyer') {
							this.evaluation = 'Evaluation : Pending';
							this.isEvaluation = true;
						}

						if (element.universalId === this.leadId && element.taskName === 'Proceed to Booking'
							&& element.assignee.empId === this.loginEmployee.empId) {
							this.lead360Service.selectedTaskObj = element;
							// this.router.navigate(['/lead360']);
							this.popCheck = true;
							return;
						}
					});
				});
			}
		});
	}

	// Post Lead Details
	updateLeadDetails(controls) {
		const tempArray = [
			this.EnquiryEditForm2.controls,
			this.EnquiryEditForm21.controls,
			this.EnquiryEditForm4.controls,
			this.PreBookingForm.controls
		]
		if (this.EnquiryEditForm2.invalid) {
			Object.keys(tempArray[0]).forEach(controlName =>
				tempArray[0][controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		} else if (this.EnquiryEditForm21.invalid) {
			Object.keys(tempArray[1]).forEach(controlName =>
				tempArray[1][controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		} else if (this.EnquiryEditForm4.invalid) {
			Object.keys(tempArray[2]).forEach(controlName =>
				tempArray[2][controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		} else if (this.PreBookingForm.invalid) {
			Object.keys(tempArray[3]).forEach(controlName =>
				tempArray[3][controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.hasSubmitted = false;
			return;
		}

		if (this.leadObject.dmsContactDto) {
			this.leadObject.dmsContactDto.salutation = controls.salutation;
			this.leadObject.dmsContactDto.firstName = controls.firstName;
			this.leadObject.dmsContactDto.lastName = controls.lastName;
			this.leadObject.dmsContactDto.gender = controls.gender;
			this.leadObject.dmsContactDto.dateOfBirth = Date.parse(controls.dateOfBirth);
			this.leadObject.dmsContactDto.age = controls.age;
		} else {
			this.leadObject.dmsAccountDto.salutation = controls.salutation;
			this.leadObject.dmsAccountDto.firstName = controls.firstName;
			this.leadObject.dmsAccountDto.lastName = controls.lastName;
			this.leadObject.dmsAccountDto.gender = controls.gender;
			this.leadObject.dmsAccountDto.dateOfBirth = Date.parse(controls.dateOfBirth);
			this.leadObject.dmsAccountDto.age = controls.age;
		}
		this.leadObject.dmsLeadDto.firstName = controls.firstName;
		this.leadObject.dmsLeadDto.lastName = controls.lastName;
		this.leadObject.dmsLeadDto.model = this.EnquiryEditForm4.value.model;
		// this.leadObject.dmsLeadDto.dmsExpectedDeliveryDate = Date.parse(controls.expected_delivery_date);
		this.leadObject.dmsLeadDto.dmsAddresses = this.sendCommunicationDetails(this.EnquiryEditForm2.value, this.EnquiryEditForm21.value);
		this.leadObject.dmsLeadDto.dmsLeadProducts = this.sendModelSelection(this.EnquiryEditForm4.value);
		this.leadObject.dmsLeadDto.dmsfinancedetails = this.sendFinanceDetails(this.EnquiryEditForm6.value);
		this.leadObject.dmsLeadDto.dmsAttachments = this.documentsObject;
		this.leadObject.dmsLeadDto.dmsAccessories = this.accessoriesArray;

		this.leadObject.dmsLeadDto.maritalStatus = controls.maritalStatus;
		this.leadObject.dmsLeadDto.documentType = controls.documentType;
		this.leadObject.dmsLeadDto.customerCategoryType = controls.customerCategoryType;
		this.leadObject.dmsLeadDto.gstNumber = controls.gstNumber;
		this.leadObject.dmsLeadDto.otherVehicleType = controls.otherVehicleType;
		this.leadObject.dmsLeadDto.otherVehicleRcNo = controls.otherVehicleRcNo;
		this.leadObject.dmsLeadDto.commitmentDeliveryPreferredDate = Date.parse(controls.commitmentDeliveryPreferredDate);
		this.leadObject.dmsLeadDto.commitmentDeliveryTentativeDate = Date.parse(controls.commitmentDeliveryTentativeDate);
		this.leadObject.dmsLeadDto.occasion = controls.occasion;

		if (!this.leadObject.dmsLeadDto.dmsBooking) {
			this.leadObject.dmsLeadDto.dmsBooking = {};
		}
		this.leadObject.dmsLeadDto.dmsBooking.id = this.leadObject.dmsLeadDto.dmsBooking ? this.leadObject.dmsLeadDto.dmsBooking.id : 0;
		this.leadObject.dmsLeadDto.dmsBooking.bookingAmount = this.PreBookingForm.controls.bookingAmount.value;
		this.leadObject.dmsLeadDto.dmsBooking.paymentAt = this.PreBookingForm.controls.paymentAt.value;
		this.leadObject.dmsLeadDto.dmsBooking.modeOfPayment = this.PreBookingForm.controls.modeOfPayment.value;
		this.leadObject.dmsLeadDto.dmsBooking.leadId = this.leadObject.dmsLeadDto.id;
		this.leadObject.dmsLeadDto.dmsBooking.otherVehicle = this.PreBookingForm.controls.otherVehicle.value;
		this.leadObject.dmsLeadDto.dmsBooking.deliveryLocation = this.PreBookingForm.controls.deliveryLocation.value;

		this.postOnRoadPriceTable.additionalOffer1 = this.PreBookingForm.controls.additionalOffer1.value;
		this.postOnRoadPriceTable.additionalOffer2 = this.PreBookingForm.controls.additionalOffer2.value;
		this.postOnRoadPriceTable.cashDiscount = this.PreBookingForm.controls.cashDiscount.value;
		this.postOnRoadPriceTable.corporateCheck = this.PreBookingForm.controls.corporateCheck.value;
		this.postOnRoadPriceTable.corporateName = this.PreBookingForm.controls.corporateName.value;
		this.postOnRoadPriceTable.corporateOffer = this.slectedCorporateOfferCost;
		this.postOnRoadPriceTable.essentialKit = this.onRoadPrice.essential_kit;
		this.postOnRoadPriceTable.exShowroomPrice = this.onRoadPrice.ex_showroom_price;
		this.postOnRoadPriceTable.offerData = this.offerData;
		this.postOnRoadPriceTable.finalPrice = this.onRoadPriceDiscountCalculator;
		this.postOnRoadPriceTable.focAccessories = this.PreBookingForm.controls.focAccessories.value;
		this.postOnRoadPriceTable.handlingCharges = this.onRoadPrice.handling_charges;
		this.postOnRoadPriceTable.id = this.postOnRoadPriceTable.id ? this.postOnRoadPriceTable.id : 0;
		this.postOnRoadPriceTable.insuranceAddonData = this.insuranceAddonData.value;
		this.postOnRoadPriceTable.insuranceAmount = this.insuranceType;
		this.postOnRoadPriceTable.insuranceType = this.PreBookingForm.controls.insuranceType.value;
		this.postOnRoadPriceTable.lead_id = this.leadObject.dmsLeadDto.id;
		this.postOnRoadPriceTable.lifeTax = this.lifeTaxCal();
		this.postOnRoadPriceTable.onRoadPrice = this.onRoadPriceCalculator;
		this.postOnRoadPriceTable.promotionalOffers = this.PreBookingForm.controls.promotionalOffers.value;
		this.postOnRoadPriceTable.registrationCharges = this.onRoadPrice.registration_charges;
		this.postOnRoadPriceTable.specialScheme = this.PreBookingForm.controls.specialScheme.value;
		this.postOnRoadPriceTable.tcs = (((this.onRoadPrice.ex_showroom_price) > 1000000) ? ((this.onRoadPrice.ex_showroom_price) * ((this.onRoadPrice.tcs_percentage) / 100)) : (this.onRoadPrice.tcs_amount));
		this.postOnRoadPriceTable.warrantyAmount = this.warrantyElement;
		this.postOnRoadPriceTable.warrantyName = this.PreBookingForm.controls.warrantyName.value;

		this.enquiryservice.sendOnRoadPriceDetails(this.postOnRoadPriceTable).subscribe(response => {
			if (!response) {
				return;
			}
			if (response.success === false) {
				this.message = response.message;
				return;
			}
			this.postOnRoadPriceTable.id = response.dmsEntity.dmsOnRoadPriceDto.id;
			this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
				if (res.statusCode !== 500) {
					this.message = '';
					this.leadObject = res.dmsEntity;
					this.documentsObject = this.leadObject.dmsLeadDto.dmsAttachments;
					this.accessoriesArray = this.leadObject.dmsLeadDto.dmsAccessories;
					this.hasSubmitted = false;
					if (this.endAutoSave) {
						if (!this.editEnable) {
							this.leadObject.dmsLeadDto.leadStatus = 'SENTFORAPPROVAL';
						}
						this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
						});
						if (this.statusShow) {
							this.updateStatusMessage();
						}
					}
					this.changedetectorref.detectChanges();
				} else {
					this.hasSubmitted = false;
					this.message = res.message;
					this.gotoTop();
					this.changedetectorref.detectChanges();
				}
			});
		});
	}

	// Loan Amount Calculator
	loanAmountCal() {
		this.EnquiryEditForm6.patchValue({ loanAmount: Math.round(this.onRoadPriceCalculator - this.EnquiryEditForm6.value.downPayment) });
		this.emiCal(this.EnquiryEditForm6.value.loanAmount, this.EnquiryEditForm6.value.expectedTenureYears, this.EnquiryEditForm6.value.rateOfInterest);
	}

	// EMI Calculation
	emiCal(principle, tenure, interestRate) {
		if (principle !== '' && tenure !== '' && interestRate !== '') {
			let P = principle;
			const R = interestRate;
			const N = tenure;
			const monthlyInterstRatio = (R / 100) / 12;
			const top = Math.pow((1 + monthlyInterstRatio), N);
			const bottom = top - 1;
			const sp = top / bottom;
			const emi = ((P * monthlyInterstRatio) * sp);
			const full = N * emi;
			const interest = full - P;
			let int_pge = (interest / full) * 100;
			this.EnquiryEditForm6.patchValue({ emi: Math.round(emi) });
		}
	}

	// Lead Address Object
	sendCommunicationDetails(controls1, controls2) {
		const comData = [
			{
				addressType: 'Communication',
				houseNo: controls1.houseNo,
				street: controls1.street,
				city: controls1.city,
				district: controls1.district,
				pincode: controls1.pincode,
				state: controls1.state,
				village: controls1.village,
				county: 'India',
				rural: (controls1.urban === 'rural') ? true : false,
				urban: (controls1.urban === 'urban') ? true : false,
				id: this.leadObject.dmsLeadDto.dmsAddresses[0] ? this.leadObject.dmsLeadDto.dmsAddresses[0].id : 0
			},
			{
				addressType: 'Permanent',
				houseNo: controls2.houseNo,
				street: controls2.street,
				city: controls2.city,
				district: controls2.district,
				pincode: controls2.pincode,
				state: controls2.state,
				village: controls2.village,
				county: 'India',
				rural: (controls2.urban === 'rural') ? true : false,
				urban: (controls2.urban === 'urban') ? true : false,
				id: this.leadObject.dmsLeadDto.dmsAddresses[1] ? this.leadObject.dmsLeadDto.dmsAddresses[1].id : 0
			}
		];

		return comData;
	}

	// Lead Attachments Number Object
	documentNumber(type, docNumber) {
		const index = this.documentsObject.findIndex(element => element.documentType === type);
		if (index !== -1) {
			this.documentsObject[index].documentNumber = docNumber;
		} else {
			this.tempObjDoc.documentNumber = docNumber;
			this.tempObjDoc.documentType = type;
			this.tempObjDoc.id = 0;
			this.tempObjDoc.branchId = this.loginEmployee.branchId;
			this.tempObjDoc.orgId = this.loginEmployee.orgId;
			this.documentsObject.push(this.tempObjDoc);
		}
	}

	// File Upload for Lead Attachments
	onFileSelect(event, docType, formEle, i) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			this.EnquiryEditForm3.get(formEle).setValue(file.name);
			const formData = new FormData();
			formData.append('file', file);
			formData.append('universalId', this.leadId);
			formData.append('documentType', docType);
			this.enquiryservice.createCustomerDoc(formData).subscribe(res => {
				const index = this.documentsObject.findIndex(element => element.documentType === docType);
				if (index !== -1) {
					this.documentsObject[index].documentPath = res.documentPath;
					this.documentsObject[index].fileName = res.fileName;
					this.documentsObject[index].keyName = res.keyName;
				} else {
					this.tempObjDoc.documentPath = res.documentPath;
					this.tempObjDoc.documentType = docType;
					this.tempObjDoc.fileName = res.fileName;
					this.tempObjDoc.keyName = res.keyName;
					this.tempObjDoc.id = 0;
					this.tempObjDoc.branchId = this.loginEmployee.branchId;
					this.tempObjDoc.orgId = this.loginEmployee.orgId;
					this.tempObjDoc.modifiedBy = this.loginEmployee.empName;
					this.tempObjDoc.ownerName = this.loginEmployee.empName;
					let tempStuctObj = Object.assign({}, this.tempObjDoc);
					this.documentsObject.push(tempStuctObj);
					tempStuctObj = null;
				}
				this.previewURL[i] = res.documentPath;
				this.docKeyNames[i] = res.keyName;
				this.changedetectorref.detectChanges();
			});
		}
	}

	// Delete Documents from S3 Bucket
	deleteDocument(docName, formEle, i) {
		if (docName !== undefined) {
			this.enquiryservice.deleteDocument(docName).subscribe(res => {
				docName = undefined;
			}, (err) => {
				console.log(err);
				docName = undefined;
			});
		}
		this.EnquiryEditForm3.get(formEle).reset();
		this.documentsObject.forEach((element, index) => {
			if (element.documentPath.length === this.previewURL[i].length) {
				this.documentsObject.splice(index, 1);
			}
		});
		this.previewURL[i] = null;
	}

	// Lead Products Object
	sendModelSelection(controls) {
		const objData = [
			{
				color: controls.color,
				model: controls.model,
				fuel: controls.fuel,
				transimmisionType: controls.transimmisionType,
				variant: controls.variant,
				id: this.leadObject.dmsLeadDto.dmsLeadProducts[0] ? this.leadObject.dmsLeadDto.dmsLeadProducts[0].id : 0
			}
		];

		return objData;
	}

	// Lead Finance Details Object
	sendFinanceDetails(controls) {
		const objDataFin = [
			{
				financeType: controls.financeType,
				financeCategory: controls.financeCategory,
				downPayment: controls.downPayment,
				loanAmount: controls.loanAmount,
				financeCompany: controls.financeCompany,
				expectedTenureYears: controls.expectedTenureYears,
				annualIncome: controls.annualIncome,
				location: controls.location,
				rateOfInterest: controls.rateOfInterest,
				emi: controls.emi,
				id: this.leadObject.dmsLeadDto.dmsfinancedetails[0] ? this.leadObject.dmsLeadDto.dmsfinancedetails[0].id : 0
			}
		];

		return objDataFin;
	}

	// Pop-Up To Show Pending Tasks
	pendingTasksStatus() {
		let _title = '';
		_title = 'Pending Tasks';
		const _description = [this.testDrive, this.homeVisit, this.evaluation];
		const dialogRef = this.layoutUtilsService.taskRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.isTestDrive = false;
			this.isHomeVisit = false;
			this.isEvaluation = false;
			this.testDrive = '';
			this.homeVisit = '';
			this.evaluation = '';
			if (!this.popCheck) {
				this.updateStatusMessagePermission();
			} else {
				this.router.navigate(['/lead360']);
				this.popCheck = false;
			}
		});
	}

	// Pop-Up after Submission -- Permission Denied
	updateStatusMessagePermission() {
		let _title = '';
		_title = '';
		const _description = `Permission Denied`;
		const dialogRef = this.layoutUtilsService.updateRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.goBack();
			this.popCheck = false;
		});
	}

	// Pop-Up after PreBooking Submission
	updateStatusMessage() {
		let _title = '';
		if (this.leadObject.dmsLeadDto.leadStatus === 'SENTFORAPPROVAL') {
			_title = 'Successfully Sent for Manager Approval';
		} else if (this.leadObject.dmsLeadDto.leadStage === 'BOOKING') {
			_title = 'Payment Updated Successfully';
		} else if (this.leadObject.dmsLeadDto.leadStage === 'DROPPED') {
			if (this.hasApprover) {
				_title = 'Sent For Approval';
			} else {
				_title = 'Successfully Dropped Lead';
			}
		} else {
			_title = 'PreBooking Updated Successfully';
		}
		const _description = `PreBooking Number: ${this.leadObject.dmsLeadDto.referencenumber}`;
		const dialogRef = this.layoutUtilsService.updateRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			if (this.leadObject.dmsLeadDto.leadStage === 'BOOKING') {
				this.router.navigate(['/booking/booking']);
			} else {
				this.router.navigate(['/preBooking/preBooking']);
			}
		});
	}

	// pincode search Method for Address
	pincodeSearch(event, form) {
		if (event.length === 6) {
			if (this.EnquiryEditForm2.controls.sameAsCommunicationAddress.value !== true) {
				this.enquiryservice.getLocationUsingPincode(event).subscribe(res => {
					form.patchValue({
						state: res[0].PostOffice[0].State,
						district: res[0].PostOffice[0].District
					});
				});
			}
		}
	}

	// Change Vechile Model
	changeVechileModel() {
		const selectedModel = this.EnquiryEditForm4.controls.model.value;
		const promise = new Promise((resolve) => {
			if ((selectedModel !== null) && (selectedModel !== 'Select') && (selectedModel !== '')) {
				resolve();
			}
		});

		promise.then(() => {
			let tempData = this.vechilesData.filter(record => record.model === selectedModel)
				.map(obj => {
					return {
						variantsList: obj.varients,
					};
				})[0];
			tempData = tempData;
			this.variantsList = tempData.variantsList || [];
			this.changeVariant();
			this.showImageCheck = true;
		});
	}

	// Image display based on Model
	swapImage() {
		this.showImageCheck = false;
	}

	// Change Variant
	changeVariant() {
		this.variantRecord = [];
		const selectedVariant = this.EnquiryEditForm4.controls.variant.value;
		const promise = new Promise((resolve) => {
			if ((selectedVariant !== null) && (selectedVariant !== 'Select') && (selectedVariant !== '')) {
				this.variantRecord = this.variantsList.filter(record => record.name === selectedVariant);
				resolve();
			}
		});

		promise.then(() => {
			this.showImageCheck = false;
			this.onRoadPriceDetails();
		});
	}

	// Get vechiles Details
	getVechilesDetails() {
		this._subscription = this.sharedService.vechileDetailsChange.subscribe((value) => {
			this.vechilesData = value;
			this.changeVechileModel();
		});
	}

	// Get OnRoad Price Details
	onRoadPriceDetails() {
		this.enquiryservice.getOnRoadPriceDetails(this.variantRecord[0].id, this.loginEmployee.orgId).subscribe(res => {
			this.onRoadPrice = res;
			(this.onRoadPrice.extended_waranty).forEach(element => {
				if (element.varient_id === this.variantRecord[0].id) {
					this.warranty = element;
				}
			});
			this.enquiryservice.getAllOffers(this.variantRecord[0].vehicleId, this.variantRecord[0].id, this.loginEmployee.orgId).subscribe(res => {
				this.offers = res;
				if ((Array.isArray(this.offers.offerCorporate) === true) && this.offers.offerCorporate.length > 0) {
					this.corporateCheckValue = true;
				} else {
					this.corporateCheckValue = false;
				}
				if ((Array.isArray(this.offers.offerDetails) === true) && this.offers.offerDetails.length > 0) {
					this.offerDetailsCheckValue = true;
					if ((Array.isArray(this.postOnRoadPriceTable.offerData) === true) && this.postOnRoadPriceTable.offerData.length > 0) {
						this.offerData = this.postOnRoadPriceTable.offerData;
						this.offers.offerDetails.forEach(element => {
							this.postOnRoadPriceTable.offerData.forEach(subElement => {
								if (element.offerName === subElement.offerName && element.amount === subElement.offerAmount) {
									element.isSelected = true;
								}
							});
						});
						this.totalSelected = this.offerData.reduce((acc, cur) => acc + (cur.offerAmount || 0), 0);
					}
				} else {
					this.offerDetailsCheckValue = false;
				}
				if (this.postOnRoadPriceTable.corporateCheck) {
					this.offers.offerCorporate.forEach(parElement => {
						parElement.checkboxAllowed = false;
						parElement.offerCorporates.forEach(element => {
							if (element.company === this.postOnRoadPriceTable.corporateName) {
								this.corporateOfferPrice = element.discount_amount;
								parElement.checkboxAllowed = true;
								this.applySelectedCorporateOffer();
							}
						});
					});
				}
				this.onRoadPriceCal();
				this.onRoadPriceDiscountCal();
				this.changeInsuranceValue();
				this.changeAddOnCoversValue();
				this.changeWarrantyValue();
				this.changedetectorref.detectChanges();
			});
		});
	}

	// Get Offers
	offerDetails() {
		this.enquiryservice.getAllOffers(this.variantRecord[0].vehicleId, this.variantRecord[0].id, this.loginEmployee.orgId).subscribe(res => {
			this.offers = res;
			this.changedetectorref.detectChanges();
		});
	}

	// Get Accessories
	accessories() {
		const queryParams = new QueryParamsModel({}, '', '', this.page, this.pageSize);
		this.enquiryservice.getAllAccessories(this.variantRecord[0].vehicleId, this.loginEmployee.orgId, queryParams).subscribe(res => {
			this.accessoriesList = res.accessorylist;
			this.accessoriesList.forEach(element => {
				this.accessoriesArray.forEach(name => {
					if (element.partNo === name.accessoriesName) {
						element.checked = true;
					}
				});
			});
			this.changedetectorref.detectChanges();
		});
	}

	// Change Insurance Value
	changeInsuranceValue() {
		if (this.PreBookingForm.controls.insuranceType.value === '') {
			this.insuranceType = 0;
			this.addOnCovers = 0;
			this.PreBookingForm.patchValue({ addOnCovers: '' });
			this.onRoadPriceCal();
			return;
		}
		(this.onRoadPrice.insurance_vareint_mapping).forEach(element => {
			if (this.PreBookingForm.controls.insuranceType.value === element.policy_name) {
				this.insuranceType = element.cost;
				this.onRoadPriceCal();
				return;
			}
		});
	}

	// Change AddOn Covers Value
	changeAddOnCoversValue() {
		if (this.insuranceAddonData.value === '' || this.insuranceAddonData.value === null) {
			this.addOnCovers = 0;
			this.onRoadPriceCal();
			return;
		}
		this.addOnCovers = 0;
		this.insuranceAddonData.value.forEach(element => {
			this.addOnCovers = this.addOnCovers + parseFloat(element.insuranceAmount);
			this.onRoadPriceCal();
		});
	}

	comparer(o1: any, o2: any): boolean {
		return o1.insuranceAddonName === o2.insuranceAddonName;
	}

	// Change Warranty Value
	changeWarrantyValue() {
		if (this.PreBookingForm.controls.warrantyName.value === '') {
			this.warrantyElement = 0;
			this.onRoadPriceCal();
			return;
		}
		(this.warranty.warranty).forEach(element => {
			if (this.PreBookingForm.controls.warrantyName.value === element.document_name) {
				this.warrantyElement = parseFloat(element.cost);
				this.onRoadPriceCal();
				return;
			}
		});
	}

	// On Road Price Calculator
	onRoadPriceCal() {
		this.onRoadPriceCalculator = (this.onRoadPrice.ex_showroom_price) + (this.lifeTaxCal()) + (this.onRoadPrice.registration_charges) +
			(this.insuranceType) + (this.addOnCovers) + (this.warrantyElement) + (this.onRoadPrice.handling_charges) +
			(this.onRoadPrice.essential_kit) + (((this.onRoadPrice.ex_showroom_price) > 1000000) ? ((this.onRoadPrice.ex_showroom_price) * ((this.onRoadPrice.tcs_percentage) / 100)) : (this.onRoadPrice.tcs_amount)) +
			(this.addSelectedAccessoryCost) + (this.onRoadPrice.fast_tag);
		this.onRoadPriceDiscountCal();
	}

	// Life Tax Calculator
	lifeTaxCal() {
		switch (this.EnquiryEditForm.controls.enquirySegment.value) {
			case 'Handicapped':
				return (this.PreBookingForm.controls.otherVehicle.value) ? 1000 : 500;
			case 'Personal':
				return (this.PreBookingForm.controls.otherVehicle.value) ? ((this.onRoadPrice.ex_showroom_price) * 0.14) : ((this.onRoadPrice.ex_showroom_price) * 0.12);
			default:
				return ((this.onRoadPrice.ex_showroom_price) * 0.14);
		}
	}

	onRoadPriceDiscountCal() {
		this.onRoadPriceDiscountCalculator = this.onRoadPriceCalculator - this.totalSelected -
			((this.PreBookingForm.controls.corporateCheck.value === true) ? this.slectedCorporateOfferCost : 0) -
			((this.PreBookingForm.controls.promotionalOffers.value) ? (this.PreBookingForm.controls.promotionalOffers.value) : 0) -
			((this.PreBookingForm.controls.cashDiscount.value) ? (this.PreBookingForm.controls.cashDiscount.value) : 0) -
			((this.PreBookingForm.controls.focAccessories.value) ? (this.PreBookingForm.controls.focAccessories.value) : 0) -
			((this.PreBookingForm.controls.additionalOffer1.value) ? (this.PreBookingForm.controls.additionalOffer1.value) : 0) -
			((this.PreBookingForm.controls.additionalOffer2.value) ? (this.PreBookingForm.controls.additionalOffer2.value) : 0);
	}

	// UncheckAllCorpSelected
	uncheckAllCorpSelected() {
		this.offers.offerCorporate.forEach(element => {
			element.checkboxAllowed = true;
		});
	}

	// Offer Display calculation
	offerDisplayCal(obj) {
		if (((Date.now() - Date.parse(obj.startDate)) >= 0) && ((Date.parse(obj.end_date) - Date.now())) >= 0) {
			return true;
		} else {
			return false;
		}
	}

	// Offer Display calculation
	offerDisplayCorpCal(obj) {
		if (((Date.now() - Date.parse(obj.startDate)) >= 0) && ((Date.parse(obj.endDate) - Date.now())) >= 0) {
			return true;
		} else {
			return false;
		}
	}

	// Offers Calculation
	totalSelected = 0;
	offerData: any = [];
	applyOffersChecked(applied, selectedOffer) {
		const offerObj = {
			offerAmount: selectedOffer.amount,
			offerCheck: applied,
			offerName: selectedOffer.offerName
		};
		if (applied) {
			this.offerData.push(offerObj);
		} else {
			this.offerData.splice(this.offerData.findIndex(element => ((element.offerName === selectedOffer.offerName) && element.amount === selectedOffer.amount)), 1);
		}
		this.totalSelected = this.offerData.reduce((acc, cur) => acc + (cur.offerAmount || 0), 0);
		this.onRoadPriceDiscountCal();
	}


	// Modal Accessories Method
	openLarge(content) {
		this.accessories();
		this.modalService.open(content, {
			size: 'lg'
		});
	}

	// Other Vehicle Modal
	openLargeOtherVehicle(content) {
		this.modalService.open(content, {
			size: 'lg'
		});
	}

	// Modal Corporate Method
	openLargeCorporate(content, corpElem) {
		this.offers.offerCorporate.forEach(element => {
			if (element.name === corpElem.name) {
				element.checkboxAllowed = true;
			} else {
				element.checkboxAllowed = false;
			}
		});
		this.slectedCorporateElem = corpElem;
		this.modalService.open(content, {
			size: 'lg'
		});
	}

	tempAccessories = {
		id: 0,
		amount: 0,
		accessoriesName: "",
		leadId: 0
	}

	checkedArray = [];
	// Accessories Cost
	addAccessoriesCost(event, accessory) {
		if (event.checked === true) {
			this.checkedArray.push(accessory.id);
			this.tempAccessories.amount = accessory.cost;
			this.tempAccessories.accessoriesName = accessory.partNo;
			this.tempAccessories.leadId = this.leadObject.dmsLeadDto.id;
			let tempStuctObj = Object.assign({}, this.tempAccessories)
			this.accessoriesArray.push(tempStuctObj);
		} else {
			this.accessoriesArray.forEach((element, index) => {
				if (element.accessoriesName === accessory.partNo) {
					this.accessoriesArray.splice(index, 1);
				}
			});
			this.checkedArray.forEach((element, index) => {
				if (element === accessory.id) {
					this.checkedArray.splice(index, 1);
				}
			});
		}
		this.accessoryCost = this.accessoryCost + ((event.checked === true) ? accessory.cost : (-(accessory.cost)));
	}

	// Modal Add Selected method
	addSelectedAccessory() {
		this.addSelectedAccessoryCost = this.accessoryCost;
		this.onRoadPriceCal();
		this.modalService.dismissAll();
	}

	// Radio Button Selected Offer
	selectedCorporateOffer(price) {
		this.corporateOfferPrice = price;
	}

	// Modal Apply offer method
	applySelectedCorporateOffer() {
		this.slectedCorporateOfferCost = this.corporateOfferPrice;
		this.onRoadPriceDiscountCal();
		this.modalService.dismissAll();
	}

	// Reset Corporate offer checkBox Value
	resetValue() {
		this.PreBookingForm.patchValue({ corporateCheck: false });
		this.onRoadPriceDiscountCal();
	}

	// Save Other vehicle details
	saveOtherVehicleDetails() {
		this.modalService.dismissAll();
	}

	// Reset Other vehicle checkBox value
	resetOtherVehicle() {
		this.PreBookingForm.patchValue({ otherVehicle: false });
		this.EnquiryEditForm.patchValue({ otherVehicleType: '', otherVehicleRcNo: '' });
		this.onRoadPriceCal();
	}

	dropEnquiry() {
		this.dropClicked = true;
	}

	// Proceed to Drop
	proceedToCancel() {
		this.dropLeadDetails.dmsLeadDropInfo.additionalRemarks = this.DropEnquiryForm.value.additionalRemarks;
		this.dropLeadDetails.dmsLeadDropInfo.branchId = this.loginEmployee.branchId;
		this.dropLeadDetails.dmsLeadDropInfo.brandName = this.DropEnquiryForm.value.brandName;
		this.dropLeadDetails.dmsLeadDropInfo.dealerName = this.DropEnquiryForm.value.dealerName;
		this.dropLeadDetails.dmsLeadDropInfo.enquiryCategory = this.DropEnquiryForm.value.enquiryCategory;
		this.dropLeadDetails.dmsLeadDropInfo.leadId = this.leadObject.dmsLeadDto.id;
		this.dropLeadDetails.dmsLeadDropInfo.crmUniversalId = this.leadId;
		this.dropLeadDetails.dmsLeadDropInfo.lostReason = this.DropEnquiryForm.value.dropReason;
		this.dropLeadDetails.dmsLeadDropInfo.organizationId = this.loginEmployee.orgId;
		this.dropLeadDetails.dmsLeadDropInfo.otherReason = '';
		this.dropLeadDetails.dmsLeadDropInfo.droppedBy = this.loginEmployee.empId;
		this.dropLeadDetails.dmsLeadDropInfo.location = this.DropEnquiryForm.value.location;
		this.dropLeadDetails.dmsLeadDropInfo.model = this.DropEnquiryForm.value.model;
		this.dropLeadDetails.dmsLeadDropInfo.stage = 'PREBOOKING';
		this.dropLeadDetails.dmsLeadDropInfo.status = 'PREBOOKING';
		this.enquiryservice.sendDropDetails(this.dropLeadDetails).subscribe(res => {
			if (res.statusCode === '200') {
				this.leadObject.dmsLeadDto.leadStage = 'DROPPED';
				this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
				});
			}
			if (res.approver === this.loginEmployee.empName) {
				this.hasApprover = false;
				this.lead360Service.getAllTasksByUniversalId(this.leadId);
				this.updateStatusMessage();
			} else {
				this.hasApprover = true;
				this.lead360Service.getAllApprovalTasksByUniversalId(this.leadId);
				this.updateStatusMessage();
			}
		});
	}

	managerApprove() {
		this.leadObject.dmsLeadDto.leadStatus = 'PREBOOKINGCOMPLETED';
		this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
			this.goBack();
		});
	}

	managerReject() {
		if (this.displayRemarks === true) {
			this.leadObject.dmsLeadDto.leadStatus = 'REJECTED';
			this.leadObject.dmsLeadDto.remarks = this.EnquiryEditForm.controls.remarks.value;
			this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
				this.goBack();
			});
		}

		this.displayRemarks = true;
		this.EnquiryEditForm.get('remarks').enable({ onlySelf: true });
	}

	goBack() {
		this.router.navigate(['/preBooking/preBooking']);
	}

	gotoTop() {
		window.scroll({
			top: 0,
			left: 0,
			behavior: 'smooth'
		});
	}
}
