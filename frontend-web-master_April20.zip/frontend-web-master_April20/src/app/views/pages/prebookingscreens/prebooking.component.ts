import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'kt-prebooking',
    templateUrl: './prebooking.component.html'
})
export class PrebookingMainComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
