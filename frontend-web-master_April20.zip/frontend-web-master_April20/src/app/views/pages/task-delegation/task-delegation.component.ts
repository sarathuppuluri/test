import { ChangeDetectorRef, Component, OnInit } from "@angular/core";
import { truncate } from "lodash";
import { BranchService } from "../../../core/e-commerce";

@Component({
	selector: "kt-task-delegation",
	templateUrl: "./task-delegation.component.html",
	styleUrls: ["./task-delegation.component.scss"],
})
export class TaskDelegationComponent implements OnInit {
	departmentDesignation: any;
	employeesFrom = [];
	employeesTo = [];

	constructor(
		private branchService: BranchService,
		private changedetectorref: ChangeDetectorRef
	) {}

	message = "";
	userName = "";
	loginEmployee: any;
	department;
	designationFrom;
	designationTo;
	empFrom;
	empTo;
	submitButCheck = false;

	ngOnInit() {
		this.userName = JSON.parse(
			localStorage.getItem("loginEmployee")
		).empName;
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.loadDepartAndDesig();
	}

	/**
	 * Load Department and Designation
	 */
	loadDepartAndDesig() {
		this.branchService
			.getDepartmentDesignation(
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe(
				(res) => {
					this.departmentDesignation = res.dmsEntity;
				},
				(error) => {
					console.log(error);
				}
			);
	}

	/**
	 * Load Employees Based on Department and Designation
	 */
	loadEmployeesFrom() {
		if (
			this.department === "" ||
			this.department === undefined ||
			this.designationFrom === "" ||
			this.designationFrom === undefined
		) {
			this.message = "";
			this.submitButCheck = false;
			this.changedetectorref.detectChanges();
			return;
		}

		this.branchService
			.getEmpLowLevel(
				this.loginEmployee.orgId,
				this.loginEmployee.branchId,
				this.department,
				this.designationFrom
			)
			.subscribe(
				(res) => {
					if (res.success === false) {
						this.employeesFrom = [];
						this.message = res.errorMessage;
						this.submitButCheck = false;
						this.changedetectorref.detectChanges();
						return;
					}
					this.message = "";
					this.employeesFrom = res.dmsEntity.employees;
					this.changedetectorref.detectChanges();
				},
				(error) => {
					console.log(error);
				}
			);

		if (
			this.empFrom === "" ||
			this.empFrom === undefined ||
			this.empTo === "" ||
			this.empTo === undefined
		) {
			this.submitButCheck = false;
		} else {
			this.submitButCheck = true;
		}
	}

	loadEmployeesTo() {
		if (
			this.department === "" ||
			this.department === undefined ||
			this.designationTo === "" ||
			this.designationTo === undefined
		) {
			this.message = "";
			this.submitButCheck = false;
			this.changedetectorref.detectChanges();
			return;
		}

		this.branchService
			.getEmpLowLevel(
				this.loginEmployee.orgId,
				this.loginEmployee.branchId,
				this.department,
				this.designationTo
			)
			.subscribe(
				(res) => {
					if (res.success === false) {
						this.employeesTo = [];
						this.message = res.errorMessage;
						this.submitButCheck = false;
						this.changedetectorref.detectChanges();
						return;
					}
					this.message = "";
					this.employeesTo = res.dmsEntity.employees;
					this.changedetectorref.detectChanges();
				},
				(error) => {
					console.log(error);
				}
			);

		if (
			this.empFrom === "" ||
			this.empFrom === undefined ||
			this.empTo === "" ||
			this.empTo === undefined
		) {
			this.submitButCheck = false;
		} else {
			this.submitButCheck = true;
		}
	}

	/**
	 * Send Task Delegation Employees
	 */
	sendTaskDelegateEmployees() {
		this.branchService
			.sendEmpTransfer(this.empFrom, this.empTo)
			.subscribe((res) => {
				if (res.success === true) {
					this.message = "Transferred Successfully";
					this.submitButCheck = false;
					this.changedetectorref.detectChanges();
				}
			});
	}
}
