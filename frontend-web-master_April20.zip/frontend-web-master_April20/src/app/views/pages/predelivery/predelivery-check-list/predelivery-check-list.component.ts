import { Component, ElementRef, OnInit, OnDestroy, ViewChild, ChangeDetectorRef, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgControlStatus } from '@angular/forms';
import { EnquiryService, SharedService, MyRolesService, Lead360Service } from '../../../../core/e-commerce/_services';
import { ActivatedRoute, Router } from '@angular/router';
import { LayoutUtilsService } from '../../../../core/_base/crud/utils/layout-utils.service';
import { QueryParamsModel } from '../../../../core/_base/crud';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';

@Component({
	selector: 'kt-predelivery-check-list',
	templateUrl: './predelivery-check-list.component.html',
	styleUrls: ['./predelivery-check-list.component.scss']
})
export class PredeliveryCheckListComponent implements OnInit, OnDestroy {
	loginEmployee: any;
	dropClicked = false;
	dropLeadDetails: any = { dmsLeadDropInfo: {} };
	message: string;
	@Input() id: string;

	// Subscriptions
	private subscriptions: Subscription[] = [];

	constructor(private fb: FormBuilder, private enquiryservice: EnquiryService, private routeData: ActivatedRoute,
		private layoutUtilsService: LayoutUtilsService,
		private sharedService: SharedService,
		private myroleService: MyRolesService,
		private lead360Service: Lead360Service,
		private router: Router,
		private changedetectorref: ChangeDetectorRef,
		private modalService: NgbModal) {
	}

	EnquiryEditForm3: FormGroup;
	DropEnquiryForm: FormGroup;

	hasFormErrors = false;

	submitted = false;
	leadId = '';

	hasSubmitted = false;
	endAutoSave = false;
	statusShow = false;

	leadObject: any = {};

	documentsObject = [];
	// Lead Attachments Object
	tempObjDoc = {
		branchId: '',
		contentSize: 0,
		createdBy: Date.now(),
		description: '',
		documentNumber: '',
		documentPath: '',
		documentType: '',
		documentVersion: 0,
		fileName: '',
		gstNumber: '',
		id: 0,
		isActive: 0,
		isPrivate: 0,
		keyName: '',
		modifiedBy: '',
		orgId: '',
		ownerId: '',
		ownerName: '',
		parentId: '',
		tinNumber: ''
	};

	previewURL = [];
	docKeyNames = [];

	docsPath: any = {};

	popCheck = false;
	testDrive = '';
	homeVisit = '';
	evaluation = '';
	isTestDrive = false;
	isHomeVisit = false;
	isEvaluation = false;

	ngOnInit() {
		this.leadId = (this.id === null || this.id === undefined || this.id === '') ? this.routeData.snapshot.paramMap.get('id') : this.id;;
		this.endAutoSave = false;
		this.statusShow = false;
		this.enquiryForm();
		this.getLeadDetailsUniversalId();
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
	}

	ngOnDestroy(): void {
		// Called once, before the instance is destroyed.
		// Add 'implements OnDestroy' to the class.
		this.endAutoSave = true;
		this.statusShow = false;
		this.subscriptions.forEach(el => el.unsubscribe());
	}

	enquiryForm() {
		this.EnquiryEditForm3 = this.fb.group({
			pan: [''],
			panFileName: [''],
			aadhar: [''],
			aadharFileName: [''],
			employeeId: [''],
			employeeIdFileName: [''],
			payslips: [''],
			payslipsFileName: [''],
			relationshipProof: [''],
			relationshipProofFileName: [''],
			receipt: [''],
			receiptFileName: [''],
			hsrp: [''],
			hsrpFileName: [''],
			registration: [''],
			registrationFileName: [''],
			tcs: [''],
			tcsFileName: [''],
			oldpan: [''],
			oldpanFileName: [''],
			oldaadhar: [''],
			oldaadharFileName: [''],
			oldrcfront: [''],
			oldrcfrontFileName: [''],
			oldrcback: [''],
			oldrcbackFileName: [''],
			pencilprintold: [''],
			pencilprintoldFileName: [''],
			oldinsurance: [''],
			oldinsuranceFileName: [''],
			bregister: [''],
			bregisterFileName: [''],
			draft: [''],
			draftFileName: [''],
			managerletter: [''],
			managerletterFileName: [''],
			pencilprint: [''],
			pencilprintFileName: ['']
		});

		this.DropEnquiryForm = this.fb.group({
			dropReason: [''],
			dealerName: [''],
			brandName: [''],
			otherReason: [''],
			additionalRemarks: [''],
			location: [''],
			model: ['']
		});
	}

	/**
	* Checking control validation
	*
	* @param controlName: string => Equals to formControlName
	* @param validationType: string => Equals to valitors name
	*/
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.EnquiryEditForm3.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}

	onSubmit() {
		this.hasSubmitted = true;
		this.endAutoSave = true;
		this.statusShow = true;
		this.updateLeadDetails(this.EnquiryEditForm3.value);
	}

	proceedToDelivery() {
		this.myroleService.getAllTasksUniversalID(this.leadId, 'Pre Delivery').subscribe(taskRes => {
			taskRes.dmsEntity.tasks.forEach((element) => {
				if (element.universalId === this.leadId && element.taskName === 'Proceed to Delivery') {
					this.lead360Service.selectedTaskObj = element;
					this.router.navigate(['/lead360']);
					return;
				}
			});
		});
	}

	// Get Lead Details By UniversalID
	getLeadDetailsUniversalId() {
		this.enquiryservice.getLeadByUniversalID(this.leadId).subscribe(res => {
			if (!res) {
				return;
			}
			this.leadObject = res.dmsEntity;
			if (this.leadObject.dmsLeadDto.dmsAttachments.length > 0) {
				this.documentsObject = this.leadObject.dmsLeadDto.dmsAttachments;
				const customerDocs = this.leadObject.dmsLeadDto.dmsAttachments.reduce((acc, record) => {
					acc[record.documentType] = (record.documentNumber === '' ? record.fileName : record.documentNumber);
					acc[record.documentType + 'doc'] = record.documentPath;
					acc[record.documentType + 'key'] = record.keyName;
					return acc;
				}, {});
				const test = {
					panFileName: customerDocs.pan,
					aadharFileName: customerDocs.aadhar,
					employeeIdFileName: customerDocs.employeeId,
					payslipsFileName: customerDocs.payslips,
					relationshipProofFileName: customerDocs.relationshipProof,
					receiptFileName: customerDocs.receipt,
					hsrpFileName: customerDocs.hsrp,
					registrationFileName: customerDocs.registration,
					tcsFileName: customerDocs.tcs,
					oldpanFileName: customerDocs.oldpan,
					oldaadharFileName: customerDocs.oldaadhar,
					oldrcfrontFileName: customerDocs.oldrcfront,
					oldrcbackFileName: customerDocs.oldrcback,
					pencilprintoldFileName: customerDocs.pencilprintold,
					oldinsuranceFileName: customerDocs.oldinsurance,
					bregisterFileName: customerDocs.bregister,
					draftFileName: customerDocs.draft,
					managerletterFileName: customerDocs.managerletter,
					pencilprintFileName: customerDocs.pencilprint
				};
				this.docsPath = {
					panDocPath: customerDocs.pandoc,
					panKey: customerDocs.pankey,
					aadharDocPath: customerDocs.aadhardoc,
					aadharKey: customerDocs.aadharkey,
					employeeIdDocPath: customerDocs.employeeIddoc,
					employeeIdKey: customerDocs.employeeIdkey,
					payslipsDocPath: customerDocs.payslipsdoc,
					payslipsKey: customerDocs.payslipskey,
					relationshipProofDocPath: customerDocs.relationshipProofdoc,
					relationshipProofkey: customerDocs.relationshipProofkey,
					receiptDocPath: customerDocs.receiptdoc,
					receiptKey: customerDocs.receiptkey,
					hsrpDocPath: customerDocs.hsrpdoc,
					hsrpKey: customerDocs.hsrpkey,
					registrationDocPath: customerDocs.registrationdoc,
					registrationKey: customerDocs.registrationkey,
					tcsDocPath: customerDocs.tcsdoc,
					tcsKey: customerDocs.tcskey,
					oldpanDocPath: customerDocs.oldpandoc,
					oldpanKey: customerDocs.oldpankey,
					oldaadharDocPath: customerDocs.oldaadhardoc,
					oldaadharKey: customerDocs.oldaadharkey,
					oldrcfrontDocPath: customerDocs.oldrcfrontdoc,
					oldrcfrontKey: customerDocs.oldrcfrontkey,
					oldrcbackDocPath: customerDocs.oldrcbackdoc,
					oldrcbackKey: customerDocs.oldrcbackkey,
					pencilprintoldDocPath: customerDocs.pencilprintolddoc,
					pencilprintoldKey: customerDocs.pencilprintoldkey,
					oldinsuranceDocPath: customerDocs.oldinsurancedoc,
					oldinsuranceKey: customerDocs.oldinsurancekey,
					bregisterDocPath: customerDocs.bregisterdoc,
					bregisterKey: customerDocs.bregisterkey,
					draftDocPath: customerDocs.draftdoc,
					draftKey: customerDocs.draftkey,
					managerletterDocPath: customerDocs.managerletterdoc,
					managerletterKey: customerDocs.managerletterkey,
					pencilprintDocPath: customerDocs.pencilprintdoc,
					pencilprintKey: customerDocs.pencilprintkey
				};
				this.previewURL[1] = this.docsPath.panDocPath;
				this.previewURL[2] = this.docsPath.aadharDocPath;
				this.previewURL[4] = this.docsPath.employeeIdDocPath;
				this.previewURL[5] = this.docsPath.payslipsDocPath;
				this.previewURL[11] = this.docsPath.receiptDocPath;
				this.previewURL[12] = this.docsPath.relationshipProofDocPath;
				this.previewURL[13] = this.docsPath.hsrpDocPath;
				this.previewURL[14] = this.docsPath.registrationDocPath;
				this.previewURL[15] = this.docsPath.tcsDocPath;
				this.previewURL[16] = this.docsPath.oldpanDocPath;
				this.previewURL[17] = this.docsPath.oldaadharDocPath;
				this.previewURL[18] = this.docsPath.oldrcfrontDocPath;
				this.previewURL[19] = this.docsPath.oldrcbackDocPath;
				this.previewURL[20] = this.docsPath.pencilprintoldDocPath;
				this.previewURL[21] = this.docsPath.oldinsuranceDocPath;
				this.previewURL[22] = this.docsPath.bregisterDocPath;
				this.previewURL[23] = this.docsPath.draftDocPath;
				this.previewURL[24] = this.docsPath.managerletterDocPath;
				this.previewURL[25] = this.docsPath.pencilprintDocPath;
				this.EnquiryEditForm3.patchValue(test);
			}

			if (this.leadObject.dmsLeadDto.leadStatus === 'PREDELIVERYCOMPLETED') {
				// Lead360 Tasks
				this.myroleService.getAllTasksUniversalID(this.leadId, 'Pre Delivery').subscribe(taskRes => {
					taskRes.dmsEntity.tasks.forEach((element) => {
						if (element.taskName === 'Test Drive' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')) {
							this.testDrive = 'Test Drive : Pending';
							this.isTestDrive = true;
						}
						if (element.taskName === 'Home Visit' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')) {
							this.homeVisit = 'Home Visit : Pending';
							this.isHomeVisit = true;
						}
						if (element.taskName === 'Evaluation' && (element.taskStatus === '' || element.taskStatus === 'ASSIGNED')
							&& this.leadObject.dmsLeadDto.buyerType === 'Replacement Buyer') {
							this.evaluation = 'Evaluation : Pending';
							this.isEvaluation = true;
						}

						if (element.universalId === this.leadId && element.taskName === 'Proceed to Delivery'
							&& element.assignee.empId === this.loginEmployee.empId) {
							this.lead360Service.selectedTaskObj = element;
							// this.router.navigate(['/lead360']);
							this.popCheck = true;
							return;
						}
					});
				});
			}
		});
	}

	// Post Lead Details
	updateLeadDetails(controls) {
		this.leadObject.dmsLeadDto.dmsAttachments = this.documentsObject;

		this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
			if (res.statusCode !== 500) {
				this.message = '';
				this.leadObject = res.dmsEntity;
				this.documentsObject = this.leadObject.dmsLeadDto.dmsAttachments;
				this.hasSubmitted = false;
				if (this.endAutoSave) {
					this.leadObject.dmsLeadDto.leadStatus = 'PREDELIVERYCOMPLETED';
					this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(response => {
					});
					if (this.statusShow) {
						this.updateStatusMessage('PreDeliveryCheckList Updated Successfully');
					}
				}
				this.changedetectorref.detectChanges();
			} else {
				this.hasSubmitted = false;
				this.message = res.message;
				this.gotoTop();
				this.changedetectorref.detectChanges();
			}
		});
	}

	// Lead Attachments Number Object
	documentNumber(type, docNumber) {
		const index = this.documentsObject.findIndex(element => element.documentType === type);
		if (index !== -1) {
			this.documentsObject[index].documentNumber = docNumber;
		} else {
			this.tempObjDoc.documentNumber = docNumber;
			this.tempObjDoc.documentType = type;
			this.tempObjDoc.id = 0;
			this.tempObjDoc.branchId = this.loginEmployee.branchId;
			this.tempObjDoc.orgId = this.loginEmployee.orgId;
			this.documentsObject.push(this.tempObjDoc);
		}
	}

	// File Upload for Lead Attachments
	onFileSelect(event, docType, formEle, i) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			this.EnquiryEditForm3.get(formEle).setValue(file.name);
			const formData = new FormData();
			formData.append('file', file);
			formData.append('universalId', this.leadId);
			formData.append('documentType', docType);
			this.enquiryservice.createCustomerDoc(formData).subscribe(res => {
				const index = this.documentsObject.findIndex(element => element.documentType === docType);
				if (index !== -1) {
					this.documentsObject[index].documentPath = res.documentPath;
					this.documentsObject[index].fileName = res.fileName;
					this.documentsObject[index].keyName = res.keyName;
				} else {
					this.tempObjDoc.documentPath = res.documentPath;
					this.tempObjDoc.documentType = docType;
					this.tempObjDoc.fileName = res.fileName;
					this.tempObjDoc.keyName = res.keyName;
					this.tempObjDoc.id = 0;
					this.tempObjDoc.branchId = this.loginEmployee.branchId;
					this.tempObjDoc.orgId = this.loginEmployee.orgId;
					this.tempObjDoc.modifiedBy = this.loginEmployee.empName;
					this.tempObjDoc.ownerName = this.loginEmployee.empName;
					let tempStuctObj = Object.assign({}, this.tempObjDoc);
					this.documentsObject.push(tempStuctObj);
					tempStuctObj = null;
				}
				this.previewURL[i] = res.documentPath;
				this.docKeyNames[i] = res.keyName;
				this.changedetectorref.detectChanges();
			});
		}
	}

	// Delete Documents from S3 Bucket
	deleteDocument(docName, formEle, i) {

		if (docName !== undefined) {
			this.enquiryservice.deleteDocument(docName).subscribe(res => {
				docName = undefined;
			}, (err) => {
				console.log(err);
				docName = undefined;
			});
		}
		this.EnquiryEditForm3.get(formEle).reset();
		this.documentsObject.forEach((element, index) => {
			if (element.documentPath.length === this.previewURL[i].length) {
				this.documentsObject.splice(index, 1);
			}
		});
		this.previewURL[i] = null;
	}

	// Pop-Up To Show Pending Tasks
	pendingTasksStatus() {
		let _title = '';
		_title = 'Pending Tasks';
		const _description = [this.testDrive, this.homeVisit, this.evaluation];
		const dialogRef = this.layoutUtilsService.taskRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.isTestDrive = false;
			this.isHomeVisit = false;
			this.isEvaluation = false;
			this.testDrive = '';
			this.homeVisit = '';
			this.evaluation = '';
			if (!this.popCheck) {
				this.updateStatusMessagePermission();
			} else {
				this.router.navigate(['/lead360']);
				this.popCheck = false;
			}
		});
	}

	// Pop-Up after Submission -- Permission Denied
	updateStatusMessagePermission() {
		let _title = '';
		_title = '';
		const _description = `Permission Denied`;
		const dialogRef = this.layoutUtilsService.updateRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.goBack();
			this.popCheck = false;
		});
	}

	// Pop-Up after Enquiry Submission
	updateStatusMessage(msg) {
		let _title = msg;
		const _description = `PreDelivery Number: ${this.leadObject.dmsLeadDto.referencenumber}`;
		const dialogRef = this.layoutUtilsService.updateRoute(_title, _description);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.router.navigate(['/preDelivery/preDelivery']);
		});
	}

	dropEnquiry() {
		this.dropClicked = true;
	}

	// Proceed to Drop
	proceedToCancel() {
		this.dropLeadDetails.dmsLeadDropInfo.additionalRemarks = this.DropEnquiryForm.value.additionalRemarks;
		this.dropLeadDetails.dmsLeadDropInfo.branchId = this.loginEmployee.branchId;
		this.dropLeadDetails.dmsLeadDropInfo.brandName = this.DropEnquiryForm.value.brandName;
		this.dropLeadDetails.dmsLeadDropInfo.dealerName = this.DropEnquiryForm.value.dealerName;
		this.dropLeadDetails.dmsLeadDropInfo.enquiryCategory = this.DropEnquiryForm.value.enquiryCategory;
		this.dropLeadDetails.dmsLeadDropInfo.leadId = this.leadObject.dmsLeadDto.id;
		this.dropLeadDetails.dmsLeadDropInfo.crmUniversalId = this.leadId;
		this.dropLeadDetails.dmsLeadDropInfo.lostReason = this.DropEnquiryForm.value.dropReason;
		this.dropLeadDetails.dmsLeadDropInfo.organizationId = this.loginEmployee.orgId;
		this.dropLeadDetails.dmsLeadDropInfo.otherReason = '';
		this.dropLeadDetails.dmsLeadDropInfo.droppedBy = this.loginEmployee.empId;
		this.dropLeadDetails.dmsLeadDropInfo.location = this.DropEnquiryForm.value.location;
		this.dropLeadDetails.dmsLeadDropInfo.model = this.DropEnquiryForm.value.model;
		this.dropLeadDetails.dmsLeadDropInfo.stage = 'PREDELIVERY';
		this.dropLeadDetails.dmsLeadDropInfo.status = 'PREDELIVERY';
		const sendDropDet = this.enquiryservice.sendDropDetails(this.dropLeadDetails).subscribe(res => {
			if (res.statusCode === '200') {
				this.leadObject.dmsLeadDto.leadStage = 'DROPPED';
				const sendLeadEnq = this.enquiryservice.sendLeadEnquiryDetails(this.leadObject).subscribe(res => {
				});
				this.subscriptions.push(sendLeadEnq);
			}
			if (res.approver === this.loginEmployee.empName) {
				this.lead360Service.getAllTasksByUniversalId(this.leadId);
				this.updateStatusMessage('Successfully Dropped Lead');
			} else {
				this.lead360Service.getAllApprovalTasksByUniversalId(this.leadId);
				this.updateStatusMessage('Sent For Approval');
			}
		});
		this.subscriptions.push(sendDropDet);
	}

	goBack() {
		this.router.navigate(['/preDelivery/preDelivery']);
	}

	gotoTop() {
		window.scroll({
			top: 0,
			left: 0,
			behavior: 'smooth'
		});
	}
}
