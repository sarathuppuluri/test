// Angular
import { NgModule, } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
// Metronic
import { PartialsModule } from '../../partials/partials.module';
import { CoreModule } from '../../../core/core.module';
import { UpdateEntityDialogComponent, TaskEntityDialogComponent } from '../../partials/content/crud';
// Material   // Imported By Me...
import {
    MatInputModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSortModule,
    MatTableModule,
    MatSelectModule,
    MatMenuModule,
    MatProgressBarModule,
    MatButtonModule,
    MatCheckboxModule,
    MatDialogModule,
    MatTabsModule,
    MatNativeDateModule,
    MatCardModule,
    MatRadioModule,
    MatIconModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MAT_DIALOG_DEFAULT_OPTIONS,
    MatSnackBarModule,
    MatTooltipModule,
    MatExpansionModule,
    MAT_DATE_LOCALE
} from '@angular/material';
import { NgbAlertConfig, NgbModule } from '@ng-bootstrap/ng-bootstrap';
// Components
import { PredeliveryMainComponent } from './predeliverymain.component';
import { PredeliverylistviewComponent } from './predeliverylistview/predeliverylistview.component';
import { PredeliveryCheckListComponent } from './predelivery-check-list/predelivery-check-list.component';

@NgModule({
    declarations: [
        PredeliveryMainComponent,
        PredeliverylistviewComponent,
        PredeliveryCheckListComponent
	],
	exports: [PredeliveryCheckListComponent],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PartialsModule,
        CoreModule,
        HttpClientModule,
        MatInputModule,
        MatPaginatorModule,
        MatProgressSpinnerModule,
        MatSortModule,
        MatTableModule,
        MatSelectModule,
        MatMenuModule,
        MatProgressBarModule,
        MatButtonModule,
        MatCheckboxModule,
        MatDialogModule,
        MatTabsModule,
        MatNativeDateModule,
        MatCardModule,
        MatRadioModule,
        MatIconModule,
        MatDatepickerModule,
        MatAutocompleteModule,
        MatSnackBarModule,
        MatTooltipModule,
        MatExpansionModule,
        NgbModule,
        RouterModule.forChild([
            {
                path: '',
                component: PredeliveryMainComponent,
                children: [
                    {
                        path: 'preDelivery',
                        component: PredeliverylistviewComponent
                    },
                    {
                        path: 'preDelivery/:id',
                        component: PredeliveryCheckListComponent
                    }
                ]
            },
        ])
    ],
    entryComponents: [
        UpdateEntityDialogComponent,
		TaskEntityDialogComponent
    ],
    providers: [
        NgbAlertConfig,
        { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
        {
            provide: MAT_DIALOG_DEFAULT_OPTIONS,
            useValue: {
                hasBackdrop: true,
                panelClass: 'kt-mat-dialog-container__wrapper',
                height: 'auto',
                width: '900px'
            }
        }
    ]
})
export class PredeliveryModule { }
