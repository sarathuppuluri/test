import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'kt-predelivery',
    templateUrl: './predeliverymain.component.html'
})
export class PredeliveryMainComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
