import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredeliverylistviewComponent } from './predeliverylistview.component';

describe('PredeliverylistviewComponent', () => {
  let component: PredeliverylistviewComponent;
  let fixture: ComponentFixture<PredeliverylistviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredeliverylistviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredeliverylistviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
