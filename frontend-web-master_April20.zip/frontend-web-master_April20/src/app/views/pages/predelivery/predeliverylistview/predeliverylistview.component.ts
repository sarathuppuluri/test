import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PreenquiryService } from '../../../../core/e-commerce/_services/pre-enquiry.service';
import { MatDialog, MatSort } from '@angular/material';
import { MessageType, LayoutUtilsService, QueryParamsModel } from '../../../../core/_base/crud';
import { EnquiryService } from '../../../../core/e-commerce/_services/enquiry.service';
import * as XLSX from 'xlsx';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';

@Component({
	selector: 'kt-predeliverylistview',
	templateUrl: './predeliverylistview.component.html',
	styleUrls: ['./predeliverylistview.component.scss']
})
export class PredeliverylistviewComponent implements OnInit {
	loginEmployee: any;
	constructor(private router: Router,
		private formBuilder: FormBuilder,
		private preEnquiryService: PreenquiryService,
		private enquiryService: EnquiryService,
		private changeDetectorRef: ChangeDetectorRef,
		private dialog: MatDialog,
		private layoutUtilsService: LayoutUtilsService) { }

	searchFormGroup: FormGroup;
	message = '';
	name = '';
	mobileNumber: number;
	leads = [];
	initialLeads = [];
	toLoad: boolean;
	isLoaded = false;
	hasFormErrors: boolean;
	isLoading = false;
	page = 0;
	pageSize = 10;
	searchPage = 0;
	searchPageSize = 10;
	scope: any = {};

	searchProgress = false;


	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.searchForm();
		// this.loadLeadsShowroomById();
		this.getAllLeadsByStatus();
	}

	// Get All Leads By Status
	getAllLeadsByStatus() {
		this.isLoading = true;
		this.message = '';
		const queryParams = new QueryParamsModel({}, '', '', this.page, this.pageSize);
		this.preEnquiryService.getAllLeadsByStatus('PREDELIVERY', queryParams, this.loginEmployee.empId).subscribe(res => {
			if (res.status === 500 || res.status === 400 || res.statusCode === 500 || res.statusCode === 400) {
				this.message = res.message;
				this.isLoading = false;
			} else {
				this.toLoad = true;
				this.isLoading = false;
				this.scope = res.dmsEntity.leadDtoPage;
				if (this.scope.totalElements === 0) {
					this.message = 'No Leads Found';
				}
				this.initialLeads = res.dmsEntity.leadDtoPage.content;
			}
			this.changeDetectorRef.detectChanges();
		});
	}

	//   loadLeadsShowroomById() {
	//     this.isLoading = true;
	//     const queryParams = new QueryParamsModel({}, '', '', this.page, this.pageSize);
	//     this.preEnquiryService.leadsShowroomByID(1, 12, 'Enquiry', queryParams).subscribe(res => {
	//       if (res.statusCode === 204) {
	//         this.message = res.message;
	//         this.isLoading = false;
	//       }
	//       if (res.status === 500) {
	//         this.message = res.error;
	//         this.isLoading = false;
	//       }
	//       this.initialLeads = res.content;
	//       this.toLoad = true;
	//       this.isLoading = false;
	//       this.scope = res;
	//       this.changeDetectorRef.detectChanges();
	//     });
	//   }

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		// this.loadLeadsShowroomById();
		this.getAllLeadsByStatus();
	}

	searchPaginatorEvents(event) {
		this.searchPage = event.pageIndex;
		this.searchPageSize = event.pageSize;
		// this.loadLeadsShowroomById();
		this.onSubmit();
	}

	searchForm() {
		this.searchFormGroup = this.formBuilder.group({
			name: [this.name],
			mobileNumber: [this.mobileNumber]
		});
	}


	onSubmit() {
		this.searchProgress = true;
		this.hasFormErrors = false;
		const controls = this.searchFormGroup.controls;
		/** check form */
		if (this.searchFormGroup.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.searchProgress = false;
			return;
		} else {
			this.searchFormGroup.valueChanges.subscribe(() => this.searchPage = 0);
		}
		this.message = '';
		const queryParams = new QueryParamsModel({}, '', '', this.searchPage, this.searchPageSize);
		this.preEnquiryService.getSearchResultsPreEnquiry(controls.mobileNumber.value, controls.name.value, 'PREDELIVERY', queryParams, this.loginEmployee.empId).subscribe(res => {
			this.searchProgress = false;
			if (res.statusCode !== 400 && res.status !== 500) {
				if (Array.isArray(res.dmsEntity.leadDtoPage.content) === false) {
					if (res.status !== 500) {
						this.leads.push(res.dmsEntity.dmsLeadDto);
					} else {
						this.message = 'No Record Found';
					}
				} else {
					this.scope = res.dmsEntity.leadDtoPage;
					if (this.scope.totalElements === 0) {
						this.message = 'No Leads Found';
					}
					this.leads = res.dmsEntity.leadDtoPage.content;
				}
				this.toLoad = false;
				this.initialLeads = [];
				this.isLoaded = false;
			} else {
				this.message = res.message;
				this.toLoad = false;
				this.leads = [];
			}
			this.isLoaded = true;
			this.changeDetectorRef.detectChanges();
		}, (error) => {
			this.leads = [];
			this.isLoaded = true;
			this.changeDetectorRef.detectChanges();
		});
	}

	onReset() {
		this.searchFormGroup.reset();
		this.toLoad = true;
		this.message = '';
		this.getAllLeadsByStatus();
	}

	deleteLead(leadData) {
		const _title: string = 'Lead Delete';
		const _description: string = 'Are you sure to permanently delete this Lead?';
		const _waitDesciption: string = 'Lead is deleting...';
		const _deleteMessage = 'Lead has been deleted';

		const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}

			this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
		});
	}

	getRowData(universalID) {
		this.router.navigate(['/preDelivery/preDelivery', universalID]);
	}

	mobileNumberKeyPress(event: any) {
		const pattern = /[0-9]/;
		const inputChar = String.fromCharCode(event.charCode);
		if (event.keyCode !== 8 && !pattern.test(inputChar)) {
			event.preventDefault();
		}
	}


	data;
	// For Saving as Excel File
	export(): void {
		const queryParams = new QueryParamsModel({}, '', '', this.page, this.scope.totalElements);
		this.preEnquiryService.getAllLeadsByStatus('PREDELIVERY', queryParams, this.loginEmployee.empId).subscribe(res => {
			this.data = res.dmsEntity.leadDtoPage.content;

			/* generate worksheet */
			const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.data);

			/* generate workbook and add the worksheet */
			const wb: XLSX.WorkBook = XLSX.utils.book_new();
			XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

			/* save to file */
			XLSX.writeFile(wb, 'PreDelivery.xlsx');
		});
	}

	exportToPdf() {
		let doc = new jsPDF('l', 'mm', 'a1');
		let rows = [];
		const queryParams = new QueryParamsModel({}, '', '', this.page, this.scope.totalElements);
		this.preEnquiryService.getAllLeadsByStatus('PREDELIVERY', queryParams, this.loginEmployee.empId).subscribe(res => {
			this.data = res.dmsEntity.leadDtoPage.content;
			this.data.forEach(element => {
				let temp = (Object.values(element));
				rows.push(temp);
			});

			doc.autoTable((Object.keys(this.data[0])), rows);
			doc.save('PreDelivery.pdf');
		});
	}
}
