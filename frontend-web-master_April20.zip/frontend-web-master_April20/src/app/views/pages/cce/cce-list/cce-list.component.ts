import { Component, OnInit, ChangeDetectorRef } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { CCEService } from "../../../../core/e-commerce/_services/cce.service";
// import { QueryParamsModel } from 'src/app/core/_base/crud';
import { QueryParamsModel } from "../../../../core/_base/crud";

@Component({
	selector: "kt-cce-list",
	templateUrl: "./cce-list.component.html",
	styleUrls: ["./cce-list.component.scss"],
})
export class CceListComponent implements OnInit {
	callsList;
	callsListType = "";
	loginEmployee;
	page = 0;
	pageSize = 10;
	serviceId;
	serviceTypes = [];
	fromDate = null;
	toDate = null;
	vehicleModel = "";
	filterType;
	vehicles = [];
	filterValue;
	filterList = [
		{ text: "Vehicle Model", value: "vehicleModel" },
		{ text: "Date Range", value: "dateRange" },
		{ text: "Service Type", value: "serviceId" },
	];
	scope: any = {};
	constructor(
		private router: Router,
		private cceService: CCEService,
		public route: ActivatedRoute,
		private changeDetectorRef: ChangeDetectorRef
	) {}

	ngOnInit() {
		this.callsListType = this.route.snapshot.paramMap.get("type");
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.getCallListByCategory();
		this.getServiceTypes();
		this.getVehicles();
	}

	getServiceTypes() {
		this.cceService.getServiceTypes().subscribe((data) => {
			this.serviceTypes = data.body;
		});
	}

	getCallListByCategory() {
		this.cceService
			.getCallsBYCategory(
				this.loginEmployee.branchId,
				this.callsListType,
				this.page,
				this.pageSize
			)
			.subscribe((data) => {
				this.scope = data.body;
				this.callsList = data.body.content;
				this.changeDetectorRef.detectChanges();
			});
	}

	followUpType(call) {
		this.router.navigateByUrl(
			"services/cceDashboard/follow-up/" +
				call.followUpActivityId +
				"/" +
				call.followUpId
		);
	}

	public goBack() {
		this.router.navigateByUrl("services/cceDashboard");
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.getCallListByCategory();
	}
	search() {
		if (this.fromDate && !this.toDate) {
			alert("To Date is required");
			return;
		}
		if (!this.fromDate && this.toDate) {
			alert("From Date is required");
			return;
		}
		if (
			this.serviceId ||
			(this.fromDate && this.toDate) ||
			this.vehicleModel
		) {
			this.callsList = [];
			this.cceService
				.getCallsBYCategoryWithSearch(
					this.loginEmployee.branchId,
					this.callsListType,
					this.page,
					this.pageSize,
					this.serviceId,
					this.fromDate,
					this.toDate,
					this.vehicleModel
				)
				.subscribe((data) => {
					this.callsList = [];
					this.scope = data.body;
					this.callsList = data.body.content;
					this.changeDetectorRef.detectChanges();
				});
		}
	}
	getVehicles() {
		this.cceService.getVehicles().subscribe((data) => {
			this.vehicles = data;
		});
	}
	filterTypeChanged() {
		if (this.filterType === "vehicleModel") {
			this.fromDate = null;
			this.toDate = null;
			this.serviceId = null;
		} else if (this.filterType === "dateRange") {
			this.serviceId = null;
			this.vehicleModel = null;
		} else {
			this.fromDate = null;
			this.toDate = null;
			this.vehicleModel = null;
		}
	}
}
