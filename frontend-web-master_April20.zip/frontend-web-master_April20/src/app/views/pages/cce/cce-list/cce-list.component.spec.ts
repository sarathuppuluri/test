import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CceListComponent } from './cce-list.component';

describe('CceListComponent', () => {
  let component: CceListComponent;
  let fixture: ComponentFixture<CceListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CceListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
