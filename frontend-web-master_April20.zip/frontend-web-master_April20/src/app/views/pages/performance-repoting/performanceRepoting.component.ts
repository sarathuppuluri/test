// Angular
import {
	Component,
	OnInit,
	AfterViewInit,
	ViewChild,
	HostListener,
	ElementRef,
	Inject,
	Pipe,
	PipeTransform,
	Input,
	ChangeDetectorRef,
} from "@angular/core";
import {
	EnquiryService,
	MyRolesService,
	Lead360Service,
	PerformanceService,
} from "../../../core/e-commerce/_services";
import { Router, ActivatedRoute } from "@angular/router";
import { FormBuilder, Validators } from "@angular/forms";
import {
	MatDialog,
	MatDialogRef,
	MAT_DIALOG_DATA,
	MatDialogConfig,
} from "@angular/material/dialog";
import { MatSnackBar } from "@angular/material/snack-bar";
import { MatOption, MatSelect } from "@angular/material";

import { QueryParamsModel } from "../../../core/_base/crud/models/query-models/query-params.model";
import { performanceConfirmationDialog } from "./confirmation-dialog.component";

@Component({
	selector: "kt-performancerepoting",
	templateUrl: "./performanceRepoting.component.html",
	styleUrls: ["performanceRepoting.component.scss"],
})
export class PerformanceRepotingComponent implements OnInit {
	currentTaskId: number;
	userName: string;
	screenHeight: any;
	screenWidth: any;
	loginEmployee: any = [];
	allPerformanceObject: any = [];

	limit: number = 10;
	offset: number = 0;
	scope: any = {};
	message: string;
	toLoad: boolean;
	isLoading: boolean = true;

	@HostListener("window:resize", ["$event"])
	onResize(event?) {
		this.screenHeight = window.innerHeight + "px";
		this.screenWidth = window.innerWidth - 200 + "px";
	}
	isLinear = true;

	constructor(
		private router: Router,
		private _formBuilder: FormBuilder,
		private fb: FormBuilder,
		public dialog: MatDialog,
		private _snackBar: MatSnackBar,
		private changeDetectorRef: ChangeDetectorRef,
		private enquiryservice: EnquiryService,
		private performanceService: PerformanceService
	) {
		this.onResize();
		//this.aStartDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
	}
	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));

		this.getAllPerformance();
	}
	paginatorEvents(event) {
		this.offset = event.pageIndex;
		this.limit = event.pageSize;
		this.getAllPerformance();
	}
	getAllPerformance() {
		this.isLoading = true;
		this.performanceService
			.getAllPerformance(
				this.loginEmployee.orgId,
				this.loginEmployee.branchId,
				this.limit,
				this.offset
			)
			.subscribe((res: any) => {
				this.isLoading = false;
				if (res.status ==="success") {
					this.allPerformanceObject = res.result.content;
					this.scope = res.result;
					this.toLoad = true;
					this.changeDetectorRef.detectChanges();
				} else {
					this.toLoad = false;
					this.allPerformanceObject = [];
					this.openSnackBar(res.showMessage, res.status);
					this.changeDetectorRef.detectChanges();
				}
			});
	}

	delete(obj) {
		if (obj.id != "") {
			const dialogConfig = new MatDialogConfig();
			dialogConfig.disableClose = false;
			dialogConfig.autoFocus = true;
			dialogConfig.width = "400px";
			//dialogConfig.height='480px';
			dialogConfig.data = {
				message: "Are you sure want to delete?",
				buttonText: { ok: "Yes", cancel: "No" },
			};
			const dialogRef = this.dialog.open(
				performanceConfirmationDialog,
				dialogConfig
			);
			dialogRef.afterClosed().subscribe((confirmed: boolean) => {
				if (confirmed) {
					this.performanceService
						.deletePerformance(obj.id)
						.subscribe((res: any) => {
							if (res.status ==="success") {
								this.openSnackBar(
									obj.objective +
										" - has been deleted successfully",
									res.status
								);
								this.getAllPerformance();
								this.changeDetectorRef.detectChanges();
							} else {
								this.openSnackBar(res.showMessage, res.status);
							}
						});
				}
			});
		}
	}
	edit(performanceObj) {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		dialogConfig.width = "600px";
		//dialogConfig.height='480px';
		dialogConfig.data = performanceObj;

		const dialogRef = this.dialog.open(
			CreatePerformanceDialog,
			dialogConfig
		);

		dialogRef.afterClosed().subscribe((result) => {
			if (result ==="success") {
				this.getAllPerformance();
			}
		});
	}

	routetoMappings(obj) {
		this.router.navigateByUrl('Performance/Performance/'+obj.id);
		}

	createPerformance() {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		dialogConfig.width = "600px";
		dialogConfig.data = {

		};

		const dialogRef = this.dialog.open(
			CreatePerformanceDialog,
			dialogConfig
		);

		dialogRef.afterClosed().subscribe((result) => {
			if (result ==="success") {
				this.getAllPerformance();
			}
		});
	}
	getAllModels(modelsList) {
		let models = [];
		modelsList.forEach((element) => {
			models.push(element.model);
		});
		return models;
	}
	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 2000,
		});
	}
}
/******************************************************************************************************************************************************************************* */

@Component({
	selector: "create-Performance-dialog",
	templateUrl: "./create-performance-dialog.html",
	styleUrls: ["./performanceRepoting.component.scss"],
})
export class CreatePerformanceDialog {
	loginEmployee: any;
	allSelected = false;
	performanceFormGroup = this.formBuilder.group({
		objectiveName: ["", Validators.required],
		description: ["", ""],
	});
	selectedModels: any = [];
	startDate;
	myrolesResult=[]
	searchMsg: string = "";
	performanceObj: any;
	isLoading: boolean;
	page: number = 150;
	pageSize: number = 0;
	@ViewChild("myModels", { static: true }) skillSel: MatSelect;

	constructor(
		private formBuilder: FormBuilder,
		private _snackBar: MatSnackBar,
		private changeDetectorRef: ChangeDetectorRef,
		private myroleservice: MyRolesService,
		private lead360Service: Lead360Service,
		private performanceService: PerformanceService,
		public dialogRef: MatDialogRef<CreatePerformanceDialog>,
		@Inject(MAT_DIALOG_DATA) data
	) {
		this.performanceObj = data;
		this.startDate = new Date(
			new Date().getFullYear(),
			new Date().getMonth(),
			new Date().getDate()
		);
	}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.loadMyRolesListView();
		if (this.performanceObj.id) {
			this.patchForm();
		}
	}

	loadMyRolesListView() {
		this.myrolesResult = [];
		this.isLoading = true;

		this.myroleservice
			.getAllRoles(
				this.page,
				this.pageSize,
				this.loginEmployee.orgId,
				this.loginEmployee.branchId
			)
			.subscribe((res) => {
				this.isLoading = false;

				this.myrolesResult = res.dmsEntity.rolePage.content;
				this.changeDetectorRef.detectChanges();
				if (this.performanceObj.id) {
					this.patchForm();
				}
			});
	}

	/**
	 * this method is for patch the form with exsiting test performance info.
	 */
	public patchForm() {
		this.performanceFormGroup.controls["objectiveName"].setValue(
			this.performanceObj.objective
		);
		this.performanceFormGroup.controls["description"].setValue(
			this.performanceObj.description
		);
	}

	onFormSubmit() {
		if (
			this.performanceFormGroup.value.objectiveName &&
			this.performanceFormGroup.value.objectiveName.trim() ===""
		) {
			this.openSnackBar("Objective should not be empty.", "");
			return null;
		}
		if (
			this.performanceFormGroup.value.description &&
			this.performanceFormGroup.value.description.trim() ===""
		) {
			this.openSnackBar("Description should not be empty.", "");
			return null;
		}
		const objNewPerformance = {
			id: null,
			branchId: this.loginEmployee.branchId,
			createdBy: this.loginEmployee.empId,
			createdDate: Date.parse(Date()),
			description: this.performanceFormGroup.value.description,
			modifiedDate: Date.parse(Date()),
			objective: this.performanceFormGroup.value.objectiveName,
			orgId: this.loginEmployee.orgId,
			updatedBy: null,
			dmsPerformanceModelMappingsDto: [
				{
					department: "",
					designation: "",
					empName: "",
					empid: "",
					id: "",
					incentiveId: "",
					model: "",
					objective: this.performanceFormGroup.value.objective,
					target: this.performanceFormGroup.value.targetValue,
					targetType: this.performanceFormGroup.value.selectTargetType,
					dmsPerformanceMd: {
						id: "",
						branchId: this.loginEmployee.branchId,
						createdBy: this.loginEmployee.empId,
						createdDate: Date.parse(Date()),
						description: this.performanceFormGroup.value
							.description,
						modifiedDate: Date.parse(Date()),
						objective: this.performanceFormGroup.value.objective,
						orgId: this.loginEmployee.orgId,
						updatedBy: "",
						dmsPerformanceModelMappingsDtos: "",
					},
				},
			],
		};
		this.performanceService.savePerformance(objNewPerformance).subscribe(
			(res: any) => {
				if (res.status ==="success") {
					this.openSnackBar(
						"Performance has been created successfully.",
						"success"
					);
					this.dialogRef.close("success");
				} else {
					this.openSnackBar(
						"Oops! Performance has not been created.",
						"fail"
					);
					this.dialogRef.close();
				}
			},
			(err) => {
				console.log("result: ", err);
				this.openSnackBar(err["message"], err["status"]);
			}
		);
	}
	updateForm() {
		if (
			this.performanceFormGroup.value.objectiveName &&
			this.performanceFormGroup.value.objectiveName.trim() ===""
		) {
			this.openSnackBar("Objective should not be empty.", "");
			return null;
		}
		if (
			this.performanceFormGroup.value.description &&
			this.performanceFormGroup.value.description.trim() ===""
		) {
			this.openSnackBar("Description should not be empty.", "");
			return null;
		}



		const objNewPerformance = {
			id: this.performanceObj.id,
			branchId: this.performanceObj.branchId,
			createdBy: this.performanceObj.createdBy,
			createdDate: this.performanceObj.createdDate,
			orgId: this.performanceObj.orgId,
			description: this.performanceFormGroup.value.description,
			modifiedDate: Date.parse(Date()),
			objective: this.performanceFormGroup.value.objectiveName,
			updatedBy: this.loginEmployee.empId,
			dmsPerformanceModelMappingsDtos: [],
		};

		this.performanceService.updatePerformance(objNewPerformance).subscribe(
			(res: any) => {
				if (res.status ==="success") {
					this.openSnackBar(
						"Performance has been updated successfully.",
						"success"
					);
					this.dialogRef.close("success");
				} else {
					this.openSnackBar(
						"Oops! Performance has not been updated.",
						"fail"
					);
					this.dialogRef.close();
				}
			},
			(err) => {
				console.log("result: ", err);
				this.openSnackBar(err["message"], err["status"]);
			}
		);
	}

	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 2000,
		});
	}
	resetForm() {
		this.performanceFormGroup.reset();
	}

	onNoClick(): void {
		this.dialogRef.close();
	}



	numericOnly(event): boolean {
		// restrict e,+,-,E characters in  input type number
		const charCode = event.which ? event.which : event.keyCode;
		if (
			charCode ===101 ||
			charCode ===69 ||
			charCode ===45 ||
			charCode ===43
		) {
			return false;
		}
		return true;
	}
}
