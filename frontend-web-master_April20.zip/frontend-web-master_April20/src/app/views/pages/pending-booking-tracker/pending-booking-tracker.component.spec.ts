import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingBookingTrackerComponent } from './pending-booking-tracker.component';

describe('PendingBookingTrackerComponent', () => {
  let component: PendingBookingTrackerComponent;
  let fixture: ComponentFixture<PendingBookingTrackerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PendingBookingTrackerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingBookingTrackerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
