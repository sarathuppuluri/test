import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { EnquiryService } from '../../../core/e-commerce/_services';
import { QueryParamsModel } from '../../../core/_base/crud';

@Component({
	selector: 'kt-pending-booking-tracker',
	templateUrl: './pending-booking-tracker.component.html',
	styleUrls: ['./pending-booking-tracker.component.scss']
})
export class PendingBookingTrackerComponent implements OnInit {
	loginEmployee: any;

	isLoading = false;
	message = '';
	page = 0;
	pageSize = 10;

	scope: any = {};
	pendingBookingTrackerList = [];

	constructor(private enquiryservice: EnquiryService,
		private changeDetectorRef: ChangeDetectorRef) { }

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.getPendingBookingTrackerList();
	}

	getPendingBookingTrackerList() {
		this.isLoading = true;
		this.message = '';
		const queryParams = new QueryParamsModel({}, '', '', this.page, this.pageSize);
		this.enquiryservice.getBookingTracker(this.loginEmployee.empId, queryParams).subscribe(res => {
			if (res.status === 500 || res.status === 400 || res.statusCode === 500 || res.statusCode === 400) {
				this.message = res.message;
				this.isLoading = false;
			} else {
				this.isLoading = false;
				this.scope = res;
				if (this.scope.totalElements === 0) {
					this.message = 'No Data Found';
				}
				this.pendingBookingTrackerList = res.content;
			}
			this.changeDetectorRef.detectChanges();
		}, error => {
			this.isLoading = false;
			this.message = 'Network Error';
			this.changeDetectorRef.detectChanges();
		});
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.getPendingBookingTrackerList();
	}

}
