import { Injectable } from "@angular/core";
import { HttpClient, HttpParams, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { environment } from "../../../../environments/environment.base";
import moment from "moment";

@Injectable({
	providedIn: "root",
})
export class UsedVehiclesService {
	loginEmployee: any = JSON.parse(localStorage.getItem("loginEmployee"));
	role = this.loginEmployee.hrmsRole;
	branchId = this.loginEmployee.branchId;
	orgId = this.loginEmployee.orgId;

	constructor(public http: HttpClient) {}

	public getAllBrands() {
		return this.http.get<any>(`${environment.notificationServices}/oldcar/api/all`);
	}

	public getUsedVehicles(offset, limit, requestBody?) {
		let url = `${environment.inventory}/buyUsedCar/fetchBuyUsedCar?orgid=${this.orgId}&offset=${offset}&limit=${limit}`;
		if (requestBody) {
			url = requestBody.brandId
				? `${url}&brandId=${requestBody.brandId}`
				: url;
			url = requestBody.modelId
				? `${url}&modelId=${requestBody.modelId}`
				: url;
			url = requestBody.price1
				? `${url}&price1=${requestBody.price1}`
				: url;
			url = requestBody.price2
				? `${url}&price2=${requestBody.price2}`
				: url;
		}
		return this.http.get<any>(url);
	}

	public getUsedVehicle(id) {
		const url = `${environment.inventory}/buyUsedCar/fetchBuyUsedCar/${id}`;
		return this.http.get<any>(url);
	}

	public saveUsedVehicle(requestBody) {
		const url = `${environment.inventory}/buyUsedCar/saveBuyUsedCar`;
		return this.http.post<any>(url, requestBody);
	}

	public updateUsedVehicle(requestBody) {
		const url = `${environment.inventory}/buyUsedCar/updateBuyUsedCar`;
		return this.http.post<any>(url, requestBody);
	}

	public deleteVehicle(id) {
		const url = `${environment.inventory}/buyUsedNCar/deleteBuyUsedCarDetails/${id}`;
		return this.http.delete<any>(url);
	}
}
