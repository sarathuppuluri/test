import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { UsedVehiclesService } from './used-vehicles.service';

@Component({
  selector: 'kt-used-vehicles',
  templateUrl: './used-vehicles.component.html',
  styleUrls: ['./used-vehicles.component.scss']
})
export class UsedVehiclesComponent implements OnInit {

  public usedVehiclesSearchForm: FormGroup;
	public searchResults = [];
	public pageLimit: number = 10;
	public pageSize: number = 0;
  public totalCount: number;
  public brands: any = [];
  public models: any = [];

	constructor(
		private fb: FormBuilder,
		private router: Router,
		private usedVehiclesService: UsedVehiclesService,
		private cd: ChangeDetectorRef
	) {}

	ngOnInit() {
		this.createForm();
    this.onLoadSearch();
    this.getBrandsInfo();
	}

	public createForm() {
		this.usedVehiclesSearchForm = this.fb.group({
      brandId: [''],
      modelId: [''],
      price1: [''],
      price2: ['']
		});
  }

  public getBrandsInfo() {
    this.usedVehiclesService.getAllBrands().subscribe(response => {
      if(response) {
        this.brands = response.brand;
        this.models = response.model;
        this.cd.detectChanges();
      }
    });
  }

  private onLoadSearch(requestBody?) {
    this.usedVehiclesService.getUsedVehicles(this.pageSize, this.pageLimit, requestBody).subscribe(vehicles => {
      if(vehicles.status === "success") {
        this.searchResults = vehicles.result.content;
        this.totalCount = vehicles.result.totalElements;
        this.cd.detectChanges();
      }
    });
  }

  public paginatorEvents(event) {
		this.pageSize = event.pageIndex;
		this.onLoadSearch();
	}

  public search() {
    this.onLoadSearch(this.usedVehiclesSearchForm.value);
  }

  public reset() {
    this.usedVehiclesSearchForm.reset();
    this.onLoadSearch();
  }

  public selectVehicle(vehicle) {
    this.router.navigateByUrl(`adminPanel/create-usedVehicle/${vehicle.id}`);
  }

  public createNew() {
    this.router.navigateByUrl('adminPanel/create-usedVehicle/0');
  }

}
