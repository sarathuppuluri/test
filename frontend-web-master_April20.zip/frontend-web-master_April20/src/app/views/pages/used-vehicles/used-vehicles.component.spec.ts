import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsedVehiclesComponent } from './used-vehicles.component';

describe('UsedVehiclesComponent', () => {
  let component: UsedVehiclesComponent;
  let fixture: ComponentFixture<UsedVehiclesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsedVehiclesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsedVehiclesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
