import { Component, OnInit, ChangeDetectorRef } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { UsedVehiclesService } from "../used-vehicles.service";
import moment from 'moment';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
	selector: "kt-vehicle-create",
	templateUrl: "./vehicle-create.component.html",
	styleUrls: ["./vehicle-create.component.scss"],
})
export class VehicleCreateComponent implements OnInit {
  public vehicleId;
  public vehicle: any;
  public vehicleForm: FormGroup;
  public brands: any = [];
  public models: any = [];
  public variants: any = [];
  public mainModels: any = [];
  public mainVariants: any = [];
  public bargainTypes: any = ['Fixed','Negopiable'];
  public owners: any = ['1st Owner','2nd Owner','3rd Owner','4th Owner','5th Owner'];
  public insuranceTypes: any = ['Comprehensive', 'Nil_Dep', 'Third_Party'];
  public months: any = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  public todayDate = new Date();
  public documents: any = [];
  public imagefiles: any = [];
  public documentTypes: any = [];
  public formData: FormData = new FormData();

  loginEmployee: any = JSON.parse(localStorage.getItem("loginEmployee"));
	role = this.loginEmployee.hrmsRole;
	branchId = this.loginEmployee.branchId;
	orgId = this.loginEmployee.orgId;

	constructor(
		private fb: FormBuilder,
		private router: Router,
		private usedVehiclesService: UsedVehiclesService,
		private cd: ChangeDetectorRef,
    private routeData: ActivatedRoute,
    private _snackBar: MatSnackBar,
	) {}

	ngOnInit() {
    this.vehicleId = this.routeData.snapshot.paramMap.get("id");
    this.buildForm();
    this.getBrandsInfo();
		this.vehicleId == "0" ? null : this.getInfo();
	}

	public buildForm() {
		this.vehicleForm = this.fb.group({
			id: 0,
			organizationId: [],
			branchId: [],
			brandId: [],
			modelId: [],
			varientId: [],
			makingYear: [""],
			makingMonth: [""],
			price: [""],
			bargainType: [""],
			color: [""],
			drivenKms: [""],
			rcNumber: [""],
			registrationDate: [""],
			noOfOwners: [""],
			insuranceType: [""],
			customerId: [""],
			insuranceValidity: [""],
			images: [""],
			createdBy: [""],
			createdDatetime: [""],
			modifiedBy: [""],
			modifiedDate: [""],
			imagefiles: null,
			documentTypes: null,
			documentList: [],
		});
  }

  public back() {
    this.router.navigateByUrl('/adminPanel/usedVehicles');
  }
  
  public getBrandsInfo() {
    this.usedVehiclesService.getAllBrands().subscribe(response => {
      if(response) {
        this.brands = response.brand;
        this.mainModels = response.model;
        this.mainVariants = response.variant;
        this.onBrandChange();
        this.onModelChange();
        this.cd.detectChanges();
      }
    });
  }

	public getInfo() {
		this.usedVehiclesService
			.getUsedVehicle(this.vehicleId)
			.subscribe((veh) => {
				if (veh.status == "success") {
          this.vehicle = veh.result;
          this.vehicleForm.patchValue(veh.result);
          this.cd.detectChanges();
				}
			});
  }
  
  public onBrandChange() {
    this.models = this.mainModels.filter(model => model.brandId == this.vehicleForm.controls.brandId.value);
  }

  public onModelChange() {
    this.variants = this.mainVariants.filter(variant => variant.modelId == this.vehicleForm.controls.modelId.value);
  }

  public deleteDocument(deleteUrl: string) {
    let documentList = this.vehicleForm.controls.documentList.value.filter(url => url != deleteUrl);
    this.vehicleForm.controls.documentList.setValue(documentList);
  }

  public addNewDoc() {
    this.documents.push({});
  }

  public onImageSelected(event, index) {
    if (event.target.files.length) {
      this.formData.append('imagefiles', event.target.files[0]);
      this.formData.append('documentTypes', 'JPEG');
    }
  }

  public submit() {
    this.appendFormData();
    this.usedVehiclesService.saveUsedVehicle(this.formData).subscribe(response => {
      if(response.status == "success") {
        this.openSnackBar('Vehicle is saved Successfully', 'Success');
        this.back();
      }
    },(error) => {
      this.openSnackBar(
        error.error["message"],
        error.error["status"]
      );
    });
  }

  public update() {
    this.appendFormData();
    this.formData.append('id', this.vehicleForm.value.id);
    this.vehicleForm.value.documentList ? this.formData.append('documentList', this.vehicleForm.value.documentList) : null;
    this.usedVehiclesService.updateUsedVehicle(this.formData).subscribe(response => {
      if(response.status == "success") {
        this.openSnackBar('Vehicle is updated Successfully', 'Success');
        this.back();
      }
    },(error) => {
      this.openSnackBar(
        error.error["message"],
        error.error["status"]
      );
    });
  }

  public deleteVehicle() {
    this.usedVehiclesService.deleteVehicle(this.vehicleId).subscribe(response => {
      if(response.status == "success") {
        this.openSnackBar('Vehicle is deleted Successfully', 'Success');
        this.back();
      }
    },(error) => {
      this.openSnackBar(
        error.error["message"],
        error.error["status"]
      );
    });
  }

  public appendFormData() {
    this.vehicleForm.value.modifiedBy = this.loginEmployee.empId;
    this.vehicleForm.value.createdBy = this.loginEmployee.empId;
    this.vehicleForm.value.insuranceValidity  = moment(this.vehicleForm.value.insuranceValidity).format('DD/MM/YYYY');
    this.vehicleForm.value.registrationDate = moment(this.vehicleForm.value.registrationDate).format('DD/MM/YYYY');
    this.vehicleForm.value.modifiedDate = moment().format('DD/MM/YYYY');
    this.vehicleForm.value.createdDatetime  = moment().format('DD/MM/YYYY');

    this.formData.append('brandId', this.vehicleForm.value.brandId);
    this.formData.append('modelId', this.vehicleForm.value.modelId);
    this.formData.append('varientId', this.vehicleForm.value.varientId);
    this.formData.append('makingYear', this.vehicleForm.value.makingYear);
    this.formData.append('makingMonth', this.vehicleForm.value.makingMonth);
    this.formData.append('price', this.vehicleForm.value.price);
    this.formData.append('bargainType', this.vehicleForm.value.bargainType);
    this.formData.append('color', this.vehicleForm.value.color);
    this.formData.append('drivenKms', this.vehicleForm.value.drivenKms);
    this.formData.append('rcNumber', this.vehicleForm.value.rcNumber);
    this.formData.append('registrationDate', this.vehicleForm.value.registrationDate);
    this.formData.append('noOfOwners', this.vehicleForm.value.noOfOwners);
    this.formData.append('insuranceType', this.vehicleForm.value.insuranceType);
    this.formData.append('insuranceValidity', this.vehicleForm.value.insuranceValidity);
    this.formData.append('createdBy', this.vehicleForm.value.createdBy);
    this.formData.append('createdDatetime', this.vehicleForm.value.createdDatetime);
    this.formData.append('modifiedBy', this.vehicleForm.value.modifiedBy);
    this.formData.append('modifiedDate', this.vehicleForm.value.modifiedDate);
    this.formData.append('organizationId', this.orgId);
    this.formData.append('branchId', this.branchId);
    
  }

  private openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 5000,
		});
	}
}

