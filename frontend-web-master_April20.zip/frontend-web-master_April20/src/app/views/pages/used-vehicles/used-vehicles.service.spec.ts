import { TestBed } from '@angular/core/testing';

import { UsedVehiclesService } from './used-vehicles.service';

describe('UsedVehiclesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UsedVehiclesService = TestBed.get(UsedVehiclesService);
    expect(service).toBeTruthy();
  });
});
