import { Component, OnInit } from '@angular/core';
import { each, find, some } from 'lodash';
import { MenuEditComponent } from './menu-edit/menu-edit.component';
import { MatDialog } from '@angular/material';
import { MessageType, LayoutUtilsService } from '../../../core/_base/crud';
import { MenuAsideService } from '../../../core/_base/layout/services/menu-aside.service';
import { MenuService } from '../../../core/e-commerce/_services/menu.service';
import { MyRolesService } from '../../../core/e-commerce/_services/myroles.service';

@Component({
	selector: 'kt-menu',
	templateUrl: './menu.component.html',
	styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {
	menuEdit = [];
	userName;

	constructor(private dialog: MatDialog,
		private layoutUtilsService: LayoutUtilsService,
		private menuAsideService: MenuAsideService,
		private menuService: MenuService,
		private myroleservice: MyRolesService) { }

	ngOnInit() {
		this.menuEdit = this.menuAsideService.tempList
	}


	editMenu(menuData) {
		const saveMessageTranslateParam = 'Menu Updated';
		const dialogRef = this.dialog.open(MenuEditComponent, { data: { menuData } });

		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.menuService.updateMenu(menuData.editApiUrl, res.data).subscribe(res => {
				this.menuAsideService.PrepareJSONData();
			});
			this.layoutUtilsService.showActionNotification(saveMessageTranslateParam, MessageType.Update);
		});
	}

}
