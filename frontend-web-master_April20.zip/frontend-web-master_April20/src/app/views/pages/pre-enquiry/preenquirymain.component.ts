import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'kt-preenquiry',
    templateUrl: './preenquirymain.component.html'
})
export class PreenquiryMainComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
