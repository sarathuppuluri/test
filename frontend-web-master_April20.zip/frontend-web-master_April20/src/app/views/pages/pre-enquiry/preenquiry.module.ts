// Angular
import { NgModule, } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
// Metronic
import { PartialsModule } from '../../partials/partials.module';
import { CoreModule } from '../../../core/core.module';
import { UpdateEntityDialogComponent, TaskEntityDialogComponent } from '../../partials/content/crud';
// Components
import { PreenquiryMainComponent } from './preenquirymain.component';
import { LeadEditComponent } from './lead-edit/lead-edit.component';
import { LeadsComponent } from './leads/leads.component';
import { LeadsSubviewComponent } from './leads-subview/leads-subview.component';
import { NewleadsComponent } from './newleads/newleads.component';
import { BulkUploadComponent } from './bulk-upload/bulk-upload.component';
// Material   // Imported By Me...
import {
    MatInputModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSortModule,
    MatTableModule,
    MatSelectModule,
    MatMenuModule,
    MatProgressBarModule,
    MatButtonModule,
    MatCheckboxModule,
    MatDialogModule,
    MatTabsModule,
    MatNativeDateModule,
    MatCardModule,
    MatRadioModule,
    MatIconModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MAT_DIALOG_DEFAULT_OPTIONS,
    MatSnackBarModule,
    MatTooltipModule,
    MatExpansionModule,
    MAT_DATE_LOCALE
} from '@angular/material';
import { NgbAlertConfig, NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
    declarations: [
        PreenquiryMainComponent,
        LeadsComponent,
		NewleadsComponent,
		LeadEditComponent,
		LeadsSubviewComponent,
		BulkUploadComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PartialsModule,
        CoreModule,
        HttpClientModule,
        MatInputModule,
        MatPaginatorModule,
        MatProgressSpinnerModule,
        MatSortModule,
        MatTableModule,
        MatSelectModule,
        MatMenuModule,
        MatProgressBarModule,
        MatButtonModule,
        MatCheckboxModule,
        MatDialogModule,
        MatTabsModule,
        MatNativeDateModule,
        MatCardModule,
        MatRadioModule,
        MatIconModule,
        MatDatepickerModule,
        MatAutocompleteModule,
        MatSnackBarModule,
        MatTooltipModule,
        MatExpansionModule,
        NgbModule,
        RouterModule.forChild([
            {
                path: '',
                component: PreenquiryMainComponent,
                children: [
                    {
                        path: 'preEnquiry',
                        component: LeadsComponent
                    },
                    {
                        path: 'preEnquiry/subview/:profileId',
                        component: LeadsSubviewComponent
                    },
                    {
                        path: 'preEnquiry/newlead',
                        component: NewleadsComponent
                    },
                    {
                        path: 'bulkUpload',
                        component: BulkUploadComponent
                    }
                ]
            },
        ])
    ],
    entryComponents: [
        UpdateEntityDialogComponent,
        TaskEntityDialogComponent,
        LeadEditComponent
    ],
    providers: [
        NgbAlertConfig,
        { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
        {
            provide: MAT_DIALOG_DEFAULT_OPTIONS,
            useValue: {
                hasBackdrop: true,
                panelClass: 'kt-mat-dialog-container__wrapper',
                height: 'auto',
                width: '900px'
            }
        }
    ]
})
export class PreenquiryModule { }
