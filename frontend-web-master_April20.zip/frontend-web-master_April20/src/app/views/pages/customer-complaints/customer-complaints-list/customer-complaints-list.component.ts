// Angular
import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
// Material
import { MatSnackBar, MatDialog } from '@angular/material';
// RXJS
import { Subscription } from 'rxjs';
// CRUD
import { LayoutUtilsService, MessageType, QueryParamsModel } from '../../../../core/_base/crud';
// Translate Module
import { TranslateService } from '@ngx-translate/core';
// Services and Models
import { CustomerCompliantsModel } from '../../../../core/e-commerce/_models/customer-compliants.model';
// Components
import { CustomerComplaintsEditDialogComponent } from '../customer-complaints-edit/customer-complaints-edit.dialog.component';
import { CustomerComplaintsService } from '../../../../core/e-commerce/_services/customer-complaints.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
	// tslint:disable-next-line:component-selector
	selector: 'kt-customer-complaints',
	templateUrl: './customer-complaints-list.component.html',
	styleUrls: ['./customer-complaints-list.component.scss']
})
export class CustomerComplaintsListComponent implements OnInit, OnDestroy {
	loginEmployee: any;

	page = 0;
	pageSize = 10;
	isLoading = false;
	scope: any = {};

	searchFormGroup: FormGroup;

	// Subscriptions
	private subscriptions: Subscription[] = [];

	tempData = [];
	orgId: any;

	searchProgress = false;
	leadSearchProgress = false;
	hasFormErrors: boolean;
	leadMessage: string;
	message: string;
	leads: any[];
	tempLeadData: any = {};

	/**
	 * Component constructor
	 *
	 * @param dialog: MatDialog
	 * @param snackBar: MatSnackBar
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 */
	constructor(
		public dialog: MatDialog,
		private custComplService: CustomerComplaintsService,
		private translate: TranslateService,
		public snackBar: MatSnackBar,
		private router: Router,
		private changeDetectorRef: ChangeDetectorRef,
		private layoutUtilsService: LayoutUtilsService,
		private routeData: ActivatedRoute,
		private formBuilder: FormBuilder
	) {
	}


	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.searchForm();
		this.getCustComplList();
	}

	/**
	 * On Destroy
	 */
	ngOnDestroy() {
		this.subscriptions.forEach(el => el.unsubscribe());
	}

	mobileNumberKeyPress(event: any) {
		const pattern = /[0-9]/;
		const inputChar = String.fromCharCode(event.charCode);
		if (event.keyCode !== 8 && !pattern.test(inputChar)) {
			event.preventDefault();
		}
	}

	/**
	 * Load Incentive List from service
	 */
	getCustComplList() {
		this.isLoading = true;
		const queryParams = new QueryParamsModel({}, '', '', this.page, this.pageSize);
		this.custComplService.getCustComplList(queryParams).subscribe(res => {
			this.isLoading = false;
			this.scope = res.dmsCustomerComplaintPage;
			this.tempData = res.dmsCustomerComplaintPage.content;
			this.changeDetectorRef.detectChanges();
		}, error => {
			console.log('All Data of CustCompl error::' + error);
			this.changeDetectorRef.detectChanges();
		});
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.getCustComplList();
	}

	searchForm() {
		this.searchFormGroup = this.formBuilder.group({
			complaintType: [''],
			customerName: [''],
			employee: [''],
			name: [''],
			mobileNumber: ['']
		});
	}

	onSubmitLead() {
		this.leadSearchProgress = true;
		this.hasFormErrors = false;
		const controls = this.searchFormGroup.controls;
		/** check form */
		if (this.searchFormGroup.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.leadSearchProgress = false;
			return;

		}
		this.leadMessage = '';
		this.leads = [];
		this.custComplService.getSearchResultsPreEnquiry(controls.mobileNumber.value, controls.name.value).subscribe(res => {
			this.leadSearchProgress = false;
			if (res.statusCode !== 400 && res.status !== 500) {
				if (Array.isArray(res.dmsEntity.dmsLeadDtoList) === false) {
					if (res.status !== 500) {
						this.leads.push(res.dmsEntity.dmsLeadDto);
					} else {
						this.leadMessage = 'No Record Found';
					}
				} else {
					this.leads = res.dmsEntity.dmsLeadDtoList;
				}
			} else {
				this.leadMessage = res.message;
				this.leads = [];
			}
			this.changeDetectorRef.detectChanges();
		}, (error) => {
			this.leads = [];
			this.changeDetectorRef.detectChanges();
		});
	}

	onSubmit() {
		this.searchProgress = true;
		this.hasFormErrors = false;
		const controls = this.searchFormGroup.controls;
		/** check form */
		if (this.searchFormGroup.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.searchProgress = false;
			return;

		}
		this.message = '';
		this.custComplService.searchCustCompl(controls.complaintType.value, controls.customerName.value, controls.employee.value).subscribe(res => {
			this.searchProgress = false;
			if (res.error === true) {
				this.message = res.errorMessage;
				this.changeDetectorRef.detectChanges();
				return;
			} else {
				this.tempData = res.dmsCustomerComplaintList;
			}
			this.changeDetectorRef.detectChanges();
		}, (error) => {
			this.tempData = [];
			this.searchProgress = false;
			this.changeDetectorRef.detectChanges();
		});
	}

	onReset() {
		this.searchFormGroup.reset();
		this.message = '';
		this.leadMessage = '';
		this.leads = [];
		this.getCustComplList();
	}

	/**
	* Checking control validation
	*
	* @param controlName: string => Equals to formControlName
	* @param validationType: string => Equals to valitors name
	*/
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.searchFormGroup.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}


	deleteCustCompl(element) {
		const _title = 'Customer Complaint Delete';
		const _description = 'Are you sure to permanently delete this Customer Compliant?';
		const _waitDesciption = 'Compliant is deleting...';
		const _deleteMessage = 'Compliant has been deleted';

		const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.custComplService.deleteCustCompl(element.id).subscribe(custComplRes => {
				if (custComplRes.status === 500) {
					this.layoutUtilsService.showActionNotification('There is an Error Deleting Customer Compliant');
					return;
				}
				this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
				this.getCustComplList();
			});
		});
	}

	saveLeadDetails(lead) {
		this.tempLeadData = lead;
	}


	/**
	 * Show add vehicle dialog
	 */
	addCustCompl() {
		const editCustCompl = new CustomerCompliantsModel();
		editCustCompl.clear(); // Set all defaults fields
		editCustCompl.customerId = this.tempLeadData.id;
		editCustCompl.customerName = `${this.tempLeadData.firstName} ${this.tempLeadData.lastName}`;
		this.editCustCompl(editCustCompl);
	}

	/**
	 * Show Edit vehicle dialog and save after success close result
	 * @param editCustCompl: IncentiveModel
	 */
	editCustCompl(editCustCompl: CustomerCompliantsModel) {
		let saveMessageTranslateParam = 'ECOMMERCE.CUSTOMERCOMPLAINTS.EDIT.';
		saveMessageTranslateParam += editCustCompl.id > 0 ? 'UPDATE_MESSAGE' : 'ADD_MESSAGE';
		const _saveMessage = this.translate.instant(saveMessageTranslateParam);
		const _messageType = Number(editCustCompl.id) > 0 ? MessageType.Update : MessageType.Create;

		const dialogRef = this.dialog.open(CustomerComplaintsEditDialogComponent, { data: { editCustCompl } });
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			if (res.response.status === 500) {
				this.layoutUtilsService.showActionNotification('There is an Error Creating Customer Compliant');
				return;
			}
			this.layoutUtilsService.showActionNotification(_saveMessage, _messageType).afterOpened().subscribe(custComplRes => {
				this.getCustComplList();
			});
		});
	}
}
