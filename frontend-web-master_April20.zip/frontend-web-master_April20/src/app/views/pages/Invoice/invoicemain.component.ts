import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'kt-invoice',
    templateUrl: './invoicemain.component.html'
})
export class InvoiceMainComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
