// Angular
import { NgModule, } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
// Metronic
import { PartialsModule } from '../../partials/partials.module';
import { CoreModule } from '../../../core/core.module';
import { UpdateEntityDialogComponent, TaskEntityDialogComponent } from '../../partials/content/crud';
// Material   // Imported By Me...
import {
    MatInputModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSortModule,
    MatTableModule,
    MatSelectModule,
    MatMenuModule,
    MatProgressBarModule,
    MatButtonModule,
    MatCheckboxModule,
    MatDialogModule,
    MatTabsModule,
    MatNativeDateModule,
    MatCardModule,
    MatRadioModule,
    MatIconModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MAT_DIALOG_DEFAULT_OPTIONS,
    MatSnackBarModule,
    MatTooltipModule,
    MatExpansionModule,
    MAT_DATE_LOCALE
} from '@angular/material';
import { NgbAlertConfig, NgbModule } from '@ng-bootstrap/ng-bootstrap';
// Components
import { InvoiceMainComponent } from './invoicemain.component';
import { InvoiceListComponent } from './invoice-list/invoice-list.component';
import { InvoiceformComponent } from './invoiceform/invoiceform.component';

@NgModule({
    declarations: [
        InvoiceMainComponent,
        InvoiceListComponent,
        InvoiceformComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PartialsModule,
        CoreModule,
        HttpClientModule,
        MatInputModule,
        MatPaginatorModule,
        MatProgressSpinnerModule,
        MatSortModule,
        MatTableModule,
        MatSelectModule,
        MatMenuModule,
        MatProgressBarModule,
        MatButtonModule,
        MatCheckboxModule,
        MatDialogModule,
        MatTabsModule,
        MatNativeDateModule,
        MatCardModule,
        MatRadioModule,
        MatIconModule,
        MatDatepickerModule,
        MatAutocompleteModule,
        MatSnackBarModule,
        MatTooltipModule,
        MatExpansionModule,
        NgbModule,
        RouterModule.forChild([
            {
                path: '',
                component: InvoiceMainComponent,
                children: [
                    {
                        path: 'invoice',
                        component: InvoiceListComponent
                    },
                    {
                        path: 'invoice/:id',
                        component: InvoiceformComponent
                    }
                ]
            },
        ])
    ],
    entryComponents: [
        UpdateEntityDialogComponent,
        TaskEntityDialogComponent
    ],
    providers: [
        NgbAlertConfig,
        { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
        {
            provide: MAT_DIALOG_DEFAULT_OPTIONS,
            useValue: {
                hasBackdrop: true,
                panelClass: 'kt-mat-dialog-container__wrapper',
                height: 'auto',
                width: '900px'
            }
        }
    ]
})
export class InvoiceModule { }
