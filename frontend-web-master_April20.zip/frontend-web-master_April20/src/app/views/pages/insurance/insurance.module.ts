import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { InsuranceListComponent } from "./insurance-list/insurance-list.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
	MatInputModule,
	MatPaginatorModule,
	MatProgressSpinnerModule,
	MatSortModule,
	MatTableModule,
	MatSelectModule,
	MatMenuModule,
	MatProgressBarModule,
	MatButtonModule,
	MatCheckboxModule,
	MatDialogModule,
	MatTabsModule,
	MatNativeDateModule,
	MatCardModule,
	MatRadioModule,
	MatIconModule,
	MatDatepickerModule,
	MatAutocompleteModule,
	MatSnackBarModule,
	MatTooltipModule,
	MatExpansionModule,
} from "@angular/material";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { RouterModule } from "@angular/router";
import { OfferListComponent } from "../admin/offer/offer-list/offer-list.component";
import { InsuranceService } from "../../../core/e-commerce/_services/insurance.service";
import { InsuranceComponent } from './insurance/insurance.component';

@NgModule({
	declarations: [InsuranceListComponent, InsuranceComponent],
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatInputModule,
		MatPaginatorModule,
		MatProgressSpinnerModule,
		MatSortModule,
		MatTableModule,
		MatSelectModule,
		MatMenuModule,
		MatProgressBarModule,
		MatButtonModule,
		MatCheckboxModule,
		MatDialogModule,
		MatTabsModule,
		MatNativeDateModule,
		MatCardModule,
		MatRadioModule,
		MatIconModule,
		MatDatepickerModule,
		MatAutocompleteModule,
		MatSnackBarModule,
		MatTooltipModule,
		MatExpansionModule,
		NgbModule,
		RouterModule.forChild([
			{
				path: "",
				component: InsuranceListComponent,
			},
			{
				path: "create",
				component: InsuranceComponent,
			},
			{
				path: "edit/:id",
				component: InsuranceComponent,
			},
		]),
	],
	providers: [InsuranceService],
})
export class InsuranceModule {}
