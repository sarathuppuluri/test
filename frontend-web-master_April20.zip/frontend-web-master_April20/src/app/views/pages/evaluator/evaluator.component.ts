import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, Validators, FormArray, FormBuilder } from '@angular/forms';
import {
  EvaluatorService,
  EnquiryService,
  Lead360Service,
} from '../../../core/e-commerce/_services';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { LayoutUtilsService } from '../../../core/_base/crud';
import { MatSnackBar } from '@angular/material';
@Component({
  selector: 'kt-evaluator',
  templateUrl: './evaluator.component.html',
  styleUrls: ['./evaluator.component.scss'],
  providers: [DatePipe],
})
export class EvaluatorComponent implements OnInit {
  loginEmployee: any;
  evalutorId: any;
  // managerId: any;
  evalutorId1: any;
  rem: boolean;
  definedOtherCosts = [];
  purl1: any[];
  managerid: any;
  exteriorarray: any;
  image0: boolean;
  regnum: any;
  hasFormErrors: boolean;

  constructor(
    private http: EvaluatorService,
    private fb: FormBuilder,
    private modalService: NgbModal,
    private date: DatePipe,
    private router: Router,
    private changedetectorref: ChangeDetectorRef,
    private enquiryservice: EnquiryService,
    private layoutUtilsService: LayoutUtilsService,
    private _snackBar: MatSnackBar,
    private lead360Service: Lead360Service
  ) {}

  role;
  flags2 = false;
  flags1 = false;
  flags = true;
  step = 0;

  crmUniversalId = '';
  defaultone: boolean;
  editone: boolean;
  purl: any = [];
  id: any;
  updatedDate: any;
  mangerForm: FormGroup;
  generalappearenceList: any;
  newdriverseatarray: any;
  login: any;
  // managerForm: any;
  Admin: string;
  newinteriorarray: any[];
  checkdata1: any;
  getid: any;
  edited1: boolean;
  default1: boolean;
  default2: boolean;

  panelOpenState = false;

  flag = false;
  flag1 = false;
  flag2 = false;
  flag3 = false;
  flag4 = false;
  flag5 = false;
  flag6 = false;
  flag7 = false;
  flag8 = false;
  image: boolean;
  // image1:boolean;
  url1: string | ArrayBuffer;
  url2: string | ArrayBuffer;
  valuesalll: Array<any>;
  url3: string | ArrayBuffer;
  url4: any;
  url5: any;
  url6: any;
  url7: any;
  url8: any;
  url9: any;
  url10: any;
  url11: any;
  url12: any;
  url13: any;
  url14: any;
  url15: any;
  url16: any;
  url17: any;
  url18: any;
  url19: any;

  imagepush: Array<any> = [];
  otherimagepush: Array<any> = [];
  image1: boolean;
  image2: boolean;
  getObject: any;
  submitted = false;
  otherImageUrl: any = [];

  edit1 = false;
  hypotheticationFlag = false;
  insuranceFlag = false;
  showMajorAccidentRemarks = false;
  showMinorAccidentRemarks = false;
  priceFinalisation: boolean;
  totalRefurbishmentCost: any = 0;
  profileForm: FormGroup;
  extraCosts = [];
  url: string | ArrayBuffer;
  valuesall: Array<any> = [];
  value3: boolean;
  image3: boolean;
  image4: boolean;
  image5: boolean;
  image6: boolean;
  image7: boolean;
  image8: boolean;
  image9: boolean;
  image10: boolean;
  image11: boolean;
  image12: boolean;
  image13: boolean;
  image14: boolean;
  image15: boolean;
  image16: boolean;
  image17: boolean;
  image18: boolean;
  image19: boolean;
  previewForm: FormGroup;
  formData: [''];
  checkdata: any;
  setStep(index: number) {
    this.step = index;
  }
  nextStep() {
    this.step++;
  }
  prevStep() {
    this.step--;
  }
  bindValueCheck(list, belt) {
    if (belt === true) {
      const obj = {
        isAvailable: true,
        questionId: list.id,
      };
      this.valuesall.push(obj);
    } else {
      this.valuesall.splice(
        this.valuesall.findIndex((element) => element.questionId === list.id),
        1
      );
    }
  }

  bindRemarks(list, belt, remarks) {
    if (belt === true) {
      this.valuesall.forEach((element) => {
        if (element.questionId === list.id) {
          element.remarks = remarks ? remarks : '';
        }
      });
    } else {
      this.valuesall.splice(
        this.valuesall.findIndex((element) => element.questionId === list.id),
        1
      );
    }
  }

  ngOnInit() {
    this.role = JSON.parse(localStorage.getItem('loginEmployee'));

    this.evalutorId = this.role.empId;

    this.http.getchecklist().subscribe((res) => {
      this.checkdata = res;
      this.newdriverseatarray = this.checkdata;
      this.exteriorarray = this.newdriverseatarray[0].subCategory;
    });

    this.previewForm = this.fb.group({
      previewregistrationNumber: ['', Validators.required],
      previewnameonRC: [''],
      previewmodel: [''],
      previewvariant: [''],
      previewregDate: [''],
      previewmake: [''],
      previewfuelType: [''],
      previewtransmission: [''],
      previewtotalRefurbishmentCost: [],
      role: [''],
      previewVehicleServiceCost: [''],
      previewvehicleServiceCost: [''],
      previewengineNumber: [''],
      previewpincode: [''],
      previewchallanPending: [''],
      previewminorAccidentRemarks: [''],
      previewminorAccident: [''],
      previewmajorAccidentRemarks: [''],
      previewmajorAccident: [''],
      previewcolour: [''],
      previewevalutorId: [''],
      previewcustExpectedPrice: [''],
      previewemission: [''],
      previewevaluatorOfferPrice: [''],
      previewoilChanges: [''],
      previewoilChangesCost: [],
      previewpowerbrakefluidchange: [''],
      previewpowerBrakeFluidChangeCost: [],
      previewcoolantFilterChange: [''],
      previewcoolantFilterChangeCost: [],
      previewremovalStainMarksStickers: [''],
      previewremovalStainMarksStickersCost: [],
      previewcarpetCleaning: [''],
      previewcarpetCleaningCost: [],
      previewengineRoom: [''],
      previewengineRoomCost: [],
      previewvehicleTransfer: [''],
      previewvehicleTransferCharges: [],
      previewnocClearanceExpense: [''],
      previewnocClearanceExpenseCost: [],
      previewchallanAmount: [''],
      previewchallanAmountCost: [],
      previewccClearanceExpense: [''],
      previewccClearanceExpenseCost: [],
      previewfrontWheelLeft: [''],
      previewfrontWheelRight: [''],
      previewhypothecatedBranch: [''],
      previewhypothecatedCompletedDate: [''],
      previewhypothecation: [''],
      previewimageDocuments: [''],
      previewinsFromDate: [''],
      previewinsToDate: [''],
      previewinsurance: [''],
      previewinsuranceCompanyName: [''],
      previewinsuranceCost: [],
      previewinsuranceType: [''],
      previewkmDriven: [''],
      previewloanAmountDue: [''],
      previewnoOfOwners: [''],
      previewpolicyNumber: [''],
      previewpollutionCertificate: [''],
      previewpollutionCertificateCost: [],
      previewmobileNum: [''],
      previewname: [''],
      previewcost: [''],
      previewotherDocName: [''],
      previewotherDocFile: [''],
      previewrearWheelLeft: [''],
      previewrearWheelRight: [''],
      previewregCity: [''],
      previewregDistrict: [''],
      regDocument: [''],
      regDocumentCharges: [],
      previewregState: [''],
      previewregValidity: [''],
      previewrubbingPolishing: [''],
      previewrubbingPolishingCost: [],
      previewspareAlliWheel: [''],
      previewspareDiskWheel: [''],
      previewspareKey: [''],
      previewspareKeyCost: [],
      previewtypeOfBody: [''],
      previewvehicleType: [''],
      previewyearMonthOfManufacturing: [''],
      previewchassisNum: [''],
      previewperiodicServiceCost: [],
      previewperiodicService: [''],
      previewoldCarNocImg: [''],
      previewoldCarNocName: [''],
      previewnumberPlateImg: [''],
      previewnumberPlateName: [''],
      previewbreaksDmgImg: [''],
      previewbreaksDmgName: [''],
      previewfunctionsImg: [''],
      previewfunctionsName: [''],
      previewdentImg: [''],
      previewdentName: [''],
      previewscratchImg: [''],
      previewscratchName: [''],
      previewextraFitmentImg: [''],
      previewextraFitmentName: [''],
      previewinvoiceImg: [''],
      previewinvoiceName: [''],
      previewinsuranceImg: [''],
      previewinsuranceName: [''],
      previewrcBackImg: [''],
      previewrcBackName: [''],
      previewrcFrontImg: [''],
      previewrcFrontName: [''],
      previewinteriorBackImg: [''],
      previewinteriorBackName: [''],
      previewinteriorFrontImg: [''],
      previewinteriorFrontName: [''],
      previewchassisImg: [''],
      previewchassisImgName: [''],
      previewspeedoMeterImg: [''],
      previewspeedoMeterImgName: [''],
      previewcarRightImg: [''],
      previewcarLeftImg: [''],
      previewcarLeftImgName: [''],
      previewcarBackImg: [''],
      previewcarBackImgName: [''],
      previewcarFrontImg: [''],
      previewcarFrontImgName: [''],
      previewcarRightImgName: [''],
    });

    this.profileForm = this.fb.group({
      registrationNumber: ['', Validators.required],
      nameonRC: [''],

      make: [''],
      model: [''],
      variant: [''],
      color: [''],
      fuelType: [''],
      transmission: [''],

      chassisNumber: ['', Validators.required],
      engineNumber: ['', Validators.required],
      yearOfManufacturing: ['', [Validators.required, Validators.minLength(6)]],
      dateOfRegistration: [''],
      registrationValidity: [''],
      pincode: [''],
      belt: ['', [Validators.required]],
      airconditioning: [''],
      remarks1: [''],
      bodyrust: [''],
      registrationState: [''],
      registrationDistrict: [''],
      registrationCity: [''],
      emission: [''],
      Interior: [''],
      Trunk: [''],
      Exterior: [''],
      role: [''],
      managerId: [''],
      Engineroomcleaning: [''],

      evaluatorId: [''],
      UnderneathVehicle: [''],
      InTheDiversseat: [''],
      cruisecontrol: [''],
      DrivingYourTestDrive: [''],
      vehicletype: [''],
      typeofbody: [''],
      distanceDriven: [''],
      NoOfOwners: [''],
      floorcovering: [''],
      challanPending: [''],
      exhaustpipe: [''],
      VehicleExterior: [''],
      bumper: [''],
      vehicleServiceCost: [''],
      engineandtransmission: [],
      steeringandfluid: [],
      coolantandfilter: [],
      removalstains: [],
      drycleaning: [],
      engineroomcleaning: ['no'],
      vehicletransfercharges: [],
      nocclearance: [],
      challenamount: [],
      CCClearance: [],
      pollutioncertificate: [],
      managerid: [''],

      frontright: [''],
      frontleft: [''],
      rearright: [''],
      rearleft: [''],
      sparediskwheel: [''],
      sparealliwheel: [''],
      majorAccident: [''],
      majorAccidentRemarks: [''],
      minorAccident: [''],
      minorAccidentRemarks: [''],
      hypothetication: ['', Validators.pattern('^[a-zA-Z]+$')],
      hypotheticatedBranch: ['', Validators.pattern('^[a-zA-Z]+$')],
      loanDue: [''],
      hypotheticationcompletedbranch: [''],
      insuranceType: [''],
      generalappearence: [''],
      Engine: [''],
      engine: [''],
      colour: [''],
      remarks: [''],
      insuranceCompanyName: [''],
      policyNumber: [''],
      insuranceFrom: [''],
      insuranceTo: [''],

      carFrontImgName: [''],
      carFrontImg: [''],
      dashboard: [''],
      carBackImgName: [''],
      carBackImg: [''],
      carLeftImgName: [''],
      carLeftImg: [''],
      carRightImgName: [''],
      carRightImg: [''],
      speedoMeterImgName: [''],
      speedoMeterImg: [''],
      chassisImgName: [''],
      chassisImg: [''],
      // Engineroomcleaning: [''],
      VehicleServiceCost: [''],
      interiorImg: [''],
      Pollutioncertificate: ['no'],
      vinPlateImg: [''],
      rcFrontName: [''],
      rcFrontImg: [''],
      Drycleaning: ['no'],
      RubbingPolishingCost: ['no'],
      CCClearances: ['no'],
      SpareKeysCost: ['no'],
      Challenamount: ['no'],
      otherCharges: [''],
      otherImages: [''],
      Engineandtransmission: ['no'],
      RegistrationCost: ['no'],
      Vehicletransfercharges: ['no'],
      Removalstains: ['no'],
      Nocclearance: ['no'],
      Coolantandfilter: ['no'],
      Steeringandfluid: ['no'],
      rcBackName: [''],
      rcBackImg: [''],
      insuranceName: [''],
      insuranceImg: [''],
      InsuranceCost: ['no'],
      interiorFrontName: [''],
      interiorFrontImg: [''],
      interiorBackName: [''],
      interiorBackImg: [''],
      invoiceName: [''],
      invoiceImg: [''],
      extraFitmentName: [''],
      extraFitmentImg: [''],
      functionsName: [''],
      functionsImg: [''],
      getcardetails: [''],
      scratchName: [''],
      scratchImg: [''],
      dentName: [''],
      dentImg: [''],
      breaksDmgName: [''],
      breaksDmgImg: [''],
      numberPlateName: [''],
      numberPlateImg: [''],
      oldCarNocName: [''],
      oldCarNocImg: [''],
      totalRefurbishmentCost: [],
      periodicServiceValue: [''],
      periodicServiceCost: [],
      insuranceValue: [''],
      insuranceCost: [],
      spareKeysValue: [''],
      spareKeysCost: [],
      registrationValue: [''],
      registrationCost: [],
      rubbingPolishingValue: [''],
      rubbingPolishingCost: ['no'],
      mobileNum: [''],
      otherDocfieldName: [''],
      periodicService: ['no'],

      interiorCleaningValue: [''],
      interiorCleaningCost: [''],
      pollutionCertificateValue: [''],
      pollutionCertificateCost: [''],
      custExpectedPrice: [''],
      entertextfield: [''],
      custOfferedPrice: [''],
      priceGap: [''],
      acceptCost: [''],
      rejectCost: [''],
      evaluatorofferedprice: [''],
      otherImagesDoc: this.fb.array([]),
      otherfieldsDoc: this.fb.array([]),
    });
  }

  get otherDocArray(): FormArray {
    return this.profileForm.get('otherImagesDoc') as FormArray;
  }

  get otherDocfieldArray(): FormArray {
    return this.profileForm.get('otherfieldsDoc') as FormArray;
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.profileForm.controls;
  }

  // add other images
  addOtherGroup() {
    return this.fb.group({
      documentName: [],
      url: [],
    });
  }

  special_char(event) {
    let k;
    k = event.charCode;
    return (
      (k > 64 && k < 91) ||
      (k > 96 && k < 123) ||
      k === 8 ||
      k === 32 ||
      (k >= 48 && k <= 57)
    );
  }

  AddOtherIMG() {
    this.otherDocArray.push(this.addOtherGroup());
    this.otherimagepush.push('');
  }

  removeOtherIMG(index) {
    this.otherDocArray.removeAt(index);
    this.otherimagepush.splice(index, 1);
    this.otherImageUrl.splice(index, 1);
  }

  // add other costs
  addOtherfield() {
    return this.fb.group({
      name: [],
      cost: [],
    });
  }
  othercost() {
    this.otherDocfieldArray.push(this.addOtherfield());
  }
  removeOthercost(index) {
    this.otherDocfieldArray.removeAt(index);
  }

  keyup(e) {}
  edits() {
    this.default1 = true;
    this.edited1 = true;
    this.flags = false;
    this.flags1 = true;
    this.value3 = true;
    this.defaultone = false;
    this.editone = true;
  }

  dropdown() {
    this.flags2 = true;
  }
  Remarks() {
    this.rem = true;
  }

  //  update!!!!
  updatevalues() {
    const editvalues = {
      id: this.id,
      nameOnRC: this.previewForm.value.previewnameonRC,
      registrationNumber: this.previewForm.value.previewregistrationNumber,
      mobileNum: this.previewForm.value.previewmobileNum,
      customerId: this.crmUniversalId,
      regValidity: this.previewForm.value.previewregValidity,
      regDistrict: this.previewForm.value.previewregDistrict,
      regCity: this.previewForm.value.previewregCity,
      pincode: this.previewForm.value.previewpincode,
      regState: this.previewForm.value.previewregState,
      imageDocuments: this.imagepush,
      // otherCharges:this.previewForm.value.
      model: this.previewForm.value.previewmodel,
      varient: this.previewForm.value.previewvariant,
      yearMonthOfManufacturing: this.previewForm.value
        .previewyearMonthOfManufacturing,
      vehicleType: this.previewForm.value.previewvehicleType,
      typeOfBody: this.previewForm.value.previewtypeOfBody,
      kmDriven: this.previewForm.value.previewkmDriven,
      frontWheelRight: this.previewForm.value.previewfrontWheelRight,
      frontWheelLeft: this.previewForm.value.previewfrontWheelLeft,
      rearWheelRight: this.previewForm.value.previewrearWheelRight,
      rearWheelLeft: this.previewForm.value.previewrearWheelLeft,
      spareDiskWheel: this.previewForm.value.previewspareDiskWheel,
      spareAlliWheel: this.previewForm.value.previewspareAlliWheel,
      anyMajorAccident: this.previewForm.value.previewminorAccident,
      anyMajorAccidentRemark: this.previewForm.value
        .previewmajorAccidentRemarks,
      anyMinorAccident: this.previewForm.value.previewminorAccident,
      anyMinorAccidentRemark: this.previewForm.value
        .previewminorAccidentRemarks,
      updatedDate: this.updatedDate,
      make: this.previewForm.value.previewmake,
      fuelType: this.previewForm.value.previewfuelType,
      chassisNum: this.previewForm.value.previewchassisNum,
      noOfOwners: this.previewForm.value.previewnoOfOwners,
      colour: this.previewForm.value.previewcolour,
      transmission: this.previewForm.value.previewtransmission,
      evalutorId: this.evalutorId,
      role: this.role.hrmsRole,
      engineNumber: this.previewForm.value.previewengineNumber,
      regDate: this.previewForm.value.previewregDate,
      emission: this.previewForm.value.previewemission,
      challanPending: this.previewForm.value.previewchallanPending,
      hypothecation: this.previewForm.value.previewhypothecation,
      hypothecatedBranch: this.previewForm.value.previewhypothecatedBranch,
      hypothecatedCompletedDate: this.previewForm.value
        .previewhypothecatedCompletedDate,
      insuranceType: this.previewForm.value.previewinsuranceType,
      loanAmountDue: this.previewForm.value.previewloanAmountDue,
      insuranceCompanyName: this.previewForm.value.previewinsuranceCompanyName,
      policyNumber: this.previewForm.value.previewpolicyNumber,
      insFromDate: this.previewForm.value.previewinsFromDate,
      insToDate: this.previewForm.value.previewinsToDate,
      periodicService: this.previewForm.value.previewperiodicService,
      periodicServiceCost: this.previewForm.value.previewperiodicServiceCost,
      spareKey: this.previewForm.value.previewspareKey,
      spareKeyCost: this.previewForm.value.previewspareKeyCost,
      rubbingPolishing: this.previewForm.value.previewrubbingPolishing,
      rubbingPolishingCost: this.previewForm.value.previewrubbingPolishingCost,
      image: this.imagepush,
      insurance: this.previewForm.value.previewinsurance,
      insuranceCost: this.previewForm.value.previewinsuranceCost,
      regDocument: this.previewForm.value.regDocument,
      regDocumentCharges: this.previewForm.value.regDocumentCharges,
      pollutionCertificate: this.previewForm.value.previewpollutionCertificate,
      pollutionCertificateCost: this.previewForm.value
        .previewpollutionCertificateCost,
      oilChanges: this.previewForm.value.previewoilChanges,
      oilChangesCost: this.previewForm.value.previewoilChangesCost,
      powerbrakefluidchange: this.previewForm.value
        .previewpowerbrakefluidchange,
      powerBrakeFluidChangeCost: this.previewForm.value
        .previewpowerBrakeFluidChangeCost,
      coolantFilterChange: this.previewForm.value.previewcoolantFilterChange,
      coolantFilterChangeCost: this.previewForm.value
        .previewcoolantFilterChangeCost,
      removalStainMarksStickers: this.previewForm.value
        .previewremovalStainMarksStickers,
      removalStainMarksStickersCost: this.previewForm.value
        .previewremovalStainMarksStickersCost,
      carpetCleaning: this.previewForm.value.previewcarpetCleaning,
      engineRoom: this.previewForm.value.previewengineRoom,
      engineRoomCost: this.previewForm.value.previewengineRoomCost,
      vehicleTransfer: this.previewForm.value.previewvehicleTransfer,
      vehicleTransferCharges: this.previewForm.value
        .previewvehicleTransferCharges,
      nocClearanceExpense: this.previewForm.value.previewnocClearanceExpense,
      nocClearanceExpenseCost: this.previewForm.value
        .previewnocClearanceExpenseCost,
      challanAmount: this.previewForm.value.previewchallanAmount,
      challanAmountCost: this.previewForm.value.previewchallanAmountCost,
      ccClearanceExpense: this.previewForm.value.previewccClearanceExpense,
      ccClearanceExpenseCost: this.previewForm.value
        .previewccClearanceExpenseCost,
      totalRefurbishmentCost: this.previewForm.value
        .previewtotalRefurbishmentCost,
      custExpectedPrice: this.previewForm.value.previewcustExpectedPrice,
      evaluatorOfferPrice: this.previewForm.value.previewevaluatorOfferPrice,
      managerId: this.role.approverId,
      evalutionStatus: 'EvalutionSubmitted',
    };

    this.http
      .editevaluationoldcardetails(
        this.previewForm.value.previewregistrationNumber,
        editvalues
      )
      .subscribe(
        (res) => {},
        (err) => {
          console.log(err);
        },
        () => {}
      );
    this.modalService.dismissAll();
    window.alert('Updated successfully');
  }

  savedraft() {
    this.profileForm.value.registrationValidity = this.date.transform(
      this.profileForm.value.registrationValidity,
      'yyyy-MM-dd'
    );
    this.profileForm.value.insuranceFrom = this.date.transform(
      this.profileForm.value.insuranceFrom,
      'yyyy-MM-dd'
    );
    this.profileForm.value.insuranceTo = this.date.transform(
      this.profileForm.value.insuranceTo,
      'yyyy-MM-dd'
    );
    this.profileForm.value.hypotheticationcompletedbranch = this.date.transform(
      this.profileForm.value.hypotheticationcompletedbranch,
      'yyyy-MM-dd'
    );

    let imgUploadArray: any = [];
    imgUploadArray = this.imagepush;
    if (this.otherimagepush.length > 0) {
      this.otherimagepush.forEach((element) => {
        if (element != '') {
          imgUploadArray.push(element);
        }
      });
    }

    const values = {
      id: '',
      role: this.role.hrmsRole,
      nameOnRC: this.profileForm.value.nameonRC,
      registrationNumber: this.profileForm.value.registrationNumber,
      mobileNum: this.profileForm.value.mobileNum,
      customerId: this.crmUniversalId,
      regValidity: this.profileForm.value.registrationValidity,
      regDistrict: this.profileForm.value.registrationDistrict,
      regCity: this.profileForm.value.registrationCity,
      pincode: this.profileForm.value.pincode,
      regState: this.profileForm.value.registrationState,
      imageDocuments: imgUploadArray,
      model: this.profileForm.value.model,
      varient: this.profileForm.value.variant,
      yearMonthOfManufacturing: this.profileForm.value.yearOfManufacturing,
      vehicleType: this.profileForm.value.vehicletype,
      typeOfBody: this.profileForm.value.typeofbody,
      kmDriven: this.profileForm.value.distanceDriven,
      frontWheelRight: this.profileForm.value.frontright,
      frontWheelLeft: this.profileForm.value.frontleft,
      rearWheelRight: this.profileForm.value.rearright,
      rearWheelLeft: this.profileForm.value.rearleft,
      spareDiskWheel: this.profileForm.value.sparediskwheel,
      spareAlliWheel: this.profileForm.value.sparealliwheel,
      anyMajorAccident: this.profileForm.value.majorAccident,
      anyMajorAccidentRemark: this.profileForm.value.majorAccidentRemarks,
      anyMinorAccident: this.profileForm.value.minorAccident,
      anyMinorAccidentRemark: this.profileForm.value.minorAccidentRemarks,
      updatedDate: '',
      make: this.profileForm.value.make,
      fuelType: this.profileForm.value.fuelType,
      chassisNum: this.profileForm.value.chassisNumber,
      noOfOwners: this.profileForm.value.NoOfOwners,
      colour: this.profileForm.value.colour,
      transmission: this.profileForm.value.transmission,
      totalRefurbishmentCost: parseInt(
        this.profileForm.value.totalRefurbishmentCost
      ),
      evalutorId: this.evalutorId,
      VehicleExterior: this.profileForm.value.VehicleExterior,
      DrivingYourTestDrive: this.profileForm.value.DrivingYourTestDrive,
      InTheDiversseat: this.profileForm.value.InTheDiversseat,
      UnderneathVehicle: this.profileForm.value.UnderneathVehicle,
      Trunk: this.profileForm.value.Trunk,
      Engine: this.profileForm.value.Engine,
      Exterior: this.profileForm.value.Exterior,
      Interior: this.profileForm.value.Interior,
      engineNumber: this.profileForm.value.engineNumber,
      regDate: this.profileForm.value.dateOfRegistration,
      emission: this.profileForm.value.emission,
      challanPending: this.profileForm.value.challanPending,
      hypothecation: this.profileForm.value.hypothetication,
      hypothecatedBranch: this.profileForm.value.hypotheticatedBranch,
      hypothecatedCompletedDate: this.profileForm.value
        .hypotheticationcompletedbranch,
      insuranceType: this.profileForm.value.insuranceType,
      loanAmountDue: this.profileForm.value.loanDue,
      insuranceCompanyName: this.profileForm.value.insuranceCompanyName,
      policyNumber: this.profileForm.value.policyNumber,
      insFromDate: this.profileForm.value.insuranceFrom,
      insToDate: this.profileForm.value.insuranceTo,
      periodicService: this.profileForm.value.periodicService,
      periodicServiceCost: this.profileForm.value.periodicServiceCost,
      spareKey: this.profileForm.value.SpareKeysCost,
      spareKeyCost: this.profileForm.value.spareKeysCost,
      rubbingPolishing: this.profileForm.value.RubbingPolishingCost,
      rubbingPolishingCost: this.profileForm.value.rubbingPolishingCost,
      insurance: this.profileForm.value.InsuranceCost,
      insuranceCost: this.profileForm.value.insuranceCost,
      regDocument: this.profileForm.value.RegistrationCost,
      regDocumentCharges: this.profileForm.value.registrationCost,
      pollutionCertificate: this.profileForm.value.Pollutioncertificate,
      pollutionCertificateCost: this.profileForm.value.pollutioncertificate,
      oilChanges: this.profileForm.value.Engineandtransmission,
      oilChangesCost: this.profileForm.value.engineandtransmission,
      powerbrakefluidchange: this.profileForm.value.Steeringandfluid,
      powerBrakeFluidChangeCost: this.profileForm.value.steeringandfluid,
      coolantFilterChange: this.profileForm.value.Coolantandfilter,
      coolantFilterChangeCost: this.profileForm.value.coolantandfilter,
      removalStainMarksStickers: this.profileForm.value.Removalstains,
      removalStainMarksStickersCost: this.profileForm.value.removalstains,
      carpetCleaning: this.profileForm.value.Drycleaning,
      carpetCleaningCost: this.profileForm.value.drycleaning,
      engineRoom: this.profileForm.value.Engineroomcleaning,
      engineRoomCost: this.profileForm.value.engineroomcleaning,
      vehicleTransfer: this.profileForm.value.Vehicletransfercharges,
      vehicleTransferCharges: this.profileForm.value.vehicletransfercharges,
      nocClearanceExpense: this.profileForm.value.Nocclearance,
      nocClearanceExpenseCost: this.profileForm.value.nocclearance,
      challanAmount: this.profileForm.value.Challenamount,
      challanAmountCost: this.profileForm.value.challenamount,
      ccClearanceExpense: this.profileForm.value.CCClearances,
      ccClearanceExpenseCost: this.profileForm.value.CCClearance,
      custExpectedPrice: this.profileForm.value.custExpectedPrice,
      evaluatorOfferPrice: this.profileForm.value.evaluatorofferedprice,
      managerId: this.role.approverId,
    };
    this.http.saveevalutionoldcardetails(values).subscribe((res) => {});
    window.alert('Registration Submitted successfully');
  }

  /**
   * Checking control validation
   *
   * @param controlName: string => Equals to formControlName
   * @param validationType: string => Equals to valitors name
   */
  isControlHasError(controlName: string, validationType: string): boolean {
    const control = this.profileForm.controls[controlName];
    if (!control) {
      return false;
    }
    const result =
      control.hasError(validationType) && (control.dirty || control.touched);
    return result;
  }

  onSubmit() {
    this.submitted = true;

    const uploadImages = [
      { documentName: 'frontside', url: this.url },
      { documentName: 'backside', url: this.url1 },
      { documentName: 'leftside', url: this.url2 },
      { documentName: 'rightside', url: this.url3 },
      { documentName: 'speedometer', url: this.url4 },
      { documentName: 'chassis', url: this.url5 },
      { documentName: 'interiorfront', url: this.url6 },
      { documentName: 'interiorback', url: this.url7 },
      { documentName: 'rc front', url: this.url8 },
      { documentName: 'rc back', url: this.url9 },
      { documentName: 'insurance', url: this.url10 },
      { documentName: 'invoice', url: this.url11 },
      { documentName: 'extra fitment', url: this.url12 },
      { documentName: 'scrach damage', url: this.url13 },
      { documentName: 'dent damage', url: this.url14 },
      { documentName: 'functions', url: this.url15 },
      { documentName: 'break damage', url: this.url16 },
      { documentName: 'number plate', url: this.url17 },
      { documentName: 'bank finance old car/noc', url: this.url18 },
    ];

    // stop here if form is invalid
    if (this.profileForm.invalid) {
      return;
    }

    this.hasFormErrors = false;
    const controls = this.profileForm.controls;
    /** check form */
    if (this.profileForm.invalid) {
      Object.keys(controls).forEach((controlName) =>
        controls[controlName].markAsTouched()
      );
      this.hasFormErrors = true;
      return;
    }

    this.profileForm.value.registrationValidity = this.date.transform(
      this.profileForm.value.registrationValidity,
      'yyyy-MM-dd'
    );
    this.profileForm.value.insuranceFrom = this.date.transform(
      this.profileForm.value.insuranceFrom,
      'yyyy-MM-dd'
    );
    this.profileForm.value.insuranceTo = this.date.transform(
      this.profileForm.value.insuranceTo,
      'yyyy-MM-dd'
    );
    this.profileForm.value.hypotheticationcompletedbranch = this.date.transform(
      this.profileForm.value.hypotheticationcompletedbranch,
      'yyyy-MM-dd'
    );
    let imgUploadArray: any = [];
    imgUploadArray = this.imagepush;
    if (this.otherimagepush.length > 0) {
      this.otherimagepush.forEach((element) => {
        if (element !== '') {
          imgUploadArray.push(element);
        }
      });
    }
    const values = {
      id: '',
      nameOnRC: this.profileForm.value.nameonRC,
      registrationNumber: this.profileForm.value.registrationNumber,
      mobileNum: this.profileForm.value.mobileNum,
      customerId: this.crmUniversalId,
      regValidity: this.profileForm.value.registrationValidity,
      regDistrict: this.profileForm.value.registrationDistrict,
      regCity: this.profileForm.value.registrationCity,
      pincode: this.profileForm.value.pincode,
      regState: this.profileForm.value.registrationState,
      imageDocuments: uploadImages,
      otherImages: this.otherimagepush,
      model: this.profileForm.value.model,
      varient: this.profileForm.value.variant,
      yearMonthOfManufacturing: this.profileForm.value.yearOfManufacturing,
      vehicleType: this.profileForm.value.vehicletype,
      typeOfBody: this.profileForm.value.typeofbody,
      kmDriven: this.profileForm.value.distanceDriven,
      frontWheelRight: this.profileForm.value.frontright,
      frontWheelLeft: this.profileForm.value.frontleft,
      rearWheelRight: this.profileForm.value.rearright,
      rearWheelLeft: this.profileForm.value.rearleft,
      spareDiskWheel: this.profileForm.value.sparediskwheel,
      spareAlliWheel: this.profileForm.value.sparealliwheel,
      anyMajorAccident: this.profileForm.value.majorAccident,
      anyMajorAccidentRemark: this.profileForm.value.majorAccidentRemarks,
      anyMinorAccident: this.profileForm.value.minorAccident,
      anyMinorAccidentRemark: this.profileForm.value.minorAccidentRemarks,
      updatedDate: '',
      make: this.profileForm.value.make,
      fuelType: this.profileForm.value.fuelType,
      chassisNum: this.profileForm.value.chassisNumber,
      noOfOwners: this.profileForm.value.NoOfOwners,
      colour: this.profileForm.value.colour,
      transmission: this.profileForm.value.transmission,
      data: this.valuesall,
      role: this.role.hrmsRole,
      totalRefurbishmentCost: this.totalRefurbishmentCost,
      evalutionStatus: 'EvalutionSubmitted',
      evalutorId: this.evalutorId,
      VehicleExterior: this.profileForm.value.VehicleExterior,
      DrivingYourTestDrive: this.profileForm.value.DrivingYourTestDrive,
      InTheDiversseat: this.profileForm.value.InTheDiversseat,
      UnderneathVehicle: this.profileForm.value.UnderneathVehicle,
      Trunk: this.profileForm.value.Trunk,
      Engine: this.profileForm.value.Engine,
      Exterior: this.profileForm.value.Exterior,
      Interior: this.profileForm.value.Interior,
      engineNumber: this.profileForm.value.engineNumber,
      regDate: this.profileForm.value.dateOfRegistration,
      emission: this.profileForm.value.emission,
      challanPending: this.profileForm.value.challanPending,
      hypothecation: this.profileForm.value.hypothetication,
      hypothecatedBranch: this.profileForm.value.hypotheticatedBranch,
      hypothecatedCompletedDate: this.profileForm.value
        .hypotheticationcompletedbranch,
      insuranceType: this.profileForm.value.insuranceType,
      loanAmountDue: this.profileForm.value.loanDue,
      insuranceCompanyName: this.profileForm.value.insuranceCompanyName,
      policyNumber: this.profileForm.value.policyNumber,
      insFromDate: this.profileForm.value.insuranceFrom,
      insToDate: this.profileForm.value.insuranceTo,
      periodicService: this.profileForm.value.periodicService,
      periodicServiceCost: this.profileForm.value.periodicServiceCost,
      spareKey: this.profileForm.value.SpareKeysCost,
      spareKeyCost: this.profileForm.value.spareKeysCost,
      rubbingPolishing: this.profileForm.value.RubbingPolishingCost,
      rubbingPolishingCost: this.profileForm.value.rubbingPolishingCost,
      insurance: this.profileForm.value.InsuranceCost,
      insuranceCost: this.profileForm.value.insuranceCost,
      regDocument: this.profileForm.value.RegistrationCost,
      regDocumentCharges: this.profileForm.value.registrationCost,
      pollutionCertificate: this.profileForm.value.Pollutioncertificate,
      pollutionCertificateCost: this.profileForm.value.pollutioncertificate,
      oilChanges: this.profileForm.value.Engineandtransmission,
      oilChangesCost: this.profileForm.value.engineandtransmission,
      powerbrakefluidchange: this.profileForm.value.Steeringandfluid,
      powerBrakeFluidChangeCost: this.profileForm.value.steeringandfluid,
      coolantFilterChange: this.profileForm.value.Coolantandfilter,
      coolantFilterChangeCost: this.profileForm.value.coolantandfilter,
      removalStainMarksStickers: this.profileForm.value.Removalstains,
      removalStainMarksStickersCost: this.profileForm.value.removalstains,
      carpetCleaning: this.profileForm.value.Drycleaning,
      carpetCleaningCost: this.profileForm.value.drycleaning,
      engineRoom: this.profileForm.value.Engineroomcleaning,
      engineRoomCost: this.profileForm.value.engineroomcleaning,
      vehicleTransfer: this.profileForm.value.Vehicletransfercharges,
      vehicleTransferCharges: this.profileForm.value.vehicletransfercharges,
      nocClearanceExpense: this.profileForm.value.Nocclearance,
      nocClearanceExpenseCost: this.profileForm.value.nocclearance,
      challanAmount: this.profileForm.value.Challenamount,
      challanAmountCost: this.profileForm.value.challenamount,
      ccClearanceExpense: this.profileForm.value.CCClearances,
      ccClearanceExpenseCost: this.profileForm.value.CCClearance,
      otherCharges: this.profileForm.value.otherfieldsDoc,
      custExpectedPrice: this.profileForm.value.custExpectedPrice,
      evaluatorOfferPrice: this.profileForm.value.evaluatorofferedprice,
      // managerId: this.role.reportingManagerId,
      managerId: this.role.approverId,
    };
    this.http.saveevalutionoldcardetails(values).subscribe(
      (res) => {
        if (res.statusCode === 'CREATED') {
          this.openSnackBar(
            'Evaluation has been created successfully.',
            'success'
          );
          this.updateTask(
            res.body.id,
            'SENT_FOR_APPROVAL',
            'Success',
            'Evaluation'
          );
        } else if (res.statusCode === 'FAILED') {
          this.openSnackBar('Evaluation has not been created', 'fail');
        } else {
          this.openSnackBar(res.statusCode, 'fail');
        }
      },
      (error) => {
        this.openSnackBar('Sever is down', 'Save Evaluation failed');
      }
    );
    window.alert('Registration Submitted successfully');
    this.router.navigate(['evaluator/evaluatorMenu']);
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 3000,
    });
  }

  /**
   * Task Update
   */
  public updateTask(confirmationId, status, remarks, taskName) {
    const requestBody = {
      universalId: this.crmUniversalId,
      taskId: null,
      remarks: remarks ? remarks : '',
      universalModuleId: confirmationId,
      evaluationApproverId: this.role.approverId,
      status,
      taskName,
    };

    this.lead360Service.updateEvaluationTask(requestBody).subscribe(
      (res: any) => {
        if (res.success) {
          this.openSnackBar(
            'Evaluation confirmation Id updated in task.',
            'success'
          );
        } else if (res.statusCode === 500) {
          this.openSnackBar('Internal server error, statusCode:500 ', 'fail');
        } else if (res.success === 'fail') {
          this.openSnackBar(
            'Oops! Evaluation confirmation Id not updated in task.',
            'fail'
          );
        } else {
          this.openSnackBar(res.errorMessage, 'fail');
        }
      },
      (error) => {
        this.openSnackBar('Server is down', 'UpdateEvaluationTask failed');
      }
    );
  }

  previewbutton(form, content) {
    this.modalService.open(content, {
      size: 'lg',
    });
    let imgUploadArray: any = [];
    imgUploadArray = this.imagepush;
    if (this.otherimagepush.length > 0) {
      this.otherimagepush.forEach((element) => {
        if (element != '') {
          imgUploadArray.push(element);
        }
      });
    }
    this.purl = imgUploadArray;
    this.previewForm.patchValue({
      previewregistrationNumber: form.registrationNumber.value,
      previewnameonRC: form.nameonRC.value,
      previewmake: form.make.value,
      previewmodel: form.model.value,
      previewvariant: form.variant.value,
      previewmobileNum: form.mobileNum.value,
      previewfuelType: form.fuelType.value,
      previewengineNumber: form.engineNumber.value,
      previewmajorAccident: form.majorAccident.value,
      previewmajorAccidentRemarks: form.majorAccidentRemarks.value,
      previewminorAccident: form.minorAccident.value,
      previewminorAccidentRemarks: form.minorAccidentRemarks.value,
      previewchallanPending: form.challanPending.value,
      previewchassisNum: form.chassisNumber.value,
      previewcolour: form.colour.value,
      previewcustExpectedPrice: form.custExpectedPrice.value,
      previewcustomerId: this.crmUniversalId,
      previewemission: form.emission.value,
      previewevaluatorOfferPrice: form.evaluatorofferedprice.value,
      previewoilChanges: form.Engineandtransmission.value,
      previewoilChangesCost: form.engineandtransmission.value,
      previewpowerbrakefluidchange: form.Steeringandfluid.value,
      previewpowerBrakeFluidChangeCost: form.steeringandfluid.value,
      previewcoolantFilterChange: form.Coolantandfilter.value,
      previewcoolantFilterChangeCost: form.coolantandfilter.value,
      previewremovalStainMarksStickers: form.Removalstains.value,
      previewremovalStainMarksStickersCost: form.removalstains.value,
      previewcarpetCleaning: form.Drycleaning.value,
      previewcarpetCleaningCost: form.drycleaning.value,
      previewengineRoom: form.Engineroomcleaning.value,
      previewengineRoomCost: form.engineroomcleaning.value,
      previewvehicleTransfer: form.Vehicletransfercharges.value,
      previewvehicleTransferCharges: form.vehicletransfercharges.value,
      previewnocClearanceExpense: form.Nocclearance.value,
      previewnocClearanceExpenseCost: form.nocclearance.value,
      previewchallanAmount: form.Challenamount.value,
      previewchallanAmountCost: form.challenamount.value,
      previewccClearanceExpense: form.CCClearances.value,
      previewccClearanceExpenseCost: form.CCClearance.value,
      previewtotalRefurbishmentCost: form.totalRefurbishmentCost.value,
      previewevalutorId: this.evalutorId,
      previewfrontWheelLeft: form.frontleft.value,
      previewfrontWheelRight: form.frontright.value,
      previewhypothecatedBranch: form.hypotheticatedBranch.value,
      previewhypothecatedCompletedDate:
        form.hypotheticationcompletedbranch.value,
      previewhypothecation: form.hypothetication.value,
      imageDocuments: imgUploadArray,
      previewinsFromDate: form.insuranceFrom.value,
      previewinsToDate: form.insuranceTo.value,
      previewinsurance: form.InsuranceCost.value,
      previewinsuranceCompanyName: form.insuranceCompanyName.value,
      previewinsuranceCost: form.insuranceCost.value,
      previewinsuranceType: form.insuranceType.value,
      previewkmDriven: form.distanceDriven.value,
      previewloanAmountDue: form.loanDue.value,
      previewmanagerId: form.managerId.value,
      previewnoOfOwners: form.NoOfOwners.value,
      previewperiodicService: form.periodicService.value,
      previewperiodicServiceCost: form.periodicServiceCost.value,
      previewpincode: form.pincode.value,
      previewpolicyNumber: form.policyNumber.value,
      previewpollutionCertificate: form.Pollutioncertificate.value,
      previewpollutionCertificateCost: form.pollutioncertificate.value,
      previewrearWheelLeft: form.rearleft.value,
      previewrearWheelRight: form.rearright.value,
      previewregCity: form.registrationCity.value,
      previewregDate: form.dateOfRegistration.value,
      previewregDistrict: form.registrationDistrict.value,
      role: form.role.value,
      regDocument: form.RegistrationCost.value,
      regDocumentCharges: form.registrationCost.value,
      previewregState: form.registrationState.value,
      previewregValidity: form.registrationValidity.value,
      previewrubbingPolishing: form.RubbingPolishingCost.value,
      previewrubbingPolishingCost: form.rubbingPolishingCost.value,
      previewspareAlliWheel: form.sparealliwheel.value,
      previewspareDiskWheel: form.sparediskwheel.value,
      previewspareKey: form.SpareKeysCost.value,
      previewspareKeyCost: form.spareKeysCost.value,
      previewtransmission: form.transmission.value,
      previewtypeOfBody: form.typeofbody.value,
      updatedDate: '',
      previewvarient: form.variant.value,
      previewvehicleType: form.vehicletype.value,
      previewyearMonthOfManufacturing: form.yearOfManufacturing.value,
    });
  }

  ngDoCheck() {
    this.addCost();
  }

  addCost() {
    const sumOfCost =
      this.profileForm.controls.periodicServiceCost.value +
      this.profileForm.controls.insuranceCost.value +
      this.profileForm.controls.engineandtransmission.value +
      this.profileForm.controls.registrationCost.value +
      this.profileForm.controls.steeringandfluid.value +
      this.profileForm.controls.vehicletransfercharges.value +
      this.profileForm.controls.coolantandfilter.value +
      this.profileForm.controls.nocclearance.value +
      this.profileForm.controls.removalstains.value +
      this.profileForm.controls.challenamount.value +
      this.profileForm.controls.drycleaning.value +
      this.profileForm.controls.CCClearance.value +
      this.profileForm.controls.spareKeysCost.value +
      this.profileForm.controls.pollutioncertificate.value +
      this.profileForm.controls.rubbingPolishingCost.value +
      this.profileForm.controls.engineroomcleaning.value;
    const resultArray = this.otherDocfieldArray.value.map(function (a) {
      return a.cost;
    });
    if (resultArray.length > 0) {
      this.totalRefurbishmentCost =
        sumOfCost + resultArray.reduce(this.sumofArray);
    } else {
      this.totalRefurbishmentCost = sumOfCost;
    }
  }
  sumofArray(sum, num) {
    return sum + num;
  }

  onFileSelect(docType, formEle) {}

  hypothetication() {
    this.hypotheticationFlag = !this.hypotheticationFlag;
  }

  InsuranceCheck() {
    this.insuranceFlag = !this.insuranceFlag;
  }

  generalappearence() {
    this.flag = !this.flag;
  }
  InTheDiversseat() {
    this.flag6 = !this.flag6;
  }
  DrvingYourTestDrive() {
    this.flag7 = !this.flag7;
  }
  VehicleExterior() {
    this.flag8 = !this.flag8;
  }
  Engine() {
    this.flag1 = !this.flag1;
  }
  Exterior() {
    this.flag2 = !this.flag2;
  }
  Interior() {
    this.flag3 = !this.flag3;
  }
  Trunk() {
    this.flag4 = !this.flag4;
  }
  UnderneathVehicle() {
    this.flag5 = !this.flag5;
  }

  otherImagesOnFileSelected(event, idx) {
    this.image = true;
    this.default1 = false;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'otherImages');
    this.http.getimage(formData).subscribe((res: any) => {
      this.otherImageUrl[idx] = res.documentPath;
      this.changedetectorref.detectChanges();
      this.otherimagepush[idx] = {
        documentName: this.profileForm.value.otherImagesDoc[idx].documentName,
        url: this.otherImageUrl[idx],
      };
    });
  }

  onFileSelected0(event) {
    this.default1 = false;
    this.image0 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carFrontImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('carFrontImgName')
        .setValue(event.target.files[0].name);
      this.url = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'frontside', url: res.documentPath });
    });
  }

  onFileSelected1(event) {
    this.default2 = false;
    this.image1 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carBackImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('carBackImgName')
        .setValue(event.target.files[0].name);
      this.url1 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'backside', url: this.url1 });
    });
  }
  onFileSelected2(event) {
    this.default1 = false;
    this.image2 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carLeftImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('carLeftImgName')
        .setValue(event.target.files[0].name);
      this.url2 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'leftside', url: this.url2 });
    });
  }
  onFileSelected3(event) {
    this.default1 = false;
    this.image3 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'carRightImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('carRightImgName')
        .setValue(event.target.files[0].name);
      this.url3 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'rightside', url: this.url3 });
    });
  }
  onFileSelected4(event) {
    this.default1 = false;
    this.image4 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'speedoMeterImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('speedoMeterImgName')
        .setValue(event.target.files[0].name);
      this.url4 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'speedometer', url: this.url4 });
    });
  }
  onFileSelected5(event) {
    this.default1 = false;
    this.image5 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'chassisImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('chassisImgName')
        .setValue(event.target.files[0].name);
      this.url5 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'Chassis', url: this.url5 });
    });
  }
  onFileSelected6(event) {
    this.default1 = false;
    this.image6 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'interiorFrontImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('interiorFrontName')
        .setValue(event.target.files[0].name);
      this.url6 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'interior front', url: this.url6 });
    });
  }
  onFileSelected7(event) {
    this.default1 = false;
    this.image7 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'interiorBackImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('interiorBackName')
        .setValue(event.target.files[0].name);

      this.url7 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'interior back', url: this.url7 });
    });
  }
  onFileSelected8(event) {
    this.default1 = false;
    this.image8 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'rcFrontImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm.get('rcFrontName').setValue(event.target.files[0].name);

      this.url8 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'RC front', url: this.url8 });
    });
  }
  onFileSelected9(event) {
    this.default1 = false;
    this.image9 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'rcBackImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm.get('rcBackName').setValue(event.target.files[0].name);

      this.url9 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'RC back', url: this.url9 });
    });
  }
  onFileSelected10(event) {
    this.default1 = false;
    this.image10 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'insuranceImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('insuranceName')
        .setValue(event.target.files[0].name);

      this.url10 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'insurance', url: this.url10 });
    });
  }
  onFileSelected11(event) {
    this.default1 = false;
    this.image11 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'invoiceImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm.get('invoiceName').setValue(event.target.files[0].name);

      this.url11 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'invoice', url: this.url11 });
    });
  }
  onFileSelected12(event) {
    this.default1 = false;
    this.image12 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'extraFitmentImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('extraFitmentName')
        .setValue(event.target.files[0].name);

      this.url12 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'extra fitment', url: this.url12 });
    });
  }
  onFileSelected13(event) {
    this.default1 = false;
    this.image13 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'scratchDamageImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm.get('scratchName').setValue(event.target.files[0].name);

      this.url13 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'scratch damage', url: this.url13 });
    });
  }
  onFileSelected14(event) {
    this.default1 = false;
    this.image14 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'dentDamageImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm.get('dentName').setValue(event.target.files[0].name);

      this.url14 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'dent damage', url: this.url14 });
    });
  }
  onFileSelected15(event) {
    this.default1 = false;
    this.image15 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'funtionsImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('functionsName')
        .setValue(event.target.files[0].name);

      this.url15 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'funtions', url: this.url15 });
    });
  }
  onFileSelected16(event) {
    this.default1 = false;
    this.image16 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'breaksDmgImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('breaksDmgName')
        .setValue(event.target.files[0].name);
      this.url16 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'break damage', url: this.url16 });
    });
  }
  onFileSelected17(event) {
    this.default1 = false;
    this.image17 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'numberPlateImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('numberPlateName')
        .setValue(event.target.files[0].name);
      this.url17 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({ documentName: 'number plate', url: this.url17 });
    });
  }
  onFileSelected18(event) {
    this.default1 = false;
    this.image18 = true;
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
    formData.append('universalId', this.crmUniversalId);
    formData.append('documentType', 'oldCarNocImg');
    this.http.getimage(formData).subscribe((res: any) => {
      this.profileForm
        .get('oldCarNocName')
        .setValue(event.target.files[0].name);
      this.url18 = res.documentPath;
      this.changedetectorref.detectChanges();
      this.imagepush.push({
        documentName: 'bank/finance old car NOC',
        url: this.url18,
      });
    });
  }

  majorAccidnt(e) {
    if (e.source.value === 'Yes') {
      this.showMajorAccidentRemarks = true;
    } else {
      this.showMajorAccidentRemarks = false;
    }
  }

  minorAccidnt(e) {
    if (e.source.value === 'Yes') {
      this.showMinorAccidentRemarks = true;
    } else {
      this.showMinorAccidentRemarks = false;
    }
  }

  pincodeSearch(event, form) {
    this.http.getLocationUsingPincode(event).subscribe((res) => {
      form.patchValue({
        registrationState: res[0].PostOffice[0].State,
        registrationDistrict: res[0].PostOffice[0].District,
      });
    });
  }

  registrationSearch(event, form) {
    this.regnum = event;
    this.enquiryservice.checkLeadAvailability(event).subscribe(
      (leadRes) => {
        if (leadRes.isSuccess === 'true') {
          this.crmUniversalId = leadRes.crmUniversalId;
          this.http.getcarparameters(event).subscribe((carRes) => {
            if (carRes === null) {
              this.http.getregistration(event).subscribe(
                (res) => {
                  form.patchValue({
                    make: res.make,
                    model: res.model,
                    variant: res.variant,
                    nameonRC: res.nameOnRC,
                    fuelType: res.fuelType,
                    chassisNumber: res.chassisNum,
                    engineNumber: res.engineNumber,
                  });
                },
                (err) => {
                  console.log(err);
                  window.alert('Invalid registration number');
                },
                () => {}
              );
            } else if (carRes.registrationNumber === this.regnum) {
              window.alert('registration number already exits');
            }
          });
        } else {
          this.leadCreationStatus();
        }
      },
      (error) => {
        console.log(error);
        window.alert('Network Error. Check you Network and Try Again');
      }
    );
  }

  // Pop-Up To Show Lead Creation Status
  leadCreationStatus() {
    let _title = '';
    _title = 'Lead Creation Status';
    const _description = [
      'Lead Not Created with this Registration Number. Please Create and Try Again',
    ];
    const dialogRef = this.layoutUtilsService.taskRoute(_title, _description);
    dialogRef.afterClosed().subscribe((res) => {
      if (!res) {
        return;
      }
      this.router.navigate(['/ems/preEnquiry/newlead']);
    });
  }

  remove() {
    this.profileForm.patchValue({ carFrontImgName: '' });
    this.url = '';
  }
  remove1() {
    this.profileForm.patchValue({ carBackImgName: '' });
    this.url1 = '';
  }
  remove2() {
    this.profileForm.patchValue({ carLeftImgName: '' });
    this.url2 = '';
  }
  remove3() {
    this.profileForm.patchValue({ carRightImgName: '' });
    this.url3 = '';
  }
  remove4() {
    this.profileForm.patchValue({ speedoMeterImgName: '' });
    this.url4 = '';
  }
  remove5() {
    this.profileForm.patchValue({ chassisImgName: '' });
    this.url5 = '';
  }
  remove6() {
    this.profileForm.patchValue({ interiorFrontName: '' });
    this.url6 = '';
  }
  remove7() {
    this.profileForm.patchValue({ interiorBackName: '' });
    this.url7 = '';
  }
  remove8() {
    this.profileForm.patchValue({ rcFrontName: '' });
    this.url8 = '';
  }
  remove9() {
    this.profileForm.patchValue({ rcBackName: '' });
    this.url9 = '';
  }
  remove10() {
    this.profileForm.patchValue({ insuranceName: '' });
    this.url10 = '';
  }
  remove11() {
    this.profileForm.patchValue({ invoiceName: '' });
    this.url11 = '';
  }
  remove12() {
    this.profileForm.patchValue({ extraFitmentName: '' });
    this.url12 = '';
  }
  remove13() {
    this.profileForm.patchValue({ scratchName: '' });
    this.url13 = '';
  }
  remove14() {
    this.profileForm.patchValue({ dentName: '' });
    this.url14 = '';
  }
  remove15() {
    this.profileForm.patchValue({ functionsName: '' });
    this.url15 = '';
  }
  remove16() {
    this.profileForm.patchValue({ breaksDmgName: '' });
    this.url16 = '';
  }
  remove17() {
    this.profileForm.patchValue({ numberPlateName: '' });
    this.url17 = '';
  }
  remove18() {
    this.profileForm.patchValue({ oldCarNocName: '' });
    this.url18 = '';
  }
}
