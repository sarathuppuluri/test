import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { EnquiryService } from './../../../core/e-commerce/_services';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from "@angular/material";
import { AppDateAdapter, APP_DATE_FORMATS } from './format-date';

@Component({
	selector: 'kt-data-bank',
	templateUrl: './data-bank.component.html',
	styleUrls: ['./data-bank.component.scss'],
	providers: [
		{
			provide: DateAdapter, useClass: AppDateAdapter
		},
		{
			provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
		}
	]
})
export class DataBankComponent implements OnInit {

	second = 1000;
	minute = this.second * 60;
	hour = this.minute * 60;
	day = this.hour * 24;
	month = this.day * 30;
	year = this.day * 365;

	leadObject: any = {};
	docsPath: any = {};
	documentsObject: any;
	previewURL = [];
	docKeyNames = [];
	changedetectorref: any;
	leadId = '';

	constructor(private fb: FormBuilder, private enquiryservice: EnquiryService) { }

	DataBankForm: FormGroup;
	DataBankForm1: FormGroup;
	DataBankForm2: FormGroup;
	DataBankForm21: FormGroup;
	DataBankForm3: FormGroup;
	DataBankForm4: FormGroup;
	DataBankForm5: FormGroup;
	DataBankForm6: FormGroup;
	DataBankForm7: FormGroup;

	tempObjDoc: any = {
		contentSize: 0,
		createdBy: Date.now(),
		description: "",
		documentNumber: "",
		documentPath: "",
		documentType: "",
		documentVersion: 0,
		fileName: "",
		gstNumber: "",
		id: 0,
		keyName: "",
	}

	documentNumber(type, docNumber) {
		this.tempObjDoc.documentNumber = docNumber;
		this.tempObjDoc.documentType = type;
		this.tempObjDoc.id = 0;
		this.documentsObject.push(this.tempObjDoc);
	}

	onFileSelect(event, docType, formEle, i) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			this.DataBankForm3.get(formEle).setValue(file.name);
		}
	}
	deleteDocument(docName, formEle, i) {
		this.DataBankForm3.get(formEle).reset();
	}

	ageCal() {
		let millisecondsDiff = (Date.now() - Date.parse(this.DataBankForm1.controls.dateOfBirth.value));
		let age = Math.round(millisecondsDiff / this.year);
		this.DataBankForm1.patchValue({ age: age });
	}

	assignAddress(event) {
		if (this.DataBankForm2.controls.sameAsCommunicationAddress.value === true) {
			this.DataBankForm21.patchValue(this.DataBankForm2.value);
		}
	}

	pincodeSearch(event, form) {
		if (this.DataBankForm2.controls.sameAsCommunicationAddress.value !== true) {
			this.enquiryservice.getLocationUsingPincode(event).subscribe(res => {
				form.patchValue({
					state: res[0].PostOffice[0].State,
					district: res[0].PostOffice[0].District
				});
			});
		}
	}

	expiryCount(dateVal, i, formCtl, frmNM, patName) {
		let date1 = Date.now();
		let date2 = Date.parse(dateVal);
		let diff = (date2 - date1);
		let days = Math.round(diff / this.day);
		//let years  =  Math.floor(days / 365 );
		let months = Math.floor(days / 30);
		let remainingdays = Math.floor(days % 30);
		let monthsDisplay = months > 0 ? months + (months == 1 ? " Month " : " Months ") : "";
		let daysDisplay = remainingdays > 0 ? remainingdays + (remainingdays == 1 ? " Day" : " Days") : "";
		let temp = (<FormArray>frmNM.controls[formCtl]).at(i);
		temp.patchValue({[patName]: monthsDisplay + daysDisplay });
	}

	initFourWheelRows() {
		return this.fb.group({
			noOfVehicles: [''],
			Make: [''],
			Model: [''],
			variant: [''],
			regNo: [''],
			myf: [''],
			hypothecationName: [''],
			hypothecationBranch: [''],
			insuranceCompany: [''],
			insuranceNumber: [''],
			insuranceExpiry: [''],
			insuranceExpiryCount: [''],
			kmReading: [''],
			service: [''],
			serviceCenterName: [''],
			location: [''],
			contactNo: [''],
			outsideserviceCenterName: [''],
			outsidelocation: [''],
			contactPerson: [''],
			contactNumber: [''],
			units: [''],
		});
	}
	initTwoWheelRows() {
		return this.fb.group({
			noOfVehicles2: [''],
			make2: [''],
			model2: [''],
			variant2: [''],
			regNo2: [''],
			myf2: [''],
			hypothecationName2: [''],
			hypothecationBranch2: [''],
			insuranceCompany2: [''],
			insuranceNumber2: [''],
			insuranceExpiry2: [''],
			insuranceExpiryCount2: [''],
			kmReading2: [''],
			service2: [''],
			serviceCenterName2: [''],
			location2: [''],
			contactNo2: [''],
			outsideserviceCenterName2: [''],
			outsidelocation2: [''],
			contactPerson2: [''],
			contactNumber2: [''],
			units2: [''],
		});
	}

	initThreeWheelRows() {
		return this.fb.group({
			noOfVehicles3: [''],
			make3: [''],
			model3: [''],
			variant3: [''],
			regNo3: [''],
			myf3: [''],
			hypothecationName3: [''],
			hypothecationBranch3: [''],
			insuranceCompany3: [''],
			insuranceNumber3: [''],
			insuranceExpiry3: [''],
			insuranceExpiryCount3: [''],
			kmReading3: [''],
			service3: [''],
			serviceCenterName3: [''],
			location3: [''],
			contactNo3: [''],
			outsideserviceCenterName3: [''],
			outsidelocation3: [''],
			contactPerson3: [''],
			contactNumber3: [''],
			units3: [''],
		});
	}

	initLCVRows() {
		return this.fb.group({
			noOfVehicles4: [''],
			make4: [''],
			model4: [''],
			variant4: [''],
			regNo4: [''],
			myf4: [''],
			hypothecationName4: [''],
			hypothecationBranch4: [''],
			insuranceCompany4: [''],
			insuranceNumber4: [''],
			insuranceExpiry4: [''],
			insuranceExpiryCount4: [''],
			kmReading4: [''],
			service4: [''],
			serviceCenterName4: [''],
			location4: [''],
			contactNo4: [''],
			outsideserviceCenterName4: [''],
			outsidelocation4: [''],
			contactPerson4: [''],
			contactNumber4: [''],
			units4: [''],
		});
	}

	initTractorRows() {
		return this.fb.group({
			noOfTractors: [''],
			make5: [''],
			model5: [''],
			variant5: [''],
			regNo5: [''],
			myf5: [''],
			hypothecationName5: [''],
			hypothecationBranch5: [''],
			insuranceCompany5: [''],
			insuranceNumber5: [''],
			insuranceExpiry5: [''],
			insuranceExpiryCount5: [''],
			kmReading5: [''],
			service5: [''],
			serviceCenterName5: [''],
			location5: [''],
			contactNo5: [''],
			outsideserviceCenterName5: [''],
			outsidelocation5: [''],
			contactPerson5: [''],
			contactNumber5: [''],
			units5: [''],
			summer: [''],
			rainy: [''],
			winter: [''],
			hoursInsummer: [''],
			hoursInrainy: [''],
			hoursInwinter: [''],
			hoursInagriculture: [''],
			hoursIntransport: [''],
			tractorUsage: [''],
			selfUsage: [''],
			commerical: [''],
			kmdrivenPerday: [''],
			mileage: [''],
			kmdrivenPerdayCommerical: [''],
			mileageCommerical: [''],
			tarilNo: [''],
			_4or3wheel: [''],
			tarilLoadability: [''],
			holdingAcres: [''],
			soilType: [''],
			cropCoverage: [''],
			incomeInagriculture: [''],
			rice: [''],
			corn: [''],
			wheat: [''],
			cotton: [''],
			perAcerrice: [''],
			totalEldingrice: [''],
			incomePeracerrice: [''],
			perAcercorn: [''],
			totalEldingcorn: [''],
			incomePeracercorn: [''],
			perAcerwheat: [''],
			totalEldingwheat: [''],
			incomePeracerwheat: [''],
			perAcercotton: [''],
			totalEldingcotton: [''],
			incomePeracercotton: [''],
			kisanCreditCard: [''],
			NameOfTheBank: [''],
			acc_Number: [''],
			LocationOfTheBank: [''],
			OtherSourceOfIncome: [''],
			trillageImplements: [''],
			trillageMileage: [''],
			seedbedImplements: [''],
			seedbedMileage: [''],
			harvestingImplements: [''],
			harvestingMileage: [''],
		});
	}

	initItemsCargo() {
		return this.fb.group({
			makeCargo: [''],
			model: [''],
			variant: [''],
			color: [''],
			regNo: [''],
			insuranceCompanyName: [''],
			insuranceNum: [''],
			insuranceExp: [''],
			insuranceExpCount: [''],
			financeCompanyName: [''],
			financeNum: [''],
			financeExp: [''],
			financeExpCount: [''],
		});
	}

	initItemsPassenger() {
		return this.fb.group({
			makee: [''],
			modell: [''],
			variantt: [''],
			colorr: [''],
			regNoo: [''],
			insuranceCompanyNamee: [''],
			insuranceNumm: [''],
			insuranceExpp: [''],
			insuranceExpCountt: [''],
			financeCompanyNamee: [''],
			financeNumm: [''],
			financeExpp: [''],
			financeExpCountt: [''],
		});
	}

	get formArr() {
		return this.DataBankForm4.get('FourWheelRows') as FormArray;
	}
	addNewRow() {
		this.formArr.push(this.initFourWheelRows());
	}
	deleteRow(index: number) {
		this.formArr.removeAt(index);
	}

	get formArr1() {
		return this.DataBankForm4.get('TwoWheelRows') as FormArray;
	}
	addNewRow1() {
		this.formArr1.push(this.initTwoWheelRows());
	}
	deleteRow1(index: number) {
		this.formArr1.removeAt(index);
	}

	get formArr2() {
		return this.DataBankForm4.get('ThreeWheelRows') as FormArray;
	}
	addNewRow2() {
		this.formArr2.push(this.initThreeWheelRows());
	}
	deleteRow2(index: number) {
		this.formArr2.removeAt(index);
	}

	get formArr3() {
		return this.DataBankForm4.get('LCVRows') as FormArray;
	}
	addNewRow3() {
		this.formArr3.push(this.initLCVRows());
	}
	deleteRow3(index: number) {
		this.formArr3.removeAt(index);
	}

	get formArr4() {
		return this.DataBankForm4.get('TractorRows') as FormArray;
	}
	addNewRow4() {
		this.formArr4.push(this.initTractorRows());
	}
	deleteRow4(index: number) {
		this.formArr4.removeAt(index);
	}

	get formArr5() {
		return this.DataBankForm7.get('cargoRows') as FormArray;
	}
	addNewRow5() {
		this.formArr5.push(this.initItemsCargo());
	}
	deleteRow5(index: number) {
		this.formArr5.removeAt(index);
	}

	get formArr6() {
		return this.DataBankForm7.get('passengerRows') as FormArray;
	}
	addNewRow6() {
		this.formArr6.push(this.initItemsPassenger());
	}
	deleteRow6(index: number) {
		this.formArr6.removeAt(index);
	}

	ngOnInit() {
		this.dataBankForm();
	}

	dataBankForm() {

		this.DataBankForm = this.fb.group({
			databank: [''],
		});

		this.DataBankForm1 = this.fb.group({
			salutation: ['Select'],
			firstName: ['', Validators.required],
			lastName: [''],
			phone: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
			secondaryPhone: [''],
			email: ['', Validators.email],
			gender: ['Select'],
			dateOfBirth: [''],
			age: [''],
			anniversaryDate: [''],
		});

		this.DataBankForm2 = this.fb.group({
			houseNo: [''],
			street: [''],
			address: [''],
			village: [''],
			city: [''],
			district: [''],
			state: [''],
			pincode: [''],
			sameAsCommunicationAddress: ['']
		});

		this.DataBankForm21 = this.fb.group({
			houseNo: [''],
			street: [''],
			address: [''],
			village: [''],
			city: [''],
			district: [''],
			state: [''],
			pincode: [''],
		});

		this.DataBankForm3 = this.fb.group({
			qualification: [''],
			occupation: [''],
			otherSource: [''],
			panFileName: [''],
			pan: [''],
			aadharFileName: [''],
			aadhar: [''],
			driverLicenseFileName: [''],
			license: [''],
			profesionalExperience: [''],
			changingVehicles: [''],
			incomePerMonth: [''],
			sourceType: [''],
			bankType: [''],
			businessBank: [''],
			businessbankName: [''],
			businesaccNumber: [''],
			businessaccType: [''],
			businessName: [''],
			businessType: [''],
			gstFileName: [''],
			gst: [''],
			itPersonalFileName: [''],
			itPersonal: [''],
			itBusinessFileName: [''],
			itBusiness: [''],
			bankName: [''],
			accNumber: [''],
			accType: ['Select'],
		});

		this.DataBankForm4 = this.fb.group({
			fourwheel: [''],
			FourWheelRows: this.fb.array([this.initFourWheelRows()]),
			twowheel: [''],
			TwoWheelRows: this.fb.array([this.initTwoWheelRows()]),
			threewheel: [''],
			ThreeWheelRows: this.fb.array([this.initThreeWheelRows()]),
			lcvmcv: [''],
			LCVRows: this.fb.array([this.initLCVRows()]),
			tractor: [''],
			TractorRows: this.fb.array([this.initTractorRows()]),
		});

		this.DataBankForm5 = this.fb.group({
			sNumber: [''],
			name_LogBook: [''],
			mobile_LogBook: [''],
			vehicleRegno_LogBook: [''],
			model_LogBook: [''],
			daytripCount: [''],
			weektripCount: [''],
			monthtripCount: [''],
			yeartripCount: [''],
			routeRanking: [''],
			standRanking: [''],
			avgtripPaxx: [''],
			moneyGenerated: [''],
			maintance: [''],
			diesel: [''],
			revenueFileName: [''],
			revenue: [''],
			emiPaid: [''],
			documentWallet: [''],
			financeFileName: [''],
			finance: [''],
		});

		this.DataBankForm6 = this.fb.group({
			shedName: [''],
			mechanicName: [''],
			ownORrent: [''],
			singleORpartner: [''],
			partnerName: [''],
			partnerContact: [''],
			authorisedORlocal: [''],
			brandName: [''],
			generalBey: [''],
			gbey: [''],
			accidentBey: [''],
			abey: [''],
			waterwash: [''],
			waterw: [''],
			wheelAllignment: [''],
			equipmentBrand: [''],
			yearsOfservice: [''],
			postLift: [''],
			postLiftBodyshop: [''],
			postLiftGeneral: [''],
			sparespurchaseCenter: [''],
			sparespurchaseLocation: [''],
			sparesContactnumber: [''],
			accessoriespurchaseCenter: [''],
			accessoriespurchaseLocation: [''],
			accessoriespurchaseContact: [''],
			manPower: [''],
			staffAvailable: [''],
			wheelAllignmenter: [''],
			denter: [''],
			painter: [''],
			electrician: [''],
			foundaryWorkshopName: [''],
			foundaryLocation: [''],
			foundaryPerson: [''],
			foundaryContactNumber: [''],
			fuelInjectionName: [''],
			fuelInjectionLocation: [''],
			fuelInjectionPerson: [''],
			fuelInjectionNumber: [''],
			tyreCenterName: [''],
			tyreCenterLocation: [''],
			tyrePerson: [''],
			tyreNumber: [''],
			batteryCenterName: [''],
			batteryCenterLocation: [''],
			batteryPerson: [''],
			batteryNumber: [''],
			thirdORin: [''],
			denterprovidingCenterName: [''],
			denterprovidingCenterLocation: [''],
			denterprovidingPerson: [''],
			denterprovidingNumber: [''],
			painterprovidingCenterName: [''],
			painterprovidingCenterLocation: [''],
			painterprovidingPerson: [''],
			painterprovidingNumber: [''],
			electricianprovidingCenterName: [''],
			electricianprovidingCenterLocation: [''],
			electricianprovidingPerson: [''],
			electricianprovidingNumber: [''],
			wheelallignmentCenterName: [''],
			wheelallignmentCenterLocation: [''],
			wheelallignmentPerson: [''],
			wheelallignmentNumber: [''],
			painsuppelierCompanyName: [''],
			painsuppelierCompanyLocation: [''],
			painsuppelierPerson: [''],
			painsuppelierNumber: [''],
		});

		this.DataBankForm7 = this.fb.group({
			unionName: [''],
			standType: [''],
			location: [''],
			election: [''],
			lastelectionDate: [''],
			nextelectionDate: [''],
			partyName: [''],
			vehiclesInstand: [''],
			brandWisevehicles: [''],
			vehicleAttendence: [''],
			leaderName: [''],
			leaderContact: [''],
			passengerVehicle: [''],
			paxxAccept: [''],
			tripsPerday: [''],
			travelRoutes: [''],
			villages: [''],
			routewiseVehicles: [''],
			dayCoverage: [''],
			chargePerkm: [''],
			chargePerperson: [''],
			chargeBasedon: [''],
			quintol: [''],
			tones: [''],
			tripsPerDay: [''],
			tripsPerMonth: [''],
			chargePerquintol: [''],
			kmPerday: [''],
			tripsPerWeekinseason: [''],
			tripsPerDayinseason: [''],
			tripsPerMonthinseason: [''],
			tripsPerWeekinunseason: [''],
			tripsPerDayinunseason: [''],
			tripsPerMonthinunseason: [''],

			cargo: [''],
			cargoRows: this.fb.array([this.initItemsCargo()]),
			passenger: [''],
			passengerRows: this.fb.array([this.initItemsPassenger()]),
		});
	}
}



