import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { SharedService } from '../../../core/e-commerce/_services/shared.service';
import { InventoryService } from '../../..//core/e-commerce/_services/inventory.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
	selector: 'kt-inventory',
	templateUrl: './inventory.component.html',
	styleUrls: ['./inventory.component.scss'],
})
export class InventoryComponent implements OnInit {
	constructor(
		private sharedService: SharedService,
		private fb: FormBuilder,
		private inventoryService: InventoryService,
		private router: Router,
		private route: ActivatedRoute
	) { }

	inventoryForm: FormGroup;
	vechilesData = [];
	variantsList = [];
	vehicleDetails = [];
	vehicleId;
	loginEmployee: any;
	changeVechileModel() {
		this.variantsList = this.vechilesData.filter(
			(a) => a.model === this.inventoryForm.value.model
		)[0].varients;
	}

	changeVariant() {
		this.vehicleDetails = this.variantsList.filter(
			(record) => record.name === this.inventoryForm.value.varient
		);
	}

	omit_special_char(event) {
		let k;
		k = event.charCode;
		return ((k > 64 && k < 91) || (k > 96 && k < 123) || k === 8 || k === 32 || (k >= 48 && k <= 57));
	}

	ngOnInit() {
		this.createForm();
		this.vehicleId = this.route.snapshot.paramMap.get('id');
		this.vechilesData = this.sharedService.getVechilesData();
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.getVehicles();
	}

	getVehicles() {
		this.inventoryService
			.getVehicles(this.loginEmployee.orgId)
			.subscribe((data) => {
				this.vechilesData = data;
				if (this.vehicleId) {
					this.getInventoryDetails();
				}
			});
	}

	getInventoryDetails() {
		this.inventoryService.getById(this.vehicleId).subscribe((data) => {
			this.inventoryForm.patchValue(data.vehicleInventory);
			this.changeVechileModel();
			this.changeVariant();
		});
	}

	clear() {
		this.createForm();
	}

	createForm() {
		this.inventoryForm = this.fb.group({
			alloted: [''],
			allotedDate: [''],
			branch_id: [''],
			chassis_no: [''],
			created_datetime: [''],
			deallocation_date: [''],
			engineno: [''],
			fuel: [''],
			color: [''],
			id: [''],
			key_no: [''],
			model: [''],
			modified_datetime: [''],
			org_id: [''],
			rc_no: [''],
			transmission_type: [''],
			universel_id: [''],
			varient: [''],
			vin_no: [''],
		});
	}

	submit() {
		if (this.vehicleId) {
			this.inventoryService.update(this.inventoryForm.value).subscribe((data) => {
				this.router.navigateByUrl('inventory/inventory');
			});
		} else {
			this.inventoryForm.patchValue({
				alloted: 0,
				branch_id: this.loginEmployee.branchId,
				org_id: this.loginEmployee.orgId,
				created_datetime: new Date(),
			});
			this.inventoryService.save(this.inventoryForm.value).subscribe((data) => {
				this.router.navigateByUrl('inventory/inventory');
			});
		}
	}
}
