import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment.base';

@Injectable({
  providedIn: 'root'
})
export class ServicesAdminService {

  loginEmployee: any = JSON.parse(localStorage.getItem('loginEmployee'));
	role = this.loginEmployee.hrmsRole;
	branchId = this.loginEmployee.branchId;
	orgId = this.loginEmployee.orgId;
  serviceHostUrl = `${environment.vehicleServices}`;
  driversHostUrl =`${environment.vehicleServices}/drivers`;

  constructor(public http: HttpClient) { }

  getAllTimeSlots() {
    const url = `${this.serviceHostUrl}/api/tenant/${this.branchId}/master-data/service-slot/all-by-day`;
    return this.http.get<any>(url);
  }

  deleteTimeSlot(slotId: number) {
    const url = `${this.serviceHostUrl}/api/tenant/${this.branchId}/master-data/service-slot/${slotId}`;
    return this.http.delete<any>(url);
  }

  updateTimeslot(slotId: number, requestBody) {
    const url = `${this.serviceHostUrl}/api/tenant/${this.branchId}/master-data/service-slot/${slotId}`;
    return this.http.put<any>(url, requestBody);
  }

  saveTimeSlot(requestBody) {
    const url = `${this.serviceHostUrl}/api/tenant/${this.branchId}/master-data/service-slot`;
    return this.http.post<any>(url, requestBody);
  }

  getAllDrivers() {
    const url = `${this.driversHostUrl}/all?orgId=${this.orgId}&branchId=${this.branchId}`;
    return this.http.get<any>(url);
  }

  saveDriver(requestBody) {
    const url = `${this.driversHostUrl}`;
    return this.http.post<any>(url, requestBody);
  }

  deleteDriver(driverId) {
    const url = `${this.driversHostUrl}/id/${driverId}`;
    return this.http.delete<any>(url);
  }

}
