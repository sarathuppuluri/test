import { ChangeDetectorRef, Component, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { ServicesAdminService } from "../services-admin.service";
import { CreateTimeSlotComponent } from "./create-time-slot/create-time-slot.component";

@Component({
	selector: "kt-time-slots",
	templateUrl: "./time-slots.component.html",
	styleUrls: ["./time-slots.component.scss"],
})
export class TimeSlotsComponent implements OnInit {
	slots = [];
	days = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"];

	constructor(
		private servicesAdminService: ServicesAdminService,
		public dialog: MatDialog,
		private cd: ChangeDetectorRef
	) {}

	ngOnInit() {
		this.getSlots();
  }
  
  getSlots() {
    this.servicesAdminService.getAllTimeSlots().subscribe((slots) => {
			this.slots = this.days.map((day) => {
				return slots.body[day];
      });
      this.cd.detectChanges();
		});
  }

	deleteSlot(slotId, dayIndex) {
		this.servicesAdminService.deleteTimeSlot(slotId).subscribe(() => {
			this.slots[dayIndex] = this.slots[dayIndex].filter(
				(slot) => slot.id !== slotId
			);
			this.cd.detectChanges();
		});
	}

	openSlotInfo(slot: any) {
		const dialogRef = this.dialog.open(CreateTimeSlotComponent, {
			data: {
				slot,
				days: this.days,
			},
		});
		dialogRef.afterClosed().subscribe((result) => {
			this.getSlots();
		});
	}

	addSlot(day: string) {
		const dialogRef = this.dialog.open(CreateTimeSlotComponent, {
			data: {
				days: this.days,
				day,
			},
		});
		dialogRef.afterClosed().subscribe((result) => {
			this.getSlots();
		});
	}
}
