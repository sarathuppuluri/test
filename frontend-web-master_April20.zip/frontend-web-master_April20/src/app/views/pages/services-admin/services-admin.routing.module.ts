import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TimeSlotsComponent } from './time-slots/time-slots.component';

const routes: Routes = [
	{
		path: '',
		component: TimeSlotsComponent,
    }
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
})
export class ServicesAdminRoutingModule {}