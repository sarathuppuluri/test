import { TestBed } from '@angular/core/testing';

import { ServicesAdminService } from './services-admin.service';

describe('ServicesAdminService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ServicesAdminService = TestBed.get(ServicesAdminService);
    expect(service).toBeTruthy();
  });
});
