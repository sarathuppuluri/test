import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { TimeSlotsComponent } from "./time-slots/time-slots.component";
import { ServicesAdminRoutingModule } from "./services-admin.routing.module";
import { RouterModule } from "@angular/router";
import { FlexLayoutModule } from "@angular/flex-layout";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
	MatIconModule,
	MatTabsModule,
	MatCardModule,
	MatFormFieldModule,
	MatStepperModule,
	MatDialogModule,
	MatMenuModule,
	MatCheckboxModule,
	MatPaginatorModule,
	MatSelectModule,
	MatButtonModule,
	MatAutocompleteModule,
	MatInputModule,
	MatExpansionModule,
	MatDatepickerModule,
	MatRadioModule,
} from "@angular/material";
import { FullCalendarModule } from "@fullcalendar/angular";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { CoreModule } from "../../../core/core.module";
import { PartialsModule } from "../../partials/partials.module";
import { CreateTimeSlotComponent } from "./time-slots/create-time-slot/create-time-slot.component";
import { DriverListComponent } from './driver-list/driver-list.component';
import { CreateDriverComponent } from './driver-list/create-driver/create-driver.component';

@NgModule({
	declarations: [TimeSlotsComponent, CreateTimeSlotComponent, DriverListComponent, CreateDriverComponent],
	imports: [
		CommonModule,
		PartialsModule,
		CoreModule,
		MatIconModule,
		NgbModule,
		MatTabsModule,
		MatCardModule,
		FormsModule,
		ReactiveFormsModule,
		MatFormFieldModule,
		MatStepperModule,
		MatDialogModule,
		MatMenuModule,
		MatCheckboxModule,
		MatPaginatorModule,
		FullCalendarModule,
		MatSelectModule,
		MatButtonModule,
		MatAutocompleteModule,
		MatInputModule,
		MatExpansionModule,
		ReactiveFormsModule,
		FlexLayoutModule,
		MatDatepickerModule,
		MatRadioModule,
		ServicesAdminRoutingModule,
		RouterModule.forChild([
			{
				path: "timeSlots",
				component: TimeSlotsComponent,
			},
			{
				path: "driver",
				component: DriverListComponent
			}
		]),
	],
	entryComponents: [CreateTimeSlotComponent, CreateDriverComponent],
})
export class ServicesAdminModule {}
