import { ChangeDetectorRef, Component, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { ServicesAdminService } from "../services-admin.service";
import { CreateDriverComponent } from "./create-driver/create-driver.component";
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
	selector: "kt-driver-list",
	templateUrl: "./driver-list.component.html",
	styleUrls: ["./driver-list.component.scss"],
})
export class DriverListComponent implements OnInit {
	drivers = [];
	selectedDriver;

	constructor(
		private servicesAdminService: ServicesAdminService,
		public dialog: MatDialog,
		private cd: ChangeDetectorRef,
		private _snackBar: MatSnackBar
	) {}

	ngOnInit() {
		this.servicesAdminService.getAllDrivers().subscribe((res) => {
			if (res.success) {
				this.drivers = res.body;
				this.cd.detectChanges();
			}
		});
	}

	getDriver(driver) {
		this.selectedDriver = driver;
		const dialogRef = this.dialog.open(CreateDriverComponent, {
			data: {
				driver,
			},
		});
		dialogRef.afterClosed().subscribe((result) => {
			this.drivers = this.drivers.map((driver) => {
				if (driver.id === result.id) {
					driver = result;
				}
				return driver;
			});
			this.cd.detectChanges();
			this.openSnackBar("Driver Saved Successfully", "Success");
		});
	}

	createNew() {
		const dialogRef = this.dialog.open(CreateDriverComponent, {
			data: {},
		});
		dialogRef.afterClosed().subscribe((result) => {
			this.drivers.push(result);
			this.cd.detectChanges();
			this.openSnackBar(" Driver Saved Successfully", "Success");
		});
	}

	deleteDriver(driver) {
		const confirmDialog = window.confirm(
			"Are you sure to delete the document?"
		);
		if (confirmDialog) {
			this.servicesAdminService
				.deleteDriver(driver.id)
				.subscribe((res) => {
					if (res.success) {
            this.drivers = this.drivers.filter(drv => drv.id !== driver.id);
            this.cd.detectChanges();
						this.openSnackBar(
							"Driver deleted Successfully",
							"Success"
						);
					}
				});
		}
	}

	private openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 5000,
		});
	}
}
