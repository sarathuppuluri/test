import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-vehicle-exchange',
  templateUrl: './vehicle-exchange.component.html',
  styleUrls: ['./vehicle-exchange.component.scss']
})
export class VehicleExchangeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
