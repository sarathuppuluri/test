import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VehicleExchangeComponent } from './vehicle-exchange.component';

describe('VehicleExchangeComponent', () => {
  let component: VehicleExchangeComponent;
  let fixture: ComponentFixture<VehicleExchangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VehicleExchangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VehicleExchangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
