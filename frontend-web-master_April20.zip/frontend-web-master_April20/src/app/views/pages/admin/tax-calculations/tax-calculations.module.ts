import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { TaxCalculationListComponent } from "./tax-calculation-list/tax-calculation-list.component";
import { TaxCalculationComponent } from "./tax-calculation/tax-calculation.component";
import { TaxCalculationService } from "../../../../core/e-commerce/_services/taxCalculation.service";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
	MatInputModule,
	MatPaginatorModule,
	MatProgressSpinnerModule,
	MatSortModule,
	MatTableModule,
	MatSelectModule,
	MatMenuModule,
	MatProgressBarModule,
	MatButtonModule,
	MatCheckboxModule,
	MatDialogModule,
	MatTabsModule,
	MatNativeDateModule,
	MatCardModule,
	MatRadioModule,
	MatIconModule,
	MatDatepickerModule,
	MatAutocompleteModule,
	MatSnackBarModule,
	MatTooltipModule,
	MatExpansionModule,
} from "@angular/material";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { RouterModule } from "@angular/router";

@NgModule({
	declarations: [TaxCalculationListComponent, TaxCalculationComponent],
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatInputModule,
		MatPaginatorModule,
		MatProgressSpinnerModule,
		MatSortModule,
		MatTableModule,
		MatSelectModule,
		MatMenuModule,
		MatProgressBarModule,
		MatButtonModule,
		MatCheckboxModule,
		MatDialogModule,
		MatTabsModule,
		MatNativeDateModule,
		MatCardModule,
		MatRadioModule,
		MatIconModule,
		MatDatepickerModule,
		MatAutocompleteModule,
		MatSnackBarModule,
		MatTooltipModule,
		MatExpansionModule,
		NgbModule,
		RouterModule.forChild([
			{
				path: "",
				component: TaxCalculationListComponent,
			},
			{
				path: "create",
				component: TaxCalculationComponent,
			},
			{
				path: "edit/:id",
				component: TaxCalculationComponent,
			},
		]),
	],
	providers: [TaxCalculationService],
})
export class TaxCalculationsModule {}
