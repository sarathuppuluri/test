import { Component, OnInit,ChangeDetectorRef, Input, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EMIService } from '../../../../core/e-commerce/_services/emi.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
	selector: "kt-emi-calculator",
	templateUrl: "./emi-calculator.component.html",
	styleUrls: ["./emi-calculator.component.scss"],
})
export class EMICalculatorComponent implements OnInit {
	EMICalculatorForm: FormGroup;

	public pageLimit: number = 0;
	public pageSize: number = 10;
	public totalCount: number;
	loginEmployee: any;
	changeDetectorRef: any;
	EMICalculatorObj: any = {};
	isSave = true;
	emiForm() {
		this.EMICalculatorForm = this.formBuilder.group({
			interestRate: [null, Validators.required],
			tenure: [null, Validators.required],
			//tenure: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9,]*$')])],
			//interestRate: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9,]*$')])],
		});
	}

	constructor(
		private formBuilder: FormBuilder,
		private changedetectorref: ChangeDetectorRef,
		private emiService: EMIService,
		private _snackBar: MatSnackBar
	) {}

	ngOnInit() {
		this.emiForm();
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.getEmiCaluclatorData();
	}
	getEmiCaluclatorData() {
		this.emiService
			.getEmiData(this.pageSize, this.pageLimit, this.loginEmployee.orgId)
			.subscribe((res) => {
				if (res.status === "SUCCESS") {
					if (res.emis.length > 0) {
						this.EMICalculatorObj = res.emis[0];
						this.isSave = false;
						this.EMICalculatorForm.controls[
							"interestRate"
						].setValue(res.emis[0].interestRate);
						this.EMICalculatorForm.controls["tenure"].setValue(
							res.emis[0].noOfMonths
						);
					} else {
						this.isSave = true;
					}
				}
				//this.changeDetectorRef.detectChanges();
			});
	}
	save() {
		if (
			this.EMICalculatorForm.value.interestRate === "" ||
			this.EMICalculatorForm.value.interestRate === null
		) {
			this.openSnackBar("Interest Rate should not be empty.", "");
			return null;
		}
		if (
			this.EMICalculatorForm.value.tenure === "" ||
			this.EMICalculatorForm.value.tenure === null
		) {
			this.openSnackBar("Tenure should not be empty.", "");
			return null;
		}

		let requestObj = {
			emi: {
				branchId: 0,
				createdDatetime: Date.parse(Date()),
				createdby: this.loginEmployee.empName,
				id: 0,
				interestRate: this.EMICalculatorForm.value.interestRate,
				noOfMonths: this.EMICalculatorForm.value.tenure,
				modifiedDatetime: Date.parse(Date()),
				modifiedby: this.loginEmployee.empName,
				orgId: this.loginEmployee.orgId,
			},
		};
		this.emiService.saveEMICalc(requestObj).subscribe(
			(result) => {
				if (result.status === "SUCCESS") {
					this.getEmiCaluclatorData();
					this.openSnackBar(
						"EMI Calculator has been saved successfully.",
						"success"
					);
				} else {
					this.openSnackBar(
						"Oops! EMI Calculator has not been saved.",
						"fail"
					);
				}
			},
			(err) => {
				this.openSnackBar(err["message"], err["status"]);
			}
		);
	}
	update() {
		if (
			this.EMICalculatorForm.value.interestRate === "" ||
			this.EMICalculatorForm.value.interestRate === null
		) {
			this.openSnackBar("Interest Rate should not be empty.", "");
			return null;
		}
		if (
			this.EMICalculatorForm.value.tenure === "" ||
			this.EMICalculatorForm.value.tenure === null
		) {
			this.openSnackBar("Tenure should not be empty.", "");
			return null;
		}
		let requestObj = {
			emi: {
				branchId: this.EMICalculatorObj.branchId,
				createdDatetime: this.EMICalculatorObj.createdDatetime,
				createdby: this.EMICalculatorObj.createdby,
				id: this.EMICalculatorObj.id,
				interestRate: this.EMICalculatorForm.value.interestRate,
				modifiedDatetime: Date.parse(Date()),
				modifiedby: this.loginEmployee.empName,
				noOfMonths: this.EMICalculatorForm.value.tenure,
				orgId: this.EMICalculatorObj.orgId,
			},
		};
		this.emiService.updateEMICalc(requestObj).subscribe(
			(result) => {
				if (result.status === "SUCCESS") {
					this.getEmiCaluclatorData();
					this.openSnackBar(
						"EMI Calculator has been updated successfully.",
						"success"
					);
				} else {
					this.openSnackBar(
						"Oops! EMI Calculator has not been updated.",
						"fail"
					);
				}
			},
			(err) => {
				this.openSnackBar(err["message"], err["status"]);
			}
		);
	}

	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 3000,
		});
	}
}

