import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../../../core/e-commerce/_services/admin.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { debug } from 'console';
import { ignoreElements } from 'rxjs/operators';
import * as _ from 'lodash';
import { maxLength, RxwebValidators } from '@rxweb/reactive-form-validators';

@Component({
	selector: 'kt-my-task',
	templateUrl: './my-task.component.html',
	styleUrls: ['./my-task.component.scss']
})
export class MyTasksComponent {
	taskForm: FormGroup;
	closeTaskForm: FormGroup;
	tasksList: Array<any> = [];
	tasksList1: Array<any> = [];
	item: any;
	showDiv: boolean = false;
	taskstartdate: string;
	taskenddate: string;
	approver: string;
	employeeDetails: any;
	checked: boolean = false;
	remainderFreqVals = ['Minutes', 'Hours', 'Months', 'Quaterly', 'Semi Annual', 'Annual'];
	taskCategories = ['Property Docs', 'General Bills', 'Software Info', 'Asset Info', 'Equipment Info', 'Company Vehicle Info', 'Statuary Permission']
	taskTypes = ['Follow-up', 'Get Signed']
	taskStartDate: any;
	taskEndDate: any;
	remainderStartDate: any;
	remainderEndDate: any;
	itemSelected: any;
	actualEndDate: any;
	actualStartDate: any;
	type: any;
	empName: any;
	approverList: any = [];
	taskOwnerList: any = [];
	assigneeList: any = [];
	showTaskOwnerDiv: boolean = false;
	showAssigneeDiv: boolean = false;
	showApproverDiv: boolean = false;
	constructor(private AdminService: AdminService, private fb: FormBuilder,
		private modalService: NgbModal) {
	}

	ngOnInit() {
		this.taskForm = this.fb.group({
			taskName: ['', Validators.required],
			taskType: ['', Validators.required],
			taskStartDate: ['', Validators.required],
			taskEndDate: ['', Validators.required],
			taskAssignee: ['', Validators.required],
			taskVerifier: ['', Validators.required],
			isRemainder: '',
			remainderStartDate: '',
			remainderEndDate: '',
			remainderFreq: '',
			remainderFreqVal: '',
			remarks: ['', Validators.required],
			taskCategory: ['', Validators.required],
			taskOwner: ['', Validators.required],
		})
		this.closeTaskForm = this.fb.group({
			remarks: ['' , Validators.maxLength(100)],
			customerRemarks: ['', Validators.maxLength(100)],
			empRemarks: ['', Validators.maxLength(100)],
			actualStartDate: ['', Validators.required],
			actualEndDate: ['', Validators.required]
		})
		this.employeeDetails = JSON.parse(localStorage.getItem('loginEmployee'));
		this.empName = this.employeeDetails.empName;
		this.AdminService.getAlltasksByName(this.empName, 1, 1).subscribe((result: any) => {
			this.tasksList = [...result];
				this.tasksList.forEach((element) => {
					if(element.approver === this.empName){
						this.approverList.push(element);
					}
					if(element.task_owner === this.empName){
						this.taskOwnerList.push(element);
					}
					if(element.assigneto === this.empName){
						this.assigneeList.push(element);
					}
				})
		})
	}



	isSelectedChanged(event) {
		this.taskForm.get('isRemainder').setValue(event.checked);
		if (event.checked === true) {
			this.checked = true;
		} else {
			this.checked = false;
		}
	}
	showMenu(item, i, type) {
		this.item = item;
		if(type === 'owner'){
			this.showTaskOwnerDiv = true;
			this.showAssigneeDiv = false;
			this.showApproverDiv = false;
		} else if(type === 'assignee'){
			this.showTaskOwnerDiv = false;
			this.showAssigneeDiv = true;
			this.showApproverDiv = false;
		} else {
			this.showTaskOwnerDiv = false;
			this.showAssigneeDiv = false;
			this.showApproverDiv = true;
		}
		if (item.taskstartdate != null) {
			item.taskstartdate = moment(item.taskstartdate).format('YYYY-MM-DD');
			this.taskStartDate = new Date(this.tasksList[i].taskstartdate).toISOString();
		}
		if (item.taskenddate != null) {
			item.taskenddate = moment(item.taskenddate).format('YYYY-MM-DD');
			this.taskEndDate = new Date(this.tasksList[i].taskenddate).toISOString();
		}
		if (item.reminsder_startdate != null) {
			item.reminsder_startdate = moment(item.reminsder_startdate).format('YYYY-MM-DD');
			this.remainderStartDate = new Date(this.tasksList[i].reminsder_startdate).toISOString();
		}
		if (item.reminder_enddate != null) {
			item.reminder_enddate = moment(item.reminder_enddate).format('YYYY-MM-DD');
			this.remainderEndDate = new Date(this.tasksList[i].reminder_enddate).toISOString();
		}
	}
	rescheduleTask(item, content) {
		this.modalService.open(content, {
			size: 'lg'
		});
		this.taskForm = this.fb.group({
			taskName: item.task_name,
			taskType: item.task_type,
			taskStartDate: item.taskstartdate,
			taskEndDate: item.taskenddate,
			taskAssignee: item.assigneto,
			taskVerifier: item.approver,
			isRemainder: item.isRemainder,
			remainderStartDate: item.reminsder_startdate,
			remainderEndDate: item.reminder_enddate,
			remainderFreq: item.unit,
			remainderFreqVal: item.reminder_frequency,
			remarks: item.remarks,
			taskCategory: item.task_category,
			taskOwner: item.task_owner
		})
		if (item.isRemainder) {
			this.checked = true;
		} else {
			this.checked = false;
		}

	}
	openLarge(item, content) {
		this.modalService.open(content, {
			size: 'lg'
		});
		this.itemSelected = item;
	}
	closeTask(item, content, status) {
		this.modalService.open(content, {
			size: 'lg'
		});
		this.type = status;

	}
	actualEndDateCal(event) {
		this.actualEndDate = Date.parse(event.target.value);
		this.closeTaskForm.patchValue({ actualEndDate: moment(this.actualEndDate).format('YYYY-MM-DD') });
		this.actualEndDate = event.target.value.toISOString();
	}
	actualStartDateCal(event) {
		this.actualStartDate = Date.parse(event.target.value);
		this.closeTaskForm.patchValue({ actualStartDate: moment(this.actualStartDate).format('YYYY-MM-DD') });
		this.actualStartDate = event.target.value.toISOString();
	}
	cancelConfirm() {
		let formObj = {
			"id": this.item.id,
			"approver": this.item.approver,
			"assigneto": this.item.assigneto,
			"branch_id": 1,
			"cancelled_date": null,
			"created_datetime": this.item.created_datetime,
			"documentLink": "string",
			"isRemainder": this.item.isRemainder,
			"modified_datetime": null,
			"org_id": 1,
			"reminder_enddate": moment(this.item.reminder_enddate).toISOString(),
			"reminder_frequency": this.item.reminder_frequency,
			"reminsder_startdate": moment(this.item.reminsder_startdate).toISOString(),
			"task_category": this.item.task_category,
			"task_name": this.item.task_name,
			"task_owner": this.item.task_owner,
			"task_type": this.item.task_type,
			"taskenddate": moment(this.item.taskenddate).toISOString(),
			"taskstartdate": moment(this.item.taskstartdate).toISOString(),
			"unit": this.item.unit,
			"remarks": this.closeTaskForm.controls.remarks.value,
			"customerRemarks": this.closeTaskForm.controls.customerRemarks.value,
			"empRemarks": this.closeTaskForm.controls.empRemarks.value,
			"actualStartDate": this.actualStartDate,
			"actaulEndDate": this.actualEndDate,
			"status": this.type
		}
		this.AdminService.saveAlltasks(formObj).subscribe((result) => {
		})
		this.closeTaskForm.reset();
		this.closeLarge();
	}
	cancelTask() {
		this.showTaskOwnerDiv = false;
		this.showAssigneeDiv = false;
		this.showApproverDiv = false;
	}
	closeLarge() {
		this.modalService.dismissAll();
	}
	taskStartDateCal(event) {
		this.taskStartDate = Date.parse(event.target.value);
		this.taskForm.patchValue({ taskStartDate: moment(this.taskStartDate).format('YYYY-MM-DD') });
		this.taskStartDate = event.target.value.toISOString()
	}
	taskEndDateCal(event) {
		this.taskEndDate = Date.parse(event.target.value);
		this.taskForm.patchValue({ taskEndDate: moment(this.taskEndDate).format('YYYY-MM-DD') });
		this.taskEndDate = event.target.value.toISOString()
	}
	remainderStartDateCal(event) {
		this.remainderStartDate = Date.parse(event.target.value);
		this.taskForm.patchValue({ remainderStartDate: moment(this.remainderStartDate).format('YYYY-MM-DD') });
		this.remainderStartDate = event.target.value.toISOString();
	}
	remainderEndDateCal(event) {
		this.remainderEndDate = Date.parse(event.target.value);
		this.taskForm.patchValue({ remainderEndDate: moment(this.remainderEndDate).format('YYYY-MM-DD') });
		this.remainderEndDate = event.target.value.toISOString();
	}
	submitTask() {
		let formObj = {
			"id": this.item.id,
			"approver": this.taskForm.controls.taskVerifier.value,
			"assigneto": this.taskForm.controls.taskAssignee.value,
			"branch_id": 1,
			"cancelled_date": null,
			"created_datetime": this.item.created_datetime,
			"documentLink": "string",
			"isRemainder": this.checked,
			"modified_datetime": null,
			"org_id": 1,
			"remarks": this.taskForm.controls.remarks.value,
			"reminder_enddate": this.remainderEndDate ? this.remainderEndDate : null,
			"reminder_frequency": this.taskForm.controls.remainderFreqVal.value,
			"reminsder_startdate": this.remainderStartDate ? this.remainderStartDate : null,
			"status": "RESCHEDULE",
			"task_category": this.taskForm.controls.taskCategory.value,
			"task_name": this.taskForm.controls.taskName.value,
			"task_owner": this.taskForm.controls.taskOwner.value,
			"task_type": this.taskForm.controls.taskType.value,
			"taskenddate": this.taskEndDate,
			"taskstartdate": this.taskStartDate,
			"unit": this.taskForm.controls.remainderFreq.value
		}
		this.AdminService.saveAlltasks(formObj).subscribe((result) => {
		});
		this.closeLarge();
		this.taskForm.reset();
	}
}
