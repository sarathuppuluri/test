import { Component, OnInit, ChangeDetectorRef } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import * as moment from "moment";
import { AdminService } from "../../../../core/e-commerce/_services/admin.service";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { THIS_EXPR } from "@angular/compiler/src/output/output_ast";
import { ActivatedRoute } from "@angular/router";

@Component({
	selector: "kt-property-docs",
	templateUrl: "./property-docs.component.html",
	styleUrls: ["./property-docs.component.scss"],
})
export class PropertyDocsComponent implements OnInit {
	rowCount = 0;
	displayTable;
	documentsList: Array<any> = [];
	softwareDocList: Array<any> = [];
	permissionDocList: Array<any> = [];
	listDocuments: Array<any> = [];
	planTypes: Array<any> = ["Postpaid", "Prepaid"];
	fileTypeValues: Array<any> = [
		"Lease deed or Rental Agreement",
		"Sale deed or Registered document",
		"Link Document(Own)",
		"Legal opinion",
		"Land Evaluation",
		"Property tax",
		"Trade license",
		"Factory License - Workshop",
		"GHMC Permission - Signages",
		"PCB Permission",
		"Building permissions - GHMC",
		"Layout - Showroom & Workshop",
		"Fire license",
		"Power Bill",
		"Water Bill",
	];
	persmissionTypes: Array<any> = [
		"Labour License",
		"RTA Registration",
		"RTA Trade Certificated - New Car",
		"Trade Certificate Insurance",
		"Asset Insurance",
		"Infrastructure Insurance",
		"Internal Damage Coverage Insurance",
		"Group Health Insurance",
		"PF Registration",
		"ESI Registration",
		"GST Registration",
		"Professional Tax",
		"Certificate of Incorporation (PAN, TAN, CIN)",
		"MSME Registartion",
		"SSI Registration",
	];
	typeOfUsageItems: Array<any> = [
		"New car showroom",
		"Workshop",
		"Used cars showroom",
	];
	softwareTypes: Array<any> = [
		"Firewall",
		"Antivirus",
		"MSOffice",
		"Tally",
		"DMS_Softwars",
		"Other",
	];
	subsoftwareTypes: Array<any> = [
		"Monthly",
		"Quaterly",
		"Half Yearly",
		"Yearly",
	];
	taskTypeOfDoc: Array<any> = ["Follow Up", "Execution", "Others"];
	vehicleUsageTypes: Array<any> = ["Company", "Finance", "Leasing"];
	assetsArray: Array<any> = [
		{
			addTask: true,
			description: "NA",
			documents: null,
			name: "Generator",
			owner: "Ramya",
			type: "Nessecity",
			tasks: [
				{
					name: "RC",
					type: "Renewal",
				},
				{
					name: "Insurance",
					type: "Renewal",
				},
			],
		},
		{
			addTask: true,
			description: "NA",
			documents: null,
			name: "Ambulance",
			owner: "Ramya",
			type: "Emergency",
			tasks: [
				{
					name: "RC",
					type: "Renewal",
				},
				{
					name: "Insurance",
					type: "Renewal",
				},
			],
		},
		{
			addTask: true,
			description: "",
			documents: null,
			name: "Generator",
			owner: "Ramu",
			type: "Neccesity",
			tasks: [
				{
					name: "RC",
					type: "Renewal",
				},
				{
					name: "Insurance",
					type: "Renewal",
				},
			],
		},
	];
	billsData: Array<any> = [];
	softwareList: Array<any> = [];
	docsData: Array<any> = [];
	assetsList: Array<any> = [];
	equipmentList: Array<any> = [];
	vehiclesList: Array<any> = [];
	permissionList: Array<any> = [];
	title;
	assetForm: FormGroup;
	documentsForm: FormGroup;
	generalBillsForm: FormGroup;
	softwareInfoForm: FormGroup;
	equipmentForm: FormGroup;
	vehiclesForm: FormGroup;
	permissionForm: FormGroup;

	infoArray = [];
	assetTable: boolean;
	assetDocsNames: Array<any> = [];
	expiryDate;
	remainderDate;
	enteredData: boolean;
	enteredData1: boolean;
	enteredData2: boolean;
	enteredData3: boolean;
	enteredData4: boolean;
	enteredData5: boolean;
	enteredData6: boolean;
	taskArray: Array<any> = [];
	tenureStartDate;
	tenureEndDate;
	taskBeforeDate;
	taskAfterDate;
	billsList: Array<any> = [];
	billRemainder;
	billTaskDate;
	taskCompleteBeforeDate;
	showSubDropdown: boolean = false;
	softwareStartDate;
	softwareEndDate;
	licenseRemainderDate;
	docRemainderDate;
	invoiceDate;
	warrantyStartDate;
	warrantyEndDate;
	exWarrantyStartDate;
	exWarrantyEndDate;
	showExWarranty: boolean = false;
	showExWarranty1: boolean = false;
	amcEndDate;
	amcStartDate;
	serviceDate;
	remainderDateOfDoc;
	showAMC: boolean = false;
	showAMC1: boolean = false;
	invoiceList: Array<any> = [];
	invoiceList1: Array<any> = [];
	warrantyList: Array<any> = [];
	warrantyList1: Array<any> = [];
	serviceDocList: Array<any> = [];
	serviceDocList1: Array<any> = [];
	showRemarks: boolean = false;
	docAssignedDate;
	confirm: string;
	selectedVal: any;
	selectedVal1: any;
	notApplicable: boolean = true;
	noCoveredOrOpen: boolean = true;
	signage: boolean = false;
	noTenure: boolean = false;
	emiRemainder: boolean = false;
	rentStartDate;
	rentEscalationRemainder;
	rentEndDate;
	pdiTrue: boolean = false;
	location: boolean = false;
	asset: boolean = false;
	itemsList: boolean = false;
	gradeWise: boolean = false;
	manPowerList: boolean = false;
	gstFlag: boolean = false;
	noList: boolean = false;
	invoiceNamesArray: Array<any> = [];
	warrantyNamesArray: Array<any> = [];
	serviceDocsNames: Array<any> = [];
	invoiceNamesArray1: Array<any> = [];
	warrantyNamesArray1: Array<any> = [];
	serviceDocsNames1: Array<any> = [];
	leadId: string = "";
	docUrl: any;
	type: any;
	confirmationId: any;
	createdTime: any;
	vehicleId: any;
	dmsCompanyVehicleInsurancesId: any;
	dmsCompanyVehicleAccidentsId: any;
	dmsCompanyVehicleServicesId: any;
	formData1 = new FormData();
	accidentsArray = [];
	insuranceArray = [];
	servicesArray = [];
	emiRemainderDate: string;
	rcExpiryDate: string;
	insurancePolicyStartDate: string;
	insurancePolicyEndDate: string;
	insuranceRemainderDate: string;
	insuranceTaskAssignedDate: string;
	insuranceTaskAssignedDueDate: string;
	serviceDate1;
	serviceRemainderDate: string;
	serviceTaskAssignedDate: string;
	serviceTaskAssignedDueDate: string;
	incidentOrAccidentDate: string;
	accidentvehicleId: any;
	insuranceVehicleId: any;
	serviceVehicleId: any;
	warrantyEndDate1;
	warrantyStartDate1;
	invoiceDate1;
	serviceDate2: string;
	amcEndDate1;
	amcStartDate1;
	exWarrantyEndDate1;
	exWarrantyStartDate1;
	viewBillForm: any;
	softwareViewForm: any;
	docInfoForm: any;
	assetInfoForm: any;
	equipmentInfoForm: any;
	companyVehicleInfo: any;
	permissionViewInfo: any;

	taskForm: FormGroup;
	taskEndDate: any;
	taskStartDate: any;
	checked: boolean = false;
	remainderEndDate: any;
	remainderStartDate: any;
	myTasksList = [];
	remainderFreqVals = [
		"Minutes",
		"Hours",
		"Months",
		"Quaterly",
		"Semi Annual",
		"Annual",
	];
	taskCategories = [
		"Property Docs",
		"General Bills",
		"Software Info",
		"Asset Info",
		"Equipment Info",
		"Company Vehicle Info",
		"Statuary Permission",
	];
	taskTypes = ["Follow-up", "Get Signed"];
	docType: string;
	docType1: string;
	docType2: string;
	docType3: string;
	docType4: string;
	docType5: string;
	docType6: string;
	employeeDetails: any;
	taskOwnerName: any;
	documentsObject: any = [];
	taskWoners: any;
	searchMsg: string;
	taskVerifiers: any;
	assetsList1: any = [];
	equipmentList1: any = [];

	constructor(
		private fb: FormBuilder,
		private AdminService: AdminService,
		private routeData: ActivatedRoute,
		private modalService: NgbModal,
		private changedetectorref: ChangeDetectorRef
	) {
		this.leadId = this.routeData.snapshot.paramMap.get("leadId");
	}
	assetDocsList: Array<any> = [];
	tempActions: Array<any> = [
		{ actionName: "assignTask" },
		{ actionName: "remainder" },
		{ actionName: "viewDoc" },
		{ actionName: "editDoc" },
		{ actionName: "deleteDoc" },
		{ actionName: "addTask" },
	];
	tempActions1: Array<any> = [
		{ actionName: "assignTask" },
		{ actionName: "remainder" },
		{ actionName: "viewBill" },
		{ actionName: "editBill" },
		{ actionName: "deleteBill" },
		{ actionName: "addTask" },
	];
	tempActions2: Array<any> = [
		{ actionName: "assignTask" },
		{ actionName: "remainder" },
		{ actionName: "viewSoftware" },
		{ actionName: "editSoftware" },
		{ actionName: "deleteSoftware" },
		{ actionName: "addTask" },
	];
	tempActions3: Array<any> = [
		{ actionName: "assignTask" },
		{ actionName: "remainder" },
		{ actionName: "viewVehicle" },
		{ actionName: "editVehicle" },
		{ actionName: "deleteVehicle" },
		{ actionName: "addTask" },
	];
	tempActions4: Array<any> = [
		{ actionName: "assignTask" },
		{ actionName: "remainder" },
		{ actionName: "viewAsset" },
		{ actionName: "editAsset" },
		{ actionName: "deleteAsset" },
		{ actionName: "addTask" },
	];
	tempActions5: Array<any> = [
		{ actionName: "viewPermission" },
		{ actionName: "editPermission" },
		{ actionName: "deletePermission" },
		{ actionName: "addTask" },
	];
	tempActions6: Array<any> = [
		{ actionName: "viewEquipment" },
		{ actionName: "editEquipment" },
		{ actionName: "deleteEquipment" },
		{ actionName: "addTask" },
	];

	ngOnInit() {
		this.employeeDetails = JSON.parse(
			localStorage.getItem("loginEmployee")
		);
		this.documentsForm = this.fb.group({
			fileType: "",
			location: "",
			landmark: "",
			typeOfUsage: "",
			totalArea: "",
			covered: "",
			open: "",
			tenure: "",
			tenureStartDate: "",
			tenureEndDate: "",
			fileName: "",
			remainderDate: "",
			taskAssignee: "",
			taskVerifier: "",
			taskBeforeDate: "",
			taskAfterDate: "",
			startUnit: "",
			endUnit: "",
			rentEscalationRemainder: "",
			rentStartDate: "",
			rentEndDate: "",
			nextEscalationPer: "",
			rentAmount: "",
			documentsUrl: "",
		});
		this.generalBillsForm = this.fb.group({
			companyName: "",
			number: ["", Validators.pattern(/^[0-9]*$/)],
			planType: ["", Validators.pattern(/^[0-9]*$/)],
			postOrPre: "",
			billName: "",
			documentUrl: "",
		});
		this.softwareInfoForm = this.fb.group({
			softwareType: "",
			startDate: "",
			endDate: "",
			licenseNumber: ["", Validators.pattern(/^[0-9]*$/)],
			licenseRemainderDate: "",
			documentName: "",
			docRemainderDate: "",
			documentUrl: "",
		});
		this.assetForm = this.fb.group({
			assetName: "",
			assetMake: "",
			serialNo: "",
			location: "",
			locationType: "",
			invoiceDate: "",
			invoiceNo: "",
			warrantyStartDate: "",
			warrantyEndDate: "",
			exWarranty: "",
			exWarrantyStartDate: "",
			exWarrantyEndDate: "",
			amc: "",
			amcStartDate: "",
			amcEndDate: "",
			serviceDate: "",
			serviceCost: "",
			invoiceName: "",
			warrantyName: "",
			serviceDocName: "",
			invoiceDocumentUrl: "",
			serviceInvoiceUpload: "",
			warrantyDocumentUrl: "",
			typeDocument: "Asset",
		});
		this.equipmentForm = this.fb.group({
			assetName: "",
			assetMake: "",
			serialNo: "",
			location: "",
			locationType: "",
			invoiceDate: "",
			invoiceNo: "",
			warrantyStartDate: "",
			warrantyEndDate: "",
			exWarranty: "",
			exWarrantyStartDate: "",
			exWarrantyEndDate: "",
			amc: "",
			amcStartDate: "",
			amcEndDate: "",
			serviceDate: "",
			serviceCost: "",
			invoiceName: "",
			warrantyName: "",
			serviceDocName: "",
			invoiceDocumentUrl: "",
			serviceInvoiceUpload: "",
			warrantyDocumentUrl: "",
			typeDocument: "Equipment",
		});
		this.vehiclesForm = this.fb.group({
			location: "",
			locationType: "",
			vehicleUsage: "",
			typeOfOwnership: "",
			emiRemainderDate: "",
			rcNumber: "",
			rcExpiryDate: "",
			insuranceCompanyName: "",
			insurancePolicyNo: "",
			insurancePolicyStartDate: "",
			insurancePolicyEndDate: "",
			insuranceRemainderDate: "",
			insuranceRemainderTo: "",
			insuranceTaskAssignee: "",
			insuranceTaskVerifier: "",
			insuranceTaskAssignedDate: "",
			insuranceTaskAssignedDueDate: "",
			serviceDate: "",
			serviceCost: ["", Validators.pattern(/^[0-9]*$/)],
			serviceRemainderDate: "",
			serviceRemainderTo: "",
			serviceTaskAssignee: "",
			serviceTaskVerifier: "",
			serviceTaskAssignedDate: "",
			serviceTaskAssignedDueDate: "",
			incidentOrAccidentDate: "",
			incidentOrAccidentWriteup: "",
			estimatedCost: ["", Validators.pattern(/^[0-9]*$/)],
			repairCost: ["", Validators.pattern(/^[0-9]*$/)],
			ageOfVehicle: ["", Validators.pattern(/^[0-9]*$/)],
		});
		this.permissionForm = this.fb.group({
			permissionType: "",
			location: "",
			typeOfUsage: "",
			totalArea: "",
			covered: "",
			open: "",
			noOfManPower: "",
			trainingRoom: "",
			startDate: "",
			endDate: "",
			documentName: "",
			pdiLocation: "",
			valueOfVehicle: "",
			vehicleType: "",
			assetValue: "",
			itemsList: "",
			itemsValue: "",
			gradeWiseManPower: "",
			addressDeclaration: "",
			manPowerList: "",
			directorNames: "",
			listDoc: "",
			listUpload: "",
			documentUpload: "",
		});

		this.getAllGeneralBills();
		this.getSoftwareDetails();
		this.getAllPropertyDocs();
		this.getAllAssets();
		this.getAllCompanyVehicles();
		this.getAllEquipments();
		this.getAllPermissionDocs();

		this.taskForm = this.fb.group({
			taskName: ["", Validators.required],
			taskType: ["", Validators.required],
			taskStartDate: ["", Validators.required],
			taskEndDate: ["", Validators.required],
			taskAssignee: ["", Validators.required],
			taskVerifier: ["", Validators.required],
			isRemainder: "",
			remainderStartDate: "",
			remainderEndDate: "",
			remainderFreq: "",
			remainderFreqVal: "",
			remarks: ["", Validators.required],
			taskCategory: ["", Validators.required],
			taskOwner: ["", Validators.required],
			documentLink: [""],
			verifierId: [""],
			wonerId: [""],
		});
	}
	getAllGeneralBills() {
		this.AdminService.getGeneralBills().subscribe((result) => {
			this.billsData = [...result.generalBills];
			this.docType = "General Bills";
			if (this.billsData.length > 0) {
				this.enteredData1 = true;
			} else {
				this.enteredData1 = false;
			}
		});
	}
	getSoftwareDetails() {
		this.AdminService.getSoftwareDetails().subscribe((result) => {
			this.docType1 = "Software Information";
			this.softwareList = [...result.softwareDetails];
			if (this.softwareList.length > 0) {
				this.enteredData2 = true;
			} else {
				this.enteredData2 = false;
			}
		});
	}
	getAllPropertyDocs() {
		this.AdminService.getdmsPropertyDocument().subscribe((result) => {
			this.docsData = [...result.propertyDocuments];
			this.docType2 = "Property Docs";
			if (this.docsData.length > 0) {
				this.enteredData = true;
			} else {
				this.enteredData = false;
			}
		});
	}
	getAllPermissionDocs() {
		this.AdminService.getdmsStatutory().subscribe((result) => {
			this.permissionList = [...result.statutories];
			this.docType3 = "Statuary Permission";
			if (this.permissionList.length > 0) {
				this.enteredData6 = true;
			} else {
				this.enteredData6 = false;
			}
		});
	}
	getAllAssets() {
		this.AdminService.getdmsAssetDetails().subscribe((result) => {
			if (result.assetDetails.length > 0) {
				this.docType4 = "Assets Information";
				this.assetsList1 = [];
				result.assetDetails.forEach((element) => {
					if (
						element.typeDocument === "Asset" ||
						element.typeDocument === null
					) {
						this.assetsList1.push(element);
					}
				});
			}
			this.assetsList = [...this.assetsList1];
			if (this.assetsList.length > 0) {
				this.enteredData3 = true;
			} else {
				this.enteredData3 = false;
			}
		});
	}
	getAllEquipments() {
		this.AdminService.getdmsAssetDetails().subscribe((result) => {
			if (result.assetDetails.length > 0) {
				this.equipmentList1 = [];
				result.assetDetails.forEach((element) => {
					this.docType5 = "Equipment Information";
					if (element.typeDocument === "Equipment") {
						this.equipmentList1.push(element);
					}
				});
			}
			this.equipmentList = [...this.equipmentList1];
			if (this.equipmentList.length > 0) {
				this.enteredData5 = true;
			} else {
				this.enteredData5 = false;
			}
		});
	}
	getAllCompanyVehicles() {
		this.AdminService.getdmsCompanyVehicle().subscribe((result) => {
			this.vehiclesList = [...result.vehicles];
			this.docType6 = "Company Vehicle Information";
			if (this.vehiclesList.length > 0) {
				this.enteredData4 = true;
			} else {
				this.enteredData4 = false;
			}
		});
	}
	coveredSelect(val) {
		this.documentsForm.patchValue({ covered: val });
	}
	openSelect(val) {
		this.documentsForm.patchValue({ open: val });
	}
	dateCalStart(event) {
		this.tenureStartDate = Date.parse(event.target.value);
		this.documentsForm.patchValue({
			tenureStartDate: moment(this.tenureStartDate).format("YYYY-MM-DD"),
		});
		this.tenureStartDate = moment(event.target.value).format(
			"YY-MM-DD hh:mm-ss"
		);
	}
	dateCalEnd(event) {
		this.tenureEndDate = Date.parse(event.target.value);
		this.documentsForm.patchValue({
			tenureEndDate: moment(this.tenureEndDate).format("YYYY-MM-DD"),
		});
		this.tenureEndDate = moment(event.target.value).format(
			"YY-MM-DD hh:mm-ss"
		);
	}
	remainderDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.documentsForm.patchValue({
			remainderDate: moment(this.remainderDate).format("YYYY-MM-DD"),
		});
		this.remainderDate = moment(event.target.value).format(
			"YY-MM-DD hh:mm-ss"
		);
	}
	taskBeforeDateCal(event) {
		this.taskBeforeDate = Date.parse(event.target.value);
		this.documentsForm.patchValue({
			taskBeforeDate: moment(this.taskBeforeDate).format("YYYY-MM-DD"),
		});
		this.taskBeforeDate = moment(event.target.value).format(
			"YY-MM-DD hh:mm-ss"
		);
	}
	taskAfterDateCal(event) {
		this.taskAfterDate = Date.parse(event.target.value);
		this.documentsForm.patchValue({
			taskAfterDate: moment(this.taskAfterDate).format("YYYY-MM-DD"),
		});
		this.taskAfterDate = moment(event.target.value).format(
			"YY-MM-DD hh:mm-ss"
		);
	}
	docRemainderStartCal(event) {
		this.remainderDateOfDoc = Date.parse(event.target.value);
		this.documentsForm.patchValue({
			startDate: moment(this.remainderDateOfDoc).format("YYYY-MM-DD"),
		});
		this.remainderDateOfDoc = moment(event.target.value).format(
			"YY-MM-DD hh:mm-ss"
		);
	}
	rentStartDateCal(event) {
		this.rentStartDate = Date.parse(event.target.value);
		this.documentsForm.patchValue({
			rentStartDate: moment(this.rentStartDate).format("YYYY-MM-DD"),
		});
		this.rentStartDate = moment(event.target.value).format(
			"YY-MM-DD hh:mm-ss"
		);
	}
	rentEndDateCal(event) {
		this.rentEndDate = Date.parse(event.target.value);
		this.documentsForm.patchValue({
			rentEndDate: moment(this.rentEndDate).format("YYYY-MM-DD"),
		});
		this.rentEndDate = moment(event.target.value).format(
			"YY-MM-DD hh:mm-ss"
		);
	}
	rentEscalationRemainderCal(event) {
		this.rentEscalationRemainder = Date.parse(event.target.value);
		this.documentsForm.patchValue({
			rentEscalationRemainder: moment(
				this.rentEscalationRemainder
			).format("YYYY-MM-DD"),
		});
		this.rentEscalationRemainder = moment(event.target.value).format(
			"YY-MM-DD hh:mm-ss"
		);
	}
	docTaskChange(event) {
		if (event.target.value === "others") {
			this.showRemarks = true;
		} else {
			this.showRemarks = false;
		}
	}
	docassignedDateCal(event) {
		this.docAssignedDate = Date.parse(event.target.value);
		this.documentsForm.patchValue({
			assignedDate: moment(this.docAssignedDate).format("YYYY-MM-DD"),
		});
		this.docAssignedDate = moment(event.target.value).format(
			"YY-MM-DD hh:mm-ss"
		);
	}

	billChoose(event) {
		this.billsList.push(event.target.files[0]);
		this.generalBillsForm.patchValue({
			billName: event.target.files[0].name,
		});
	}
	billRemainderDate(event) {
		this.billRemainder = Date.parse(event.target.value);
		this.generalBillsForm.patchValue({
			remainderDate: moment(this.billRemainder).format("YYYY-MM-DD"),
		});
		this.billRemainder = moment(event.target.value).format(
			"YY-MM-DD hh:mm-ss"
		);
	}
	billTaskDateCal(event) {
		this.billTaskDate = Date.parse(event.target.value);
		this.generalBillsForm.patchValue({
			billTaskDate: moment(this.billTaskDate).format("YYYY-MM-DD"),
		});
	}
	taskCompleteBeforeDateCal(event) {
		this.taskCompleteBeforeDate = Date.parse(event.target.value);
		this.generalBillsForm.patchValue({
			taskCompleteBeforeDate: moment(this.taskCompleteBeforeDate).format(
				"YYYY-MM-DD"
			),
		});
	}
	submitDoc(val) {
		if (this.type === "edit") {
			let formObj = {
				propertyDocument: {
					branchId: 1,
					covered: this.documentsForm.controls.covered.value,
					createdDatetime: this.createdTime,
					documentsUrl: this.documentsForm.controls.documentsUrl
						.value,
					endDate: this.tenureEndDate,
					fileType: this.documentsForm.controls.fileType.value,
					id: this.confirmationId,
					landmark: this.documentsForm.controls.landmark.value,
					location: this.documentsForm.controls.location.value,
					modifiedDatetime: null,
					open: this.documentsForm.controls.open.value,
					orgId: 1,
					startDate: this.tenureStartDate,
					tenure: this.documentsForm.controls.tenure.value,
					totalArea: this.documentsForm.controls.totalArea.value,
					typeOfUsage: this.documentsForm.controls.typeOfUsage.value,
				},
			};
			this.AdminService.dmsPropertyDocumentUpdate(
				formObj
			).subscribe((result) => {});
		} else {
			let formObj = {
				propertyDocument: {
					branchId: 1,
					covered: this.documentsForm.controls.covered.value,
					createdDatetime: null,
					documentsUrl: this.documentsForm.controls.documentsUrl
						.value,
					endDate: this.tenureEndDate,
					fileType: this.documentsForm.controls.fileType.value,
					id: 0,
					landmark: this.documentsForm.controls.landmark.value,
					location: this.documentsForm.controls.location.value,
					modifiedDatetime: null,
					open: this.documentsForm.controls.open.value,
					orgId: 1,
					startDate: this.tenureStartDate,
					tenure: this.documentsForm.controls.tenure.value,
					totalArea: this.documentsForm.controls.totalArea.value,
					typeOfUsage: this.documentsForm.controls.typeOfUsage.value,
				},
			};
			this.AdminService.dmsPropertyDocumentSave(
				formObj
			).subscribe((result) => {});
		}
		this.closeLarge();
		this.getAllPropertyDocs();
		this.documentsForm.reset();
	}

	tempObjDoc = {
		branchId: '',
		contentSize: 0,
		createdBy: Date.now(),
		description: "",
		documentNumber: "",
		documentPath: "",
		documentType: "",
		documentVersion: 0,
		fileName: "",
		gstNumber: "",
		id: 0,
		isActive: 0,
		isPrivate: 0,
		keyName: "",
		modifiedBy: "Admin",
		orgId: '',
		ownerId: "",
		ownerName: "Admin",
		parentId: "",
		tinNumber: "",
	};

	submitBill(val) {
		if (this.type === "edit") {
			let formObj = {
				generalBill: {
					branchId: 1,
					companyName: this.generalBillsForm.controls.companyName
						.value,
					createdDatetime: this.createdTime,
					documentUrl: this.generalBillsForm.controls.documentUrl
						.value,
					files: [null],
					id: this.confirmationId,
					modifiedDatetime: null,
					number: this.generalBillsForm.controls.number.value,
					orgId: 1,
					planType: this.generalBillsForm.controls.planType.value,
				},
			};
			this.AdminService.generalBillUpdate(
				formObj
			).subscribe((result) => {});
		} else {
			let formObj = {
				generalBill: {
					branchId: 1,
					companyName: this.generalBillsForm.controls.companyName
						.value,
					createdDatetime: null,
					documentUrl: this.generalBillsForm.controls.documentUrl
						.value,
					files: [null],
					id: 0,
					modifiedDatetime: null,
					number: this.generalBillsForm.controls.number.value,
					orgId: 1,
					planType: this.generalBillsForm.controls.planType.value,
				},
			};
			this.AdminService.generalBillSave(
				formObj
			).subscribe((result) => {});
		}
		this.closeLarge();
		this.getAllGeneralBills();
		this.generalBillsForm.reset();
	}
	submitSoftwareDoc(val) {
		if (this.type === "edit") {
			let formObj = {
				softwareDetail: {
					branchId: 1,
					createdDatetime: this.createdTime,
					documentUrl: val.controls.documentUrl.value,
					endDate: val.controls.endDate.value,
					id: this.confirmationId,
					licenceNo: val.controls.licenseNumber.value,
					modifiedDatetime: null,
					orgId: 1,
					softwareType: val.controls.softwareType.value,
					startDate: val.controls.startDate.value,
				},
			};
			this.AdminService.softwareDetailsUpdate(
				formObj
			).subscribe((result) => {});
		} else {
			let formObj = {
				softwareDetail: {
					branchId: 1,
					createdDatetime: null,
					documentUrl: val.controls.documentUrl.value,
					endDate: val.controls.endDate.value,
					id: 0,
					licenceNo: val.controls.licenseNumber.value,
					modifiedDatetime: null,
					orgId: 1,
					softwareType: val.controls.softwareType.value,
					startDate: val.controls.startDate.value,
				},
			};
			this.AdminService.softwareDetailsSave(
				formObj
			).subscribe((result) => {});
		}
		this.closeLarge();
		this.getSoftwareDetails();
		this.softwareInfoForm.reset();
	}
	assignTask(val, content) {
		this.documentsForm.controls.task = this.fb.group({
			name: val[0].name,
			type: val[0].type,
			remarks: val[0].remarks,
			assignee: val[0].assignee,
			verifier: val[0].verifier,
			assignedDate: val[0].assignedDate,
		});
	}
	remainderCal(val, content) {
		this.documentsForm.controls.remainder = this.fb.group({
			name: val[0].name,
			startDate: val[0].startDate,
			frequency: val[0].frequency,
			assignee: val[0].assignee,
		});
	}
	changeFileType(val) {
		if (
			val.target.value.includes("Sale deed or Registered document") ||
			val.target.value.includes("Link Document(Own)") ||
			val.target.value.includes("Legal opinion") ||
			val.target.value.includes("Land Evaluation") ||
			val.target.value.includes("Fire license")
		) {
			this.notApplicable = false;
		} else {
			this.notApplicable = true;
		}
		if (
			val.target.value.includes("Power Bill") ||
			val.target.value.includes("Water Bill")
		) {
			this.noCoveredOrOpen = false;
		} else {
			this.noCoveredOrOpen = true;
		}
		if (val.target.value.includes("GHMC Permission - Signages")) {
			this.signage = true;
		} else {
			this.signage = false;
		}
		if (!val.target.value.includes("Lease deed or Rental Agreement")) {
			this.noTenure = false;
		} else {
			this.noTenure = true;
		}
	}
	editDoc(val, content, type) {
		this.confirmationId = val.id;
		this.openSmall(content, type);
		this.documentsForm = this.fb.group({
			fileType: val.fileType,
			location: val.location,
			landmark: val.landmark,
			typeOfUsage: val.typeOfUsage,
			totalArea: val.totalArea,
			covered: val.covered,
			open: val.open,
			tenure: val.tenure,
			tenureStartDate: moment(val.tenureStartDate).format("YYYY-MM-DD"),
			tenureEndDate: moment(val.tenureEndDate).format("YYYY-MM-DD"),
			fileName: val.fileName,
			remainderDate: val.remainderDate,
			taskAssignee: val.taskAssignee,
			taskVerifier: val.taskVerifier,
			taskBeforeDate: val.taskBeforeDate,
			taskAfterDate: val.taskAfterDate,
			startUnit: "",
			endUnit: "",
			rentEscalationRemainder: "",
			rentStartDate: "",
			rentEndDate: "",
			nextEscalationPer: "",
			rentAmount: "",
			documentsUrl: val.documentsUrl,
		});
		this.AdminService.getdmsPropertyDocumentById(
			this.confirmationId
		).subscribe((result: any) => {
			this.createdTime = result.propertyDocument.createdDatetime;
		});
	}
	deleteDoc(val, content, type) {
		this.openSmall(content, type);
		this.selectedVal = val;
	}
	deleteDocConfirm(val) {
		if (val === "true") {
			this.AdminService.dmsPropertyDocumentDelete(
				this.selectedVal.id
			).subscribe((result) => {});
			this.getAllPropertyDocs();
		}
		this.closeLarge();
	}
	editBill(val, content, type) {
		this.openSmall(content, type);
		this.confirmationId = val.id;
		this.generalBillsForm = this.fb.group({
			companyName: val.companyName,
			number: val.number,
			planType: val.planType,
			postOrPre: val.postOrPre,
			billName: val.billName,
			documentUrl: val.documentUrl,
		});
		this.AdminService.getGeneralBillsById(this.confirmationId).subscribe(
			(result: any) => {
				this.createdTime = result.generalBill.createdDatetime;
			}
		);
	}
	deleteBill(val, content, type) {
		this.openSmall(content, type);
		this.selectedVal1 = val;
	}
	deleteBillConfirm(val) {
		if (val === "true") {
			this.AdminService.generalBillDelete(
				this.selectedVal1.id
			).subscribe((result) => {});
			this.getAllGeneralBills();
		}
		this.closeLarge();
	}
	editSoftware(val, content, type) {
		this.openSmall(content, type);
		this.confirmationId = val.id;
		this.softwareInfoForm = this.fb.group({
			softwareType: val.softwareType,
			startDate: moment(val.startDate).format("YYYY-MM-DD"),
			endDate: moment(val.endDate).format("YYYY-MM-DD"),
			licenseNumber: val.licenceNo,
			licenseRemainderDate: moment(val.licenseRemainderDate).format(
				"YYYY-MM-DD"
			),
			documentName: val.documentName,
			docRemainderDate: moment(val.docRemainderDate).format("YYYY-MM-DD"),
			documentUrl: val.documentUrl,
		});

		this.AdminService.getSoftwareDetailsById(this.confirmationId).subscribe(
			(result: any) => {
				this.createdTime = result.softwareDetail.createdDatetime;
			}
		);
	}
	deleteSoftware(val, content, type) {
		this.openSmall(content, type);
		this.selectedVal1 = val;
	}
	deleteSoftwareConfirm(val) {
		if (val === "true") {
			this.AdminService.softwareDetailsDelete(
				this.selectedVal1.id
			).subscribe((result) => {});
			this.getSoftwareDetails();
		}

		this.closeLarge();
	}
	softwareChange(event) {
		if (event.target.value === "6: DMS Software") {
			this.showSubDropdown = true;
		} else {
			this.showSubDropdown = false;
		}
	}
	softwareStartDateCal(event) {
		this.softwareStartDate = Date.parse(event.target.value);
		this.softwareInfoForm.patchValue({
			startDate: moment(this.softwareStartDate).format("YYYY-MM-DD"),
		});
		this.softwareStartDate = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	softwareEndDateCal(event) {
		this.softwareEndDate = Date.parse(event.target.value);
		this.softwareInfoForm.patchValue({
			endDate: moment(this.softwareEndDate).format("YYYY-MM-DD"),
		});
		this.softwareEndDate = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	licenseRemainderCal(event) {
		this.licenseRemainderDate = Date.parse(event.target.value);
		this.softwareInfoForm.patchValue({
			licenseRemainderDate: moment(this.licenseRemainderDate).format(
				"YYYY-MM-DD"
			),
		});
		this.licenseRemainderDate = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	docRemainderDateCal(event) {
		this.docRemainderDate = Date.parse(event.target.value);
		this.softwareInfoForm.patchValue({
			docRemainderDate: moment(this.docRemainderDate).format(
				"YYYY-MM-DD"
			),
		});
		this.docRemainderDate = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	invoiceDateCal(event) {
		this.invoiceDate = Date.parse(event.target.value);
		this.assetForm.patchValue({
			invoiceDate: moment(this.invoiceDate).format("YYYY-MM-DD"),
		});
		this.invoiceDate = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	warrantyStartDateCal(event) {
		this.warrantyStartDate = Date.parse(event.target.value);
		this.assetForm.patchValue({
			warrantyStartDate: moment(this.warrantyStartDate).format(
				"YYYY-MM-DD"
			),
		});
		this.warrantyStartDate = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	warrantyEndDateCal(event) {
		this.warrantyEndDate = Date.parse(event.target.value);
		this.assetForm.patchValue({
			warrantyEndDate: moment(this.warrantyEndDate).format("YYYY-MM-DD"),
		});
		this.warrantyEndDate = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	setExWaranty(val) {
		this.assetForm.patchValue({ exWarranty: val });
		if (val === "true") {
			this.showExWarranty = true;
		} else {
			this.showExWarranty = false;
		}
	}
	exWarrantyStartDateCal(event) {
		this.exWarrantyStartDate = Date.parse(event.target.value);
		this.assetForm.patchValue({
			exWarrantyStartDate: moment(this.exWarrantyStartDate).format(
				"YYYY-MM-DD"
			),
		});
		this.exWarrantyStartDate = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	exWarrantyEndDateCal(event) {
		this.exWarrantyEndDate = Date.parse(event.target.value);
		this.assetForm.patchValue({
			exWarrantyEndDate: moment(this.exWarrantyEndDate).format(
				"YYYY-MM-DD"
			),
		});
		this.exWarrantyEndDate = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	setAMC(val) {
		this.assetForm.patchValue({ amc: val });
		if (val === "true") {
			this.showAMC = true;
		} else {
			this.showAMC = false;
		}
	}
	amcStartDateCal(event) {
		this.amcStartDate = Date.parse(event.target.value);
		this.assetForm.patchValue({
			amcStartDate: moment(this.amcStartDate).format("YYYY-MM-DD"),
		});
		this.amcStartDate = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	amcEndDateCal(event) {
		this.amcEndDate = Date.parse(event.target.value);
		this.assetForm.patchValue({
			amcEndDate: moment(this.amcEndDate).format("YYYY-MM-DD"),
		});
		this.amcEndDate = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	serviceDateCal(event) {
		this.serviceDate = Date.parse(event.target.value);
		this.assetForm.patchValue({
			serviceDate: moment(this.serviceDate).format("YYYY-MM-DD"),
		});
		this.serviceDate = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	assetRemainderDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.assetForm.patchValue({
			remainderDate: moment(this.remainderDate).format("YYYY-MM-DD"),
		});
	}
	submitAsset(value) {
		if (this.type === "edit") {
			let formObj = {
				assetDetail: {
					amc: this.assetForm.controls.amcStartDate != null ? 1 : 0,
					amcEndDate: this.amcEndDate,
					amcStartDate: this.amcEndDate,
					branchId: 1,
					createdDatetime: this.createdTime,
					exWarranty:
						this.assetForm.controls.exWarrantyStartDate != null
							? 1
							: 0,
					exWarrantyEndDate: this.exWarrantyEndDate,
					exWarrantyStartDate: this.exWarrantyStartDate,
					id: this.confirmationId,
					invoiceDate: this.invoiceDate,
					invoiceNo: value.controls.invoiceNo.value,
					location: this.assetForm.controls.location.value,
					locationType: this.assetForm.controls.locationType.value,
					make: this.assetForm.controls.assetMake.value,
					modifiedDatetime: null,
					name: this.assetForm.controls.assetName.value,
					orgId: 1,
					serialNumber: this.assetForm.controls.serialNo.value,
					serviceCost: this.assetForm.controls.serviceCost.value,
					serviceDate: this.serviceDate,
					invoiceDocumentUrl: this.assetForm.controls
						.invoiceDocumentUrl.value,
					serviceInvoiceUpload: this.assetForm.controls
						.serviceInvoiceUpload.value,
					warrantyDocumentUrl: this.assetForm.controls
						.warrantyDocumentUrl.value,
					warrantyEndDate: this.warrantyEndDate,
					warrantyStartDate: this.warrantyStartDate,
					typeDocument: "Asset",
				},
			};

			this.AdminService.dmsAssetDetailUpdate(
				formObj
			).subscribe((result) => {});
		} else {
			let formObj = {
				assetDetail: {
					amc: this.assetForm.controls.amcStartDate != null ? 1 : 0,
					amcEndDate: this.amcEndDate,
					amcStartDate: this.amcEndDate,
					branchId: 1,
					createdDatetime: null,
					exWarranty:
						this.assetForm.controls.exWarrantyStartDate != null
							? 1
							: 0,
					exWarrantyEndDate: this.exWarrantyEndDate,
					exWarrantyStartDate: this.exWarrantyStartDate,
					id: 0,
					invoiceDate: this.invoiceDate,
					invoiceNo: value.controls.invoiceNo.value,
					location: this.assetForm.controls.location.value,
					locationType: this.assetForm.controls.locationType.value,
					make: this.assetForm.controls.assetMake.value,
					modifiedDatetime: null,
					name: this.assetForm.controls.assetName.value,
					orgId: 1,
					serialNumber: this.assetForm.controls.serialNo.value,
					serviceCost: this.assetForm.controls.serviceCost.value,
					serviceDate: this.serviceDate,
					invoiceDocumentUrl: this.assetForm.controls
						.invoiceDocumentUrl.value,
					serviceInvoiceUpload: this.assetForm.controls
						.serviceInvoiceUpload.value,
					warrantyDocumentUrl: this.assetForm.controls
						.warrantyDocumentUrl.value,
					warrantyEndDate: this.warrantyEndDate,
					warrantyStartDate: this.warrantyStartDate,
					typeDocument: "Asset",
				},
			};
			this.AdminService.assetDetailsSave(
				formObj
			).subscribe((result) => {});
		}
		this.closeLarge();
		this.getAllAssets();
		this.assetForm.reset();
	}
	editAsset(val, content, type) {
		this.confirmationId = val.id;

		this.openSmall(content, type);
		this.assetForm = this.fb.group({
			assetName: val.name,
			assetMake: val.make,
			serialNo: val.serialNumber,
			location: val.location,
			locationType: val.locationType,
			invoiceDate: moment(val.invoiceDate).format("YYYY-MM-DD"),
			invoiceNo: val.invoiceNo,
			warrantyStartDate: moment(val.warrantyStartDate).format(
				"YYYY-MM-DD"
			),
			warrantyEndDate: moment(val.warrantyEndDate).format("YYYY-MM-DD"),
			exWarranty: val.exWarranty,
			exWarrantyStartDate: moment(val.exWarrantyStartDate).format(
				"YYYY-MM-DD"
			),
			exWarrantyEndDate: moment(val.exWarrantyEndDate).format(
				"YYYY-MM-DD"
			),
			amc: val.amc,
			amcStartDate: moment(val.amcStartDate).format("YYYY-MM-DD"),
			amcEndDate: moment(val.amcEndDate).format("YYYY-MM-DD"),
			serviceDate: moment(val.serviceDate).format("YYYY-MM-DD"),
			serviceCost: val.serviceCost,
			warrantyName: val.warrantyName,
			serviceDocName: val.serviceDocName,
			invoiceName: val.invoiceName,
			invoiceDocumentUrl: val.invoiceDocumentUrl,
			serviceInvoiceUpload: val.serviceInvoiceUpload,
			warrantyDocumentUrl: val.warrantyDocumentUrl,
		});
		this.AdminService.getdmsAssetDetailById(this.confirmationId).subscribe(
			(result) => {
				this.createdTime = result.assetDetail.createdDatetime;
			}
		);
	}
	deleteAsset(val, content) {
		this.openSmall(content, this.type);
		this.selectedVal1 = val;
	}
	deleteAssetConfirm(val) {
		if (val === "true") {
			this.AdminService.dmsAssetDetailDelete(
				this.selectedVal1.id
			).subscribe((result) => {});
			this.getAllAssets();
		}
		this.closeLarge();
	}

	invoiceDateCal1(event) {
		this.invoiceDate1 = Date.parse(event.target.value);
		this.equipmentForm.patchValue({
			invoiceDate: moment(this.invoiceDate1).format("YYYY-MM-DD"),
		});
		this.invoiceDate1 = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	warrantyStartDateCal1(event) {
		this.warrantyStartDate1 = Date.parse(event.target.value);
		this.equipmentForm.patchValue({
			warrantyStartDate: moment(this.warrantyStartDate1).format(
				"YYYY-MM-DD"
			),
		});
		this.warrantyStartDate1 = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	warrantyEndDateCal1(event) {
		this.warrantyEndDate1 = Date.parse(event.target.value);
		this.equipmentForm.patchValue({
			warrantyEndDate: moment(this.warrantyEndDate1).format("YYYY-MM-DD"),
		});
		this.warrantyEndDate1 = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	setExWaranty1(val) {
		this.equipmentForm.patchValue({ exWarranty: val });
		if (val === "true") {
			this.showExWarranty1 = true;
		} else {
			this.showExWarranty1 = false;
		}
	}
	exWarrantyStartDateCal1(event) {
		this.exWarrantyStartDate1 = Date.parse(event.target.value);
		this.equipmentForm.patchValue({
			exWarrantyStartDate: moment(this.exWarrantyStartDate).format(
				"YYYY-MM-DD"
			),
		});
		this.exWarrantyStartDate1 = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	exWarrantyEndDateCal1(event) {
		this.exWarrantyEndDate1 = Date.parse(event.target.value);
		this.equipmentForm.patchValue({
			exWarrantyEndDate: moment(this.exWarrantyEndDate).format(
				"YYYY-MM-DD"
			),
		});
		this.exWarrantyEndDate1 = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	setAMC1(val) {
		this.equipmentForm.patchValue({ amc: val });
		if (val === "true") {
			this.showAMC1 = true;
		} else {
			this.showAMC1 = false;
		}
	}
	amcStartDateCal1(event) {
		this.amcStartDate1 = Date.parse(event.target.value);
		this.equipmentForm.patchValue({
			amcStartDate: moment(this.amcStartDate).format("YYYY-MM-DD"),
		});
		this.amcStartDate1 = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	amcEndDateCal1(event) {
		this.amcEndDate1 = Date.parse(event.target.value);
		this.equipmentForm.patchValue({
			amcEndDate: moment(this.amcEndDate).format("YYYY-MM-DD"),
		});
		this.amcEndDate1 = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	serviceDateCal1(event) {
		this.serviceDate1 = Date.parse(event.target.value);
		this.equipmentForm.patchValue({
			serviceDate: moment(this.serviceDate).format("YYYY-MM-DD"),
		});
		this.serviceDate1 = moment(event.target.value).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	assetRemainderDateCal1(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.equipmentForm.patchValue({
			remainderDate: moment(this.remainderDate).format("YYYY-MM-DD"),
		});
	}
	submitEquipment(value) {
		if (this.type === "edit") {
			let formObj = {
				assetDetail: {
					amc:
						this.equipmentForm.controls.amcStartDate.value != null
							? 1
							: 0,
					amcEndDate: this.amcEndDate1,
					amcStartDate: this.amcStartDate1,
					branchId: 1,
					createdDatetime: this.createdTime,
					exWarranty:
						this.equipmentForm.controls.exWarrantyStartDate.value !=
						null
							? 1
							: 0,
					exWarrantyEndDate: this.exWarrantyEndDate1,
					exWarrantyStartDate: this.exWarrantyStartDate1,
					id: this.confirmationId,
					invoiceDate: this.invoiceDate1,
					invoiceNo: value.controls.invoiceNo.value,
					location: this.equipmentForm.controls.location.value,
					locationType: this.equipmentForm.controls.locationType
						.value,
					make: this.equipmentForm.controls.assetMake.value,
					modifiedDatetime: null,
					name: this.equipmentForm.controls.assetName.value,
					orgId: 1,
					serialNumber: this.equipmentForm.controls.serialNo.value,
					serviceCost: this.equipmentForm.controls.serviceCost.value,
					serviceDate: this.serviceDate1,
					warrantyEndDate: this.warrantyEndDate1,
					warrantyStartDate: this.warrantyStartDate1,
					invoiceDocumentUrl: this.equipmentForm.controls
						.invoiceDocumentUrl.value,
					serviceInvoiceUpload: this.equipmentForm.controls
						.serviceInvoiceUpload.value,
					warrantyDocumentUrl: this.equipmentForm.controls
						.warrantyDocumentUrl.value,
					typeDocument: "Equipment",
				},
			};
			this.AdminService.dmsAssetDetailUpdate(
				formObj
			).subscribe((result) => {});
		} else {
			let formObj = {
				assetDetail: {
					amc:
						this.equipmentForm.controls.amcStartDate.value != null
							? 1
							: 0,
					amcEndDate: this.amcEndDate1,
					amcStartDate: this.amcStartDate1,
					branchId: 1,
					createdDatetime: null,
					exWarranty:
						this.equipmentForm.controls.exWarrantyStartDate.value !=
						null
							? 1
							: 0,
					exWarrantyEndDate: this.exWarrantyEndDate1,
					exWarrantyStartDate: this.exWarrantyStartDate1,
					id: 0,
					invoiceDate: this.invoiceDate1,
					invoiceNo: value.controls.invoiceNo.value,
					location: this.equipmentForm.controls.location.value,
					locationType: this.equipmentForm.controls.locationType
						.value,
					make: this.equipmentForm.controls.assetMake.value,
					modifiedDatetime: null,
					name: this.equipmentForm.controls.assetName.value,
					orgId: 1,
					serialNumber: this.equipmentForm.controls.serialNo.value,
					serviceCost: this.equipmentForm.controls.serviceCost.value,
					serviceDate: this.serviceDate1,
					warrantyEndDate: this.warrantyEndDate1,
					warrantyStartDate: this.warrantyStartDate1,
					invoiceDocumentUrl: this.equipmentForm.controls
						.invoiceDocumentUrl.value,
					serviceInvoiceUpload: this.equipmentForm.controls
						.serviceInvoiceUpload.value,
					warrantyDocumentUrl: this.equipmentForm.controls
						.warrantyDocumentUrl.value,
					typeDocument: "Equipment",
				},
			};
			this.AdminService.assetDetailsSave(
				formObj
			).subscribe((result) => {});
		}
		this.closeLarge();
		this.equipmentForm.reset();
	}
	editEquipment(val, content, type) {
		this.confirmationId = val.id;

		this.openSmall(content, type);
		this.equipmentForm = this.fb.group({
			assetName: val.name,
			assetMake: val.make,
			serialNo: val.serialNumber,
			location: val.location,
			locationType: val.locationType,
			invoiceDate: moment(val.invoiceDate).format("YYYY-MM-DD"),
			invoiceNo: val.invoiceNo,
			warrantyStartDate: moment(val.warrantyStartDate).format(
				"YYYY-MM-DD"
			),
			warrantyEndDate: moment(val.warrantyEndDate).format("YYYY-MM-DD"),
			exWarranty: val.exWarranty,
			exWarrantyStartDate: moment(val.exWarrantyStartDate).format(
				"YYYY-MM-DD"
			),
			exWarrantyEndDate: moment(val.exWarrantyEndDate).format(
				"YYYY-MM-DD"
			),
			amc: val.amc,
			amcStartDate: moment(val.amcStartDate).format("YYYY-MM-DD"),
			amcEndDate: moment(val.amcEndDate).format("YYYY-MM-DD"),
			serviceDate: moment(val.serviceDate).format("YYYY-MM-DD"),
			serviceCost: val.serviceCost,
			warrantyName: val.warrantyName,
			serviceDocName: val.serviceDocName,
			invoiceName: val.invoiceName,
			invoiceDocumentUrl: val.invoiceDocumentUrl,
			serviceInvoiceUpload: val.serviceInvoiceUpload,
			warrantyDocumentUrl: val.warrantyDocumentUrl,
		});

		this.AdminService.getdmsAssetDetailById(this.confirmationId).subscribe(
			(result) => {
				this.createdTime = result.assetDetail.createdDatetime;
			}
		);
	}
	deleteEquipment(val, content) {
		this.openSmall(content, this.type);
		this.selectedVal1 = val;
	}
	deleteEquipmentConfirm(val) {
		if (val === "true") {
			this.AdminService.dmsAssetDetailDelete(
				this.selectedVal1.id
			).subscribe((result) => {});
			this.getAllEquipments();
		}
		this.closeLarge();
	}

	emiRemainderDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.vehiclesForm.patchValue({
			emiRemainderDate: moment(this.remainderDate).format("YYYY-MM-DD"),
		});
		this.emiRemainderDate = moment(this.remainderDate).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	rcExpiryDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.vehiclesForm.patchValue({
			rcExpiryDate: moment(this.remainderDate).format("YYYY-MM-DD"),
		});
		this.rcExpiryDate = moment(this.remainderDate).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	insurancePolicyStartDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.vehiclesForm.patchValue({
			insurancePolicyStartDate: moment(this.remainderDate).format(
				"YYYY-MM-DD"
			),
		});
		this.insurancePolicyStartDate = moment(this.remainderDate).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	insurancePolicyEndDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.vehiclesForm.patchValue({
			insurancePolicyEndDate: moment(this.remainderDate).format(
				"YYYY-MM-DD"
			),
		});
		this.insurancePolicyEndDate = moment(this.remainderDate).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	insuranceRemainderDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.vehiclesForm.patchValue({
			insuranceRemainderDate: moment(this.remainderDate).format(
				"YYYY-MM-DD"
			),
		});
		this.insuranceRemainderDate = moment(this.remainderDate).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	insuranceTaskAssignedDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.vehiclesForm.patchValue({
			insuranceTaskAssignedDate: moment(this.remainderDate).format(
				"YYYY-MM-DD"
			),
		});
		this.insuranceTaskAssignedDate = moment(this.remainderDate).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	insuranceTaskAssignedDueDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.vehiclesForm.patchValue({
			insuranceTaskAssignedDueDate: moment(this.remainderDate).format(
				"YYYY-MM-DD"
			),
		});
		this.insuranceTaskAssignedDueDate = moment(this.remainderDate).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	serviceDateCal2(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.vehiclesForm.patchValue({
			serviceDate: moment(this.remainderDate).format("YYYY-MM-DD"),
		});
		this.serviceDate2 = moment(this.remainderDate).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	serviceRemainderDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.vehiclesForm.patchValue({
			serviceRemainderDate: moment(this.remainderDate).format(
				"YYYY-MM-DD"
			),
		});
		this.serviceRemainderDate = moment(this.remainderDate).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	serviceTaskAssignedDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.vehiclesForm.patchValue({
			serviceTaskAssignedDate: moment(this.remainderDate).format(
				"YYYY-MM-DD"
			),
		});
		this.serviceTaskAssignedDate = moment(this.remainderDate).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	serviceTaskAssignedDueDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.vehiclesForm.patchValue({
			serviceTaskAssignedDueDate: moment(this.remainderDate).format(
				"YYYY-MM-DD"
			),
		});
		this.serviceTaskAssignedDueDate = moment(this.remainderDate).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	incidentOrAccidentDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.vehiclesForm.patchValue({
			incidentOrAccidentDate: moment(this.remainderDate).format(
				"YYYY-MM-DD"
			),
		});
		this.incidentOrAccidentDate = moment(this.remainderDate).format(
			"YYYY-MM-DD hh:mm:ss"
		);
	}
	submitVehicleDoc(val) {
		if (this.type === "edit") {
			let formObj = {
				vehicle: {
					id: this.confirmationId,
					branchId: 1,
					createdDatetime: this.createdTime,
					ifFinanceLeasingEmiDate: val.controls.emiRemainderDate.value
						? moment(val.controls.emiRemainderDate.value).format(
								"YYYY-MM-DD hh:mm:ss"
						  )
						: null,
					location: val.controls.location.value,
					locationType: val.controls.locationType.value,
					modifiedDatetime: null,
					noOfYears: parseInt(val.controls.ageOfVehicle.value),
					orgId: 1,
					ownershipType: val.controls.vehicleUsage.value,
					rcDocumentUrl: "string",
					rcExpiryDate: val.controls.rcExpiryDate.value
						? moment(val.controls.rcExpiryDate.value).format(
								"YYYY-MM-DD hh:mm:ss"
						  )
						: null,
					rcNo: val.controls.rcNumber.value,
					status: "Active",
					vehicleUsage: val.controls.vehicleUsage.value,
					dmsCompanyVehicleAccidents: [
						{
							id: this.accidentvehicleId,
							companyVehicleId: this.confirmationId,
							accidentDate: val.controls.incidentOrAccidentDate
								.value
								? moment(
										val.controls.incidentOrAccidentDate
											.value
								  ).format("YYYY-MM-DD hh:mm:ss")
								: null,
							accidentWriteup:
								val.controls.incidentOrAccidentWriteup.value,
							afterPhotos: "string",
							beforePhotos: "string",
							createdDatetime: this.createdTime,
							estimatedCost: parseInt(
								val.controls.estimatedCost.value
							),
							modifiedDatetime: null,
							monthlyStatusPhotos: "string",
							repairCost: parseInt(val.controls.repairCost.value),
							vehicleAge: parseInt(
								val.controls.ageOfVehicle.value
							),
						},
					],
					dmsCompanyVehicleInsurances: [
						{
							id: this.insuranceVehicleId,
							companyVehicleId: this.confirmationId,
							createdDatetime: this.createdTime,
							endDate: val.controls.insurancePolicyEndDate.value
								? moment(
										val.controls.insurancePolicyEndDate
											.value
								  ).format("YYYY-MM-DD hh:mm:ss")
								: null,
							insurenceCompnayName:
								val.controls.insuranceCompanyName.value,
							modifiedDatetime: null,
							policyNo: val.controls.insurancePolicyNo.value,
							startDate: val.controls.insurancePolicyStartDate
								.value
								? moment(
										val.controls.insurancePolicyStartDate
											.value
								  ).format("YYYY-MM-DD hh:mm:ss")
								: null,
						},
					],
					dmsCompanyVehicleServices: [
						{
							id: this.serviceVehicleId,
							companyVehicleId: this.confirmationId,
							createdDatetime: this.createdTime,
							modifiedDatetime: null,
							sericeCost: parseInt(
								val.controls.serviceCost.value
							),
							serviceDate: val.controls.serviceRemainderDate.value
								? moment(
										val.controls.serviceRemainderDate.value
								  ).format("YYYY-MM-DD hh:mm:ss")
								: null,
							serviceInvoice: "string",
						},
					],
				},
			};

			this.AdminService.dmsCompanyVehicleUpdate(
				formObj
			).subscribe((result) => {});
		} else {
			let formObj = {
				vehicle: {
					id: 0,
					branchId: 1,
					createdDatetime: null,
					ifFinanceLeasingEmiDate: this.emiRemainderDate,
					location: val.controls.location.value,
					locationType: val.controls.locationType.value,
					modifiedDatetime: null,
					noOfYears: parseInt(val.controls.ageOfVehicle.value),
					orgId: 1,
					ownershipType: val.controls.vehicleUsage.value,
					rcDocumentUrl: "string",
					rcExpiryDate: this.rcExpiryDate,
					rcNo: val.controls.rcNumber.value,
					status: "Active",
					vehicleUsage: val.controls.vehicleUsage.value,
					dmsCompanyVehicleAccidents: [
						{
							id: 0,
							companyVehicleId: 0,
							accidentDate: this.incidentOrAccidentDate,
							accidentWriteup:
								val.controls.incidentOrAccidentWriteup.value,
							afterPhotos: "string",
							beforePhotos: "string",
							createdDatetime: null,
							estimatedCost: parseInt(
								val.controls.estimatedCost.value
							),
							modifiedDatetime: null,
							monthlyStatusPhotos: "string",
							repairCost: parseInt(val.controls.repairCost.value),
							vehicleAge: parseInt(
								val.controls.ageOfVehicle.value
							),
						},
					],
					dmsCompanyVehicleInsurances: [
						{
							id: 0,
							companyVehicleId: 0,
							createdDatetime: null,
							endDate: this.insurancePolicyEndDate,
							insurenceCompnayName:
								val.controls.insuranceCompanyName.value,
							modifiedDatetime: null,
							policyNo: val.controls.insurancePolicyNo.value,
							startDate: this.insurancePolicyStartDate,
						},
					],
					dmsCompanyVehicleServices: [
						{
							id: 0,
							companyVehicleId: 0,
							createdDatetime: null,
							modifiedDatetime: null,
							sericeCost: parseInt(
								val.controls.serviceCost.value
							),
							serviceDate: this.serviceRemainderDate,
							serviceInvoice: "string",
						},
					],
				},
			};

			this.AdminService.dmsCompanyVehicleSave(
				formObj
			).subscribe((result) => {});
		}
		this.closeLarge();
		this.getAllCompanyVehicles();
		this.vehiclesForm.reset();
	}
	changeVehicleUsage(val) {
		if (
			val.target.value.includes("Finance") ||
			val.target.value.includes("Leasing")
		) {
			this.emiRemainder = true;
		} else {
			this.emiRemainder = false;
		}
	}
	editVehicle(val, content, type) {
		this.confirmationId = val.id;
		this.vehicleId = val.id;
		if (val.dmsCompanyVehicleAccidents.length > 0) {
			this.accidentvehicleId = val.dmsCompanyVehicleAccidents[0].id
				? val.dmsCompanyVehicleAccidents[0].id
				: 0;
		}
		if (val.dmsCompanyVehicleInsurances.length > 0) {
			this.insuranceVehicleId = val.dmsCompanyVehicleInsurances[0].id
				? val.dmsCompanyVehicleInsurances[0].id
				: 0;
		}
		if (val.dmsCompanyVehicleServices.length > 0) {
			this.serviceVehicleId = val.dmsCompanyVehicleServices[0].id
				? val.dmsCompanyVehicleServices[0].id
				: 0;
		}

		this.openLarge(content, type);
		this.confirmationId = val.id;
		this.vehiclesForm = this.fb.group({
			location: val.location,
			locationType: val.locationType,
			vehicleUsage: val.ownershipType,
			typeOfOwnership: val.ownershipType,
			emiRemainderDate: val.ifFinanceLeasingEmiDate
				? moment(val.ifFinanceLeasingEmiDate).format("YYYY-MM-DD")
				: null,
			rcNumber: val.rcNo,
			rcExpiryDate: val.rcExpiryDate
				? moment(val.rcExpiryDate).format("YYYY-MM-DD")
				: null,
			insuranceCompanyName:
				val.dmsCompanyVehicleInsurances.length > 0
					? val.dmsCompanyVehicleInsurances[0].insurenceCompnayName
					: "",
			insurancePolicyNo:
				val.dmsCompanyVehicleInsurances.length > 0
					? val.dmsCompanyVehicleInsurances[0].policyNo
					: "",
			insurancePolicyStartDate:
				val.dmsCompanyVehicleInsurances.length > 0
					? moment(
							val.dmsCompanyVehicleInsurances[0].startDate
					  ).format("YYYY-MM-DD")
					: null,
			insurancePolicyEndDate:
				val.dmsCompanyVehicleInsurances.length > 0
					? moment(val.dmsCompanyVehicleInsurances[0].endDate).format(
							"YYYY-MM-DD"
					  )
					: null,
			serviceDate:
				val.dmsCompanyVehicleServices.length > 0
					? moment(
							val.dmsCompanyVehicleServices[0].serviceDate
					  ).format("YYYY-MM-DD")
					: null,
			serviceCost:
				val.dmsCompanyVehicleServices.length > 0
					? val.dmsCompanyVehicleServices[0].sericeCost
					: "",
			serviceRemainderDate:
				val.dmsCompanyVehicleServices.length > 0
					? moment(
							val.dmsCompanyVehicleServices[0].serviceDate
					  ).format("YYYY-MM-DD")
					: null,
			incidentOrAccidentDate:
				val.dmsCompanyVehicleAccidents.length > 0
					? moment(
							val.dmsCompanyVehicleAccidents[0].accidentDate
					  ).format("YYYY-MM-DD")
					: null,
			incidentOrAccidentWriteup:
				val.dmsCompanyVehicleAccidents.length > 0
					? val.dmsCompanyVehicleAccidents[0].accidentWriteup
					: "",
			estimatedCost:
				val.dmsCompanyVehicleAccidents.length > 0
					? val.dmsCompanyVehicleAccidents[0].estimatedCost
					: "",
			repairCost:
				val.dmsCompanyVehicleAccidents.length > 0
					? val.dmsCompanyVehicleAccidents[0].repairCost
					: "",
			ageOfVehicle:
				val.dmsCompanyVehicleAccidents.length > 0
					? val.dmsCompanyVehicleAccidents[0].vehicleAge
					: "",
		});
		this.AdminService.getdmsCompanyVehicleById(
			this.confirmationId
		).subscribe((result: any) => {
			this.createdTime = result.vehicle.createdDatetime;
			this.dmsCompanyVehicleInsurancesId =
				val.dmsCompanyVehicleInsurances.length > 0
					? val.dmsCompanyVehicleInsurances[0].id
					: 0;
			this.dmsCompanyVehicleAccidentsId =
				val.dmsCompanyVehicleAccidents.length > 0
					? val.dmsCompanyVehicleAccidents[0].id
					: 0;
			this.dmsCompanyVehicleServicesId =
				val.dmsCompanyVehicleServices.length > 0
					? val.dmsCompanyVehicleServices[0].id
					: 0;
		});
	}
	deleteVehicle(val, content) {
		this.openSmall(content, this.type);
		this.selectedVal1 = val;
	}
	deleteVehicleConfirm(val) {
		if (val === "true") {
			this.AdminService.dmsCompanyVehicleDelete(
				this.selectedVal1.id
			).subscribe((result) => {});
			this.AdminService.getdmsCompanyVehicle().subscribe((result) => {
				this.vehiclesList = [...result.vehicles];
			});
			this.getAllCompanyVehicles();
		}
		this.closeLarge();
	}

	permissionStartDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.permissionForm.patchValue({
			startDate: moment(this.remainderDate).format("YYYY-MM-DD"),
		});
	}
	permissionEndDateCal(event) {
		this.remainderDate = Date.parse(event.target.value);
		this.permissionForm.patchValue({
			endDate: moment(this.remainderDate).format("YYYY-MM-DD"),
		});
	}
	submitStatuaryPermission(val, type) {
		if (this.type === "edit") {
			let formObj = {
				statutory: {
					addressDeclaration: val.controls.addressDeclaration.value,
					assetValue: val.controls.assetValue.value,
					coverd: val.covered,
					createdDatetime: this.createdTime,
					dirctorName: val.directorNames,
					documentUpload: val.controls.documentUpload
						? val.controls.documentUpload.value
						: "",
					enddate: moment(val.controls.endDate.value).format(
						"YYYY-MM-DD hh:mm:ss"
					),
					gradeWiseManpower: val.controls.gradeWiseManPower.value,
					id: this.confirmationId,
					itemValue: val.controls.itemsValue.value,
					listUpload: val.controls.listUplaod
						? val.controls.listUplaod.value
						: "",
					location: val.controls.location.value,
					manpowerList: val.controls.manPowerList.value,
					modifiedDatetime: null,
					name: val.controls.permissionType.value,
					noofmanpower: val.controls.noOfManPower.value,
					open: val.controls.open.value,
					startdate: moment(val.controls.startDate.value).format(
						"YYYY-MM-DD hh:mm:ss"
					),
					totalarea: val.controls.totalArea.value,
					trainingroom: val.controls.trainingRoom.value,
					typeVehicle: val.controls.vehicleType.value,
					typeofusage: val.controls.typeOfUsage.value,
					vehicleValue: val.controls.valueOfVehicle.value,
				},
			};

			this.AdminService.dmsStatutoryUpdate(
				formObj
			).subscribe((result) => {});
		} else {
			let formObj = {
				statutory: {
					addressDeclaration: val.controls.addressDeclaration.value,
					assetValue: val.controls.assetValue.value,
					coverd: val.covered,
					createdDatetime: null,
					dirctorName: val.directorNames,
					documentUpload: val.controls.documentUpload
						? val.controls.documentUpload.value
						: "",
					enddate: moment(val.controls.endDate.value).format(
						"YYYY-MM-DD hh:mm:ss"
					),
					gradeWiseManpower: val.controls.gradeWiseManPower.value,
					id: 0,
					itemValue: val.controls.itemsValue.value,
					listUpload: val.controls.listUplaod
						? val.controls.listUplaod.value
						: "",
					location: val.controls.location.value,
					manpowerList: val.controls.manPowerList.value,
					modifiedDatetime: null,
					name: val.controls.permissionType.value,
					noofmanpower: val.controls.noOfManPower.value,
					open: val.controls.open.value,
					startdate: moment(val.controls.startDate.value).format(
						"YYYY-MM-DD hh:mm:ss"
					),
					totalarea: val.controls.totalArea.value,
					trainingroom: val.controls.trainingRoom.value,
					typeVehicle: val.controls.vehicleType.value,
					typeofusage: val.controls.typeOfUsage.value,
					vehicleValue: val.controls.valueOfVehicle.value,
				},
			};
			this.AdminService.dmsStatutorySave(
				formObj
			).subscribe((result) => {});
		}
		this.closeLarge();
		this.getAllPermissionDocs();
		this.permissionForm.reset();
	}
	changePermissionType(val) {
		if (val.target.value.includes("RTA Registration")) {
			this.pdiTrue = true;
		} else {
			this.pdiTrue = false;
		}
		if (val.target.value.includes("Labour License")) {
			this.location = true;
		} else {
			this.location = false;
		}
		if (val.target.value.includes("Asset Insurance")) {
			this.asset = true;
		} else {
			this.asset = false;
		}
		if (
			val.target.value.includes("Infrastructure Insurance") ||
			val.target.value.includes("Internal Damage Coverage Insurance")
		) {
			this.itemsList = true;
		} else {
			this.itemsList = false;
		}
		if (val.target.value.includes("Group Health Insurance")) {
			this.gradeWise = true;
		} else {
			this.gradeWise = false;
		}
		if (
			val.target.value.includes("PF Registration") ||
			val.target.value.includes("ESI Registration") ||
			val.target.value.includes("Professional Tax")
		) {
			this.manPowerList = true;
		} else {
			this.manPowerList = false;
		}
		if (val.target.value.includes("GST Registration")) {
			this.gstFlag = true;
		} else {
			this.gstFlag = false;
		}
		if (
			val.target.value.includes(
				"Certificate of Incorporation (PAN, TAN, CIN)"
			) ||
			val.target.value.includes("MSME Registartion") ||
			val.target.value.includes("SSI Registration")
		) {
			this.noList = true;
		} else {
			this.noList = false;
		}
	}
	editPermission(val, content, type) {
		this.openSmall(content, type);
		this.confirmationId = val.id;
		this.permissionForm = this.fb.group({
			permissionType: val.name,
			location: val.location,
			typeOfUsage: val.typeofusage,
			totalArea: val.totalarea,
			covered: val.coverd,
			open: val.open,
			noOfManPower: val.noofmanpower,
			trainingRoom: val.trainingroom,
			startDate: moment(val.startDate).format("YYYY-MM-DD"),
			endDate: moment(val.endDate).format("YYYY-MM-DD"),
			documentName: val.documentName,
			pdiLocation: val.pdiLocation,
			valueOfVehicle: val.assetValue,
			vehicleType: val.typeVehicle,
			assetValue: val.assetValue,
			itemsList: val.itemsList,
			itemsValue: val.itemValue,
			gradeWiseManPower: val.gradeWiseManPower,
			addressDeclaration: val.addressDeclaration,
			manPowerList: val.manpowerList,
			directorNames: val.dirctorName,
			listDoc: val.listDoc,
			listUplaod: val.listUpload,
			documentUpload: val.documentUpload,
		});
		this.AdminService.getdmsStatutoryById(this.confirmationId).subscribe(
			(result: any) => {
				this.createdTime = result.statutory.createdDatetime;
			}
		);
	}
	deletePermission(val, content, type) {
		this.openSmall(content, type);
		this.selectedVal = val;
	}
	deletePermissionConfirm(val) {
		if (val === "true") {
			this.AdminService.dmsStatutoryDelete(
				this.selectedVal.id
			).subscribe((result) => {});
			this.getAllPermissionDocs();
		}
		this.closeLarge();
	}
	openLarge(content, type) {
		this.modalService.open(content, {
			size: "xl",
		});
		this.type = type;
		if (this.type === "new") {
			this.assetForm.reset();
			this.documentsForm.reset();
			this.generalBillsForm.reset();
			this.softwareInfoForm.reset();
			this.equipmentForm.reset();
			this.vehiclesForm.reset();
			this.permissionForm.reset();
		}
	}
	openSmall(content, type) {
		this.modalService.open(content, {
			size: "lg",
		});
		this.type = type;
	}

	ViewBill(val, content, type) {
		this.openSmall(content, type);
		this.viewBillForm = val;
	}
	printBill() {
		let DocumentContainer = document.getElementById("content22");

		let WindowObject = window.open();
		let strHtml = "" + DocumentContainer.innerHTML + "";
		WindowObject.document.writeln(strHtml);
		WindowObject.document.close();
		WindowObject.focus();
		WindowObject.print();
		WindowObject.close();
	}
	viewSoftware(val, content, type) {
		this.openSmall(content, type);
		this.softwareViewForm = val;
	}
	printSoftware() {
		let DocumentContainer = document.getElementById("content23");

		let WindowObject = window.open();
		let strHtml = "" + DocumentContainer.innerHTML + "";
		WindowObject.document.writeln(strHtml);
		WindowObject.document.close();
		WindowObject.focus();
		WindowObject.print();
		WindowObject.close();
	}
	viewDoc(val, content, type) {
		this.openSmall(content, type);
		this.docInfoForm = val;
	}
	printDoc() {
		let DocumentContainer = document.getElementById("content24");

		let WindowObject = window.open();
		let strHtml = "" + DocumentContainer.innerHTML + "";
		WindowObject.document.writeln(strHtml);
		WindowObject.document.close();
		WindowObject.focus();
		WindowObject.print();
		WindowObject.close();
	}
	viewAsset(val, content, type) {
		this.openSmall(content, type);
		this.assetInfoForm = val;
	}
	printAsset() {
		let DocumentContainer = document.getElementById("content25");

		let WindowObject = window.open();
		let strHtml = "" + DocumentContainer.innerHTML + "";
		WindowObject.document.writeln(strHtml);
		WindowObject.document.close();
		WindowObject.focus();
		WindowObject.print();
		WindowObject.close();
	}
	viewEquipment(val, content, type) {
		this.openSmall(content, type);
		this.equipmentInfoForm = val;
	}
	printEquipment() {
		let DocumentContainer = document.getElementById("content26");

		let WindowObject = window.open();
		let strHtml = "" + DocumentContainer.innerHTML + "";
		WindowObject.document.writeln(strHtml);
		WindowObject.document.close();
		WindowObject.focus();
		WindowObject.print();
		WindowObject.close();
	}
	viewVehicle(val, content, type) {
		this.openSmall(content, type);
		this.companyVehicleInfo = val;
	}
	printCompanyVehicle() {
		let DocumentContainer = document.getElementById("content27");

		let WindowObject = window.open();
		let strHtml = "" + DocumentContainer.innerHTML + "";
		WindowObject.document.writeln(strHtml);
		WindowObject.document.close();
		WindowObject.focus();
		WindowObject.print();
		WindowObject.close();
	}
	viewPermission(val, content, type) {
		this.openSmall(content, type);
		this.permissionViewInfo = val;
	}
	printPermission() {
		let DocumentContainer = document.getElementById("content28");

		let WindowObject = window.open();
		let strHtml = "" + DocumentContainer.innerHTML + "";
		WindowObject.document.writeln(strHtml);
		WindowObject.document.close();
		WindowObject.focus();
		WindowObject.print();
		WindowObject.close();
	}

	closeLarge() {
		this.modalService.dismissAll();
	}
	openLarge1(content) {
		this.modalService.open(content, {
			size: "lg",
		});
	}
	addTask(item, content) {
		this.taskForm.get("taskCategory").setValue(item);
		this.employeeDetails = JSON.parse(
			localStorage.getItem("loginEmployee")
		);
		this.taskForm.get("taskOwner").setValue(this.employeeDetails.empName);

		this.openLarge1(content);
	}
	taskStartDateCal(event) {
		this.taskStartDate = Date.parse(event.target.value);
		this.taskForm.patchValue({
			taskStartDate: moment(this.taskStartDate).format("YYYY-MM-DD"),
		});
		this.taskStartDate = event.target.value.toISOString();
	}
	taskEndDateCal(event) {
		this.taskEndDate = Date.parse(event.target.value);
		this.taskForm.patchValue({
			taskEndDate: moment(this.taskEndDate).format("YYYY-MM-DD"),
		});
		this.taskEndDate = event.target.value.toISOString();
	}
	isSelectedChanged(event) {
		this.taskForm.get("isRemainder").setValue(event.checked);
		if (event.checked === true) {
			this.checked = true;
			this.taskForm.controls.remainderStartDate.setValidators(
				Validators.required
			);
			this.taskForm.controls.remainderEndDate.setValidators(
				Validators.required
			);
			this.taskForm.controls.remainderFreqVal.setValidators([
				Validators.required,
				Validators.pattern(/^[0-9]*$/),
			]);
			this.taskForm.controls.remainderFreq.setValidators(
				Validators.required
			);
		} else {
			this.checked = false;
			this.taskForm.controls.remainderStartDate.clearValidators();
			this.taskForm.controls.remainderEndDate.clearValidators();
			this.taskForm.controls.remainderFreqVal.clearValidators();
			this.taskForm.controls.remainderFreq.clearValidators();
		}
		this.taskForm.controls.remainderStartDate.updateValueAndValidity();
		this.taskForm.controls.remainderEndDate.updateValueAndValidity();
		this.taskForm.controls.remainderFreqVal.updateValueAndValidity();
		this.taskForm.controls.remainderFreq.updateValueAndValidity();
	}
	remainderStartDateCal(event) {
		this.remainderStartDate = Date.parse(event.target.value);
		this.taskForm.patchValue({
			remainderStartDate: moment(this.remainderStartDate).format(
				"YYYY-MM-DD"
			),
		});
		this.remainderStartDate = event.target.value.toISOString();
	}
	remainderEndDateCal(event) {
		this.remainderEndDate = Date.parse(event.target.value);
		this.taskForm.patchValue({
			remainderEndDate: moment(this.remainderEndDate).format(
				"YYYY-MM-DD"
			),
		});
		this.remainderEndDate = event.target.value.toISOString();
	}

	submitTask() {
		let formObj = {
			approver: this.taskForm.controls.taskVerifier.value.empName,
			assigneto: this.taskForm.controls.taskAssignee.value.empName,
			branch_id: 1,
			cancelled_date: null,
			created_datetime: null,
			documentLink: "string",
			isRemainder: this.checked,
			modified_datetime: null,
			org_id: 1,
			remarks: this.taskForm.controls.remarks.value,
			reminder_enddate: this.remainderEndDate
				? this.remainderEndDate
				: null,
			reminder_frequency: this.taskForm.controls.remainderFreqVal.value,
			reminsder_startdate: this.remainderStartDate
				? this.remainderStartDate
				: null,
			status: "NEW",
			task_category: this.taskForm.controls.taskCategory.value,
			task_name: this.taskForm.controls.taskName.value,
			task_owner: this.taskForm.controls.taskOwner.value,
			task_type: this.taskForm.controls.taskType.value,
			taskenddate: this.taskEndDate,
			taskstartdate: this.taskStartDate,
			unit: this.taskForm.controls.remainderFreq.value,
		};

		this.AdminService.saveAlltasks(formObj).subscribe((result) => {});
		this.closeLarge();
		this.taskForm.reset();
	}
	searchWoner() {
		this.searchMsg = "";
		let empName = "",
			empId = "";
		if (
			this.taskForm.value.taskAssignee === "" &&
			this.taskForm.value.wonerId === ""
		) {
			this.searchMsg = "Please enter Emplayee name or/and Emplayee Id";
			return "";
		}
		if (
			this.taskForm.value.wonerId != "" &&
			this.taskForm.value.wonerId != null &&
			this.taskForm.value.wonerId != "null"
		) {
			empId = this.taskForm.value.wonerId;
			this.searchMsg = "";
		}
		if (this.taskForm.value.taskAssignee != "") {
			empName = this.taskForm.value.taskAssignee;
			this.searchMsg = "";
		}

		if (empName != "" || empId != "") {
			this.AdminService.getEmplayeeByNameOrId(empName, empId).subscribe(
				(res) => {
					if (res.success === true) {
						this.taskWoners =
							res.dmsEntity.employeeDTOs.length > 0
								? res.dmsEntity.employeeDTOs
								: [];
					}
				},
				(err) => {
					this.searchMsg = err.error.message;
				},
				() => {}
			);
		} else {
			this.searchMsg = "Please enter Emplayee name or/and Emplayee Id";
			return "";
		}
	}
	serchVerifiers() {
		this.searchMsg = "";
		let empName = "",
			empId = "";
		if (
			this.taskForm.value.taskVerifier === "" &&
			this.taskForm.value.verifierId === ""
		) {
			this.searchMsg = "Please enter Emplayee name or/and Emplayee Id";
			return "";
		}
		if (
			this.taskForm.value.verifierId != "" &&
			this.taskForm.value.verifierId != null &&
			this.taskForm.value.verifierId != "null"
		) {
			empId = this.taskForm.value.verifierId;
			this.searchMsg = "";
		}
		if (this.taskForm.value.taskVerifier != "") {
			empName = this.taskForm.value.taskVerifier;
			this.searchMsg = "";
		}

		if (empName != "" || empId != "") {
			this.AdminService.getEmplayeeByNameOrId(empName, empId).subscribe(
				(res) => {
					if (res.success === true) {
						this.taskVerifiers =
							res.dmsEntity.employeeDTOs.length > 0
								? res.dmsEntity.employeeDTOs
								: [];
					}
				},
				(err) => {
					this.searchMsg = err.error.message;
				},
				() => {}
			);
		} else {
			this.searchMsg = "Please enter Emplayee name or/and Emplayee Id";
			return "";
		}
	}
	numericOnly(event): boolean {
		// restrict e,+,-,E characters in  input type number
		const charCode = event.which ? event.which : event.keyCode;
		if (
			charCode === 101 ||
			charCode === 69 ||
			charCode === 45 ||
			charCode === 43
		) {
			return false;
		}
		return true;
	}
	fileChoose(event, docType) {
		if (event.target.files.length > 0) {
			this.documentsList.push(event.target.files[0]);
			const file = event.target.files[0];
			this.documentsForm.get("fileName").setValue(file.name);
			const formData = new FormData();
			formData.append("file", file);
			formData.append("randomNumber", "admin");
			formData.append("documentType", docType);
			this.AdminService.createCustomerDoc(formData).subscribe((res) => {
				this.tempObjDoc.documentPath = res.documentPath;
				this.tempObjDoc.documentType = docType;
				this.tempObjDoc.fileName = res.fileName;
				this.tempObjDoc.keyName = res.keyName;
				this.tempObjDoc.id = 0;
				this.tempObjDoc.branchId = this.employeeDetails.branchId;
				this.tempObjDoc.orgId = this.employeeDetails.orgId;
				let tempStuctObj = Object.assign({}, this.tempObjDoc);
				this.documentsObject.push(tempStuctObj);
				tempStuctObj = null;
				this.documentsForm
					.get("documentsUrl")
					.setValue(res.documentPath);
				this.changedetectorref.detectChanges();
			});
		}
	}
	onFileSelectBill(event, docType) {
		if (event.target.files.length > 0) {
			this.documentsList.push(event.target.files[0]);
			const file = event.target.files[0];
			this.generalBillsForm.get("billName").setValue(file.name);
			const formData = new FormData();
			formData.append("file", file);
			formData.append("randomNumber", "admin");
			formData.append("documentType", docType);
			this.AdminService.createCustomerDoc(formData).subscribe((res) => {
				this.generalBillsForm
					.get("documentUrl")
					.setValue(res.documentPath);
				this.changedetectorref.detectChanges();
			});
		}
	}

	softwareDocChoose(event, docType) {
		if (event.target.files.length > 0) {
			this.softwareDocList.push(event.target.files[0]);
			const file = event.target.files[0];
			this.softwareInfoForm.get("documentName").setValue(file.name);
			const formData = new FormData();
			formData.append("file", file);
			formData.append("randomNumber", "admin");
			formData.append("documentType", docType);
			this.AdminService.createCustomerDoc(formData).subscribe((res) => {
				this.softwareInfoForm
					.get("documentUrl")
					.setValue(res.documentPath);
				this.changedetectorref.detectChanges();
			});
		}
	}
	invoiceDocChoose(event, docType) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			this.assetForm.get("invoiceName").setValue(file.name);
			const formData = new FormData();
			formData.append("file", file);
			formData.append("randomNumber", "admin");
			formData.append("documentType", docType);
			this.AdminService.createCustomerDoc(formData).subscribe((res) => {
				this.assetForm
					.get("invoiceDocumentUrl")
					.setValue(res.documentPath);
				this.changedetectorref.detectChanges();
			});
		}
	}
	warrantyDocChoose(event, docType) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			this.assetForm.get("warrantyName").setValue(file.name);
			const formData = new FormData();
			formData.append("file", file);
			formData.append("randomNumber", "admin");
			formData.append("documentType", docType);
			this.AdminService.createCustomerDoc(formData).subscribe((res) => {
				this.assetForm
					.get("warrantyDocumentUrl")
					.setValue(res.documentPath);
				this.changedetectorref.detectChanges();
			});
		}
	}
	serviceDocChoose(event, docType) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			this.assetForm.get("serviceDocName").setValue(file.name);
			const formData = new FormData();
			formData.append("file", file);
			formData.append("randomNumber", "admin");
			formData.append("documentType", docType);
			this.AdminService.createCustomerDoc(formData).subscribe((res) => {
				this.assetForm
					.get("serviceInvoiceUpload")
					.setValue(res.documentPath);
				this.changedetectorref.detectChanges();
			});
		}
	}

	invoiceDocChoose1(event, docType) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			this.equipmentForm.get("invoiceName").setValue(file.name);
			const formData = new FormData();
			formData.append("file", file);
			formData.append("randomNumber", "admin");
			formData.append("documentType", docType);
			this.AdminService.createCustomerDoc(formData).subscribe((res) => {
				this.equipmentForm
					.get("invoiceDocumentUrl")
					.setValue(res.documentPath);
				this.changedetectorref.detectChanges();
			});
		}
	}
	warrantyDocChoose1(event, docType) {
		if (event.target.files.length > 0) {
			const file = event.target.files[0];
			this.equipmentForm.get("warrantyName").setValue(file.name);
			const formData = new FormData();
			formData.append("file", file);
			formData.append("randomNumber", "admin");
			formData.append("documentType", docType);
			this.AdminService.createCustomerDoc(formData).subscribe((res) => {
				this.equipmentForm
					.get("warrantyDocumentUrl")
					.setValue(res.documentPath);
				this.changedetectorref.detectChanges();
			});
		}
	}
	serviceDocChoose1(event, docType) {
		if (event.target.files.length > 0) {
			this.softwareDocList.push(event.target.files[0]);
			const file = event.target.files[0];
			this.equipmentForm.get("serviceDocName").setValue(file.name);
			const formData = new FormData();
			formData.append("file", file);
			formData.append("randomNumber", "admin");
			formData.append("documentType", docType);
			this.AdminService.createCustomerDoc(formData).subscribe((res) => {
				this.equipmentForm
					.get("serviceInvoiceUpload")
					.setValue(res.documentPath);
				this.changedetectorref.detectChanges();
			});
		}
	}

	listUplaod(event, docType) {
		if (event.target.files.length > 0) {
			this.listDocuments.push(event.target.files[0]);
			const file = event.target.files[0];
			this.permissionForm.get("listDoc").setValue(file.name);
			const formData = new FormData();
			formData.append("file", file);
			formData.append("randomNumber", "admin");
			formData.append("documentType", docType);
			this.AdminService.createCustomerDoc(formData).subscribe((res) => {
				this.permissionForm
					.get("listUplaod")
					.setValue(res.documentPath);
				this.changedetectorref.detectChanges();
			});
		}
	}

	permissionDocChoose(event, docType) {
		if (event.target.files.length > 0) {
			this.permissionDocList.push(event.target.files[0]);
			const file = event.target.files[0];
			this.permissionForm.get("documentName").setValue(file.name);
			const formData = new FormData();
			formData.append("file", file);
			formData.append("randomNumber", "admin");
			formData.append("documentType", docType);
			this.AdminService.createCustomerDoc(formData).subscribe((res) => {
				this.permissionForm
					.get("documentUpload")
					.setValue(res.documentPath);
				this.changedetectorref.detectChanges();
			});
		}
	}
}
