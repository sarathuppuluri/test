import { Component, OnInit,ChangeDetectorRef, Input, EventEmitter, Output,Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LatestNewsService } from '../../../../core/e-commerce/_services/latest-news.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material/dialog';
import moment from 'moment';
import { performanceConfirmationDialog } from '../../performance-repoting/confirmation-dialog.component';
import { VehiclesService } from '../../../../core/e-commerce/_services/vehicles.service';
@Component({
	selector: 'kt-latest-news',
	templateUrl: './latest-news.component.html',
	styleUrls: ['./latest-news.component.scss'],
})
export class LatestNewsComponent implements OnInit {
	globalDataObject:any={};

	public page: number = 0;
	public pageSize: number = 10;
	public totalCount: number;
	loginEmployee: any;

	latestNewsObj:any=[];
	isLoading=false;

	constructor(
		private changeDetectorRef: ChangeDetectorRef,
		private latestNewsService: LatestNewsService,
		private _snackBar: MatSnackBar,public dialog: MatDialog) { }

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		this.getLatestNewsData();
	}
	getLatestNewsData(){
		this.isLoading = true;
		this.latestNewsObj=[];
		this.latestNewsService.getLatestNewsData(this.pageSize,this.page,this.loginEmployee.orgId).subscribe(res => {
			this.isLoading = false;
			if (res.status=== "SUCCESS") {
				this.globalDataObject=res;
				this.latestNewsObj=res.vehicleNews;
			}
			this.changeDetectorRef.detectChanges();
		});
	}

	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 3000,
		});
	}

	paginatorLatestNews(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.getLatestNewsData();
	}

	deleteNews(obj){
		if (obj.id != "") {
            const dialogConfig = new MatDialogConfig();
            dialogConfig.disableClose = false;
            dialogConfig.autoFocus = true;
            dialogConfig.width = '400px';
            //dialogConfig.height='480px';
            dialogConfig.data = {
                message: 'Are you sure want to delete?',
                buttonText: { ok: 'Yes', cancel: 'No' }
            };
            const dialogRef = this.dialog.open(performanceConfirmationDialog, dialogConfig);
            dialogRef.afterClosed().subscribe((confirmed: boolean) => {
                if (confirmed) {
                    this.latestNewsService.deleteLatestNews(obj.id).subscribe((res: any) => {
                        if (res.statusCode === "200") {
                            this.openSnackBar(obj.heading + " - has been deleted successfully", 'SUCCESS');
                            this.getLatestNewsData();
                            this.changeDetectorRef.detectChanges();
                        } else {
                            this.openSnackBar(res.statusDescription, res.status);
                        }
                    });
                }
            });
        }
	}

	editNews(Obj){
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = false;
        dialogConfig.autoFocus = true;
        dialogConfig.width = '700px';
        //dialogConfig.height='480px';
        dialogConfig.data = Obj;

        const dialogRef = this.dialog.open(CreateLatestNewsDialog, dialogConfig);

        dialogRef.afterClosed().subscribe(result => {
            if (result === 'success') {
                this.getLatestNewsData();
            }
			this.changeDetectorRef.detectChanges();
        });
    }


/* **********************************Popup code starts here************************************************ */

	createLatestNews(): void {
		const dialogConfig = new MatDialogConfig();
		dialogConfig.disableClose = false;
		dialogConfig.autoFocus = true;
		dialogConfig.width = '700px';
		//dialogConfig.height='480px';
		dialogConfig.data = {
			animal: 'string',
			name: 'string',
		};

		const dialogRef = this.dialog.open(CreateLatestNewsDialog, dialogConfig);

		dialogRef.afterClosed().subscribe(result => {
			if (result === 'success') {
				this.getLatestNewsData();
			}
		});
	  }
}

export interface DialogData {
	animal: string;
	name: string;
}

@Component({
	selector: 'create-latestnews-dialog',
	templateUrl: 'create-latestnews-dialog.html',
})
export class CreateLatestNewsDialog {
	loginEmployee: any;
	latestNewsObj:any;
	isUpdate:boolean=false;
	url: any;
	fileTyle:string="";
	LatestNewsFormGroup = this.formBuilder.group({
		heading: ["", Validators.required],
		description: ["", Validators.required],
	});

	constructor(
		private vehSer: VehiclesService,
		private formBuilder: FormBuilder,
		private changedetectorref: ChangeDetectorRef,
		private latestNewsService: LatestNewsService,
		private _snackBar: MatSnackBar,
		public dialog: MatDialog,
		public dialogRef: MatDialogRef<CreateLatestNewsDialog>,
		@Inject(MAT_DIALOG_DATA) public data) {
			this.latestNewsObj = data;
		}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem('loginEmployee'));
		if(this.latestNewsObj.id){
			this.isUpdate=true;

			if(this.latestNewsObj.imageUrl!=""){
				this.url=this.latestNewsObj.imageUrl;
				this.fileTyle='image/jpeg';
			}else if(this.latestNewsObj.videoUrl!=""){
				this.url=this.latestNewsObj.videoUrl;
				this.fileTyle='video/mp4'
			}

            this.patchForm();
        }
	}

	public patchForm() {
        this.LatestNewsFormGroup.controls['heading'].setValue(this.latestNewsObj.heading);
        this.LatestNewsFormGroup.controls['description'].setValue(this.latestNewsObj.description);
        //this.LatestNewsFormGroup.controls['query'].setValue(this.latestNewsObj.query);
    }


	onSave(){
		if (this.LatestNewsFormGroup.value.heading === "" || this.LatestNewsFormGroup.value.heading === null) {
			this.openSnackBar("Heading should not be empty.", "");
			return null;
		}
		if(this.url===''){
			this.openSnackBar("Please upload the images/video", "");
			return null;
		}
		if (this.LatestNewsFormGroup.value.description == "" || this.LatestNewsFormGroup.value.description == null) {
			this.openSnackBar("Description should not be empty.", "");
			return null;
		}

		let requestObj={
			news: {
			  branchId: 0,
			  createdDatetime: Date.parse(Date()),
			  createdby: this.loginEmployee.empName,
			  description: this.LatestNewsFormGroup.value.description,
			  heading: this.LatestNewsFormGroup.value.heading,
			  id: 0,
			  modifiedDatetime: Date.parse(Date()),
			  modifiedby: this.loginEmployee.empName,
			  orgId:  this.loginEmployee.orgId,
			  imageUrl: "",
			  videoUrl: ""
			}
		  }

		if(this.fileTyle=='image/jpeg' || this.fileTyle=='image/png'){
			requestObj.news.imageUrl=this.url;
		}
		if(this.fileTyle=='video/mp4'){
			requestObj.news.videoUrl=this.url;
		}

		this.latestNewsService.saveLatestNews(requestObj).subscribe((res) => {
			if (res.status== "SUCCESS") {
				this.openSnackBar("Latest News has been saved successfully.", "success");
				this.dialogRef.close('success');
			}
			else {
				this.openSnackBar("Oops! Latest News has not been saved.", "fail");
			}
		},
		(err) => {
			this.openSnackBar(err['message'], err["status"]);
		});

	}

	onUpdate(){
		if (this.LatestNewsFormGroup.value.heading == "" || this.LatestNewsFormGroup.value.heading == null) {
			this.openSnackBar("Heading should not be empty.", "");
			return null;
		}
		if(this.url==''){
			this.openSnackBar("Please upload the images/video", "");
			return null;
		}
		if (this.LatestNewsFormGroup.value.description == "" || this.LatestNewsFormGroup.value.description == null) {
			this.openSnackBar("Description should not be empty.", "");
			return null;
		}

		let requestObj={
			news: {
			  branchId: this.latestNewsObj.branchId,
			  createdDatetime: this.latestNewsObj.createdDatetime,
			  createdby: this.latestNewsObj.createdby,
			  description: this.LatestNewsFormGroup.value.description,
			  heading: this.LatestNewsFormGroup.value.heading,
			  id: this.latestNewsObj.id,
			  modifiedDatetime: Date.parse(Date()),
			  modifiedby: this.loginEmployee.empName,
			  orgId:  this.latestNewsObj.orgId,
			  imageUrl: "",
			  videoUrl: ""
			}
		}
		if(this.fileTyle=='image/jpeg' || this.fileTyle=='image/png'){
			requestObj.news.imageUrl=this.url;
		}
		if(this.fileTyle=='video/mp4'){
			requestObj.news.videoUrl=this.url;
		}

		this.latestNewsService.updateLatestNews(requestObj).subscribe((res) => {
			if (res.status== "SUCCESS") {
				this.openSnackBar("Latest News has been updated successfully.", "success");
				this.dialogRef.close('success');
			}
			else {
				this.openSnackBar("Oops! Latest News has not been updated.", "fail");
			}
		},
		(err) => {
			this.openSnackBar(err['message'], err["status"]);
		});
	}
	isMatSpinner:boolean=false;
	fileChoose(event, docType) {
		if (event.target.files.length > 0) {
		  const tempFormData = new FormData();
		  let tempName = '';
		  for (let i = 0; i < event.target.files.length; i++) {
			  tempFormData.append('uploadFiles', event.target.files[i]);
			  tempName = tempName.concat(event.target.files[i].name, (i === ((event.target.files.length) - 1)) ? '' : ', ');
		  }
		  this.isMatSpinner=true;
		  this.vehSer.saveMultipleVehicleDetails(tempFormData,'eventscampaigns').subscribe(res => {
			this.isMatSpinner=false;
			this.url = res.uploadFiles[0].url;
			this.changedetectorref.detectChanges();
		  });
		}
	}

	deleteUrl(){
		this.url="";
		this.fileTyle="";
	  };
	resetForm() {
		this.LatestNewsFormGroup.reset();
	}

	openSnackBar(message: string, action: string) {
		this._snackBar.open(message, action, {
			duration: 3000,
		});
	}
	onNoClick(): void {
	  this.dialogRef.close();
	}

}

