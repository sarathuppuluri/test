import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../../../core/e-commerce/_services/admin.service';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
	selector: 'kt-add-vehicle',
	templateUrl: './add-vehicle.component.html',
	styleUrls: ['./add-vehicle.component.scss']
})
export class AddVehicleComponent implements OnInit {
	modalName: string;
	modalStatus: boolean;
	modalPriority: any;
	modelsArray: Array<any> = [];
	vehicleAddForm : FormGroup;
	imageArray: Array<any> = [];
	selectedId: any;
	active: boolean;
	imageUrl: any;
	formData = new FormData();
	formData1 = new FormData();
	inputFile: any;
	vehiclesList: any = [];
	count = 0;
	src: any;

	constructor(private AdminService: AdminService, private fb: FormBuilder,) {
	}
	ngOnInit(): void {
		this.vehiclesList = [];
		this.count = 0;
		this.vehicleAddForm = this.fb.group({
			id: [''],
			organizationId: [],
			vehicleId: [],
			priority: [],
			content: [''],
			status: ['']
		});
		this.AdminService.getAllImages().subscribe((result) => {
			this.vehiclesList = result;
		  });
	}
	sortBy(prop: string) {
		return this.vehiclesList.sort((a, b) => a[prop] > b[prop] ? 1 : a[prop] === b[prop] ? 0 : -1);
	}
	showModal() {
		let modal = document.getElementById("overlay");
		modal.style.display = "block";
	}
	fileChoose(event) {
		this.inputFile = event.target.files[0];
		this.formData.append('file', this.inputFile);
		this.vehicleAddForm.patchValue({content: this.inputFile.name});
	}
	closeModal() {
		let modal = document.getElementById("overlay");
		modal.style.display = "none";
	}
	priorityChange(event){
		this.vehicleAddForm.patchValue({prioirty: event.target.value});
	}
	statusChange(event) {
		this.vehicleAddForm.patchValue({status : event.target.checked});
	}
	saveVehicle(formObj: any) {
		this.count++;
		formObj.id = 0;
		formObj.status = formObj.status;
		formObj.prioirty = formObj.prioirty;
		formObj.content = formObj.content;
		let object1 = {"dashboardImage":{
			"id" : 0,
			"organizationId": 0,
			"vehicleId": 1,
			"priority": formObj.priority,
			"content":this.inputFile.name
	 }
	}
	this.formData1.append('input', JSON.stringify(object1));
	this.formData1.append('file', this.inputFile);
	this.AdminService.addDashboardImage(this.formData1).subscribe((result) => {
		this.vehiclesList.push(result);
	});
	  
	this.formData1.delete('input');
	this.formData1.delete('file');
	
		let modal = document.getElementById("overlay");
		modal.style.display = "none";
	}
	editImg(index){
		this.selectedId = index;
		setTimeout(() => {
			let imageSelectedDiv = document.getElementById('img'+this.selectedId);
			this.vehiclesList.forEach((element, index) => {
				if(this.selectedId === element.id) {
					this.src = this.vehiclesList[index].path;
				}
			})
			imageSelectedDiv.setAttribute('src', this.src );
		}, 0);
		
		let modal1 = document.getElementById("overlay1");
		modal1.style.display = "block";
	}
	deleteImg(index1){
		this.vehiclesList.forEach((element, index) => {
			if(index1 === element.id) {
				this.vehiclesList.splice(index, 1);
			}
		})
	}

	saveEdit(formObj: any) {
		this.count++;
		formObj.id = this.selectedId;
		formObj.status = formObj.status;
		formObj.prioirty = formObj.prioirty;
		formObj.content = formObj.content;
		let object1 = {"dashboardImage":{
			"id": this.selectedId,
			"organizationId": 0,
			"vehicleId": 1,
			"priority": formObj.priority,
			"content": this.inputFile.name
	 }
	}
	this.formData1.append('input', JSON.stringify(object1));
	this.formData1.append('file', this.inputFile);
	
	this.AdminService.updateDashboardImage(this.formData1).subscribe((result) => {
		
	});
	  
	this.formData1.delete('input');
	this.formData1.delete('file');
	
		let modal = document.getElementById("overlay1");
		modal.style.display = "none";
	}
	closeEdit(){
		let modal1 = document.getElementById("overlay1");
		modal1.style.display = "none";
	}
}
