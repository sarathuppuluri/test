import { Component, OnInit } from "@angular/core";
import {
	CdkDragDrop,
	moveItemInArray,
	transferArrayItem,
} from "@angular/cdk/drag-drop";
import { TerritoryService } from "../territory.service";
import { forkJoin } from "rxjs";
import { isNgTemplate } from "@angular/compiler";
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
	selector: "rural-territory-allocation",
	templateUrl: "./rural-territory-allocation.component.html",
	styleUrls: ["./rural-territory-allocation.component.scss"],
})
export class RuralTerritoryAllocationComponent implements OnInit {
	ruralState;
	ruralDistrict;
  ruralMandal;
  ruralVillage;
  ruralPincode;
  ruralStand;

	ruralTerritories = [];

	ruralStates = [];
	ruralDistricts = [];
  ruralMandals = [];
  ruralVillages = [];
  ruralPincodes = [];
  ruralStands = [];
	ruralMappings = [];
  employees = [];

  loginEmployee: any = JSON.parse(localStorage.getItem('loginEmployee'));
  branchId = this.loginEmployee.branchId;
  orgId = this.loginEmployee.orgId;

	constructor(private territoryService: TerritoryService, private _snackBar: MatSnackBar) {}

  ngOnInit() {
    const rural = this.territoryService.getUrban('rural');
    const ruralMapping = this.territoryService.getMappings('currentruralmappings');
    const employees = this.territoryService.getEmployees();
    forkJoin(rural, ruralMapping, employees).subscribe((res: any) => {
      if (res.length) {
        this.ruralMappings = res[1].territoryMaps;
        this.ruralTerritories = this.assignEmployees(res[0].ruralTerritories);
        this.ruralStates = this.uniqArray(this.ruralTerritories || [], 'stateCode');
        if(res[2].dmsEntity) {
          this.employees = res[2].dmsEntity.employeeDTOPage.content;
        }
      } else {
        this.openSnackBar('Something went wrong', 'Fail');
      }
    });
  }

  public uniqArray(arr, key) {
    return arr.reduce((unique, o) => {
      if (!unique.some(obj => obj[key] === o[key])) {
        unique.push(o);
      }
      return unique;
    }, []);
  }

  public assignEmployees(arr) {
    return arr.map(nrmlArr => {
      return { ...nrmlArr, employees: [] };
    });
  }

  public drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);
    }
  }

  // For Rural Allocation

  onRuralStateChange(state_id: number) {
    this.ruralDistricts = this.uniqArray(this.ruralTerritories.filter((item) => item.stateCode === state_id), 'districtCode');
  }

  onRuralDistrictChange(dist_id: number) {
    this.ruralMandals = this.uniqArray(this.ruralTerritories.filter((item) => item.districtCode === dist_id), 'mandalCode');
  }

  onRuralMandalChange(mandal_id: number) {
    this.ruralVillages = this.uniqArray(this.ruralTerritories.filter((item) => item.mandalCode === mandal_id), 'villageCode');
  }

  onRuralVillageChange(village_id: number) {
    this.ruralPincodes = this.uniqArray(this.ruralTerritories.filter((item) => item.villageCode === village_id), 'pincode');
  }

  onRuralPincodeChange(pincode: number) {
    this.ruralStands = this.uniqArray(this.ruralTerritories.filter((item) => item.pincode === pincode), 'stand');
  }


  public submit() {
    const terr = this.ruralTerritories.filter(rural => rural.employees.length).map(rural => {
      const mappedHir = this.checkHirarchy(rural);
      const emp = rural.employees.map(empl => {
        return {empId: empl.empId, empName:empl.empName};
      })
     return {
        ...rural,
        employees: emp,
        mappedHirarchy: mappedHir.mappedHirarchy,
        mappedHirarchyValue: mappedHir.mappedHirarchyValue
      }
    });
    this.territoryService.saveMappings('ruralmappings', terr).subscribe((res: any )=> {
      if(res.status === 'Success') {
        this.openSnackBar('Records saved Successfully', 'Success');
        this.territoryService.getMappings('currentruralmappings').subscribe((mapping: any)=>{
          this.ruralMappings = mapping.territoryMaps;
        })
      } else {
        this.openSnackBar('Something went wrong', 'Fail');
      }
    })
  }

  private checkHirarchy(rural) {
    const hir = {
      mappedHirarchy: '',
      mappedHirarchyValue: ''
    };
    if(!this.ruralState) {
      hir.mappedHirarchy = 'stateCode';
      hir.mappedHirarchyValue = rural.stateCode
    } else if(!this.ruralDistrict) {
      hir.mappedHirarchy = 'districtCode';
      hir.mappedHirarchyValue = rural.districtCode
    } else if(!this.ruralMandal) {
      hir.mappedHirarchy = 'mandalCode';
      hir.mappedHirarchyValue = rural.mandalCode
    } else if(!this.ruralVillage) {
      hir.mappedHirarchy = 'villageCode';
      hir.mappedHirarchyValue = rural.villageCode
    } else if(!this.ruralPincode) {
      hir.mappedHirarchy = 'pincode';
      hir.mappedHirarchyValue = rural.pincode
    } else if(!this.ruralStand) {
      hir.mappedHirarchy = 'stand';
      hir.mappedHirarchyValue = rural.stand
    }
    return hir;
  }

  public deleteRuralRecords() {
    const deletedTerritories = this.ruralMappings.filter(rural => !!rural.checked).map(rural => {
      const terr =  {employeeIds: [] , territoryId: rural.id};
      rural.employees.map(emp => {
        terr.employeeIds.push(emp.empId);
      });
      return terr;
    });
    if(deletedTerritories.length) {
      this.territoryService.deleteMappings(deletedTerritories, 'deleteruralmappings').subscribe(res => {
        if(res.status === 'Success') {
          this.ruralMappings = this.ruralMappings.filter(rural => !rural.checked);
          this.openSnackBar('Records Deleted Successfully', 'Success');
        } else {
          this.openSnackBar('Something is wrong', 'Fail');
        }
      });
    }
  }

  private openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }

}
