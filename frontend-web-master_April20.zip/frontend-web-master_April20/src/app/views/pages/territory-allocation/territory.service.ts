import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpUtilsService } from '../../../core/_base/crud';
import { environment } from './../../../../environments/environment.base';

@Injectable({
  providedIn: 'root'
})
export class TerritoryService {

  loginEmployee: any = JSON.parse(localStorage.getItem('loginEmployee'));
  branchId = this.loginEmployee.branchId;
  orgId = this.loginEmployee.orgId;
  token = localStorage.getItem('idtoken');
  header = {
    'Content-Type': 'application/json',
    'terri-auth': this.token,
  };
  requestOptions = {
    headers: new HttpHeaders(this.header),
  };
  hostUrl = `${environment.ops}`;

  constructor(public http: HttpClient, private httpUtils: HttpUtilsService) { }

  getUrban(type: string) {
    const url = `${this.hostUrl}/${type}?branchId=${this.branchId}&orgId=${this.orgId}`;
    return this.http.get(url, this.requestOptions);
  }

  getMappings(type: string) {
    const url = `${this.hostUrl}/${type}?branchId=${this.branchId}&orgId=${this.orgId}`;
    return this.http.get(url, this.requestOptions);
  }

  getEmployees() {
    return this.http.get<any>(
		`${environment.sales}/employees/org/${this.orgId}/branch/${this.branchId}`
	);
  }

  deleteMappings(territories, type) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    const body = {
      branchId: this.branchId,
      orgId: this.orgId,
      territoryMaps: territories
    };
    const options = {
      headers: new HttpHeaders(this.header),
      body
    };
    const url = `${this.hostUrl}/${type}`;
    return this.http.delete<any>(url, options);
  }

  saveMappings(type, territories) {
    const url = `${this.hostUrl}/${type}`;
    const requestBody = {
      branchId: this.branchId,
      orgId: this.orgId,
      territoryMaps: territories
    };
    return this.http.post(url, requestBody, this.requestOptions);
  }

}
