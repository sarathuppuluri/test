import { Component, OnInit } from "@angular/core";
import {
	CdkDragDrop,
	moveItemInArray,
	transferArrayItem,
} from "@angular/cdk/drag-drop";
import { TerritoryService } from "../territory.service";
import { forkJoin } from "rxjs";
import { isNgTemplate } from "@angular/compiler";
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
	selector: "urban-territory-allocation",
	templateUrl: "./urban-territory-allocation.component.html",
	styleUrls: ["./urban-territory-allocation.component.scss"],
})
export class UrbanTerritoryAllocationComponent implements OnInit {
	urbanState;
	urbanDistrict;
	urbanArea;
	urbanPincode;

	urbanTerritories = [];

	urbanStates = [];
	urbanDistricts = [];
	urbanAreas = [];
	urbanPincodes = [];
	urbanMappings = [];
	employees = [];

  loginEmployee: any = JSON.parse(localStorage.getItem('loginEmployee'));
  branchId = this.loginEmployee.branchId;
  orgId = this.loginEmployee.orgId;

	constructor(private territoryService: TerritoryService, private _snackBar: MatSnackBar) {}

  ngOnInit() {
    const urban = this.territoryService.getUrban('urban');
    const urbanMapping = this.territoryService.getMappings('currenturbanmappings');
    const employees = this.territoryService.getEmployees();
    forkJoin(urban, urbanMapping, employees).subscribe((res: any) => {
      if (res.length) {
        this.urbanMappings = res[1].territoryMaps;
        this.urbanTerritories = this.assignEmployees(res[0].urbanTerritories);
        this.urbanStates = this.uniqArray(this.urbanTerritories || [], 'stateCode');
        if(res[2].dmsEntity) {
          this.employees = res[2].dmsEntity.employeeDTOPage.content;
        }
      } else {
        this.openSnackBar('Something went wrong', 'Fail');
      }
    });
  }

  public uniqArray(arr, key) {
    return arr.reduce((unique, o) => {
      if (!unique.some(obj => obj[key] === o[key])) {
        unique.push(o);
      }
      return unique;
    }, []);
  }

  public assignEmployees(arr) {
    return arr.map(nrmlArr => {
      return { ...nrmlArr, employees: [] };
    });
  }

  public drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);
    }
  }

  // For Urban Allocation

  onUrbanStateChange(state_id: number) {
    this.urbanDistricts = this.uniqArray(this.urbanTerritories.filter((item) => item.stateCode === state_id), 'districtCode');
  }

  onUrbanDistrictChange(dist_id: number) {
    this.urbanAreas = this.uniqArray(this.urbanTerritories.filter((item) => item.districtCode === dist_id), 'areaCode');
  }

  onUrbanAreaChange(area_id: number) {
    this.urbanPincodes = this.uniqArray(this.urbanTerritories.filter((item) => item.areaCode === area_id), 'pincode');
  }

  public submit() {
    const terr = this.urbanTerritories.filter(urban => urban.employees.length).map(urban => {
      const mappedHir = this.checkHirarchy(urban);
      const emp = urban.employees.map(empl => {
        return {empId: empl.empId, empName:empl.empName};
      })
     return {
        ...urban,
        employees: emp,
        mappedHirarchy: mappedHir.mappedHirarchy,
        mappedHirarchyValue: mappedHir.mappedHirarchyValue
      }
    });
    this.territoryService.saveMappings('urbanmappings', terr).subscribe((res: any) => {
      if(res.status === 'Success') {
        this.openSnackBar('Records saved Successfully', 'Success');
        this.territoryService.getMappings('currenturbanmappings').subscribe((mapping: any) => {
          this.urbanMappings = mapping.territoryMaps;
        })
      } else {
        this.openSnackBar('Something went wrong', 'Fail');
      }
    })
  }

  public checkHirarchy(urban) {
    const hir = {
      mappedHirarchy: '',
      mappedHirarchyValue: ''
    };
    if(!this.urbanState) {
      hir.mappedHirarchy = 'stateCode';
      hir.mappedHirarchyValue = urban.stateCode
    } else if(!this.urbanDistrict) {
      hir.mappedHirarchy = 'districtCode';
      hir.mappedHirarchyValue = urban.districtCode
    } else if(!this.urbanArea) {
      hir.mappedHirarchy = 'areaCode';
      hir.mappedHirarchyValue = urban.areaCode
    } else if(!this.urbanPincode) {
      hir.mappedHirarchy = 'pincode';
      hir.mappedHirarchyValue = urban.pincode
    }
    return hir;
  }

  public deleteUrbanRecords() {
    const deletedTerritories = this.urbanMappings.filter(urban => !!urban.checked).map(urban => {
      const terr =  {employeeIds: [] , territoryId: urban.id};
      urban.employees.map(emp => {
        terr.employeeIds.push(emp.empId);
      });
      return terr;
    });
    if(deletedTerritories.length) {
      this.territoryService.deleteMappings(deletedTerritories, 'deleteurbanmappings').subscribe(res => {
        if(res.status === 'Success') {
          this.urbanMappings = this.urbanMappings.filter(urban => !urban.checked);
          this.openSnackBar('Records Deleted Successfully', 'Success');
        } else {
          this.openSnackBar('Something is wrong', 'Fail');
        }
      });
    }
  }

  private openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }

}
