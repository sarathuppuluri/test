import { Component, OnInit } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { TerritoryService } from './territory.service';

@Component({
  selector: 'kt-territory-allocation',
  templateUrl: './territory-allocation.component.html',
  styleUrls: ['./territory-allocation.component.scss'],
})

export class TerritoryAllocationComponent implements OnInit {

  selectedState = 0;
  selectedDistrict = 0;
  selectedArea = 0;

  districts = [];
  areas = [];
  pincodes = [];

  selectState = 0;
  selectDistrict = 0;
  selectArea = 0;
  selectPincode = 0;

  ruralDistricts = [];
  ruralAreas = [];
  ruralPincodes = [];
  ruralStands = [];


  constructor(private territoryService: TerritoryService) { }

  ngOnInit() {
  }

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);
    }
  }

  // For Urban Allocation

  onSelectState(state_id: number) {
    this.selectedState = state_id;
    this.selectedDistrict = 0;
    this.areas = [];
    this.districts = this.getDistricts.filter((item) => {
      return item.state_id === Number(state_id)
    });
  }

  onSelectDistrict(dist_id: number) {
    this.selectedDistrict = dist_id;
    this.areas = this.getAreas.filter((item) => {
      return item.dist_id === Number(dist_id);
    });
  }

  onSelectArea(area_id: number) {
    this.selectedArea = area_id;
    this.pincodes = this.getPincodes.filter((item) => {
      return item.area_id === Number(area_id);
    });
  }

  // For Rural Allocation

  onSelectedState(state_id: number) {
    this.selectState = state_id;
    this.selectDistrict = 0;
    this.ruralAreas = [];
    this.ruralDistricts = this.getDistricts.filter((item) => {
      return item.state_id === Number(state_id)
    });
  }

  onSelectedDistrict(dist_id: number) {
    this.selectDistrict = dist_id;
    this.ruralAreas = this.getAreas.filter((item) => {
      return item.dist_id === Number(dist_id);
    });
  }

  onSelectedArea(area_id: number) {
    this.selectArea = area_id;
    this.ruralPincodes = this.getPincodes.filter((item) => {
      return item.area_id === Number(area_id);
    });
  }

  onSelectedPincode(pincode_id: number) {
    this.selectPincode - pincode_id;
    this.ruralStands = this.getStands.filter((item) => {
      return item.pincode_id === Number(pincode_id);
    });
  }

  getStates =
    [
      { id: 1, name: 'Telangana', emp: [] },
      { id: 2, name: 'Andhra Pradesh', emp: [] },
      { id: 3, name: 'Karnataka', emp: [] },
      { id: 4, name: 'Tamil Nadu', emp: [] },
      { id: 5, name: 'Kerela', emp: [] },
      { id: 6, name: 'Punjab', emp: [] },
    ];

  getDistricts =
    [
      { id: 1, state_id: 1, name: 'Warngal', emp: [] },
      { id: 2, state_id: 1, name: 'Ranga Reddy', emp: [] },
      { id: 3, state_id: 2, name: 'Krishna', emp: [] },
      { id: 4, state_id: 2, name: 'Prakasham', emp: [] },
      { id: 5, state_id: 3, name: 'Banglore', emp: [] },
      { id: 6, state_id: 4, name: 'Coimbatore', emp: [] },
      { id: 7, state_id: 5, name: 'Kollam', emp: [] },
      { id: 8, state_id: 6, name: 'Jalandar', emp: [] },
    ];

  getAreas =
    [
      { id: 1, dist_id: 1, name: 'HanumaKonda', emp: [] },
      { id: 2, dist_id: 1, name: 'Dharmasagar', emp: [] },
      { id: 3, dist_id: 1, name: 'Kazipet', emp: [] },
      { id: 5, dist_id: 2, name: 'Hyderabad', emp: [] },
      { id: 6, dist_id: 2, name: 'Secunderabad', emp: [] },
      { id: 7, dist_id: 2, name: 'Saidabad', emp: [] },
      { id: 9, dist_id: 3, name: 'Vijyawada', emp: [] },
      { id: 10, dist_id: 3, name: 'Amaravati', emp: [] },
      { id: 11, dist_id: 3, name: 'Krishna Lanka', emp: [] },
      { id: 12, dist_id: 4, name: 'Chirala', emp: [] },
      { id: 13, dist_id: 4, name: 'Kanigiri', emp: [] },
      { id: 13, dist_id: 4, name: 'Ongole', emp: [] },
      { id: 14, dist_id: 5, name: 'Banglore Cant', emp: [] },
      { id: 15, dist_id: 5, name: 'WhiteFeild', emp: [] },
      { id: 16, dist_id: 5, name: 'Madivala', emp: [] },
      { id: 17, dist_id: 6, name: 'Selam', emp: [] },
      { id: 18, dist_id: 6, name: 'Karambakam', emp: [] },
      { id: 19, dist_id: 7, name: 'Vallikavu', emp: [] },
      { id: 20, dist_id: 7, name: 'Ochira', emp: [] },
      { id: 21, dist_id: 8, name: 'Dharamsala', emp: [] },
      { id: 22, dist_id: 8, name: 'LPU College', emp: [] },
    ]

  getPincodes =
    [
      { id: 1, area_id: 1, code: 500001, emp: [] },
      { id: 2, area_id: 2, code: 500002, emp: [] },
      { id: 3, area_id: 3, code: 500003, emp: [] },
      { id: 4, area_id: 4, code: 500004, emp: [] },

      { id: 5, area_id: 5, code: 500005, emp: [] },
      { id: 6, area_id: 6, code: 500006, emp: [] },
      { id: 7, area_id: 7, code: 500007, emp: [] },
      { id: 8, area_id: 8, code: 500008, emp: [] },

      { id: 9, area_id: 9, code: 500009, emp: [] },
      { id: 10, area_id: 10, code: 500010, emp: [] },
      { id: 11, area_id: 11, code: 500011, emp: [] },
      { id: 12, area_id: 12, code: 500012, emp: [] },

      { id: 13, area_id: 13, code: 500013, emp: [] },
      { id: 14, area_id: 14, code: 500014, emp: [] },
      { id: 15, area_id: 15, code: 500015, emp: [] },
      { id: 16, area_id: 16, code: 500016, emp: [] },

      { id: 17, area_id: 17, code: 500017, emp: [] },
      { id: 18, area_id: 18, code: 500018, emp: [] },
      { id: 19, area_id: 19, code: 500019, emp: [] },
      { id: 20, area_id: 20, code: 500020, emp: [] },

      { id: 21, area_id: 21, code: 500021, emp: [] },
      { id: 22, area_id: 22, code: 500022, emp: [] },
      { id: 23, area_id: 22, code: 500023, emp: [] },
      { id: 24, area_id: 22, code: 500024, emp: [] },
      { id: 25, area_id: 22, code: 500025, emp: [] },
    ];

  getStands =
    [
      { id: 1, pincode_id: 1, name: 'Stand01', emp: [] },
      { id: 2, pincode_id: 1, name: 'Stand02', emp: [] },

      { id: 3, pincode_id: 2, name: 'Stand03', emp: [] },
      { id: 4, pincode_id: 3, name: 'Stand04', emp: [] },

      { id: 5, pincode_id: 4, name: 'Stand05', emp: [] },
      { id: 6, pincode_id: 4, name: 'Stand06', emp: [] },

      { id: 7, pincode_id: 5, name: 'Stand07', emp: [] },
      { id: 8, pincode_id: 6, name: 'Stand08', emp: [] },

      { id: 9, pincode_id: 7, name: 'Stand10', emp: [] },
      { id: 10, pincode_id: 7, name: 'Stand11', emp: [] },

      { id: 11, pincode_id: 8, name: 'Stand012', emp: [] },
      { id: 12, pincode_id: 9, name: 'Stand013', emp: [] },

      { id: 13, pincode_id: 10, name: 'Stand014', emp: [] },
      { id: 14, pincode_id: 11, name: 'Stand015', emp: [] },

      { id: 15, pincode_id: 12, name: 'Stand016', emp: [] },
      { id: 16, pincode_id: 12, name: 'Stand017', emp: [] },

      { id: 17, pincode_id: 13, name: 'Stand018', emp: [] },
      { id: 18, pincode_id: 14, name: 'Stand019', emp: [] },

      { id: 19, pincode_id: 15, name: 'Stand20', emp: [] },
      { id: 20, pincode_id: 16, name: 'Stand21', emp: [] },

      { id: 21, pincode_id: 17, name: 'Stand22', emp: [] },
      { id: 22, pincode_id: 17, name: 'Stand23', emp: [] },

      { id: 23, pincode_id: 18, name: 'Stand24', emp: [] },
      { id: 24, pincode_id: 19, name: 'Stand25', emp: [] },

      { id: 25, pincode_id: 20, name: 'Stand26', emp: [] },
      { id: 26, pincode_id: 21, name: 'Stand27', emp: [] },

      { id: 27, pincode_id: 22, name: 'Stand28', emp: [] },
      { id: 28, pincode_id: 22, name: 'Stand29', emp: [] },

      { id: 29, pincode_id: 23, name: 'Stand30', emp: [] },
      { id: 30, pincode_id: 24, name: 'Stand31', emp: [] },

      { id: 31, pincode_id: 25, name: 'Stand32', emp: [] },
      { id: 32, pincode_id: 25, name: 'Stand33', emp: [] },

      { id: 33, pincode_id: 25, name: 'Stand34', emp: [] },
      { id: 34, pincode_id: 25, name: 'Stand35', emp: [] },
    ];

  employees =

    [
      { emp: "Sai" }, { emp: "Kumar" }, { emp: "Krishna" },
      { emp: "Admin" }, { emp: "Joey" }, { emp: "Ross" },
      { emp: "Siva" }, { emp: "Ram" }, { emp: "SaiKiran" },
      { emp: "Venkat" }, { emp: "Kotti" }, { emp: "SaiKrishna" },
    ];

}
