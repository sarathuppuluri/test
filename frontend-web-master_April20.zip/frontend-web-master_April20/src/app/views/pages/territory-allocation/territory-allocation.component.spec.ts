import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TerritoryAllocationComponent } from './territory-allocation.component';

describe('TerritoryAllocationComponent', () => {
  let component: TerritoryAllocationComponent;
  let fixture: ComponentFixture<TerritoryAllocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TerritoryAllocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TerritoryAllocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Yet to implement', () => {
    expect(component).toBeTruthy();
  });
});
