import {
	Component,
	OnInit,
	Injectable,
	ChangeDetectorRef,
} from "@angular/core";
import { DataViewModule } from "primeng-lts/dataview";
import { Router } from "@angular/router";

import { MyRolesService } from "../../../core/e-commerce/_services/myroles.service";
import { Lead360Service } from "../../../core/e-commerce/_services/lead360.service";
import { SelectItem, LazyLoadEvent } from "primeng-lts/api";
import { QueryParamsModel } from "../../../core/_base/crud";
import { Task } from "../../../core/e-commerce/_models/car.model";

@Component({
	selector: "kt-my-task",
	templateUrl: "./my-task.component.html",
	styleUrls: ["./my-task.component.scss"],
})
export class MyTaskComponent implements OnInit {
	[x: string]: any;

	constructor(
		private router: Router,
		private changeDetectorRef: ChangeDetectorRef,
		private myRolesService: MyRolesService,
		private lead360Service: Lead360Service
	) {}
	userName: string;
	userId: number;
	userData: any;
	// selectedTaskObj
	// getMyTasksData:Task[];
	tasks: Task[];
	selectedTask: Task;
	displayTaskDialog: boolean;
	sortOptionsOfTasks: SelectItem[];
	sortTaskKey: string;
	taskSortField: string;
	taskSortOrder: number;

	displayDialog: boolean;
	sortOptions: SelectItem[];
	sortKey: string;
	sortField: string;
	sortOrder: number;

	pageLimit = 10;
	pageNo = 0;
	todayTasks: any = {};
	pendingTasks: any = {};

	myTaskObj: any = {};

	loading = false;

	groupedArray: any = [];

	txtTaskSearch = "";
	txtCustomerSearch = "";
	txtTaskSearchPending = "";
	txtCustomerSearchPending = "";

	second = 1000;
	minute = this.second * 60;
	hour = this.minute * 60;
	day = this.hour * 24;
	month = this.day * 30;
	year = this.day * 365;

	ngOnInit() {
		this.lead360Service.selectedTaskObj = {};
		this.userData = JSON.parse(localStorage.getItem("loginEmployee"));
	}

	getTodaysTasks() {
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.pageNo,
			this.pageSize
		);
		this.myRolesService
			.getAllTodaysTasks(this.userData.empId, queryParams)
			.subscribe((res) => {
				this.todayTasks = res.dmsEntity.myTasks;
				this.changeDetectorRef.detectChanges();
			});
	}

	nextPageTodays(event: LazyLoadEvent) {
		this.pageNo = event.first / event.rows;
		this.pageLimit = event.rows;
		if (this.txtCustomerSearch === "" && this.txtTaskSearch === "") {
			this.getTodaysTasks();
		} else {
			this.getSearchResultsToday();
		}
	}

	getSearchResultsToday() {
		if (this.txtCustomerSearch === "" && this.txtTaskSearch === "") {
			this.getTodaysTasks();
			return;
		}
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.pageNo,
			this.pageSize
		);
		this.myRolesService
			.searchTodaysTasks(
				this.userData.empId,
				this.txtCustomerSearch,
				this.txtTaskSearch,
				queryParams
			)
			.subscribe((res) => {
				this.todayTasks = res.dmsEntity.myTasks;
				this.changeDetectorRef.detectChanges();
			});
	}

	getPendingTasks() {
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.pageNo,
			this.pageSize
		);
		this.myRolesService
			.getAllPendingTasks(this.userData.empId, queryParams)
			.subscribe((res) => {
				this.pendingTasks = res.dmsEntity.myTasks;
				this.changeDetectorRef.detectChanges();
			});
	}

	nextPagePending(event: LazyLoadEvent) {
		this.pageNo = event.first / event.rows;
		this.pageLimit = event.rows;
		if (
			this.txtCustomerSearchPending === "" &&
			this.txtTaskSearchPending === ""
		) {
			this.getPendingTasks();
		} else {
			this.getSearchResultsPending();
		}
	}

	getSearchResultsPending() {
		if (
			this.txtCustomerSearchPending === "" &&
			this.txtTaskSearchPending === ""
		) {
			this.getPendingTasks();
			return;
		}
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.pageNo,
			this.pageSize
		);
		this.myRolesService
			.searchPendingTasks(
				this.userData.empId,
				this.txtCustomerSearchPending,
				this.txtTaskSearchPending,
				queryParams
			)
			.subscribe((res) => {
				this.pendingTasks = res.dmsEntity.myTasks;
				this.changeDetectorRef.detectChanges();
			});
	}

	calculateDays(task) {
		const millisecondsDiff = Date.now() - task.taskCreatedTime;
		const days = Math.round(millisecondsDiff / this.day);
		return days;
	}

	showLead360(event: Event, task) {
		this.lead360Service.selectedTaskObj = task;
		this.router.navigateByUrl("/lead360");
	}

	onTaskSortChange(event) {
		const value = event.value;

		if (value.indexOf("!") === 0) {
			this.taskSortOrder = -1;
			this.taskSortField = value.substring(1, value.length);
		} else {
			this.taskSortOrder = 1;
			this.taskSortField = value;
		}
	}

	onTaskDialogHide() {
		this.selectedTask = null;
	}

	filterByTaskNameAndCustomerName(event: any) {
		if (this.txtTaskSearch != "" && this.myTaskObj.content.length > 0) {
			this.tasks = this.myTaskObj.content.filter((data) => {
				if (this.txtCustomerSearch === "") {
					if (
						data.taskName &&
						data.taskName
							.toLowerCase()
							.indexOf(this.txtTaskSearch.toLowerCase()) !== -1
					) {
						return data;
					}
				} else {
					if (
						data.taskName &&
						data.taskName
							.toLowerCase()
							.indexOf(this.txtTaskSearch.toLowerCase()) !== -1 &&
						data.entityName &&
						data.entityName
							.toLowerCase()
							.indexOf(this.txtCustomerSearch.toLowerCase()) !==
							-1
					) {
						return data;
					}
				}
			});
		} else {
			if (this.txtCustomerSearch === "") {
				this.tasks = this.myTaskObj.content;
			} else {
				this.tasks = this.myTaskObj.content.filter((data) => {
					if (
						data.entityName &&
						data.entityName
							.toLowerCase()
							.indexOf(this.txtCustomerSearch.toLowerCase()) !==
							-1
					) {
						return data;
					}
				});
			}
		}
	}
}
