// Angular
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { FullCalendarModule } from "@fullcalendar/angular";
// Partials
import { PartialsModule } from "../partials/partials.module";
// Pages
import { CoreModule } from "../../core/core.module";
import { ECommerceModule } from "./apps/e-commerce/e-commerce.module";
import { UserManagementModule } from "./user-management/user-management.module";
import { MyTaskComponent } from "./my-task/my-task.component";

import { DataViewModule } from "primeng-lts/dataview";
import { AccordionModule } from "primeng-lts/accordion"; // accordion and accordion tab
import { DropdownModule } from "primeng-lts/dropdown";
import { PanelModule } from "primeng-lts/panel";
import { InputTextModule } from "primeng-lts/inputtext";
import { ButtonModule } from "primeng-lts/button";
import { TableModule } from "primeng-lts/table";
import { DialogModule } from "primeng-lts/dialog";
import { CardModule } from "primeng-lts/card";
import { TabViewModule } from "primeng-lts/tabview";
import { DigitOnlyModule } from "@uiowa/digit-only";
import { RxReactiveFormsModule } from "@rxweb/reactive-form-validators";
// Material   // Imported By Me...
import {
	MatInputModule,
	MatPaginatorModule,
	MatProgressSpinnerModule,
	MatSortModule,
	MatTableModule,
	MatSelectModule,
	MatMenuModule,
	MatProgressBarModule,
	MatButtonModule,
	MatCheckboxModule,
	MatDialogModule,
	MatTabsModule,
	MatNativeDateModule,
	MatCardModule,
	MatRadioModule,
	MatIconModule,
	MatDatepickerModule,
	MatAutocompleteModule,
	MAT_DIALOG_DEFAULT_OPTIONS,
	MatSnackBarModule,
	MatTooltipModule,
	MatExpansionModule,
	MAT_DATE_LOCALE,
} from "@angular/material";
import { DragDropModule } from "@angular/cdk/drag-drop";

import { NgbAlertConfig, NgbModule } from "@ng-bootstrap/ng-bootstrap";
// import { BsDatepickerModule } rom
import { MenuComponent } from "./menu/menu.component";
import { MenuEditComponent } from "./menu/menu-edit/menu-edit.component";
import { EvaluatorComponent } from "./evaluator/evaluator.component";
import { EvaluatorPopUpComponent } from "./lead-360/evaluator-screen/evaluator-popup.component";
import {
	ManagerscreenComponent,
	DialogContent,
} from "./managerscreen/managerscreen.component";
import { CreateEventComponent } from "./event-managment/create-event/create-event.component";
import { EventCalenderComponent } from "./event-managment/event-calender/event-calender.component";
import { DashboardModule } from "./dashboard/dashboard.module";
import { PreviewEventFormComponent } from "./event-managment/preview-event-form/preview-event-form.component";
import { EmployeeAllocationComponent } from "./employee-allocation/employee-allocation.component";
import { AddAlertComponent } from "./admin/add-alert/add-alert.component";
import { AddVehicleComponent } from "./admin/add-vehicle/add-vehicle.component";
import { MyTasksComponent } from "./admin/my-tasks/my-task.component";
import { EmicalculatorComponent } from "./emicalculator/emicalculator.component";
import { DynamicFormModule } from "./lead-360/dynamic-form/dynamic-form.module";
import { CustomMaterialModule } from "../../../../src/app/material.module";
import { PcDialogComponent } from "./lead-360/pc-dialog/pc-dialog.component";
import { CreateTimelineDialog } from "./lead-360/lead360.component";
import { PropertyDocsComponent } from "./admin/property-docs/property-docs.component";
import { TdTestappointmentComponent } from "./lead-360/booking-testdrive/tdappointment.component";
import { DisableControlDirective } from "./test-drive/disable-control.directive";
import { DataBankComponent } from "./data-bank/data-bank.component";
import { TerritoryAllocationComponent } from "./territory-allocation/territory-allocation.component";
import { UrbanTerritoryAllocationComponent } from "./territory-allocation/urban/urban-territory-allocation.component";
import { RuralTerritoryAllocationComponent } from "./territory-allocation/rural/rural-territory-allocation.component";
// Service File
import { TerritoryService } from "./territory-allocation/territory.service";
import {
	PerformanceRepotingComponent,
	CreatePerformanceDialog,
} from "./performance-repoting/performanceRepoting.component";
import { performanceConfirmationDialog } from "./performance-repoting/confirmation-dialog.component";
import { EnquiryReportsComponent } from "./Reports/enquiry-reports/enquiry-reports.component";
import { PrebookingReportsComponent } from "./Reports/prebooking-reports/prebooking-reports.component";
import { BookingReportsrtsComponent } from "./Reports/booking-reportsrts/booking-reportsrts.component";
import { PendingBookingTrackerComponent } from "./pending-booking-tracker/pending-booking-tracker.component";
import { DropAnalysisComponent } from "./drop-analysis/drop-analysis.component";
import { deleteConfirmationDialog } from "./apps/e-commerce/vehicles/accessories/delete-confirmation-dialog.component";

import { B2cTransactionsComponent } from "./b2c-transactions/b2c-transactions.component";
import { IncentivesComponent } from "./Reports/incentives/incentives.component";
import { UsedVehiclesComponent } from "./used-vehicles/used-vehicles.component";
import { VehicleCreateComponent } from "./used-vehicles/vehicle-create/vehicle-create.component";
import { AddWarrantyComponent } from "./apps/e-commerce/vehicles/add-warranty/add-warranty";
import { AddInsuranceAddonComponent } from "./apps/e-commerce/vehicles/add-insurance-addon/add-insurance-addon";

import { IncentivesListComponent } from "./incentives/incentives-list/incentives-list.component";
import { IncentivesEditDialogComponent } from "./incentives/incentives-edit/incentives-edit.dialog.component";
import { CustomerComplaintsEditDialogComponent } from "./customer-complaints/customer-complaints-edit/customer-complaints-edit.dialog.component";
import { CustomerComplaintsListComponent } from "./customer-complaints/customer-complaints-list/customer-complaints-list.component";
import { PredeliveryModule } from "./predelivery/predelivery.module";
import { VerifyDocsEditDialogComponent } from "./lead-360/verify-docs-edit.dialog/verify-docs-edit.dialog.component";
import { EMICalculatorComponent } from "./admin/emi-calculator/emi-calculator.component";
import {
	LatestNewsComponent,
	CreateLatestNewsDialog,
} from "./admin/latest-news/latest-news.component";
import { TaskDelegationComponent } from "./task-delegation/task-delegation.component";
import {
	CreateEventsCampaignsDialog,
	EventsCampaignsComponent,
} from "./admin/events-campaigns/events-campaigns.component";
import {
	CreatePerformanceMappingDialog,
	PerformanceMappingComponent,
} from "./performance-repoting/performance-mapping/performance-mapping.component";
import { AllotmentComponent } from "./allotment/allotment.component";
import { VehicleExchangeComponent } from "./vehicle-exchange/vehicle-exchange.component";
import { FinanceComponent } from "./finance/finance.component";
import { TrainingComponent } from "./training/training.component";

@NgModule({
	declarations: [
		DisableControlDirective,
		PcDialogComponent,
		DialogContent,
		TdTestappointmentComponent,
		CreateTimelineDialog,
		MenuComponent,
		MenuEditComponent,
		CreateEventComponent,
		EventCalenderComponent,
		MyTaskComponent,
		PreviewEventFormComponent,
		EmployeeAllocationComponent,
		EmicalculatorComponent,
		AddAlertComponent,
		AddVehicleComponent,
		ManagerscreenComponent,
		EvaluatorComponent,
		EvaluatorPopUpComponent,
		DataBankComponent,
		TerritoryAllocationComponent,
		UrbanTerritoryAllocationComponent,
		RuralTerritoryAllocationComponent,
		PropertyDocsComponent,
		MyTasksComponent,
		PerformanceRepotingComponent,
		CreatePerformanceDialog,
		performanceConfirmationDialog,
		deleteConfirmationDialog,
		EnquiryReportsComponent,
		PrebookingReportsComponent,
		BookingReportsrtsComponent,
		PendingBookingTrackerComponent,
		DropAnalysisComponent,
		B2cTransactionsComponent,
		IncentivesComponent,
		UsedVehiclesComponent,
		VehicleCreateComponent,
		AddWarrantyComponent,
		AddInsuranceAddonComponent,
		IncentivesEditDialogComponent,
		IncentivesListComponent,
		CustomerComplaintsListComponent,
		CustomerComplaintsEditDialogComponent,
		VerifyDocsEditDialogComponent,
		EMICalculatorComponent,
		LatestNewsComponent,
		CreateLatestNewsDialog,
		TaskDelegationComponent,
		EventsCampaignsComponent,
		CreateEventsCampaignsDialog,
		PerformanceMappingComponent,
		CreatePerformanceMappingDialog,
		AllotmentComponent,
		VehicleExchangeComponent,
		FinanceComponent,
		TrainingComponent,
	],

	exports: [
		CreateTimelineDialog,
		PcDialogComponent,
		DialogContent,
		DisableControlDirective,
		TdTestappointmentComponent,
		PropertyDocsComponent,
		CreateLatestNewsDialog,
		CreateEventsCampaignsDialog,
		CreatePerformanceMappingDialog,
	],

	imports: [
		CommonModule,
		HttpClientModule,
		FormsModule,
		CoreModule,
		PartialsModule,
		NgbModule,
		ECommerceModule,
		UserManagementModule,
		MatExpansionModule,
		MatInputModule,
		MatPaginatorModule,
		MatProgressSpinnerModule,
		MatSortModule,
		MatTableModule,
		MatSelectModule,
		MatMenuModule,
		MatProgressBarModule,
		MatButtonModule,
		MatCheckboxModule,
		MatDialogModule,
		MatTabsModule,
		MatNativeDateModule,
		MatCardModule,
		MatRadioModule,
		MatIconModule,
		MatDatepickerModule,
		MatAutocompleteModule,
		MatSnackBarModule,
		MatTooltipModule,
		DragDropModule,
		ReactiveFormsModule,
		FullCalendarModule,
		ReactiveFormsModule,
		DataViewModule,
		AccordionModule,
		DropdownModule,
		PanelModule,
		InputTextModule,
		ButtonModule,
		TableModule,
		DialogModule,
		CardModule,
		TabViewModule,
		DashboardModule,
		DynamicFormModule,
		MatIconModule,
		MatTabsModule,
		MatCardModule,
		CustomMaterialModule,
		PredeliveryModule,
		DigitOnlyModule,
		RxReactiveFormsModule,
	],
	entryComponents: [
		TdTestappointmentComponent,
		EvaluatorPopUpComponent,
		DialogContent,
		PcDialogComponent,
		CreateTimelineDialog,
		MenuEditComponent,
		PropertyDocsComponent,
		MyTasksComponent,
		PerformanceRepotingComponent,
		CreatePerformanceDialog,
		performanceConfirmationDialog,
		deleteConfirmationDialog,
		IncentivesEditDialogComponent,
		CustomerComplaintsEditDialogComponent,
		VerifyDocsEditDialogComponent,
		CreateLatestNewsDialog,
		CreateEventsCampaignsDialog,
		CreatePerformanceMappingDialog,
	],
	providers: [
		TerritoryService,
		NgbAlertConfig,
		{ provide: MAT_DATE_LOCALE, useValue: "en-GB" },
		{
			provide: MAT_DIALOG_DEFAULT_OPTIONS,
			useValue: {
				hasBackdrop: true,
				panelClass: "kt-mat-dialog-container__wrapper",
				height: "auto",
				width: "900px",
			},
		},
	],
})
export class PagesModule {}
