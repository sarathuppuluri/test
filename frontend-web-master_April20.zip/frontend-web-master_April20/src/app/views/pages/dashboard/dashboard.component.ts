// Angular
import { Component, OnInit } from "@angular/core";

@Component({
	selector: "kt-dashboard",
	templateUrl: "./dashboard.component.html",
	styleUrls: ["dashboard.component.scss"],
})
export class DashboardComponent implements OnInit {
	width: number;
	secondaryWidth: number;

	ngOnInit() {
		this.width = 80;
		this.secondaryWidth = 62;
	}
}
