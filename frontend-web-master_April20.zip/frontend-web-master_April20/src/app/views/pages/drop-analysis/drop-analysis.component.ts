import { Component, OnInit, ChangeDetectorRef } from "@angular/core";
import {
	EnquiryService,
	Lead360Service,
} from "../../../core/e-commerce/_services";
import { QueryParamsModel } from "../../../core/_base/crud";

@Component({
	selector: "kt-drop-analysis",
	templateUrl: "./drop-analysis.component.html",
	styleUrls: ["./drop-analysis.component.scss"],
})
export class DropAnalysisComponent implements OnInit {
	loginEmployee: any;

	isLoading = false;
	message = "";
	page = 0;
	pageSize = 10;

	scope: any = {};
	leadDropList = [];

	dropLeadDetails: any = { dmsLeadDropInfo: {} };

	constructor(
		private enquiryservice: EnquiryService,
		private lead360Service: Lead360Service,
		private changeDetectorRef: ChangeDetectorRef
	) {}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.getLeadDropDetailsList();
	}

	getLeadDropDetailsList() {
		this.isLoading = true;
		this.message = "";
		const queryParams = new QueryParamsModel(
			{},
			"",
			"",
			this.page,
			this.pageSize
		);
		this.enquiryservice
			.getLeadDropDetailsBranchOrg(
				this.loginEmployee.branchId,
				this.loginEmployee.orgId,
				this.loginEmployee.empName,
				queryParams
			)
			.subscribe(
				(res) => {
					if (res.statusCode === "204") {
						this.message = res.message;
						this.isLoading = false;
					} else {
						this.isLoading = false;
						this.scope = res.dmsLeadDropInfos;
						if (this.scope.totalElements === 0) {
							this.message = "No Data Found";
						}
						this.leadDropList = res.dmsLeadDropInfos.content;
					}
					this.changeDetectorRef.detectChanges();
				},
				(error) => {
					this.isLoading = false;
					this.message = "Network Error";
					this.changeDetectorRef.detectChanges();
				}
			);
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.getLeadDropDetailsList();
	}

	approve(lead) {
		this.dropLeadDetails.dmsLeadDropInfo.leadId = lead.leadId;
		this.dropLeadDetails.dmsLeadDropInfo.leadDropId = lead.leadDropId;
		this.dropLeadDetails.dmsLeadDropInfo.status = "APPROVED";
		this.enquiryservice
			.sendDropDetails(this.dropLeadDetails)
			.subscribe((res) => {
				this.getLeadDropDetailsList();
				this.lead360Service
					.fetchTaskByLeadUniversalId(lead.crmUniversalId)
					.subscribe((res) => {
						res.dmsEntity.tasks.forEach((element) => {
							if (
								element.taskStatus === "ASSIGNED" ||
								element.taskStatus === "SENT_FOR_APPROVAL"
							) {
								element.taskStatus =
									element.lastTask === true
										? "CANCELLED"
										: "CLOSED";
								this.lead360Service
									.saveFollowUpActivity(element)
									.subscribe((result: any) => {});
							}
						});
					});
			});
	}

	reject(lead) {
		this.dropLeadDetails.dmsLeadDropInfo.leadId = lead.leadId;
		this.dropLeadDetails.dmsLeadDropInfo.leadDropId = lead.leadDropId;
		this.dropLeadDetails.dmsLeadDropInfo.status = "REJECTED";
		this.enquiryservice
			.sendDropDetails(this.dropLeadDetails)
			.subscribe((res) => {
				this.getLeadDropDetailsList();
				this.lead360Service
					.fetchTaskByLeadUniversalId(lead.crmUniversalId)
					.subscribe((res) => {
						res.dmsEntity.tasks.forEach((element) => {
							if (
								element.taskStatus === "SENT_FOR_APPROVAL" &&
								element.lastTask === true
							) {
								element.taskStatus = "ASSIGNED";
								this.lead360Service
									.saveFollowUpActivity(element)
									.subscribe((result: any) => {});
							}
						});
					});
			});
	}
}
