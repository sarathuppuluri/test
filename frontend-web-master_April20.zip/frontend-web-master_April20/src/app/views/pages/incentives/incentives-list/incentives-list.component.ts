// Angular
import { Component, OnInit, OnDestroy, ChangeDetectorRef } from "@angular/core";
// Material
import { MatSnackBar, MatDialog } from "@angular/material";
// RXJS
import { Subscription } from "rxjs";
// CRUD
import {
	LayoutUtilsService,
	MessageType,
	QueryParamsModel,
} from "../../../../core/_base/crud";
// Translate Module
import { TranslateService } from "@ngx-translate/core";
// Services and Models
import { IncentivesModel } from "../../../../core/e-commerce/_models/incentive.model";
// Components
import { IncentivesEditDialogComponent } from "../incentives-edit/incentives-edit.dialog.component";
import { IncentivesService } from "../../../../core/e-commerce/_services/incentives.service";
import { Router, ActivatedRoute } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
@Component({
	selector: "kt-incentives",
	templateUrl: "./incentives-list.component.html",
	styleUrls: ["./incentives-list.component.scss"],
})
export class IncentivesListComponent implements OnInit, OnDestroy {
	loginEmployee: any;

	page = 0;
	pageSize = 10;
	isLoading = false;
	scope: any = {};

	searchFormGroup: FormGroup;

	// Subscriptions
	private subscriptions: Subscription[] = [];

	tempData = [];
	orgId: any;

	searchProgress = false;
	hasFormErrors: boolean;
	message: string;

	/**
	 * Component constructor
	 *
	 * @param dialog: MatDialog
	 * @param snackBar: MatSnackBar
	 * @param layoutUtilsService: LayoutUtilsService
	 * @param translate: TranslateService
	 */
	constructor(
		public dialog: MatDialog,
		private incentiveService: IncentivesService,
		private translate: TranslateService,
		public snackBar: MatSnackBar,
		private router: Router,
		private changeDetectorRef: ChangeDetectorRef,
		private layoutUtilsService: LayoutUtilsService,
		private routeData: ActivatedRoute,
		private formBuilder: FormBuilder
	) {}

	ngOnInit() {
		this.loginEmployee = JSON.parse(localStorage.getItem("loginEmployee"));
		this.searchForm();
		this.getIncentivesList();
	}

	/**
	 * On Destroy
	 */
	ngOnDestroy() {
		this.subscriptions.forEach((el) => el.unsubscribe());
	}

	/**
	 * Load Incentive List from service
	 */
	getIncentivesList() {
		this.isLoading = true;
		// const queryParams = new QueryParamsModel({}, '', '', this.page, this.pageSize);
		this.incentiveService.getIncentivesList().subscribe(
			(res) => {
				this.isLoading = false;
				// this.scope = res.IncentiveInquiryInfos;
				this.tempData = res.dmsEntity.listIncentiveRules;
				this.changeDetectorRef.detectChanges();
			},
			(error) => {
				console.log("All Data of Incentive error::" + error);
				this.changeDetectorRef.detectChanges();
			},
			() => {}
		);
	}

	paginatorEvents(event) {
		this.page = event.pageIndex;
		this.pageSize = event.pageSize;
		this.getIncentivesList();
	}

	searchForm() {
		this.searchFormGroup = this.formBuilder.group({
			incentiveType: ["", Validators.required],
			segment: ["", Validators.required],
		});
	}

	onSubmit() {
		this.searchProgress = true;
		this.hasFormErrors = false;
		const controls = this.searchFormGroup.controls;
		/** check form */
		if (this.searchFormGroup.invalid) {
			Object.keys(controls).forEach((controlName) =>
				controls[controlName].markAsTouched()
			);

			this.hasFormErrors = true;
			this.searchProgress = false;
			return;
		}
		this.message = "";
		this.incentiveService
			.searchIncentive(
				controls.incentiveType.value,
				controls.segment.value
			)
			.subscribe(
				(res) => {
					this.searchProgress = false;
					if (res.error === true) {
						this.message = res.errorMessage;
						this.changeDetectorRef.detectChanges();
						return;
					}
					if (res.statusCode !== 400 && res.status !== 500) {
						this.tempData = res.dmsEntity.listIncentiveRules;
					} else {
						this.message = res.message;
						this.tempData = [];
					}
					this.changeDetectorRef.detectChanges();
				},
				(error) => {
					this.tempData = [];
					this.changeDetectorRef.detectChanges();
				}
			);
	}

	onReset() {
		this.searchFormGroup.reset();
		this.message = "";
		this.getIncentivesList();
	}

	/**
	 * Checking control validation
	 *
	 * @param controlName: string => Equals to formControlName
	 * @param validationType: string => Equals to valitors name
	 */
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.searchFormGroup.controls[controlName];
		if (!control) {
			return false;
		}

		const result =
			control.hasError(validationType) &&
			(control.dirty || control.touched);
		return result;
	}

	deleteIncentive(element) {
		const _title = "Incentive Delete";
		const _description =
			"Are you sure to permanently delete this Incentive?";
		const _waitDesciption = "Incentive is deleting...";
		const _deleteMessage = "Incentive has been deleted";

		const dialogRef = this.layoutUtilsService.deleteElement(
			_title,
			_description,
			_waitDesciption
		);
		dialogRef.afterClosed().subscribe((res) => {
			if (!res) {
				return;
			}
			this.incentiveService
				.deleteIncentive(Number(element.id))
				.subscribe((IncentiveRes) => {
					if (IncentiveRes.status === 500) {
						this.layoutUtilsService.showActionNotification(
							"There is an Error Deleting Incentive"
						);
						return;
					}
					this.layoutUtilsService.showActionNotification(
						_deleteMessage,
						MessageType.Delete
					);
					this.getIncentivesList();
				});
		});
	}

	/**
	 * Show add vehicle dialog
	 */
	addIncentive() {
		const editIncentive = new IncentivesModel();
		editIncentive.clear(); // Set all defaults fields
		editIncentive.org_id = this.loginEmployee.orgId;
		editIncentive.branch_id = this.loginEmployee.branchId;
		this.editIncentive(editIncentive);
	}

	/**
	 * Show Edit vehicle dialog and save after success close result
	 * @param editIncentive: IncentiveModel
	 */
	editIncentive(editIncentive: IncentivesModel) {
		let saveMessageTranslateParam = "ECOMMERCE.INCENTIVES.EDIT.";
		saveMessageTranslateParam +=
			Number(editIncentive.id) > 0 ? "UPDATE_MESSAGE" : "ADD_MESSAGE";
		const _saveMessage = this.translate.instant(saveMessageTranslateParam);
		const _messageType =
			Number(editIncentive.id) > 0
				? MessageType.Update
				: MessageType.Create;

		const dialogRef = this.dialog.open(IncentivesEditDialogComponent, {
			data: { editIncentive },
		});
		dialogRef.afterClosed().subscribe((res) => {
			if (!res) {
				return;
			}
			if (res.response.status === 500) {
				this.layoutUtilsService.showActionNotification(
					"There is an Error Creating Incentive"
				);
				return;
			}
			this.layoutUtilsService
				.showActionNotification(_saveMessage, _messageType)
				.afterOpened()
				.subscribe((orgRes) => {
					this.getIncentivesList();
				});
		});
	}
}
