// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
	production: false,
	idToken: "idtoken",
	refreshToken: "refreshToken",
	userName: "userName",
	tokenExpiresin: "tokenExpiresin",

	hrms: "/hrms",
	ops: "/ops",
	roleManagement: "/role-management",
	sales: "/sales",
	inventory: "/inventory",
	vehicleServices: "/vehicle-services",
	admin: "/admin",
	notificationServices: "/notification-service",
	vehicleInfoService: "/vehicle-information-service",
	customerService: "/customer-service",
};
