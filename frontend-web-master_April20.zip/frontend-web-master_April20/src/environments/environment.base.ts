export const environment = {

	// TODO: Map to latest backend service names 
	preEnquiryDomain: "https://tv5zkcreeh.execute-api.ap-south-1.amazonaws.com",


	// TODO: Move to backend
	API_PINCODE_URL: "https://api.postalpincode.in/pincode",

	// TODO: This is mapped to Lambda.  This needs to be handled OR triggered from backend
	salesToServices: "https://pm15ypnl9b.execute-api.ap-south-1.amazonaws.com", 

	//New End Points

	hrms: "https://prod.auto-mate.biz/hrms",
	ops: "http://ec2-35-154-250-2.ap-south-1.compute.amazonaws.com:8085/ops",
	roleManagement: "https://prod.auto-mate.biz/role-management",
	sales: "http://ec2-65-1-56-2.ap-south-1.compute.amazonaws.com:8081/sales",
	inventory: "http://ec2-35-154-250-2.ap-south-1.compute.amazonaws.com:8086/inventory",
	vehicleServices: "https://prod.auto-mate.biz/vehicle-services",
	admin: "https://prod.auto-mate.biz/admin",
	notificationServices: "https://prod.auto-mate.biz/notification-service",
	vehicleInfoService: "https://prod.auto-mate.biz/vehicle-information-service",
	customerService: "https://prod.auto-mate.biz/customer-service",

	};
