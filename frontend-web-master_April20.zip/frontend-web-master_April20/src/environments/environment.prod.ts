export const environment = {
	production: true,
	idToken: "idtoken",
	refreshToken: "refreshToken",
	userName: "userName",
	tokenExpiresin: "tokenExpiresin",
};
